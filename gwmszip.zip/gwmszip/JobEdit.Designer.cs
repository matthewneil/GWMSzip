﻿using System;
using System.Windows.Forms;

namespace workshop_orders
{
    partial class JobEdit

    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
      this.components = new System.ComponentModel.Container();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
      this.txtVehicle = new System.Windows.Forms.TextBox();
      this.lblVehicle = new System.Windows.Forms.Label();
      this.lblInsurance = new System.Windows.Forms.Label();
      this.txtAccountNo = new System.Windows.Forms.TextBox();
      this.lblAccountNo = new System.Windows.Forms.Label();
      this.cmbInsurance = new System.Windows.Forms.ComboBox();
      this.txtAccountName = new System.Windows.Forms.TextBox();
      this.lblAccountName = new System.Windows.Forms.Label();
      this.dtpBookDate = new System.Windows.Forms.DateTimePicker();
      this.label27 = new System.Windows.Forms.Label();
      this.dgvItem = new System.Windows.Forms.DataGridView();
      this.JobItemID = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Supplier = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chAltCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Description = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.State = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Delete = new System.Windows.Forms.DataGridViewLinkColumn();
      this.chAction = new System.Windows.Forms.DataGridViewLinkColumn();
      this.cmItems = new System.Windows.Forms.ContextMenuStrip(this.components);
      this.addProductToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.deleteProductToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.productHistoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.moveProductToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.label2 = new System.Windows.Forms.Label();
      this.gbBooking = new System.Windows.Forms.GroupBox();
      this.chkBooking = new System.Windows.Forms.CheckBox();
      this.btnTimeForward = new System.Windows.Forms.Button();
      this.btnTimeBack = new System.Windows.Forms.Button();
      this.dtpBookTime = new System.Windows.Forms.DateTimePicker();
      this.label4 = new System.Windows.Forms.Label();
      this.txtAddress = new System.Windows.Forms.TextBox();
      this.cmbArea = new System.Windows.Forms.ComboBox();
      this.gbInsurance = new System.Windows.Forms.GroupBox();
      this.dataGridView2 = new System.Windows.Forms.DataGridView();
      this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
      this.dataGridViewCheckBoxColumn2 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
      this.label3 = new System.Windows.Forms.Label();
      this.dgvInvoice = new System.Windows.Forms.DataGridView();
      this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.invoiceno = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.date = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.txtNote = new System.Windows.Forms.TextBox();
      this.cmbPayment = new System.Windows.Forms.ComboBox();
      this.cmbType = new System.Windows.Forms.ComboBox();
      this.fbdJobPath = new System.Windows.Forms.FolderBrowserDialog();
      this.dgvFiles = new System.Windows.Forms.DataGridView();
      this.Files = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.toolStrip1 = new System.Windows.Forms.ToolStrip();
      this.tsBack = new System.Windows.Forms.ToolStripButton();
      this.tsSave = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
      this.tsCopy = new System.Windows.Forms.ToolStripButton();
      this.tsCancel = new System.Windows.Forms.ToolStripButton();
      this.tsSep = new System.Windows.Forms.ToolStripSeparator();
      this.tsPrint = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
      this.tsDetails = new System.Windows.Forms.ToolStripButton();
      this.tsJobID = new System.Windows.Forms.ToolStripLabel();
      this.panel1 = new System.Windows.Forms.Panel();
      this.gbPrices = new System.Windows.Forms.GroupBox();
      this.pnlCosts = new System.Windows.Forms.Panel();
      this.lblPricings = new System.Windows.Forms.Label();
      this.panel3 = new System.Windows.Forms.Panel();
      this.label12 = new System.Windows.Forms.Label();
      this.textBox1 = new System.Windows.Forms.TextBox();
      this.textBox2 = new System.Windows.Forms.TextBox();
      this.textBox3 = new System.Windows.Forms.TextBox();
      this.pnlPrice = new System.Windows.Forms.Panel();
      this.label11 = new System.Windows.Forms.Label();
      this.txtItemPrice = new System.Windows.Forms.TextBox();
      this.txtTotalPrice = new System.Windows.Forms.TextBox();
      this.txtLabourPrice = new System.Windows.Forms.TextBox();
      this.panel4 = new System.Windows.Forms.Panel();
      this.label9 = new System.Windows.Forms.Label();
      this.txtItemCost = new System.Windows.Forms.TextBox();
      this.txtTotalCost = new System.Windows.Forms.TextBox();
      this.txtLabourCost = new System.Windows.Forms.TextBox();
      this.panel2 = new System.Windows.Forms.Panel();
      this.label10 = new System.Windows.Forms.Label();
      this.label8 = new System.Windows.Forms.Label();
      this.label7 = new System.Windows.Forms.Label();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.nudIviis = new System.Windows.Forms.NumericUpDown();
      this.nudMilage = new System.Windows.Forms.NumericUpDown();
      this.gbOnsite = new System.Windows.Forms.GroupBox();
      this.label6 = new System.Windows.Forms.Label();
      this.gbDetails = new System.Windows.Forms.GroupBox();
      this.chkMilage = new System.Windows.Forms.CheckBox();
      this.cmbGroup = new System.Windows.Forms.ComboBox();
      this.label1 = new System.Windows.Forms.Label();
      this.label31 = new System.Windows.Forms.Label();
      this.btnVehicle = new System.Windows.Forms.Button();
      this.btnCustomer = new System.Windows.Forms.Button();
      this.JobNameLabel = new System.Windows.Forms.Label();
      this.txtReference = new System.Windows.Forms.TextBox();
      this.txtCustomer = new System.Windows.Forms.TextBox();
      this.label5 = new System.Windows.Forms.Label();
      this.gbNote = new System.Windows.Forms.GroupBox();
      this.txtNote2 = new System.Windows.Forms.TextBox();
      this.tcJob = new System.Windows.Forms.TabControl();
      this.tpItem = new System.Windows.Forms.TabPage();
      this.groupBox3 = new System.Windows.Forms.GroupBox();
      this.panel5 = new System.Windows.Forms.Panel();
      this.groupBox2 = new System.Windows.Forms.GroupBox();
      this.dgvLabour = new System.Windows.Forms.DataGridView();
      this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.gbItems = new System.Windows.Forms.GroupBox();
      this.toolStrip3 = new System.Windows.Forms.ToolStrip();
      this.tsAddProduct = new System.Windows.Forms.ToolStripButton();
      this.tsLabour = new System.Windows.Forms.ToolStripButton();
      this.tpNote = new System.Windows.Forms.TabPage();
      this.tpInvoice = new System.Windows.Forms.TabPage();
      this.toolStrip4 = new System.Windows.Forms.ToolStrip();
      this.tsNewInvoice = new System.Windows.Forms.ToolStripButton();
      this.tpFiles = new System.Windows.Forms.TabPage();
      this.toolStrip2 = new System.Windows.Forms.ToolStrip();
      this.tsOpenFolder = new System.Windows.Forms.ToolStripButton();
      this.timPricings = new System.Windows.Forms.Timer(this.components);
      this.lblStatus = new System.Windows.Forms.Label();
      ((System.ComponentModel.ISupportInitialize)(this.dgvItem)).BeginInit();
      this.cmItems.SuspendLayout();
      this.gbBooking.SuspendLayout();
      this.gbInsurance.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dgvInvoice)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dgvFiles)).BeginInit();
      this.toolStrip1.SuspendLayout();
      this.panel1.SuspendLayout();
      this.gbPrices.SuspendLayout();
      this.pnlCosts.SuspendLayout();
      this.panel3.SuspendLayout();
      this.pnlPrice.SuspendLayout();
      this.panel4.SuspendLayout();
      this.panel2.SuspendLayout();
      this.groupBox1.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.nudIviis)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudMilage)).BeginInit();
      this.gbOnsite.SuspendLayout();
      this.gbDetails.SuspendLayout();
      this.gbNote.SuspendLayout();
      this.tcJob.SuspendLayout();
      this.tpItem.SuspendLayout();
      this.groupBox3.SuspendLayout();
      this.panel5.SuspendLayout();
      this.groupBox2.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgvLabour)).BeginInit();
      this.gbItems.SuspendLayout();
      this.toolStrip3.SuspendLayout();
      this.tpInvoice.SuspendLayout();
      this.toolStrip4.SuspendLayout();
      this.tpFiles.SuspendLayout();
      this.toolStrip2.SuspendLayout();
      this.SuspendLayout();
      // 
      // txtVehicle
      // 
      this.txtVehicle.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
      this.txtVehicle.Cursor = System.Windows.Forms.Cursors.Default;
      this.txtVehicle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtVehicle.Location = new System.Drawing.Point(109, 154);
      this.txtVehicle.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
      this.txtVehicle.MaxLength = 6;
      this.txtVehicle.Name = "txtVehicle";
      this.txtVehicle.ReadOnly = true;
      this.txtVehicle.Size = new System.Drawing.Size(306, 26);
      this.txtVehicle.TabIndex = 1;
      // 
      // lblVehicle
      // 
      this.lblVehicle.AutoSize = true;
      this.lblVehicle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblVehicle.ForeColor = System.Drawing.Color.Black;
      this.lblVehicle.Location = new System.Drawing.Point(24, 157);
      this.lblVehicle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.lblVehicle.Name = "lblVehicle";
      this.lblVehicle.Size = new System.Drawing.Size(65, 20);
      this.lblVehicle.TabIndex = 26;
      this.lblVehicle.Text = "Vehicle:";
      // 
      // lblInsurance
      // 
      this.lblInsurance.AutoSize = true;
      this.lblInsurance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblInsurance.ForeColor = System.Drawing.Color.Black;
      this.lblInsurance.Location = new System.Drawing.Point(61, 26);
      this.lblInsurance.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.lblInsurance.Name = "lblInsurance";
      this.lblInsurance.Size = new System.Drawing.Size(70, 20);
      this.lblInsurance.TabIndex = 26;
      this.lblInsurance.Text = "Provider:";
      // 
      // txtAccountNo
      // 
      this.txtAccountNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtAccountNo.Location = new System.Drawing.Point(135, 88);
      this.txtAccountNo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
      this.txtAccountNo.MaxLength = 45;
      this.txtAccountNo.Name = "txtAccountNo";
      this.txtAccountNo.Size = new System.Drawing.Size(261, 26);
      this.txtAccountNo.TabIndex = 6;
      // 
      // lblAccountNo
      // 
      this.lblAccountNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblAccountNo.ForeColor = System.Drawing.Color.Black;
      this.lblAccountNo.Location = new System.Drawing.Point(7, 92);
      this.lblAccountNo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.lblAccountNo.Name = "lblAccountNo";
      this.lblAccountNo.Size = new System.Drawing.Size(124, 20);
      this.lblAccountNo.TabIndex = 26;
      this.lblAccountNo.Text = "Account No:";
      this.lblAccountNo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // cmbInsurance
      // 
      this.cmbInsurance.DisplayMember = "Value";
      this.cmbInsurance.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.cmbInsurance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbInsurance.ForeColor = System.Drawing.Color.Black;
      this.cmbInsurance.FormattingEnabled = true;
      this.cmbInsurance.Location = new System.Drawing.Point(135, 22);
      this.cmbInsurance.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
      this.cmbInsurance.Name = "cmbInsurance";
      this.cmbInsurance.Size = new System.Drawing.Size(261, 28);
      this.cmbInsurance.TabIndex = 4;
      this.cmbInsurance.ValueMember = "Key";
      // 
      // txtAccountName
      // 
      this.txtAccountName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtAccountName.Location = new System.Drawing.Point(135, 57);
      this.txtAccountName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
      this.txtAccountName.MaxLength = 45;
      this.txtAccountName.Name = "txtAccountName";
      this.txtAccountName.Size = new System.Drawing.Size(261, 26);
      this.txtAccountName.TabIndex = 5;
      this.txtAccountName.TextChanged += new System.EventHandler(this.policyNameText_TextChanged);
      // 
      // lblAccountName
      // 
      this.lblAccountName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblAccountName.ForeColor = System.Drawing.Color.Black;
      this.lblAccountName.Location = new System.Drawing.Point(7, 61);
      this.lblAccountName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.lblAccountName.Name = "lblAccountName";
      this.lblAccountName.Size = new System.Drawing.Size(124, 20);
      this.lblAccountName.TabIndex = 69;
      this.lblAccountName.Text = "Account Name:";
      this.lblAccountName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // dtpBookDate
      // 
      this.dtpBookDate.CustomFormat = " ddd dd MMM yyyy";
      this.dtpBookDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.dtpBookDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
      this.dtpBookDate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
      this.dtpBookDate.Location = new System.Drawing.Point(49, 23);
      this.dtpBookDate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
      this.dtpBookDate.MinDate = new System.DateTime(2020, 1, 1, 0, 0, 0, 0);
      this.dtpBookDate.Name = "dtpBookDate";
      this.dtpBookDate.Size = new System.Drawing.Size(186, 26);
      this.dtpBookDate.TabIndex = 3;
      this.dtpBookDate.Value = new System.DateTime(2020, 6, 29, 13, 1, 44, 0);
      // 
      // label27
      // 
      this.label27.AutoSize = true;
      this.label27.Location = new System.Drawing.Point(498, 176);
      this.label27.Name = "label27";
      this.label27.Size = new System.Drawing.Size(0, 20);
      this.label27.TabIndex = 181;
      // 
      // dgvItem
      // 
      this.dgvItem.AllowUserToAddRows = false;
      this.dgvItem.AllowUserToDeleteRows = false;
      this.dgvItem.AllowUserToOrderColumns = true;
      dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
      this.dgvItem.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
      this.dgvItem.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      this.dgvItem.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvItem.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.JobItemID,
            this.Supplier,
            this.Column2,
            this.Column3,
            this.chAltCode,
            this.Description,
            this.Quantity,
            this.State,
            this.Column9,
            this.Delete,
            this.chAction});
      this.dgvItem.ContextMenuStrip = this.cmItems;
      this.dgvItem.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dgvItem.Location = new System.Drawing.Point(3, 22);
      this.dgvItem.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
      this.dgvItem.MultiSelect = false;
      this.dgvItem.Name = "dgvItem";
      this.dgvItem.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
      this.dgvItem.Size = new System.Drawing.Size(1057, 226);
      this.dgvItem.TabIndex = 185;
      this.dgvItem.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvItem_CellContentClick);
      // 
      // JobItemID
      // 
      this.JobItemID.DataPropertyName = "JobItemID";
      this.JobItemID.HeaderText = "ID";
      this.JobItemID.Name = "JobItemID";
      this.JobItemID.ReadOnly = true;
      this.JobItemID.Visible = false;
      this.JobItemID.Width = 500;
      // 
      // Supplier
      // 
      this.Supplier.HeaderText = "Supplier";
      this.Supplier.Name = "Supplier";
      this.Supplier.ReadOnly = true;
      // 
      // Column2
      // 
      this.Column2.DataPropertyName = "igDescription";
      this.Column2.HeaderText = "Type";
      this.Column2.Name = "Column2";
      this.Column2.ReadOnly = true;
      this.Column2.Width = 200;
      // 
      // Column3
      // 
      this.Column3.DataPropertyName = "icCode";
      this.Column3.HeaderText = "Main Code";
      this.Column3.Name = "Column3";
      this.Column3.ReadOnly = true;
      this.Column3.Width = 250;
      // 
      // chAltCode
      // 
      this.chAltCode.DataPropertyName = "Code";
      this.chAltCode.HeaderText = "Alt Code";
      this.chAltCode.Name = "chAltCode";
      this.chAltCode.ReadOnly = true;
      this.chAltCode.Width = 120;
      // 
      // Description
      // 
      this.Description.DataPropertyName = "icDescription";
      this.Description.HeaderText = "Description";
      this.Description.Name = "Description";
      this.Description.ReadOnly = true;
      this.Description.Width = 500;
      // 
      // Quantity
      // 
      this.Quantity.DataPropertyName = "quantity";
      dataGridViewCellStyle2.NullValue = "1";
      this.Quantity.DefaultCellStyle = dataGridViewCellStyle2;
      this.Quantity.HeaderText = "Qty";
      this.Quantity.Name = "Quantity";
      this.Quantity.ReadOnly = true;
      this.Quantity.Width = 40;
      // 
      // State
      // 
      this.State.DataPropertyName = "StatusName";
      this.State.HeaderText = "Status";
      this.State.Name = "State";
      this.State.ReadOnly = true;
      // 
      // Column9
      // 
      this.Column9.DataPropertyName = "Price";
      dataGridViewCellStyle3.Format = "C2";
      dataGridViewCellStyle3.NullValue = null;
      this.Column9.DefaultCellStyle = dataGridViewCellStyle3;
      this.Column9.HeaderText = "Price";
      this.Column9.Name = "Column9";
      this.Column9.ReadOnly = true;
      this.Column9.Width = 150;
      // 
      // Delete
      // 
      dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
      dataGridViewCellStyle4.NullValue = "Delete";
      this.Delete.DefaultCellStyle = dataGridViewCellStyle4;
      this.Delete.HeaderText = "";
      this.Delete.Name = "Delete";
      this.Delete.Resizable = System.Windows.Forms.DataGridViewTriState.True;
      // 
      // chAction
      // 
      dataGridViewCellStyle5.NullValue = "On Order";
      this.chAction.DefaultCellStyle = dataGridViewCellStyle5;
      this.chAction.HeaderText = "";
      this.chAction.Name = "chAction";
      this.chAction.ReadOnly = true;
      this.chAction.Resizable = System.Windows.Forms.DataGridViewTriState.True;
      this.chAction.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
      this.chAction.Text = "On Order";
      // 
      // cmItems
      // 
      this.cmItems.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addProductToolStripMenuItem,
            this.deleteProductToolStripMenuItem,
            this.productHistoryToolStripMenuItem,
            this.moveProductToolStripMenuItem});
      this.cmItems.Name = "cmItems";
      this.cmItems.Size = new System.Drawing.Size(158, 92);
      // 
      // addProductToolStripMenuItem
      // 
      this.addProductToolStripMenuItem.Name = "addProductToolStripMenuItem";
      this.addProductToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
      this.addProductToolStripMenuItem.Text = "Add Product";
      // 
      // deleteProductToolStripMenuItem
      // 
      this.deleteProductToolStripMenuItem.Name = "deleteProductToolStripMenuItem";
      this.deleteProductToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
      this.deleteProductToolStripMenuItem.Text = "Delete Product";
      // 
      // productHistoryToolStripMenuItem
      // 
      this.productHistoryToolStripMenuItem.Name = "productHistoryToolStripMenuItem";
      this.productHistoryToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
      this.productHistoryToolStripMenuItem.Text = "Product History";
      // 
      // moveProductToolStripMenuItem
      // 
      this.moveProductToolStripMenuItem.Name = "moveProductToolStripMenuItem";
      this.moveProductToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
      this.moveProductToolStripMenuItem.Text = "Move Product";
      this.moveProductToolStripMenuItem.Click += new System.EventHandler(this.moveProductToolStripMenuItem_Click);
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label2.ForeColor = System.Drawing.Color.Black;
      this.label2.Location = new System.Drawing.Point(209, 28);
      this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(65, 20);
      this.label2.TabIndex = 190;
      this.label2.Text = "iViis No:";
      // 
      // gbBooking
      // 
      this.gbBooking.Controls.Add(this.chkBooking);
      this.gbBooking.Controls.Add(this.btnTimeForward);
      this.gbBooking.Controls.Add(this.btnTimeBack);
      this.gbBooking.Controls.Add(this.dtpBookTime);
      this.gbBooking.Controls.Add(this.dtpBookDate);
      this.gbBooking.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbBooking.ForeColor = System.Drawing.Color.Blue;
      this.gbBooking.Location = new System.Drawing.Point(468, 3);
      this.gbBooking.Name = "gbBooking";
      this.gbBooking.Size = new System.Drawing.Size(264, 94);
      this.gbBooking.TabIndex = 193;
      this.gbBooking.TabStop = false;
      this.gbBooking.Text = "Booking";
      // 
      // chkBooking
      // 
      this.chkBooking.AutoSize = true;
      this.chkBooking.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.chkBooking.ForeColor = System.Drawing.Color.Black;
      this.chkBooking.Location = new System.Drawing.Point(27, 29);
      this.chkBooking.Name = "chkBooking";
      this.chkBooking.Size = new System.Drawing.Size(15, 14);
      this.chkBooking.TabIndex = 163;
      this.chkBooking.UseVisualStyleBackColor = true;
      this.chkBooking.CheckedChanged += new System.EventHandler(this.cbNoBooking_CheckedChanged);
      // 
      // btnTimeForward
      // 
      this.btnTimeForward.BackColor = System.Drawing.Color.White;
      this.btnTimeForward.BackgroundImage = global::workshop_orders.Properties.Resources.arrow_next32;
      this.btnTimeForward.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
      this.btnTimeForward.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnTimeForward.ForeColor = System.Drawing.Color.Black;
      this.btnTimeForward.Location = new System.Drawing.Point(188, 55);
      this.btnTimeForward.Name = "btnTimeForward";
      this.btnTimeForward.Size = new System.Drawing.Size(31, 27);
      this.btnTimeForward.TabIndex = 162;
      this.btnTimeForward.UseVisualStyleBackColor = false;
      this.btnTimeForward.Click += new System.EventHandler(this.upButton_Click);
      // 
      // btnTimeBack
      // 
      this.btnTimeBack.BackColor = System.Drawing.Color.White;
      this.btnTimeBack.BackgroundImage = global::workshop_orders.Properties.Resources.arrow_back32;
      this.btnTimeBack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
      this.btnTimeBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnTimeBack.ForeColor = System.Drawing.Color.Black;
      this.btnTimeBack.Location = new System.Drawing.Point(32, 55);
      this.btnTimeBack.Name = "btnTimeBack";
      this.btnTimeBack.Size = new System.Drawing.Size(29, 26);
      this.btnTimeBack.TabIndex = 161;
      this.btnTimeBack.UseVisualStyleBackColor = false;
      this.btnTimeBack.Click += new System.EventHandler(this.downButton_Click);
      // 
      // dtpBookTime
      // 
      this.dtpBookTime.CustomFormat = "hh:mm tt";
      this.dtpBookTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.dtpBookTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
      this.dtpBookTime.Location = new System.Drawing.Point(67, 55);
      this.dtpBookTime.Name = "dtpBookTime";
      this.dtpBookTime.Size = new System.Drawing.Size(115, 26);
      this.dtpBookTime.TabIndex = 160;
      this.dtpBookTime.Value = new System.DateTime(2020, 11, 20, 8, 0, 0, 0);
      // 
      // label4
      // 
      this.label4.AutoSize = true;
      this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label4.ForeColor = System.Drawing.Color.Black;
      this.label4.Location = new System.Drawing.Point(5, 69);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(72, 20);
      this.label4.TabIndex = 158;
      this.label4.Text = "Address:";
      // 
      // txtAddress
      // 
      this.txtAddress.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
      this.txtAddress.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
      this.txtAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtAddress.ForeColor = System.Drawing.Color.Black;
      this.txtAddress.Location = new System.Drawing.Point(77, 67);
      this.txtAddress.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
      this.txtAddress.MaxLength = 50;
      this.txtAddress.Name = "txtAddress";
      this.txtAddress.Size = new System.Drawing.Size(180, 26);
      this.txtAddress.TabIndex = 69;
      // 
      // cmbArea
      // 
      this.cmbArea.DisplayMember = "textfield";
      this.cmbArea.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.cmbArea.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbArea.ForeColor = System.Drawing.Color.Black;
      this.cmbArea.FormattingEnabled = true;
      this.cmbArea.Items.AddRange(new object[] {
            "Gore",
            "Northern Southland",
            "West Otago",
            "Mataura",
            "Edendale",
            "Invercargill"});
      this.cmbArea.Location = new System.Drawing.Point(78, 29);
      this.cmbArea.Name = "cmbArea";
      this.cmbArea.Size = new System.Drawing.Size(180, 28);
      this.cmbArea.TabIndex = 157;
      this.cmbArea.ValueMember = "datafield";
      this.cmbArea.SelectedValueChanged += new System.EventHandler(this.cmbArea_SelectedValueChanged);
      // 
      // gbInsurance
      // 
      this.gbInsurance.Controls.Add(this.dataGridView2);
      this.gbInsurance.Controls.Add(this.lblInsurance);
      this.gbInsurance.Controls.Add(this.txtAccountNo);
      this.gbInsurance.Controls.Add(this.lblAccountNo);
      this.gbInsurance.Controls.Add(this.cmbInsurance);
      this.gbInsurance.Controls.Add(this.txtAccountName);
      this.gbInsurance.Controls.Add(this.lblAccountName);
      this.gbInsurance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbInsurance.ForeColor = System.Drawing.Color.Blue;
      this.gbInsurance.Location = new System.Drawing.Point(738, 4);
      this.gbInsurance.Name = "gbInsurance";
      this.gbInsurance.Size = new System.Drawing.Size(411, 129);
      this.gbInsurance.TabIndex = 195;
      this.gbInsurance.TabStop = false;
      this.gbInsurance.Text = "Insurance";
      // 
      // dataGridView2
      // 
      this.dataGridView2.AllowUserToAddRows = false;
      this.dataGridView2.AllowUserToDeleteRows = false;
      this.dataGridView2.AllowUserToOrderColumns = true;
      this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
      this.dataGridView2.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
      this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewCheckBoxColumn1,
            this.dataGridViewCheckBoxColumn2});
      this.dataGridView2.Location = new System.Drawing.Point(693, 10);
      this.dataGridView2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
      this.dataGridView2.MultiSelect = false;
      this.dataGridView2.Name = "dataGridView2";
      this.dataGridView2.Size = new System.Drawing.Size(527, 206);
      this.dataGridView2.TabIndex = 187;
      // 
      // dataGridViewTextBoxColumn1
      // 
      this.dataGridViewTextBoxColumn1.HeaderText = "PartID";
      this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
      this.dataGridViewTextBoxColumn1.ReadOnly = true;
      this.dataGridViewTextBoxColumn1.Width = 86;
      // 
      // dataGridViewTextBoxColumn2
      // 
      this.dataGridViewTextBoxColumn2.HeaderText = "PartType";
      this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
      this.dataGridViewTextBoxColumn2.ReadOnly = true;
      this.dataGridViewTextBoxColumn2.Width = 105;
      // 
      // dataGridViewTextBoxColumn3
      // 
      this.dataGridViewTextBoxColumn3.HeaderText = "MainCode";
      this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
      this.dataGridViewTextBoxColumn3.ReadOnly = true;
      this.dataGridViewTextBoxColumn3.Width = 114;
      // 
      // dataGridViewTextBoxColumn4
      // 
      this.dataGridViewTextBoxColumn4.HeaderText = "AltCode";
      this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
      this.dataGridViewTextBoxColumn4.ReadOnly = true;
      this.dataGridViewTextBoxColumn4.Width = 98;
      // 
      // dataGridViewTextBoxColumn5
      // 
      this.dataGridViewTextBoxColumn5.HeaderText = "NagCode";
      this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
      this.dataGridViewTextBoxColumn5.ReadOnly = true;
      this.dataGridViewTextBoxColumn5.Width = 108;
      // 
      // dataGridViewTextBoxColumn6
      // 
      this.dataGridViewTextBoxColumn6.HeaderText = "In-Stock";
      this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
      this.dataGridViewTextBoxColumn6.ReadOnly = true;
      this.dataGridViewTextBoxColumn6.Width = 102;
      // 
      // dataGridViewTextBoxColumn7
      // 
      this.dataGridViewTextBoxColumn7.HeaderText = "State";
      this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
      this.dataGridViewTextBoxColumn7.Width = 78;
      // 
      // dataGridViewTextBoxColumn8
      // 
      this.dataGridViewTextBoxColumn8.HeaderText = "BuyPrice";
      this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
      this.dataGridViewTextBoxColumn8.Width = 104;
      // 
      // dataGridViewCheckBoxColumn1
      // 
      this.dataGridViewCheckBoxColumn1.FalseValue = "F";
      this.dataGridViewCheckBoxColumn1.HeaderText = "AutoAllocate?";
      this.dataGridViewCheckBoxColumn1.Name = "dataGridViewCheckBoxColumn1";
      this.dataGridViewCheckBoxColumn1.TrueValue = "T";
      this.dataGridViewCheckBoxColumn1.Width = 128;
      // 
      // dataGridViewCheckBoxColumn2
      // 
      this.dataGridViewCheckBoxColumn2.FalseValue = "F";
      this.dataGridViewCheckBoxColumn2.HeaderText = "Delete?";
      this.dataGridViewCheckBoxColumn2.Name = "dataGridViewCheckBoxColumn2";
      this.dataGridViewCheckBoxColumn2.TrueValue = "T";
      this.dataGridViewCheckBoxColumn2.Width = 78;
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label3.ForeColor = System.Drawing.Color.Black;
      this.label3.Location = new System.Drawing.Point(7, 28);
      this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(68, 20);
      this.label3.TabIndex = 192;
      this.label3.Text = "Mileage:";
      // 
      // dgvInvoice
      // 
      this.dgvInvoice.AllowUserToAddRows = false;
      this.dgvInvoice.AllowUserToDeleteRows = false;
      dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
      this.dgvInvoice.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
      this.dgvInvoice.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      this.dgvInvoice.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvInvoice.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.invoiceno,
            this.amount,
            this.date});
      this.dgvInvoice.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dgvInvoice.Location = new System.Drawing.Point(3, 42);
      this.dgvInvoice.MultiSelect = false;
      this.dgvInvoice.Name = "dgvInvoice";
      this.dgvInvoice.ReadOnly = true;
      this.dgvInvoice.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
      this.dgvInvoice.Size = new System.Drawing.Size(1878, 737);
      this.dgvInvoice.TabIndex = 191;
      this.dgvInvoice.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.invoiceDataGrid_CellDoubleClick);
      // 
      // ID
      // 
      this.ID.DataPropertyName = "InvoiceID";
      this.ID.HeaderText = "ID";
      this.ID.Name = "ID";
      this.ID.ReadOnly = true;
      this.ID.Visible = false;
      // 
      // invoiceno
      // 
      this.invoiceno.DataPropertyName = "invNo";
      this.invoiceno.HeaderText = "Invoice No";
      this.invoiceno.Name = "invoiceno";
      this.invoiceno.ReadOnly = true;
      this.invoiceno.Width = 120;
      // 
      // amount
      // 
      this.amount.DataPropertyName = "invPrice";
      this.amount.FillWeight = 150F;
      this.amount.HeaderText = "Amount";
      this.amount.Name = "amount";
      this.amount.ReadOnly = true;
      this.amount.Width = 150;
      // 
      // date
      // 
      this.date.DataPropertyName = "invDate";
      this.date.HeaderText = "Date";
      this.date.Name = "date";
      this.date.ReadOnly = true;
      this.date.Width = 200;
      // 
      // txtNote
      // 
      this.txtNote.AcceptsReturn = true;
      this.txtNote.Dock = System.Windows.Forms.DockStyle.Fill;
      this.txtNote.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtNote.Location = new System.Drawing.Point(3, 22);
      this.txtNote.MaxLength = 5000;
      this.txtNote.Multiline = true;
      this.txtNote.Name = "txtNote";
      this.txtNote.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
      this.txtNote.Size = new System.Drawing.Size(809, 712);
      this.txtNote.TabIndex = 210;
      this.txtNote.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtNote_KeyDown);
      // 
      // cmbPayment
      // 
      this.cmbPayment.DisplayMember = "textfield";
      this.cmbPayment.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.cmbPayment.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbPayment.FormattingEnabled = true;
      this.cmbPayment.Location = new System.Drawing.Point(109, 120);
      this.cmbPayment.Name = "cmbPayment";
      this.cmbPayment.Size = new System.Drawing.Size(177, 28);
      this.cmbPayment.TabIndex = 209;
      this.cmbPayment.ValueMember = "datafield";
      this.cmbPayment.SelectedIndexChanged += new System.EventHandler(this.cmbPayment_SelectedIndexChanged);
      // 
      // cmbType
      // 
      this.cmbType.DisplayMember = "textfield";
      this.cmbType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.cmbType.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbType.FormattingEnabled = true;
      this.cmbType.Location = new System.Drawing.Point(223, 87);
      this.cmbType.Name = "cmbType";
      this.cmbType.Size = new System.Drawing.Size(197, 28);
      this.cmbType.TabIndex = 206;
      this.cmbType.ValueMember = "datafield";
      // 
      // fbdJobPath
      // 
      this.fbdJobPath.SelectedPath = "\\\\DATABASE\\GWGFILES\\BMS\\JobFolders";
      // 
      // dgvFiles
      // 
      this.dgvFiles.AllowUserToAddRows = false;
      this.dgvFiles.AllowUserToDeleteRows = false;
      dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
      this.dgvFiles.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
      this.dgvFiles.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      this.dgvFiles.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvFiles.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Files});
      this.dgvFiles.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dgvFiles.Location = new System.Drawing.Point(3, 40);
      this.dgvFiles.Name = "dgvFiles";
      this.dgvFiles.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
      this.dgvFiles.Size = new System.Drawing.Size(1878, 739);
      this.dgvFiles.TabIndex = 203;
      this.dgvFiles.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellDoubleClick);
      // 
      // Files
      // 
      this.Files.HeaderText = "Files";
      this.Files.Name = "Files";
      this.Files.ReadOnly = true;
      this.Files.Width = 900;
      // 
      // toolStrip1
      // 
      this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsBack,
            this.tsSave,
            this.toolStripSeparator2,
            this.tsCopy,
            this.tsCancel,
            this.tsSep,
            this.tsPrint,
            this.toolStripSeparator1,
            this.tsDetails,
            this.tsJobID});
      this.toolStrip1.Location = new System.Drawing.Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new System.Drawing.Size(1892, 39);
      this.toolStrip1.TabIndex = 207;
      this.toolStrip1.Text = "toolStrip1";
      this.toolStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.toolStrip1_ItemClicked);
      // 
      // tsBack
      // 
      this.tsBack.Image = global::workshop_orders.Properties.Resources.back;
      this.tsBack.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsBack.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsBack.Name = "tsBack";
      this.tsBack.Size = new System.Drawing.Size(68, 36);
      this.tsBack.Text = "Back";
      this.tsBack.Click += new System.EventHandler(this.tsBack_Click);
      // 
      // tsSave
      // 
      this.tsSave.Image = global::workshop_orders.Properties.Resources.save;
      this.tsSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsSave.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsSave.Name = "tsSave";
      this.tsSave.Size = new System.Drawing.Size(67, 36);
      this.tsSave.Text = "Save";
      this.tsSave.Click += new System.EventHandler(this.tsSave_Click);
      // 
      // toolStripSeparator2
      // 
      this.toolStripSeparator2.Name = "toolStripSeparator2";
      this.toolStripSeparator2.Size = new System.Drawing.Size(6, 39);
      // 
      // tsCopy
      // 
      this.tsCopy.Image = global::workshop_orders.Properties.Resources.copy32;
      this.tsCopy.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsCopy.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsCopy.Name = "tsCopy";
      this.tsCopy.Size = new System.Drawing.Size(71, 36);
      this.tsCopy.Text = "Copy";
      this.tsCopy.Click += new System.EventHandler(this.tsCopy_Click);
      // 
      // tsCancel
      // 
      this.tsCancel.Image = global::workshop_orders.Properties.Resources.cancel32;
      this.tsCancel.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsCancel.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsCancel.Name = "tsCancel";
      this.tsCancel.Size = new System.Drawing.Size(46, 36);
      this.tsCancel.Text = " ";
      this.tsCancel.Visible = false;
      this.tsCancel.Click += new System.EventHandler(this.tsCancel_Click);
      // 
      // tsSep
      // 
      this.tsSep.Name = "tsSep";
      this.tsSep.Size = new System.Drawing.Size(6, 39);
      // 
      // tsPrint
      // 
      this.tsPrint.Image = global::workshop_orders.Properties.Resources.preview;
      this.tsPrint.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsPrint.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsPrint.Name = "tsPrint";
      this.tsPrint.Size = new System.Drawing.Size(68, 36);
      this.tsPrint.Text = "Print";
      this.tsPrint.Click += new System.EventHandler(this.tsPrint_Click);
      // 
      // toolStripSeparator1
      // 
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
      // 
      // tsDetails
      // 
      this.tsDetails.Image = global::workshop_orders.Properties.Resources.note_add32;
      this.tsDetails.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsDetails.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsDetails.Name = "tsDetails";
      this.tsDetails.Size = new System.Drawing.Size(136, 36);
      this.tsDetails.Text = "Additional Details";
      this.tsDetails.Click += new System.EventHandler(this.tsDetails_Click);
      // 
      // tsJobID
      // 
      this.tsJobID.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
      this.tsJobID.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.tsJobID.Name = "tsJobID";
      this.tsJobID.Size = new System.Drawing.Size(34, 36);
      this.tsJobID.Text = "Job";
      this.tsJobID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // panel1
      // 
      this.panel1.AutoSize = true;
      this.panel1.Controls.Add(this.gbPrices);
      this.panel1.Controls.Add(this.groupBox1);
      this.panel1.Controls.Add(this.gbOnsite);
      this.panel1.Controls.Add(this.gbDetails);
      this.panel1.Controls.Add(this.gbInsurance);
      this.panel1.Controls.Add(this.gbBooking);
      this.panel1.Controls.Add(this.gbNote);
      this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
      this.panel1.ForeColor = System.Drawing.Color.Black;
      this.panel1.Location = new System.Drawing.Point(0, 39);
      this.panel1.Name = "panel1";
      this.panel1.Size = new System.Drawing.Size(1892, 207);
      this.panel1.TabIndex = 208;
      // 
      // gbPrices
      // 
      this.gbPrices.Controls.Add(this.pnlCosts);
      this.gbPrices.Controls.Add(this.panel3);
      this.gbPrices.Controls.Add(this.pnlPrice);
      this.gbPrices.Controls.Add(this.panel4);
      this.gbPrices.Controls.Add(this.panel2);
      this.gbPrices.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbPrices.ForeColor = System.Drawing.Color.Blue;
      this.gbPrices.Location = new System.Drawing.Point(1155, 4);
      this.gbPrices.Name = "gbPrices";
      this.gbPrices.Size = new System.Drawing.Size(574, 200);
      this.gbPrices.TabIndex = 203;
      this.gbPrices.TabStop = false;
      this.gbPrices.Text = "Prices";
      // 
      // pnlCosts
      // 
      this.pnlCosts.BackColor = System.Drawing.Color.Silver;
      this.pnlCosts.Controls.Add(this.lblPricings);
      this.pnlCosts.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.pnlCosts.Location = new System.Drawing.Point(3, 18);
      this.pnlCosts.Name = "pnlCosts";
      this.pnlCosts.Size = new System.Drawing.Size(568, 179);
      this.pnlCosts.TabIndex = 204;
      this.pnlCosts.Click += new System.EventHandler(this.pnlCosts_Click);
      // 
      // lblPricings
      // 
      this.lblPricings.AutoSize = true;
      this.lblPricings.ForeColor = System.Drawing.Color.Black;
      this.lblPricings.Location = new System.Drawing.Point(146, 78);
      this.lblPricings.Name = "lblPricings";
      this.lblPricings.Size = new System.Drawing.Size(270, 24);
      this.lblPricings.TabIndex = 0;
      this.lblPricings.Text = "Click here to display Job Prices";
      this.lblPricings.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      this.lblPricings.Click += new System.EventHandler(this.lblPricings_Click);
      // 
      // panel3
      // 
      this.panel3.BackColor = System.Drawing.Color.LightGray;
      this.panel3.Controls.Add(this.label12);
      this.panel3.Controls.Add(this.textBox1);
      this.panel3.Controls.Add(this.textBox2);
      this.panel3.Controls.Add(this.textBox3);
      this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
      this.panel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.panel3.ForeColor = System.Drawing.Color.Black;
      this.panel3.Location = new System.Drawing.Point(398, 22);
      this.panel3.Name = "panel3";
      this.panel3.Size = new System.Drawing.Size(173, 175);
      this.panel3.TabIndex = 216;
      // 
      // label12
      // 
      this.label12.AutoSize = true;
      this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label12.ForeColor = System.Drawing.Color.Blue;
      this.label12.Location = new System.Drawing.Point(6, 6);
      this.label12.Name = "label12";
      this.label12.Size = new System.Drawing.Size(111, 20);
      this.label12.TabIndex = 210;
      this.label12.Text = "Invoice Price";
      // 
      // textBox1
      // 
      this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.textBox1.ForeColor = System.Drawing.Color.Black;
      this.textBox1.Location = new System.Drawing.Point(6, 32);
      this.textBox1.Name = "textBox1";
      this.textBox1.ReadOnly = true;
      this.textBox1.Size = new System.Drawing.Size(138, 26);
      this.textBox1.TabIndex = 212;
      this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
      // 
      // textBox2
      // 
      this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.textBox2.ForeColor = System.Drawing.Color.Black;
      this.textBox2.Location = new System.Drawing.Point(6, 111);
      this.textBox2.Name = "textBox2";
      this.textBox2.ReadOnly = true;
      this.textBox2.Size = new System.Drawing.Size(138, 26);
      this.textBox2.TabIndex = 206;
      this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
      // 
      // textBox3
      // 
      this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.textBox3.ForeColor = System.Drawing.Color.Black;
      this.textBox3.Location = new System.Drawing.Point(6, 64);
      this.textBox3.Name = "textBox3";
      this.textBox3.ReadOnly = true;
      this.textBox3.Size = new System.Drawing.Size(138, 26);
      this.textBox3.TabIndex = 209;
      this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
      // 
      // pnlPrice
      // 
      this.pnlPrice.BackColor = System.Drawing.Color.Silver;
      this.pnlPrice.Controls.Add(this.label11);
      this.pnlPrice.Controls.Add(this.txtItemPrice);
      this.pnlPrice.Controls.Add(this.txtTotalPrice);
      this.pnlPrice.Controls.Add(this.txtLabourPrice);
      this.pnlPrice.Dock = System.Windows.Forms.DockStyle.Left;
      this.pnlPrice.Location = new System.Drawing.Point(236, 22);
      this.pnlPrice.Name = "pnlPrice";
      this.pnlPrice.Size = new System.Drawing.Size(162, 175);
      this.pnlPrice.TabIndex = 214;
      // 
      // label11
      // 
      this.label11.AutoSize = true;
      this.label11.Location = new System.Drawing.Point(6, 5);
      this.label11.Name = "label11";
      this.label11.Size = new System.Drawing.Size(49, 20);
      this.label11.TabIndex = 213;
      this.label11.Text = "Price";
      // 
      // txtItemPrice
      // 
      this.txtItemPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtItemPrice.ForeColor = System.Drawing.Color.Black;
      this.txtItemPrice.Location = new System.Drawing.Point(6, 31);
      this.txtItemPrice.Name = "txtItemPrice";
      this.txtItemPrice.ReadOnly = true;
      this.txtItemPrice.Size = new System.Drawing.Size(138, 26);
      this.txtItemPrice.TabIndex = 215;
      this.txtItemPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
      // 
      // txtTotalPrice
      // 
      this.txtTotalPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtTotalPrice.ForeColor = System.Drawing.Color.Black;
      this.txtTotalPrice.Location = new System.Drawing.Point(6, 110);
      this.txtTotalPrice.Name = "txtTotalPrice";
      this.txtTotalPrice.ReadOnly = true;
      this.txtTotalPrice.Size = new System.Drawing.Size(138, 26);
      this.txtTotalPrice.TabIndex = 213;
      this.txtTotalPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
      // 
      // txtLabourPrice
      // 
      this.txtLabourPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtLabourPrice.ForeColor = System.Drawing.Color.Black;
      this.txtLabourPrice.Location = new System.Drawing.Point(6, 64);
      this.txtLabourPrice.Name = "txtLabourPrice";
      this.txtLabourPrice.ReadOnly = true;
      this.txtLabourPrice.Size = new System.Drawing.Size(138, 26);
      this.txtLabourPrice.TabIndex = 214;
      this.txtLabourPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
      // 
      // panel4
      // 
      this.panel4.BackColor = System.Drawing.Color.LightGray;
      this.panel4.Controls.Add(this.label9);
      this.panel4.Controls.Add(this.txtItemCost);
      this.panel4.Controls.Add(this.txtTotalCost);
      this.panel4.Controls.Add(this.txtLabourCost);
      this.panel4.Dock = System.Windows.Forms.DockStyle.Left;
      this.panel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.panel4.ForeColor = System.Drawing.Color.Black;
      this.panel4.Location = new System.Drawing.Point(84, 22);
      this.panel4.Name = "panel4";
      this.panel4.Size = new System.Drawing.Size(152, 175);
      this.panel4.TabIndex = 215;
      // 
      // label9
      // 
      this.label9.AutoSize = true;
      this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label9.ForeColor = System.Drawing.Color.Blue;
      this.label9.Location = new System.Drawing.Point(6, 6);
      this.label9.Name = "label9";
      this.label9.Size = new System.Drawing.Size(46, 20);
      this.label9.TabIndex = 210;
      this.label9.Text = "Cost";
      // 
      // txtItemCost
      // 
      this.txtItemCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtItemCost.ForeColor = System.Drawing.Color.Black;
      this.txtItemCost.Location = new System.Drawing.Point(6, 32);
      this.txtItemCost.Name = "txtItemCost";
      this.txtItemCost.ReadOnly = true;
      this.txtItemCost.Size = new System.Drawing.Size(138, 26);
      this.txtItemCost.TabIndex = 212;
      this.txtItemCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
      // 
      // txtTotalCost
      // 
      this.txtTotalCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtTotalCost.ForeColor = System.Drawing.Color.Black;
      this.txtTotalCost.Location = new System.Drawing.Point(6, 111);
      this.txtTotalCost.Name = "txtTotalCost";
      this.txtTotalCost.ReadOnly = true;
      this.txtTotalCost.Size = new System.Drawing.Size(138, 26);
      this.txtTotalCost.TabIndex = 206;
      this.txtTotalCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
      this.txtTotalCost.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
      // 
      // txtLabourCost
      // 
      this.txtLabourCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtLabourCost.ForeColor = System.Drawing.Color.Black;
      this.txtLabourCost.Location = new System.Drawing.Point(6, 64);
      this.txtLabourCost.Name = "txtLabourCost";
      this.txtLabourCost.ReadOnly = true;
      this.txtLabourCost.Size = new System.Drawing.Size(138, 26);
      this.txtLabourCost.TabIndex = 209;
      this.txtLabourCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
      // 
      // panel2
      // 
      this.panel2.BackColor = System.Drawing.Color.White;
      this.panel2.Controls.Add(this.label10);
      this.panel2.Controls.Add(this.label8);
      this.panel2.Controls.Add(this.label7);
      this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
      this.panel2.Location = new System.Drawing.Point(3, 22);
      this.panel2.Name = "panel2";
      this.panel2.Size = new System.Drawing.Size(81, 175);
      this.panel2.TabIndex = 213;
      // 
      // label10
      // 
      this.label10.AutoSize = true;
      this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label10.ForeColor = System.Drawing.Color.Black;
      this.label10.Location = new System.Drawing.Point(18, 33);
      this.label10.Name = "label10";
      this.label10.Size = new System.Drawing.Size(59, 20);
      this.label10.TabIndex = 211;
      this.label10.Text = "Items:";
      // 
      // label8
      // 
      this.label8.AutoSize = true;
      this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label8.ForeColor = System.Drawing.Color.Black;
      this.label8.Location = new System.Drawing.Point(7, 62);
      this.label8.Name = "label8";
      this.label8.Size = new System.Drawing.Size(70, 20);
      this.label8.TabIndex = 208;
      this.label8.Text = "Labour:";
      // 
      // label7
      // 
      this.label7.AutoSize = true;
      this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label7.ForeColor = System.Drawing.Color.Black;
      this.label7.Location = new System.Drawing.Point(23, 111);
      this.label7.Name = "label7";
      this.label7.Size = new System.Drawing.Size(54, 20);
      this.label7.TabIndex = 205;
      this.label7.Text = "Total:";
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.Add(this.nudIviis);
      this.groupBox1.Controls.Add(this.nudMilage);
      this.groupBox1.Controls.Add(this.label3);
      this.groupBox1.Controls.Add(this.label2);
      this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.groupBox1.ForeColor = System.Drawing.Color.Blue;
      this.groupBox1.Location = new System.Drawing.Point(738, 137);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(411, 67);
      this.groupBox1.TabIndex = 202;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Extra Data";
      // 
      // nudIviis
      // 
      this.nudIviis.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.nudIviis.Location = new System.Drawing.Point(276, 26);
      this.nudIviis.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
      this.nudIviis.Name = "nudIviis";
      this.nudIviis.Size = new System.Drawing.Size(120, 26);
      this.nudIviis.TabIndex = 194;
      // 
      // nudMilage
      // 
      this.nudMilage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.nudMilage.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
      this.nudMilage.Location = new System.Drawing.Point(80, 26);
      this.nudMilage.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
      this.nudMilage.Name = "nudMilage";
      this.nudMilage.Size = new System.Drawing.Size(120, 26);
      this.nudMilage.TabIndex = 193;
      // 
      // gbOnsite
      // 
      this.gbOnsite.Controls.Add(this.label6);
      this.gbOnsite.Controls.Add(this.cmbArea);
      this.gbOnsite.Controls.Add(this.txtAddress);
      this.gbOnsite.Controls.Add(this.label4);
      this.gbOnsite.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbOnsite.ForeColor = System.Drawing.Color.Blue;
      this.gbOnsite.Location = new System.Drawing.Point(468, 100);
      this.gbOnsite.Name = "gbOnsite";
      this.gbOnsite.Size = new System.Drawing.Size(264, 104);
      this.gbOnsite.TabIndex = 201;
      this.gbOnsite.TabStop = false;
      this.gbOnsite.Text = "Onsite";
      // 
      // label6
      // 
      this.label6.AutoSize = true;
      this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label6.ForeColor = System.Drawing.Color.Black;
      this.label6.Location = new System.Drawing.Point(26, 33);
      this.label6.Name = "label6";
      this.label6.Size = new System.Drawing.Size(47, 20);
      this.label6.TabIndex = 159;
      this.label6.Text = "Area:";
      // 
      // gbDetails
      // 
      this.gbDetails.Controls.Add(this.chkMilage);
      this.gbDetails.Controls.Add(this.cmbGroup);
      this.gbDetails.Controls.Add(this.txtVehicle);
      this.gbDetails.Controls.Add(this.label1);
      this.gbDetails.Controls.Add(this.cmbPayment);
      this.gbDetails.Controls.Add(this.lblVehicle);
      this.gbDetails.Controls.Add(this.label31);
      this.gbDetails.Controls.Add(this.btnVehicle);
      this.gbDetails.Controls.Add(this.cmbType);
      this.gbDetails.Controls.Add(this.btnCustomer);
      this.gbDetails.Controls.Add(this.JobNameLabel);
      this.gbDetails.Controls.Add(this.txtReference);
      this.gbDetails.Controls.Add(this.txtCustomer);
      this.gbDetails.Controls.Add(this.label5);
      this.gbDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbDetails.ForeColor = System.Drawing.Color.Blue;
      this.gbDetails.Location = new System.Drawing.Point(4, 3);
      this.gbDetails.Name = "gbDetails";
      this.gbDetails.Size = new System.Drawing.Size(458, 201);
      this.gbDetails.TabIndex = 200;
      this.gbDetails.TabStop = false;
      this.gbDetails.Text = "Details";
      // 
      // chkMilage
      // 
      this.chkMilage.AutoSize = true;
      this.chkMilage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.chkMilage.ForeColor = System.Drawing.Color.Black;
      this.chkMilage.Location = new System.Drawing.Point(300, 122);
      this.chkMilage.Name = "chkMilage";
      this.chkMilage.Size = new System.Drawing.Size(152, 24);
      this.chkMilage.TabIndex = 212;
      this.chkMilage.Text = "Mileage Required";
      this.chkMilage.UseVisualStyleBackColor = true;
      // 
      // cmbGroup
      // 
      this.cmbGroup.DisplayMember = "textfield";
      this.cmbGroup.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.cmbGroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbGroup.FormattingEnabled = true;
      this.cmbGroup.Items.AddRange(new object[] {
            "Auto",
            "Glass"});
      this.cmbGroup.Location = new System.Drawing.Point(109, 87);
      this.cmbGroup.Name = "cmbGroup";
      this.cmbGroup.Size = new System.Drawing.Size(108, 28);
      this.cmbGroup.TabIndex = 211;
      this.cmbGroup.ValueMember = "datafield";
      this.cmbGroup.SelectedIndexChanged += new System.EventHandler(this.cmbGroup_SelectedIndexChanged);
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
      this.label1.Location = new System.Drawing.Point(13, 124);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(75, 20);
      this.label1.TabIndex = 210;
      this.label1.Text = "Payment:";
      // 
      // label31
      // 
      this.label31.AutoSize = true;
      this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label31.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
      this.label31.Location = new System.Drawing.Point(13, 90);
      this.label31.Name = "label31";
      this.label31.Size = new System.Drawing.Size(77, 20);
      this.label31.TabIndex = 10;
      this.label31.Text = "Job Type:";
      // 
      // btnVehicle
      // 
      this.btnVehicle.BackColor = System.Drawing.Color.White;
      this.btnVehicle.BackgroundImage = global::workshop_orders.Properties.Resources.find;
      this.btnVehicle.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
      this.btnVehicle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnVehicle.ForeColor = System.Drawing.Color.Black;
      this.btnVehicle.Location = new System.Drawing.Point(419, 151);
      this.btnVehicle.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
      this.btnVehicle.Name = "btnVehicle";
      this.btnVehicle.Size = new System.Drawing.Size(35, 33);
      this.btnVehicle.TabIndex = 41;
      this.btnVehicle.UseVisualStyleBackColor = false;
      this.btnVehicle.Click += new System.EventHandler(this.addRegoButton_Click);
      // 
      // btnCustomer
      // 
      this.btnCustomer.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnCustomer.BackgroundImage = global::workshop_orders.Properties.Resources.customers32;
      this.btnCustomer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
      this.btnCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnCustomer.ForeColor = System.Drawing.Color.Lime;
      this.btnCustomer.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
      this.btnCustomer.Location = new System.Drawing.Point(423, 22);
      this.btnCustomer.Margin = new System.Windows.Forms.Padding(0);
      this.btnCustomer.Name = "btnCustomer";
      this.btnCustomer.Size = new System.Drawing.Size(32, 32);
      this.btnCustomer.TabIndex = 7;
      this.btnCustomer.TextAlign = System.Drawing.ContentAlignment.BottomRight;
      this.btnCustomer.UseVisualStyleBackColor = false;
      this.btnCustomer.Click += new System.EventHandler(this.btnCustomer_Click);
      // 
      // JobNameLabel
      // 
      this.JobNameLabel.AutoSize = true;
      this.JobNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.JobNameLabel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
      this.JobNameLabel.Location = new System.Drawing.Point(6, 58);
      this.JobNameLabel.Name = "JobNameLabel";
      this.JobNameLabel.Size = new System.Drawing.Size(88, 20);
      this.JobNameLabel.TabIndex = 2;
      this.JobNameLabel.Text = "Reference:";
      // 
      // txtReference
      // 
      this.txtReference.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtReference.Location = new System.Drawing.Point(109, 55);
      this.txtReference.MaxLength = 100;
      this.txtReference.Name = "txtReference";
      this.txtReference.Size = new System.Drawing.Size(311, 26);
      this.txtReference.TabIndex = 1;
      // 
      // txtCustomer
      // 
      this.txtCustomer.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
      this.txtCustomer.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
      this.txtCustomer.Cursor = System.Windows.Forms.Cursors.Default;
      this.txtCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtCustomer.Location = new System.Drawing.Point(109, 25);
      this.txtCustomer.Name = "txtCustomer";
      this.txtCustomer.ReadOnly = true;
      this.txtCustomer.Size = new System.Drawing.Size(311, 26);
      this.txtCustomer.TabIndex = 2;
      // 
      // label5
      // 
      this.label5.AutoSize = true;
      this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
      this.label5.Location = new System.Drawing.Point(8, 27);
      this.label5.Name = "label5";
      this.label5.Size = new System.Drawing.Size(82, 20);
      this.label5.TabIndex = 4;
      this.label5.Text = "Customer:";
      // 
      // gbNote
      // 
      this.gbNote.Controls.Add(this.txtNote2);
      this.gbNote.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbNote.ForeColor = System.Drawing.Color.Blue;
      this.gbNote.Location = new System.Drawing.Point(1157, 3);
      this.gbNote.Name = "gbNote";
      this.gbNote.Size = new System.Drawing.Size(559, 200);
      this.gbNote.TabIndex = 216;
      this.gbNote.TabStop = false;
      this.gbNote.Text = "Note";
      this.gbNote.Visible = false;
      // 
      // txtNote2
      // 
      this.txtNote2.AcceptsReturn = true;
      this.txtNote2.Dock = System.Windows.Forms.DockStyle.Fill;
      this.txtNote2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtNote2.Location = new System.Drawing.Point(3, 22);
      this.txtNote2.Multiline = true;
      this.txtNote2.Name = "txtNote2";
      this.txtNote2.ScrollBars = System.Windows.Forms.ScrollBars.Both;
      this.txtNote2.Size = new System.Drawing.Size(553, 175);
      this.txtNote2.TabIndex = 0;
      this.txtNote2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtNote2_KeyDown);
      // 
      // tcJob
      // 
      this.tcJob.Controls.Add(this.tpItem);
      this.tcJob.Controls.Add(this.tpNote);
      this.tcJob.Controls.Add(this.tpInvoice);
      this.tcJob.Controls.Add(this.tpFiles);
      this.tcJob.Dock = System.Windows.Forms.DockStyle.Fill;
      this.tcJob.Location = new System.Drawing.Point(0, 246);
      this.tcJob.Name = "tcJob";
      this.tcJob.SelectedIndex = 0;
      this.tcJob.Size = new System.Drawing.Size(1892, 815);
      this.tcJob.TabIndex = 209;
      // 
      // tpItem
      // 
      this.tpItem.Controls.Add(this.groupBox3);
      this.tpItem.Controls.Add(this.panel5);
      this.tpItem.Controls.Add(this.toolStrip3);
      this.tpItem.Location = new System.Drawing.Point(4, 29);
      this.tpItem.Name = "tpItem";
      this.tpItem.Padding = new System.Windows.Forms.Padding(3);
      this.tpItem.Size = new System.Drawing.Size(1884, 782);
      this.tpItem.TabIndex = 0;
      this.tpItem.Text = "Items";
      this.tpItem.UseVisualStyleBackColor = true;
      this.tpItem.Click += new System.EventHandler(this.tpItem_Click);
      // 
      // groupBox3
      // 
      this.groupBox3.Controls.Add(this.txtNote);
      this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
      this.groupBox3.Location = new System.Drawing.Point(1066, 42);
      this.groupBox3.Name = "groupBox3";
      this.groupBox3.Size = new System.Drawing.Size(815, 737);
      this.groupBox3.TabIndex = 190;
      this.groupBox3.TabStop = false;
      this.groupBox3.Text = "Notes";
      // 
      // panel5
      // 
      this.panel5.Controls.Add(this.groupBox2);
      this.panel5.Controls.Add(this.gbItems);
      this.panel5.Dock = System.Windows.Forms.DockStyle.Left;
      this.panel5.Location = new System.Drawing.Point(3, 42);
      this.panel5.Name = "panel5";
      this.panel5.Size = new System.Drawing.Size(1063, 737);
      this.panel5.TabIndex = 191;
      // 
      // groupBox2
      // 
      this.groupBox2.Controls.Add(this.dgvLabour);
      this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
      this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.groupBox2.ForeColor = System.Drawing.Color.Black;
      this.groupBox2.Location = new System.Drawing.Point(0, 251);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new System.Drawing.Size(1063, 486);
      this.groupBox2.TabIndex = 189;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Labour";
      // 
      // dgvLabour
      // 
      this.dgvLabour.AllowUserToAddRows = false;
      this.dgvLabour.AllowUserToDeleteRows = false;
      this.dgvLabour.AllowUserToOrderColumns = true;
      dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
      this.dgvLabour.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle8;
      this.dgvLabour.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      this.dgvLabour.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvLabour.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14});
      this.dgvLabour.ContextMenuStrip = this.cmItems;
      this.dgvLabour.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dgvLabour.Location = new System.Drawing.Point(3, 22);
      this.dgvLabour.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
      this.dgvLabour.MultiSelect = false;
      this.dgvLabour.Name = "dgvLabour";
      this.dgvLabour.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
      this.dgvLabour.Size = new System.Drawing.Size(1057, 461);
      this.dgvLabour.TabIndex = 187;
      // 
      // dataGridViewTextBoxColumn9
      // 
      this.dataGridViewTextBoxColumn9.DataPropertyName = "LabourID";
      this.dataGridViewTextBoxColumn9.HeaderText = "ID";
      this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
      this.dataGridViewTextBoxColumn9.ReadOnly = true;
      this.dataGridViewTextBoxColumn9.Visible = false;
      this.dataGridViewTextBoxColumn9.Width = 500;
      // 
      // dataGridViewTextBoxColumn10
      // 
      this.dataGridViewTextBoxColumn10.DataPropertyName = "StaffFullName";
      this.dataGridViewTextBoxColumn10.HeaderText = "Staff";
      this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
      this.dataGridViewTextBoxColumn10.ReadOnly = true;
      this.dataGridViewTextBoxColumn10.Width = 200;
      // 
      // dataGridViewTextBoxColumn11
      // 
      this.dataGridViewTextBoxColumn11.DataPropertyName = "Percent";
      this.dataGridViewTextBoxColumn11.HeaderText = "Percent";
      this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
      this.dataGridViewTextBoxColumn11.ReadOnly = true;
      this.dataGridViewTextBoxColumn11.Width = 70;
      // 
      // dataGridViewTextBoxColumn12
      // 
      this.dataGridViewTextBoxColumn12.DataPropertyName = "TimeLength";
      this.dataGridViewTextBoxColumn12.HeaderText = "Time";
      this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
      this.dataGridViewTextBoxColumn12.ReadOnly = true;
      // 
      // dataGridViewTextBoxColumn13
      // 
      this.dataGridViewTextBoxColumn13.DataPropertyName = "Cost";
      dataGridViewCellStyle9.Format = "C2";
      dataGridViewCellStyle9.NullValue = "$0";
      this.dataGridViewTextBoxColumn13.DefaultCellStyle = dataGridViewCellStyle9;
      this.dataGridViewTextBoxColumn13.HeaderText = "Cost";
      this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
      this.dataGridViewTextBoxColumn13.ReadOnly = true;
      // 
      // dataGridViewTextBoxColumn14
      // 
      this.dataGridViewTextBoxColumn14.DataPropertyName = "Note";
      dataGridViewCellStyle10.NullValue = "1";
      dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
      this.dataGridViewTextBoxColumn14.DefaultCellStyle = dataGridViewCellStyle10;
      this.dataGridViewTextBoxColumn14.HeaderText = "Note";
      this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
      this.dataGridViewTextBoxColumn14.ReadOnly = true;
      this.dataGridViewTextBoxColumn14.Width = 500;
      // 
      // gbItems
      // 
      this.gbItems.Controls.Add(this.dgvItem);
      this.gbItems.Dock = System.Windows.Forms.DockStyle.Top;
      this.gbItems.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbItems.ForeColor = System.Drawing.Color.Black;
      this.gbItems.Location = new System.Drawing.Point(0, 0);
      this.gbItems.Name = "gbItems";
      this.gbItems.Size = new System.Drawing.Size(1063, 251);
      this.gbItems.TabIndex = 188;
      this.gbItems.TabStop = false;
      this.gbItems.Text = "Items";
      // 
      // toolStrip3
      // 
      this.toolStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsAddProduct,
            this.tsLabour});
      this.toolStrip3.Location = new System.Drawing.Point(3, 3);
      this.toolStrip3.Name = "toolStrip3";
      this.toolStrip3.Size = new System.Drawing.Size(1878, 39);
      this.toolStrip3.TabIndex = 186;
      this.toolStrip3.Text = "toolStrip3";
      // 
      // tsAddProduct
      // 
      this.tsAddProduct.Image = global::workshop_orders.Properties.Resources.addnew;
      this.tsAddProduct.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsAddProduct.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsAddProduct.Name = "tsAddProduct";
      this.tsAddProduct.Size = new System.Drawing.Size(110, 36);
      this.tsAddProduct.Text = "Add Product";
      this.tsAddProduct.Click += new System.EventHandler(this.tsAddProduct_Click);
      // 
      // tsLabour
      // 
      this.tsLabour.Image = global::workshop_orders.Properties.Resources.hourglass32;
      this.tsLabour.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsLabour.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsLabour.Name = "tsLabour";
      this.tsLabour.Size = new System.Drawing.Size(105, 36);
      this.tsLabour.Text = "Add Labour";
      this.tsLabour.Click += new System.EventHandler(this.tsLabour_Click_1);
      // 
      // tpNote
      // 
      this.tpNote.Location = new System.Drawing.Point(4, 29);
      this.tpNote.Name = "tpNote";
      this.tpNote.Padding = new System.Windows.Forms.Padding(3);
      this.tpNote.Size = new System.Drawing.Size(1884, 782);
      this.tpNote.TabIndex = 3;
      this.tpNote.Text = "Notes";
      this.tpNote.UseVisualStyleBackColor = true;
      // 
      // tpInvoice
      // 
      this.tpInvoice.Controls.Add(this.dgvInvoice);
      this.tpInvoice.Controls.Add(this.toolStrip4);
      this.tpInvoice.Location = new System.Drawing.Point(4, 29);
      this.tpInvoice.Name = "tpInvoice";
      this.tpInvoice.Padding = new System.Windows.Forms.Padding(3);
      this.tpInvoice.Size = new System.Drawing.Size(1884, 782);
      this.tpInvoice.TabIndex = 1;
      this.tpInvoice.Text = "Invoices";
      this.tpInvoice.UseVisualStyleBackColor = true;
      // 
      // toolStrip4
      // 
      this.toolStrip4.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsNewInvoice});
      this.toolStrip4.Location = new System.Drawing.Point(3, 3);
      this.toolStrip4.Name = "toolStrip4";
      this.toolStrip4.Size = new System.Drawing.Size(1878, 39);
      this.toolStrip4.TabIndex = 199;
      this.toolStrip4.Text = "toolStrip4";
      // 
      // tsNewInvoice
      // 
      this.tsNewInvoice.Image = global::workshop_orders.Properties.Resources.invoice_32png;
      this.tsNewInvoice.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsNewInvoice.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsNewInvoice.Name = "tsNewInvoice";
      this.tsNewInvoice.Size = new System.Drawing.Size(108, 36);
      this.tsNewInvoice.Text = "New Invoice";
      this.tsNewInvoice.Click += new System.EventHandler(this.tsNewInvoice_Click);
      // 
      // tpFiles
      // 
      this.tpFiles.Controls.Add(this.dgvFiles);
      this.tpFiles.Controls.Add(this.toolStrip2);
      this.tpFiles.Location = new System.Drawing.Point(4, 29);
      this.tpFiles.Name = "tpFiles";
      this.tpFiles.Padding = new System.Windows.Forms.Padding(3);
      this.tpFiles.Size = new System.Drawing.Size(1884, 782);
      this.tpFiles.TabIndex = 2;
      this.tpFiles.Text = "Files";
      this.tpFiles.UseVisualStyleBackColor = true;
      // 
      // toolStrip2
      // 
      this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsOpenFolder});
      this.toolStrip2.Location = new System.Drawing.Point(3, 3);
      this.toolStrip2.Name = "toolStrip2";
      this.toolStrip2.Size = new System.Drawing.Size(1878, 37);
      this.toolStrip2.TabIndex = 205;
      this.toolStrip2.Text = "toolStrip2";
      // 
      // tsOpenFolder
      // 
      this.tsOpenFolder.Image = global::workshop_orders.Properties.Resources.folder32;
      this.tsOpenFolder.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsOpenFolder.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsOpenFolder.Name = "tsOpenFolder";
      this.tsOpenFolder.Size = new System.Drawing.Size(108, 34);
      this.tsOpenFolder.Text = "Open Folder";
      this.tsOpenFolder.Click += new System.EventHandler(this.tbOpenFolder_Click);
      // 
      // timPricings
      // 
      this.timPricings.Interval = 120000;
      this.timPricings.Tick += new System.EventHandler(this.timPricings_Tick);
      // 
      // lblStatus
      // 
      this.lblStatus.AutoSize = true;
      this.lblStatus.BackColor = System.Drawing.Color.Transparent;
      this.lblStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblStatus.Location = new System.Drawing.Point(898, 7);
      this.lblStatus.Name = "lblStatus";
      this.lblStatus.Size = new System.Drawing.Size(62, 20);
      this.lblStatus.TabIndex = 210;
      this.lblStatus.Text = "Status";
      // 
      // JobEdit
      // 
      this.AllowDrop = true;
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
      this.AutoScroll = true;
      this.BackColor = System.Drawing.Color.White;
      this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
      this.ClientSize = new System.Drawing.Size(1892, 1061);
      this.ControlBox = false;
      this.Controls.Add(this.lblStatus);
      this.Controls.Add(this.tcJob);
      this.Controls.Add(this.panel1);
      this.Controls.Add(this.toolStrip1);
      this.Controls.Add(this.label27);
      this.Cursor = System.Windows.Forms.Cursors.Default;
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
      this.MaximizeBox = false;
      this.Name = "JobEdit";
      this.ShowIcon = false;
      this.ShowInTaskbar = false;
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
      this.Text = " Vehicle Job";
      this.Load += new System.EventHandler(this.CreateJobForm_Load);
      ((System.ComponentModel.ISupportInitialize)(this.dgvItem)).EndInit();
      this.cmItems.ResumeLayout(false);
      this.gbBooking.ResumeLayout(false);
      this.gbBooking.PerformLayout();
      this.gbInsurance.ResumeLayout(false);
      this.gbInsurance.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dgvInvoice)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dgvFiles)).EndInit();
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.panel1.ResumeLayout(false);
      this.gbPrices.ResumeLayout(false);
      this.pnlCosts.ResumeLayout(false);
      this.pnlCosts.PerformLayout();
      this.panel3.ResumeLayout(false);
      this.panel3.PerformLayout();
      this.pnlPrice.ResumeLayout(false);
      this.pnlPrice.PerformLayout();
      this.panel4.ResumeLayout(false);
      this.panel4.PerformLayout();
      this.panel2.ResumeLayout(false);
      this.panel2.PerformLayout();
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.nudIviis)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudMilage)).EndInit();
      this.gbOnsite.ResumeLayout(false);
      this.gbOnsite.PerformLayout();
      this.gbDetails.ResumeLayout(false);
      this.gbDetails.PerformLayout();
      this.gbNote.ResumeLayout(false);
      this.gbNote.PerformLayout();
      this.tcJob.ResumeLayout(false);
      this.tpItem.ResumeLayout(false);
      this.tpItem.PerformLayout();
      this.groupBox3.ResumeLayout(false);
      this.groupBox3.PerformLayout();
      this.panel5.ResumeLayout(false);
      this.groupBox2.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.dgvLabour)).EndInit();
      this.gbItems.ResumeLayout(false);
      this.toolStrip3.ResumeLayout(false);
      this.toolStrip3.PerformLayout();
      this.tpInvoice.ResumeLayout(false);
      this.tpInvoice.PerformLayout();
      this.toolStrip4.ResumeLayout(false);
      this.toolStrip4.PerformLayout();
      this.tpFiles.ResumeLayout(false);
      this.tpFiles.PerformLayout();
      this.toolStrip2.ResumeLayout(false);
      this.toolStrip2.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

        }

        #endregion
        private TextBox txtVehicle;
        private Label lblVehicle;
        private Label lblInsurance;
        private TextBox txtAccountNo;
        private Label lblAccountNo;
        private Button btnVehicle;
        private ComboBox cmbInsurance;
        private TextBox txtAccountName;
        private Label lblAccountName;
        private DateTimePicker dtpBookDate;
        private Label label27;
        private DataGridView dgvItem;
        private Label label2;
        private GroupBox gbBooking;
        private GroupBox gbInsurance;
        private DataGridView dataGridView2;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn1;
        private DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn2;
        private DataGridView dgvInvoice;
        private ComboBox cmbArea;
        private TextBox txtAddress;
        private Label label4;
        private FolderBrowserDialog fbdJobPath;
        private DataGridView dgvFiles;
        private DateTimePicker dtpBookTime;
        private Button btnTimeBack;
        private Button btnTimeForward;
        private ComboBox cmbType;
    private ToolStrip toolStrip1;
    private ToolStripButton tsBack;
    private ToolStripButton tsPrint;
    private ToolStripButton tsCancel;
    private ToolStripButton tsSave;
    private ToolStripButton tsCopy;
    private Panel panel1;
    private ComboBox cmbPayment;
    private TabControl tcJob;
    private TabPage tpItem;
    private TabPage tpInvoice;
    private TabPage tpFiles;
    private ToolStrip toolStrip2;
    private ToolStripButton tsOpenFolder;
    private CheckBox chkBooking;
    private ToolStrip toolStrip3;
    private ToolStripButton tsAddProduct;
    private ToolStripButton tsDetails;
    private ToolStrip toolStrip4;
    private ToolStripButton tsNewInvoice;
    private GroupBox gbDetails;
    private Label label1;
    private Label label31;
    private Button btnCustomer;
    private Label JobNameLabel;
    private TextBox txtReference;
    private TextBox txtCustomer;
    private Label label5;
    private GroupBox gbOnsite;
    private ToolStripSeparator toolStripSeparator1;
    private ToolStripSeparator toolStripSeparator2;
    private ToolStripSeparator tsSep;
    private TextBox txtNote;
    private Label label3;
    private GroupBox groupBox1;
    private NumericUpDown nudMilage;
    private NumericUpDown nudIviis;
    private DataGridViewTextBoxColumn ID;
    private DataGridViewTextBoxColumn invoiceno;
    private DataGridViewTextBoxColumn amount;
    private DataGridViewTextBoxColumn date;
    private DataGridViewTextBoxColumn Files;
    private TabPage tpNote;
    private GroupBox gbPrices;
    private Panel pnlCosts;
    private Label lblPricings;
    private TextBox txtTotalCost;
    private Label label7;
    private Label label10;
    private TextBox txtItemCost;
    private Label label8;
    private TextBox txtLabourCost;
    private Timer timPricings;
    private Panel panel4;
    private Panel pnlPrice;
    private TextBox txtItemPrice;
    private TextBox txtTotalPrice;
    private TextBox txtLabourPrice;
    private Panel panel2;
    private Label label9;
    private Label label11;
    private Label label6;
    private ToolStripLabel tsJobID;
    private ContextMenuStrip cmItems;
    private ToolStripMenuItem addProductToolStripMenuItem;
    private ToolStripMenuItem deleteProductToolStripMenuItem;
    private ToolStripMenuItem productHistoryToolStripMenuItem;
    private ComboBox cmbGroup;
    private Label lblStatus;
    private CheckBox chkMilage;
    private GroupBox gbNote;
    private TextBox txtNote2;
    private ToolStripButton tsLabour;
    private DataGridView dgvLabour;
    private GroupBox gbItems;
    private GroupBox groupBox2;
    private Panel panel3;
    private Label label12;
    private TextBox textBox1;
    private TextBox textBox2;
    private TextBox textBox3;
    private ToolStripMenuItem moveProductToolStripMenuItem;
    private DataGridViewTextBoxColumn JobItemID;
    private DataGridViewTextBoxColumn Supplier;
    private DataGridViewTextBoxColumn Column2;
    private DataGridViewTextBoxColumn Column3;
    private DataGridViewTextBoxColumn chAltCode;
    private DataGridViewTextBoxColumn Description;
    private DataGridViewTextBoxColumn Quantity;
    private DataGridViewTextBoxColumn State;
    private DataGridViewTextBoxColumn Column9;
    private DataGridViewLinkColumn Delete;
    private DataGridViewLinkColumn chAction;
    private GroupBox groupBox3;
    private Panel panel5;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
  }
}

