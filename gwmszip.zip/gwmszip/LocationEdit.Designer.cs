﻿namespace workshop_orders
{
  partial class LocationEdit
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.label1 = new System.Windows.Forms.Label();
      this.cmbGroup = new System.Windows.Forms.ComboBox();
      this.toolStrip1 = new System.Windows.Forms.ToolStrip();
      this.gbItemDetails = new System.Windows.Forms.GroupBox();
      this.label4 = new System.Windows.Forms.Label();
      this.label3 = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this.txtDescription = new System.Windows.Forms.TextBox();
      this.txtCode = new System.Windows.Forms.TextBox();
      this.cmbSubGroup = new System.Windows.Forms.ComboBox();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.dgvItems = new System.Windows.Forms.DataGridView();
      this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
      this.tsClose = new System.Windows.Forms.ToolStripButton();
      this.tsSave = new System.Windows.Forms.ToolStripButton();
      this.chID = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chJobID = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.toolStrip1.SuspendLayout();
      this.gbItemDetails.SuspendLayout();
      this.groupBox1.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgvItems)).BeginInit();
      this.SuspendLayout();
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label1.Location = new System.Drawing.Point(54, 25);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(50, 18);
      this.label1.TabIndex = 0;
      this.label1.Text = "Group";
      // 
      // cmbGroup
      // 
      this.cmbGroup.DisplayMember = "textfield";
      this.cmbGroup.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.cmbGroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbGroup.FormattingEnabled = true;
      this.cmbGroup.Location = new System.Drawing.Point(111, 22);
      this.cmbGroup.Name = "cmbGroup";
      this.cmbGroup.Size = new System.Drawing.Size(221, 26);
      this.cmbGroup.TabIndex = 1;
      this.cmbGroup.ValueMember = "datafield";
      this.cmbGroup.SelectedIndexChanged += new System.EventHandler(this.cmbGroup_SelectedIndexChanged);
      // 
      // toolStrip1
      // 
      this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsClose,
            this.tsSave,
            this.toolStripSeparator1});
      this.toolStrip1.Location = new System.Drawing.Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new System.Drawing.Size(1286, 39);
      this.toolStrip1.TabIndex = 14;
      this.toolStrip1.Text = "toolStrip1";
      // 
      // gbItemDetails
      // 
      this.gbItemDetails.Controls.Add(this.label4);
      this.gbItemDetails.Controls.Add(this.label3);
      this.gbItemDetails.Controls.Add(this.label2);
      this.gbItemDetails.Controls.Add(this.txtDescription);
      this.gbItemDetails.Controls.Add(this.txtCode);
      this.gbItemDetails.Controls.Add(this.cmbSubGroup);
      this.gbItemDetails.Controls.Add(this.label1);
      this.gbItemDetails.Controls.Add(this.cmbGroup);
      this.gbItemDetails.Dock = System.Windows.Forms.DockStyle.Top;
      this.gbItemDetails.Location = new System.Drawing.Point(0, 39);
      this.gbItemDetails.Name = "gbItemDetails";
      this.gbItemDetails.Size = new System.Drawing.Size(1286, 212);
      this.gbItemDetails.TabIndex = 18;
      this.gbItemDetails.TabStop = false;
      this.gbItemDetails.Text = "Item Details";
      // 
      // label4
      // 
      this.label4.AutoSize = true;
      this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label4.Location = new System.Drawing.Point(60, 90);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(44, 18);
      this.label4.TabIndex = 25;
      this.label4.Text = "Code";
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label3.Location = new System.Drawing.Point(22, 120);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(83, 18);
      this.label3.TabIndex = 24;
      this.label3.Text = "Description";
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label2.Location = new System.Drawing.Point(24, 57);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(80, 18);
      this.label2.TabIndex = 23;
      this.label2.Text = "Sub Group";
      // 
      // txtDescription
      // 
      this.txtDescription.AcceptsReturn = true;
      this.txtDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtDescription.Location = new System.Drawing.Point(111, 117);
      this.txtDescription.Multiline = true;
      this.txtDescription.Name = "txtDescription";
      this.txtDescription.Size = new System.Drawing.Size(336, 71);
      this.txtDescription.TabIndex = 22;
      // 
      // txtCode
      // 
      this.txtCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtCode.Location = new System.Drawing.Point(111, 87);
      this.txtCode.MaxLength = 45;
      this.txtCode.Name = "txtCode";
      this.txtCode.Size = new System.Drawing.Size(221, 24);
      this.txtCode.TabIndex = 21;
      // 
      // cmbSubGroup
      // 
      this.cmbSubGroup.DisplayMember = "textfield";
      this.cmbSubGroup.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.cmbSubGroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbSubGroup.FormattingEnabled = true;
      this.cmbSubGroup.Location = new System.Drawing.Point(111, 54);
      this.cmbSubGroup.Name = "cmbSubGroup";
      this.cmbSubGroup.Size = new System.Drawing.Size(221, 26);
      this.cmbSubGroup.TabIndex = 20;
      this.cmbSubGroup.ValueMember = "datafield";
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.Add(this.dgvItems);
      this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.groupBox1.Location = new System.Drawing.Point(0, 251);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(1286, 528);
      this.groupBox1.TabIndex = 19;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Location Item List";
      // 
      // dgvItems
      // 
      this.dgvItems.AllowUserToAddRows = false;
      this.dgvItems.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      this.dgvItems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvItems.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.chID,
            this.chCode,
            this.chDesc,
            this.chCost,
            this.chQty,
            this.chJobID});
      this.dgvItems.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dgvItems.Location = new System.Drawing.Point(3, 20);
      this.dgvItems.Name = "dgvItems";
      this.dgvItems.ReadOnly = true;
      this.dgvItems.RowHeadersWidth = 5;
      this.dgvItems.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
      this.dgvItems.Size = new System.Drawing.Size(1280, 505);
      this.dgvItems.TabIndex = 0;
      this.dgvItems.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvItems_CellDoubleClick);
      // 
      // toolStripSeparator1
      // 
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
      // 
      // tsClose
      // 
      this.tsClose.Image = global::workshop_orders.Properties.Resources.back;
      this.tsClose.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsClose.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsClose.Name = "tsClose";
      this.tsClose.Size = new System.Drawing.Size(72, 36);
      this.tsClose.Text = "Close";
      this.tsClose.Click += new System.EventHandler(this.tsClose_Click);
      // 
      // tsSave
      // 
      this.tsSave.Image = global::workshop_orders.Properties.Resources.save;
      this.tsSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsSave.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsSave.Name = "tsSave";
      this.tsSave.Size = new System.Drawing.Size(67, 36);
      this.tsSave.Text = "Save";
      this.tsSave.Click += new System.EventHandler(this.tsSave_Click);
      // 
      // chID
      // 
      this.chID.DataPropertyName = "ItemCostID";
      this.chID.HeaderText = "ID";
      this.chID.Name = "chID";
      this.chID.ReadOnly = true;
      this.chID.Visible = false;
      // 
      // chCode
      // 
      this.chCode.DataPropertyName = "icCode";
      this.chCode.HeaderText = "Code";
      this.chCode.Name = "chCode";
      this.chCode.ReadOnly = true;
      this.chCode.Width = 200;
      // 
      // chDesc
      // 
      this.chDesc.DataPropertyName = "icDescription";
      this.chDesc.HeaderText = "Description";
      this.chDesc.Name = "chDesc";
      this.chDesc.ReadOnly = true;
      this.chDesc.Width = 400;
      // 
      // chCost
      // 
      this.chCost.DataPropertyName = "icCost";
      this.chCost.HeaderText = "Cost";
      this.chCost.Name = "chCost";
      this.chCost.ReadOnly = true;
      // 
      // chQty
      // 
      this.chQty.DataPropertyName = "Quantity";
      this.chQty.HeaderText = "Qty";
      this.chQty.Name = "chQty";
      this.chQty.ReadOnly = true;
      this.chQty.Width = 50;
      // 
      // chJobID
      // 
      this.chJobID.DataPropertyName = "JobID";
      this.chJobID.HeaderText = "Job ID";
      this.chJobID.Name = "chJobID";
      this.chJobID.ReadOnly = true;
      // 
      // LocationEdit
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.ClientSize = new System.Drawing.Size(1286, 779);
      this.Controls.Add(this.groupBox1);
      this.Controls.Add(this.gbItemDetails);
      this.Controls.Add(this.toolStrip1);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
      this.Name = "LocationEdit";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
      this.Text = "Location";
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.gbItemDetails.ResumeLayout(false);
      this.gbItemDetails.PerformLayout();
      this.groupBox1.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.dgvItems)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.ComboBox cmbGroup;
    private System.Windows.Forms.ToolStrip toolStrip1;
    private System.Windows.Forms.ToolStripButton tsClose;
    private System.Windows.Forms.ToolStripButton tsSave;
    private System.Windows.Forms.GroupBox gbItemDetails;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.DataGridView dgvItems;
    private System.Windows.Forms.ComboBox cmbSubGroup;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.TextBox txtDescription;
    private System.Windows.Forms.TextBox txtCode;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
    private System.Windows.Forms.DataGridViewTextBoxColumn chID;
    private System.Windows.Forms.DataGridViewTextBoxColumn chCode;
    private System.Windows.Forms.DataGridViewTextBoxColumn chDesc;
    private System.Windows.Forms.DataGridViewTextBoxColumn chCost;
    private System.Windows.Forms.DataGridViewTextBoxColumn chQty;
    private System.Windows.Forms.DataGridViewTextBoxColumn chJobID;
  }
}