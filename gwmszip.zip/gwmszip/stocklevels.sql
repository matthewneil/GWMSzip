StockItemId
SUM(CASE when movementtype = reservation then 1 else 0 end ) As reservation
SUM(CASE when movementtype <> reservation then 1 else 0 end ) As stock
SUM(CASE when movementtype <> reservation then 1 else 0 end ) - SUM(CASE when movementtype = reservation then 1 else 0 end ) AS Avaliable
