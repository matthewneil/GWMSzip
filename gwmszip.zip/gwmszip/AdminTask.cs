﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workshop_orders
{
  public partial class AdminTask : Form
  {
    private int AdminID = -1;
    private int StaffID = -1;
    public static Workshop frm;
    public AdminTask(int AdminID, int StaffID)
    {
      InitializeComponent();
      this.AdminID = AdminID;
      this.StaffID = StaffID;
      gbAdmin.Text = DataAccess.ExecuteScalarString("SELECT AdminTaskName FROM AdminTask WHERE AdminTaskID = " + AdminID);
      tsUser.Text = DataAccess.ExecuteScalarString("SELECT StaffFullName FROM Staff WHERE StaffID = " + StaffID);
      DataAccess.FormState(this.AccessibilityObject.Name, tsAddTime);
    }

  private void tsBack_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private void tsAddTime_Click(object sender, EventArgs e)
    {
      try
      {
        if (AdminID > 0 && StaffID > 0)
        {
          DataAccess.LabourManage(StaffID, AdminID, 100, txtNote.Text);
          DataAccess.ShowMessage("Admin Time successfully added.");
          frm.LoadUsers();
          this.Close();
        }
      }
      catch(Exception ex)
      {
        DataAccess.ShowMessage("Admin Time failed to save.");
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }
    }
  }
}
