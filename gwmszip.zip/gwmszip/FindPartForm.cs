﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace workshop_orders
{
  /*This is a form is view all the created jobs in the database*
   * This data can a queried and filter so you can only display the job you want to see*/
  public partial class FindPartForm : Form
  {
    private bool update = false;
    private String rego;
    private String make;
    private String model;
    private String year;

    /*A method to connect to the GoreGlassJob database*/
    public MySqlConnection connectMySql()
    {
      using (MySqlConnection conn = new MySqlConnection(GWMS.connStr))
      {
        try
        {
          Console.WriteLine("Connecting to MySQL...");

          return conn;
        }
        catch (Exception ex)
        {
          MessageBox.Show("Error connecting to server, please contact the administrator.", "Error!");
          return null;
        }

      }
    }


    /*Initializes the component and add the database varible names to the 'WHERE' box, used for querying the job database job*/
    public FindPartForm()
    {
      InitializeComponent();
      partTypeCombo.Items.Add("FLAT GLASS");
      partTypeCombo.Items.Add("TIMBER WINDOW");
      partTypeCombo.Items.Add("Aluminium WINDOW");
      partTypeCombo.Items.Add("PERSPEX");
      partTypeCombo.Items.Add("BALUSTRADES");
      partTypeCombo.Items.Add("SHOWER DOME");
      partTypeCombo.Items.Add("Reglaze");
      partTypeCombo.Items.Add("Double Glaze");
      partTypeCombo.Items.Add("WINDSCREEN");
      partTypeCombo.Items.Add("REARSCREEN");
      partTypeCombo.Items.Add("MOULD");
      partTypeCombo.Items.Add("GELPAD");
      partTypeCombo.Items.Add("REFIT");
      partTypeCombo.Items.Add("RESEAL");
      partTypeCombo.Items.Add("R&R-STONEGUARD");
      partTypeCombo.Items.Add("WEATHERSHEILD");
      partTypeCombo.Items.Add("SIDEGLASS-LHF");
      partTypeCombo.Items.Add("SIDEGLASS-RHF");
      partTypeCombo.Items.Add("SIDEGLASS-LHR");
      partTypeCombo.Items.Add("SIDEGLASS-RHR");
      partTypeCombo.Items.Add("SIDEGLASS-LHF-1/4");
      partTypeCombo.Items.Add("SIDEGLASS-RHF-1/4");
      partTypeCombo.Items.Add("SIDEGLASS-LHR-1/4");
      partTypeCombo.Items.Add("SIDEGLASS-RHR-1/4");
      partTypeCombo.Items.Add("CANOPY-REAR");
      partTypeCombo.Items.Add("CANOPY-SIDE-L");
      partTypeCombo.Items.Add("CANOPY-SIDE-R");

      regoGridView.Enabled = false;
      modelGridView.Enabled = false;
      typeGridView.Enabled = false;
      accessGridView.Enabled = false;

      regoLabel.Text = "n/a";
      modelLabel.Text = "n/a";
      typeLabel.Text = "n/a";
      accessLabel.Text = "n/a";

      regoGridView.BackgroundColor = Color.Gray;
      modelGridView.BackgroundColor = Color.Gray;
      typeGridView.BackgroundColor = Color.Gray;
      accessGridView.BackgroundColor = Color.Gray;

      load_partdata();
      reset_all_fields();
    }

    private void load_partdata()
    {
      using (MySqlConnection conn = connectMySql())
      {
        try
        {
          conn.Open();
          String sql = String.Format("SELECT pID, pType, pCode, pAltCode, pNagcode, pDesc FROM part WHERE NOT infinite = 1 LIMIT 100000;");
          MySqlCommand cmd = new MySqlCommand(sql, conn);
          using (MySqlDataReader rdr = cmd.ExecuteReader())
          {
            while (rdr.Read())
            {
              searchText.AutoCompleteCustomSource.Add((rdr["pCode"].ToString() + " " + rdr["pAltCode"].ToString() + " " +
                  rdr["pNagCode"].ToString() + " " + rdr["pType"].ToString()).ToUpper() + " " + rdr["pDesc"].ToString()
                  + " ID: " + rdr["pID"].ToString());

              searchText.AutoCompleteCustomSource.Add((rdr["pAltCode"].ToString() + " " + rdr["pCode"].ToString() + " " +
                  rdr["pNagCode"].ToString() + " " + rdr["pType"].ToString()).ToUpper() + " " + rdr["pDesc"].ToString()
                  + " ID: " + rdr["pID"].ToString());

              searchText.AutoCompleteCustomSource.Add((rdr["pNagCode"].ToString() + " " + rdr["pCode"].ToString() + " " +
                  rdr["pAltCode"].ToString() + " " + rdr["pType"].ToString()).ToUpper() + " " + rdr["pDesc"].ToString()
                  + " ID: " + rdr["pID"].ToString());

              searchText.AutoCompleteCustomSource.Add((rdr["pType"].ToString() + " " + rdr["pCode"].ToString() + " " +
                  rdr["pAltCode"].ToString() + " " + rdr["pNagCode"].ToString()).ToUpper() + " " + rdr["pDesc"].ToString()
                  + " ID: " + rdr["pID"].ToString());

              searchText.AutoCompleteCustomSource.Add((rdr["pDesc"].ToString() + " " + rdr["pType"].ToString() + " " + rdr["pCode"].ToString() + " " +
                  rdr["pAltCode"].ToString() + " " + rdr["pNagCode"].ToString()).ToUpper()
                  + " ID: " + rdr["pID"].ToString());
            }
          }
        }
        catch (Exception ex)
        {
          DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
          System.Reflection.MethodBase.GetCurrentMethod().Name, "");
        }
        conn.Close();
      }
    }

    public FindPartForm(String rego)
    {
      try
      {
        InitializeComponent();
        partTypeCombo.Items.Add("WINDSCREEN");
        partTypeCombo.Items.Add("REARSCREEN");
        partTypeCombo.Items.Add("MOULD");


        partTypeCombo.Items.Add("GELPAD");
        partTypeCombo.Items.Add("REFIT");
        partTypeCombo.Items.Add("RESEAL");
        partTypeCombo.Items.Add("R&R-STONEGUARD");
        partTypeCombo.Items.Add("WEATHERSHEILD");
        partTypeCombo.Items.Add("SIDEGLASS-LHF");
        partTypeCombo.Items.Add("SIDEGLASS-RHF");
        partTypeCombo.Items.Add("SIDEGLASS-LHR");
        partTypeCombo.Items.Add("SIDEGLASS-RHR");
        partTypeCombo.Items.Add("SIDEGLASS-LHF-1/4");
        partTypeCombo.Items.Add("SIDEGLASS-RHF-1/4");
        partTypeCombo.Items.Add("SIDEGLASS-LHR-1/4");
        partTypeCombo.Items.Add("SIDEGLASS-RHR-1/4");
        partTypeCombo.Items.Add("CANOPY-REAR");
        partTypeCombo.Items.Add("CANOPY-SIDE-L");
        partTypeCombo.Items.Add("CANOPY-SIDE-R");
        //partTypeCombo.Items.Add("CHIP");

        String sql = String.Format("SELECT * FROM registration WHERE registration = '{0}'", rego);
        using (MySqlConnection conn = connectMySql())
        {
          try
          {
            conn.Open();
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            using (MySqlDataReader rdr = cmd.ExecuteReader())
            {
              rdr.Read();

              this.rego = rego;
              make = Regex.Replace(rdr["vehicleMake"].ToString(), @"\t|\n|\r", "");
              model = Regex.Replace(rdr["vehicleModel"].ToString(), @"\t|\n|\r", "");
              year = Regex.Replace(rdr["vehicleYear"].ToString(), @"\t|\n|\r", "");

              carModelLabel.Text = rego + ": " + make + " " + model + " " + year;

              sql = String.Format("SELECT part.pType AS Type, part.pCode AS Code, part.pAltCode AS AltCode, pState AS State, part.pDesc AS Descr " +
                  "FROM registration INNER JOIN job ON registration.registration = job.registration " +
                  "INNER JOIN jobPart ON job.jobNo = jobPart.pAllocated INNER JOIN part ON jobPart.pID = part.pID " +
                  "WHERE registration.registration = '{0}' AND NOT infinite = 1 GROUP BY type, code;", rego);
            }
          }
          catch (Exception ex)
          {
            DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
          }
          conn.Close();
        }

        using (MySqlConnection conn = connectMySql())
        {
          try
          {
            conn.Open();
            MySqlCommand cmd = new MySqlCommand(sql, conn);

            MySqlDataAdapter sqlDa = new MySqlDataAdapter(sql, conn);
            DataTable dtbl = new DataTable();
            sqlDa.Fill(dtbl);

            regoGridView.DataSource = dtbl;
          }
          catch (Exception ex)
          {
            DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
          }
          conn.Close();
        }

        using (MySqlConnection conn = connectMySql())
        {
          try
          {
            conn.Open();
            regoLabel.Text += "(" + rego + ")";
            modelLabel.Text += "(" + make + " " + model + " " + year + ")";
            typeLabel.Text += "(" + make + " " + model + ")";

            sql = String.Format("SELECT part.pType AS Type, part.pCode AS Code, part.pAltCode AS AltCode, pState AS State, vehicleYear AS Year, part.pDesc AS Descr " +
                "FROM registration INNER JOIN job ON registration.registration = job.registration " +
                "INNER JOIN jobPart ON job.jobNo = jobPart.pAllocated INNER JOIN part ON jobPart.pID = part.pID " +
                "WHERE registration.vehicleMake = '{0}' AND registration.vehicleModel = '{1}' AND registration.vehicleYear = '{2}' AND registration.registration " +
                "!= '{3}' AND NOT infinite = 1 GROUP BY type, code;",
                make, model, year, rego);

            MySqlDataAdapter sqlDa = new MySqlDataAdapter(sql, conn);
            DataTable dtbl = new DataTable();
            sqlDa.Fill(dtbl);

            modelGridView.DataSource = dtbl;
          }
          catch (Exception ex)
          {
            DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
          }
          conn.Close();
        }
        using (MySqlConnection conn = connectMySql())
        {
          try
          {
            conn.Open();
            sql = String.Format("SELECT part.pType AS Type, part.pCode AS Code, part.pAltCode AS AltCode, pState AS State, vehicleYear AS Year, part.pDesc AS Descr " +
                "FROM registration INNER JOIN job ON registration.registration = job.registration " +
                "INNER JOIN jobPart ON job.jobNo = jobPart.pAllocated INNER JOIN part ON jobPart.pID = part.pID " +
                "WHERE registration.vehicleMake = '{0}' AND registration.vehicleModel = '{1}' AND registration.vehicleYear != '{2}' AND registration.registration " +
                "!= '{3}' AND NOT infinite = 1 GROUP BY type, code;",
                make, model, year, rego);

            MySqlDataAdapter sqlDa = new MySqlDataAdapter(sql, conn);
            DataTable dtbl = new DataTable();
            sqlDa.Fill(dtbl);

            typeGridView.DataSource = dtbl;
          }
          catch (Exception ex)
          {
            DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
          }
          conn.Close();
        }
        load_partdata();
      }
      catch (Exception ex)
      {
        MessageBox.Show("Error loading Part Data. If the issue persists please contact the administrator.");
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }
    }

    private void searchText_TextChanged(object sender, EventArgs e)
    {
      try
      {
        String[] part = searchText.Text.Split(' ');
        String pID = part[part.Length - 1];
        String sql = String.Format("SELECT * FROM part WHERE pID = {0};", pID);
        using (MySqlConnection conn = connectMySql())
        {
          try
          {
            conn.Open();
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            using (MySqlDataReader rdr = cmd.ExecuteReader())
            {
              rdr.Read();
              partTypeCombo.Text = rdr["pType"].ToString();
              partCodeText.Text = rdr["pCode"].ToString();
              altCodeText.Text = rdr["pAltCode"].ToString();
              nagCodeText.Text = rdr["pNagCode"].ToString();
              descText.Text = rdr["pDesc"].ToString();
              buyText.Text = rdr["buyPrice"].ToString();
              sellText.Text = rdr["sellPrice"].ToString();
            }
          }
          catch (Exception ex)
          {
            /*DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                     System.Reflection.MethodBase.GetCurrentMethod().Name, "");*/
          }
          conn.Close();
        }

        sql = String.Format("SELECT aType AS Type, pCode AS Euro, pAltCode AS OBG, pDesc AS Descr FROM accessories INNER JOIN part ON aID = part.pID WHERE pID = {0};", pID);
        using (MySqlConnection conn = connectMySql())
        {
          try
          {
            conn.Open();
            MySqlDataAdapter sqlDa = new MySqlDataAdapter(sql, conn);
            DataTable dtbl = new DataTable();
            sqlDa.Fill(dtbl);
            accessGridView.DataSource = dtbl;
          }
          catch (Exception ex) { }
          conn.Close();
        }
        //stockLabel.Text = rdr["pQuantity"].ToString();
      }
      catch { }
    }

    /*Check if String entered into function is a number
     */
    public bool IsNumber(String number)
    {
      return number.All(char.IsNumber);
    }

    /*reset_all_fields method
     * Resets all the fields in the form to empty
     * Also refreshes the Today's orders' box to reflect any changes that may have happened to the database.
     */
    private void reset_all_fields()
    {

    }



    public void updateButton_Click()
    {

    }

    /**methods below are unused*/
    private void Form1_Load(object sender, EventArgs e)
    {

    }

    private void executeSQL(string sql, bool error)
    {
      try
      {
        using (MySqlConnection conn = connectMySql())
        {
          conn.Open();
          MySqlCommand cmd = new MySqlCommand(sql, conn);
          cmd.ExecuteReader();
          conn.Close();
        }
      }
      catch (Exception ex)
      {
        if (error)
        {
          Console.WriteLine(ex.ToString());
          MessageBox.Show("Error communicating with database. If this problem persists, please contact the administrator.\n");
          DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
        }
      }
    }

    private String quote(string x)
    {
      return "'" + x + "'";
    }

    private void partButton_Click(object sender, EventArgs e)
    {
      String pType = quote(partTypeCombo.Text);
      String pCode = quote(partCodeText.Text);
      String pAltCode = quote(altCodeText.Text);
      String pNagCode = quote(nagCodeText.Text);

      String buyPrice = buyText.Text.Trim();
      String sellPrice = sellText.Text.Trim();
      String pDesc = quote(descText.Text);


      int pID = 0;
      //String pQuantity = quantity.Text;
      String errors = "";

      if (pType == "''")
      {
        errors += "- Part Type must be specified.\n";
      }

      if (pCode == "''" && pAltCode == "''" && pNagCode == "''")
      {
        errors += "- At least ONE part code needs to be specified.\n";
      }
      else if (pAltCode == "''")
      {
        pAltCode = "NULL";
      }
      if (pCode == "''")
      {
        pCode = "NULL";
      }
      if (pNagCode == "''")
      {
        pNagCode = "NULL";
      }
      if (pDesc == "''")
      {
        pDesc = "NULL";
      }

      try
      {
        if (!IsNumber(buyPrice.Replace(".", "")) || buyPrice.Split('.').Length > 2 || buyPrice.Split('.')[1].Length > 2 || buyPrice == ".")
        {
          errors += "- Buy Price entered isn't in correct format.\n";
        }
      }
      catch { }

      if (buyPrice == "")
      {
        buyPrice = "null";
      }

      try
      {
        if (!IsNumber(sellPrice.Replace(".", "")) || sellPrice.Split('.').Length > 2 || sellPrice.Split('.')[1].Length > 2 || sellPrice == ".")
        {
          errors += "- Sell Price entered isn't in correct format.\n";
        }
      }
      catch { }

      if (sellPrice == "")
      {
        sellPrice = "null";
      }

      String sql;

      MySqlCommand cmd;
      MySqlDataReader rdr;
      int pID1 = 0;
      int pID2 = 0;
      int pID3 = 0;

      if (pCode != "NULL")
      {
        using (MySqlConnection conn = connectMySql())
        {
          try
          {
            conn.Open();
            sql = String.Format("SELECT pID FROM part WHERE pCode = {0};", pCode);
            cmd = new MySqlCommand(sql, conn);
            using (rdr = cmd.ExecuteReader())
            {
              rdr.Read();
              pID1 = int.Parse(rdr["pID"].ToString());
            }
          }
          catch (Exception ex) { }
          conn.Close();
        }
      }

      if (pAltCode != "NULL")
      {
        using (MySqlConnection conn = connectMySql())
        {
          try
          {
            conn.Open();
            sql = String.Format("SELECT pID FROM part WHERE pAltCode = {0};", pAltCode);
            cmd = new MySqlCommand(sql, conn);
            rdr = cmd.ExecuteReader();
            rdr.Read();
            pID2 = int.Parse(rdr["pID"].ToString());
          }
          catch (Exception ex) { }
          conn.Close();
        }
      }

      if (pNagCode != "NULL")
      {
        using (MySqlConnection conn = connectMySql())
        {
          try
          {
            conn.Open();
            sql = String.Format("SELECT pID FROM part WHERE pNagCode = {0};", pNagCode);
            cmd = new MySqlCommand(sql, conn);
            using (rdr = cmd.ExecuteReader())
            {
              rdr.Read();
              pID3 = int.Parse(rdr["pID"].ToString());
            }
          }
          catch (Exception ex) { }
          conn.Close();
        }
      }

      if (pID1 == 0 && pID2 == 0 && pID3 == 0)
      {
        using (MySqlConnection conn = connectMySql())
        {
          try
          {
            conn.Open();
            sql = "SELECT MAX(pID) FROM part;";
            cmd = new MySqlCommand(sql, conn);
            using (rdr = cmd.ExecuteReader())
            {
              rdr.Read();
              pID = int.Parse(rdr["MAX(pID)"].ToString()) + 1;
            }
          }
          catch (Exception ex)
          {

          }
          conn.Close();
        }
      }

      if (pID1 != 0 && pID2 != 0 && pID3 != 0)
      {
        if (pID1 == pID2 && pID1 == pID3)
        {
          pID = pID1;
        }
        else
        {
          errors += "- There are two different ID associated with these Part Codes. Please remove the non-main codes.\n";
        }
      }

      if (pID1 != 0 && pID2 != 0 && pID3 == 0)
      {
        if (pID1 == pID2)
        {
          pID = pID1;
        }
        else
        {
          errors += "- There are different IDs associated with these Part Codes. Please select which ID should be used.\n";
        }
      }

      if (pID1 != 0 && pID2 == 0 && pID3 != 0)
      {
        if (pID1 == pID3)
        {
          pID = pID1;
        }
        else
        {
          errors += "- There are different IDs associated with these Part Codes. Please select which ID should be used.\n";
        }
      }

      if (pID1 == 0 && pID2 != 0 && pID3 != 0)
      {
        if (pID2 == pID3)
        {
          pID = pID2;
        }
        else
        {
          errors += "- There are different IDs associated with these Part Codes. Please select which ID should be used.\n";
        }
      }

      if (pID1 != 0 && pID2 == 0 && pID3 == 0)
      {
        pID = pID1;
      }

      if (pID1 == 0 && pID2 != 0 && pID3 == 0)
      {
        pID = pID2;
      }

      if (pID1 == 0 && pID2 == 0 && pID3 != 0)
      {
        pID = pID3;
      }


      if (errors == "")
      {
        if (buyText.Text == "" || sellText.Text == "")
        {
          DialogResult dr = MessageBox.Show("WARNING!!\n\n" +
              "Are you sure you want to add a product with missing Pricing information?\n\n" +
              "Products with missing pricing info will need to be entered in later.",
              "WARNING", MessageBoxButtons.YesNo);

          if (dr == DialogResult.No)
          {
            return;
          }
        }
        if (pID != 0)
        {
          sql = String.Format("INSERT INTO part VALUES ({0}, {1}, {2}, {3}, {4}, '{5}', {6}, {7}, {8}, {9}, false);",
              pID, pType.ToUpper(), pCode, pAltCode, pNagCode, GWMS.StaffID, "NULL", pDesc,
              buyPrice, sellPrice);
          executeSQL(sql, false);

          sql = String.Format("UPDATE part SET pCode={0}, pAltCode={1}, pNagCode={2}, pType={4}, buyPrice={5}, sellPrice={6} " +
              "WHERE pId = {3};", pCode, pAltCode, pNagCode, pID, pType.ToUpper(), buyPrice, sellPrice);
          executeSQL(sql, false);
        }
        else
        {
          MessageBox.Show("No Part was found. Make sure the fields are properly filled out");
        }

        if ((errors == ""))
        {

          this.Close();
        }
      }
      else
      {
        MessageBox.Show(errors);
      }
    }

    private void ViewJobForm_Resize(object sender, EventArgs e)
    {

    }

    private void partModelLabel_Click(object sender, EventArgs e)
    {

    }

    private void partTypeCombo_Click(object sender, EventArgs e)
    {

    }

    private void partTypeCombo_TextChanged(object sender, EventArgs e)
    {
      if (partTypeCombo.Text == "CHIP")
      {
        //nagCodeText.Enabled = false;
        //altCodeText.Enabled = false;
        //partLabel.Text = "Chip Amount";
        //partCodeText.Text = "CR";
      }
      else
      {
        //nagCodeText.Enabled = true;
        //altCodeText.Enabled = true;
        //partLabel.Text = "PartCode (Eurocode)";
        //partCodeText.Text = "";
      }
    }
  }
}
