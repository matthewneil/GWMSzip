﻿using System;
using System.IO;
using System.Windows.Forms;

namespace workshop_orders
{
    partial class ViewPartsForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
      this.components = new System.ComponentModel.Container();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
      this.refreshButton = new System.Windows.Forms.Button();
      this.dataGridView1 = new System.Windows.Forms.DataGridView();
      this.addPartButton = new System.Windows.Forms.Button();
      this.dataGridView3 = new System.Windows.Forms.DataGridView();
      this.label1 = new System.Windows.Forms.Label();
      this.dataGridView2 = new System.Windows.Forms.DataGridView();
      this.label2 = new System.Windows.Forms.Label();
      this.label3 = new System.Windows.Forms.Label();
      this.stockSearchText = new System.Windows.Forms.TextBox();
      this.label4 = new System.Windows.Forms.Label();
      this.Stock = new System.Windows.Forms.TabControl();
      this.tabPage7 = new System.Windows.Forms.TabPage();
      this.label7 = new System.Windows.Forms.Label();
      this.label6 = new System.Windows.Forms.Label();
      this.label5 = new System.Windows.Forms.Label();
      this.recentDataGrid = new System.Windows.Forms.DataGridView();
      this.onDataGrid = new System.Windows.Forms.DataGridView();
      this.notDataGrid = new System.Windows.Forms.DataGridView();
      this.tabPage4 = new System.Windows.Forms.TabPage();
      this.dataGridView4 = new System.Windows.Forms.DataGridView();
      this.tabPage5 = new System.Windows.Forms.TabPage();
      this.dataGridView5 = new System.Windows.Forms.DataGridView();
      this.tabPage6 = new System.Windows.Forms.TabPage();
      this.autoDataGrid = new System.Windows.Forms.DataGridView();
      this.tabPage1 = new System.Windows.Forms.TabPage();
      this.tabPage2 = new System.Windows.Forms.TabPage();
      this.tabPage3 = new System.Windows.Forms.TabPage();
      this.comboBox1 = new System.Windows.Forms.ComboBox();
      this.checkBox1 = new System.Windows.Forms.CheckBox();
      this.checkBox2 = new System.Windows.Forms.CheckBox();
      this.checkBox3 = new System.Windows.Forms.CheckBox();
      this.refreshNotify = new System.Windows.Forms.Timer(this.components);
      this.creditNotify = new System.Windows.Forms.PictureBox();
      this.autoNotify = new System.Windows.Forms.PictureBox();
      ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
      this.Stock.SuspendLayout();
      this.tabPage7.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.recentDataGrid)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.onDataGrid)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.notDataGrid)).BeginInit();
      this.tabPage4.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
      this.tabPage5.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
      this.tabPage6.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.autoDataGrid)).BeginInit();
      this.tabPage1.SuspendLayout();
      this.tabPage2.SuspendLayout();
      this.tabPage3.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.creditNotify)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.autoNotify)).BeginInit();
      this.SuspendLayout();
      // 
      // refreshButton
      // 
      this.refreshButton.BackColor = System.Drawing.Color.White;
      this.refreshButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.refreshButton.Location = new System.Drawing.Point(607, 11);
      this.refreshButton.Margin = new System.Windows.Forms.Padding(4);
      this.refreshButton.Name = "refreshButton";
      this.refreshButton.Size = new System.Drawing.Size(203, 37);
      this.refreshButton.TabIndex = 22;
      this.refreshButton.Text = "Refresh";
      this.refreshButton.UseVisualStyleBackColor = false;
      this.refreshButton.Click += new System.EventHandler(this.refreshButton_Click);
      // 
      // dataGridView1
      // 
      dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
      this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
      this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
      this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dataGridView1.Location = new System.Drawing.Point(7, 7);
      this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
      this.dataGridView1.Name = "dataGridView1";
      this.dataGridView1.Size = new System.Drawing.Size(1858, 878);
      this.dataGridView1.TabIndex = 26;
      this.dataGridView1.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentDoubleClick);
      this.dataGridView1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
      // 
      // addPartButton
      // 
      this.addPartButton.BackColor = System.Drawing.Color.White;
      this.addPartButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.addPartButton.Location = new System.Drawing.Point(397, 11);
      this.addPartButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
      this.addPartButton.Name = "addPartButton";
      this.addPartButton.Size = new System.Drawing.Size(203, 37);
      this.addPartButton.TabIndex = 34;
      this.addPartButton.Text = "Add Product";
      this.addPartButton.UseVisualStyleBackColor = false;
      this.addPartButton.Click += new System.EventHandler(this.addPartButton_Click);
      // 
      // dataGridView3
      // 
      dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
      this.dataGridView3.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle8;
      this.dataGridView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
      this.dataGridView3.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dataGridView3.Location = new System.Drawing.Point(7, 7);
      this.dataGridView3.Margin = new System.Windows.Forms.Padding(4);
      this.dataGridView3.Name = "dataGridView3";
      this.dataGridView3.ReadOnly = true;
      this.dataGridView3.Size = new System.Drawing.Size(1858, 880);
      this.dataGridView3.TabIndex = 35;
      this.dataGridView3.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellContentDoubleClick);
      this.dataGridView3.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellDoubleClick);
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(688, 438);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(99, 16);
      this.label1.TabIndex = 36;
      this.label1.Text = "Parts Allocated";
      // 
      // dataGridView2
      // 
      dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
      this.dataGridView2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle9;
      this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
      this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dataGridView2.Location = new System.Drawing.Point(7, 7);
      this.dataGridView2.Margin = new System.Windows.Forms.Padding(4);
      this.dataGridView2.Name = "dataGridView2";
      this.dataGridView2.Size = new System.Drawing.Size(1858, 878);
      this.dataGridView2.TabIndex = 37;
      this.dataGridView2.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentDoubleClick);
      this.dataGridView2.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellDoubleClick);
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Location = new System.Drawing.Point(146, 376);
      this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(123, 16);
      this.label2.TabIndex = 38;
      this.label2.Text = "Parts Not Allocated";
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Location = new System.Drawing.Point(167, 217);
      this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(42, 16);
      this.label3.TabIndex = 39;
      this.label3.Text = "Stock";
      // 
      // stockSearchText
      // 
      this.stockSearchText.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
      this.stockSearchText.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
      this.stockSearchText.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
      this.stockSearchText.Location = new System.Drawing.Point(156, 16);
      this.stockSearchText.Name = "stockSearchText";
      this.stockSearchText.Size = new System.Drawing.Size(226, 22);
      this.stockSearchText.TabIndex = 40;
      this.stockSearchText.TextChanged += new System.EventHandler(this.stockSearchText_TextChanged);
      // 
      // label4
      // 
      this.label4.AutoSize = true;
      this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label4.Location = new System.Drawing.Point(18, 16);
      this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(70, 24);
      this.label4.TabIndex = 41;
      this.label4.Text = "Search";
      // 
      // Stock
      // 
      this.Stock.Controls.Add(this.tabPage7);
      this.Stock.Controls.Add(this.tabPage4);
      this.Stock.Controls.Add(this.tabPage5);
      this.Stock.Controls.Add(this.tabPage6);
      this.Stock.Controls.Add(this.tabPage1);
      this.Stock.Controls.Add(this.tabPage2);
      this.Stock.Controls.Add(this.tabPage3);
      this.Stock.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.Stock.Location = new System.Drawing.Point(12, 53);
      this.Stock.Name = "Stock";
      this.Stock.SelectedIndex = 0;
      this.Stock.Size = new System.Drawing.Size(1880, 920);
      this.Stock.TabIndex = 42;
      this.Stock.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
      // 
      // tabPage7
      // 
      this.tabPage7.Controls.Add(this.label7);
      this.tabPage7.Controls.Add(this.label6);
      this.tabPage7.Controls.Add(this.label5);
      this.tabPage7.Controls.Add(this.recentDataGrid);
      this.tabPage7.Controls.Add(this.onDataGrid);
      this.tabPage7.Controls.Add(this.notDataGrid);
      this.tabPage7.Location = new System.Drawing.Point(4, 24);
      this.tabPage7.Name = "tabPage7";
      this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
      this.tabPage7.Size = new System.Drawing.Size(1872, 892);
      this.tabPage7.TabIndex = 6;
      this.tabPage7.Text = "Orders";
      this.tabPage7.UseVisualStyleBackColor = true;
      // 
      // label7
      // 
      this.label7.AutoSize = true;
      this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label7.Location = new System.Drawing.Point(1499, 11);
      this.label7.Name = "label7";
      this.label7.Size = new System.Drawing.Size(164, 24);
      this.label7.TabIndex = 5;
      this.label7.Text = "Recently Arrived";
      // 
      // label6
      // 
      this.label6.AutoSize = true;
      this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label6.Location = new System.Drawing.Point(911, 11);
      this.label6.Name = "label6";
      this.label6.Size = new System.Drawing.Size(98, 24);
      this.label6.TabIndex = 4;
      this.label6.Text = "On Order";
      // 
      // label5
      // 
      this.label5.AutoSize = true;
      this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label5.Location = new System.Drawing.Point(240, 11);
      this.label5.Name = "label5";
      this.label5.Size = new System.Drawing.Size(126, 24);
      this.label5.TabIndex = 3;
      this.label5.Text = "Not Ordered";
      // 
      // recentDataGrid
      // 
      this.recentDataGrid.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      this.recentDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.recentDataGrid.Location = new System.Drawing.Point(1294, 42);
      this.recentDataGrid.Name = "recentDataGrid";
      this.recentDataGrid.Size = new System.Drawing.Size(561, 844);
      this.recentDataGrid.TabIndex = 2;
      // 
      // onDataGrid
      // 
      this.onDataGrid.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      this.onDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.onDataGrid.Location = new System.Drawing.Point(650, 42);
      this.onDataGrid.Name = "onDataGrid";
      this.onDataGrid.Size = new System.Drawing.Size(638, 844);
      this.onDataGrid.TabIndex = 1;
      // 
      // notDataGrid
      // 
      this.notDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
      this.notDataGrid.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      this.notDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.notDataGrid.Location = new System.Drawing.Point(6, 42);
      this.notDataGrid.Name = "notDataGrid";
      this.notDataGrid.Size = new System.Drawing.Size(638, 844);
      this.notDataGrid.TabIndex = 0;

      // 
      // tabPage4
      // 
      this.tabPage4.Controls.Add(this.dataGridView4);
      this.tabPage4.Location = new System.Drawing.Point(4, 24);
      this.tabPage4.Name = "tabPage4";
      this.tabPage4.Size = new System.Drawing.Size(1872, 892);
      this.tabPage4.TabIndex = 3;
      this.tabPage4.Text = "Order List";
      this.tabPage4.UseVisualStyleBackColor = true;
      // 
      // dataGridView4
      // 
      dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
      this.dataGridView4.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle10;
      this.dataGridView4.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
      this.dataGridView4.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dataGridView4.Location = new System.Drawing.Point(7, 7);
      this.dataGridView4.Margin = new System.Windows.Forms.Padding(4);
      this.dataGridView4.Name = "dataGridView4";
      this.dataGridView4.Size = new System.Drawing.Size(1858, 878);
      this.dataGridView4.TabIndex = 27;
      this.dataGridView4.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView4_CellDoubleClick);
      // 
      // tabPage5
      // 
      this.tabPage5.Controls.Add(this.dataGridView5);
      this.tabPage5.Location = new System.Drawing.Point(4, 24);
      this.tabPage5.Name = "tabPage5";
      this.tabPage5.Size = new System.Drawing.Size(1872, 892);
      this.tabPage5.TabIndex = 4;
      this.tabPage5.Text = "Credit Returns";
      this.tabPage5.UseVisualStyleBackColor = true;
      // 
      // dataGridView5
      // 
      dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
      this.dataGridView5.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle11;
      this.dataGridView5.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
      this.dataGridView5.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dataGridView5.Location = new System.Drawing.Point(7, 7);
      this.dataGridView5.Margin = new System.Windows.Forms.Padding(4);
      this.dataGridView5.Name = "dataGridView5";
      this.dataGridView5.Size = new System.Drawing.Size(1858, 878);
      this.dataGridView5.TabIndex = 28;
      this.dataGridView5.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView5_CellClick);
      this.dataGridView5.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView5_CellDoubleClick);
      // 
      // tabPage6
      // 
      this.tabPage6.Controls.Add(this.autoDataGrid);
      this.tabPage6.Location = new System.Drawing.Point(4, 24);
      this.tabPage6.Name = "tabPage6";
      this.tabPage6.Size = new System.Drawing.Size(1872, 892);
      this.tabPage6.TabIndex = 5;
      this.tabPage6.Text = "Auto Allocated";
      this.tabPage6.UseVisualStyleBackColor = true;
      // 
      // autoDataGrid
      // 
      dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
      this.autoDataGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle12;
      this.autoDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
      this.autoDataGrid.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      this.autoDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.autoDataGrid.Location = new System.Drawing.Point(7, 7);
      this.autoDataGrid.Margin = new System.Windows.Forms.Padding(4);
      this.autoDataGrid.Name = "autoDataGrid";
      this.autoDataGrid.Size = new System.Drawing.Size(1858, 878);
      this.autoDataGrid.TabIndex = 29;
      this.autoDataGrid.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.autoDataGrid_CellDoubleClick);
      // 
      // tabPage1
      // 
      this.tabPage1.Controls.Add(this.dataGridView1);
      this.tabPage1.Location = new System.Drawing.Point(4, 24);
      this.tabPage1.Name = "tabPage1";
      this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
      this.tabPage1.Size = new System.Drawing.Size(1872, 892);
      this.tabPage1.TabIndex = 0;
      this.tabPage1.Text = "Allocated Stock";
      this.tabPage1.UseVisualStyleBackColor = true;
      // 
      // tabPage2
      // 
      this.tabPage2.Controls.Add(this.dataGridView3);
      this.tabPage2.Location = new System.Drawing.Point(4, 24);
      this.tabPage2.Name = "tabPage2";
      this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
      this.tabPage2.Size = new System.Drawing.Size(1872, 892);
      this.tabPage2.TabIndex = 1;
      this.tabPage2.Text = "Quantities";
      this.tabPage2.UseVisualStyleBackColor = true;
      // 
      // tabPage3
      // 
      this.tabPage3.Controls.Add(this.dataGridView2);
      this.tabPage3.Location = new System.Drawing.Point(4, 24);
      this.tabPage3.Name = "tabPage3";
      this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
      this.tabPage3.Size = new System.Drawing.Size(1872, 892);
      this.tabPage3.TabIndex = 2;
      this.tabPage3.Text = "Unallocated Stock";
      this.tabPage3.UseVisualStyleBackColor = true;
      // 
      // comboBox1
      // 
      this.comboBox1.FormattingEnabled = true;
      this.comboBox1.Items.AddRange(new object[] {
            "Windscreen",
            "Mould",
            "Rearscreen",
            "Sideglass"});
      this.comboBox1.Location = new System.Drawing.Point(845, 20);
      this.comboBox1.Name = "comboBox1";
      this.comboBox1.Size = new System.Drawing.Size(180, 24);
      this.comboBox1.TabIndex = 43;
      this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
      // 
      // checkBox1
      // 
      this.checkBox1.AutoSize = true;
      this.checkBox1.Checked = true;
      this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
      this.checkBox1.Location = new System.Drawing.Point(1047, 21);
      this.checkBox1.Name = "checkBox1";
      this.checkBox1.Size = new System.Drawing.Size(74, 20);
      this.checkBox1.TabIndex = 44;
      this.checkBox1.Text = "In Stock";
      this.checkBox1.UseVisualStyleBackColor = true;
      // 
      // checkBox2
      // 
      this.checkBox2.AutoSize = true;
      this.checkBox2.Checked = true;
      this.checkBox2.CheckState = System.Windows.Forms.CheckState.Checked;
      this.checkBox2.Location = new System.Drawing.Point(1136, 21);
      this.checkBox2.Name = "checkBox2";
      this.checkBox2.Size = new System.Drawing.Size(121, 20);
      this.checkBox2.TabIndex = 45;
      this.checkBox2.Text = "Allocated Stock";
      this.checkBox2.UseVisualStyleBackColor = true;
      // 
      // checkBox3
      // 
      this.checkBox3.AutoSize = true;
      this.checkBox3.Location = new System.Drawing.Point(1280, 21);
      this.checkBox3.Name = "checkBox3";
      this.checkBox3.Size = new System.Drawing.Size(82, 20);
      this.checkBox3.TabIndex = 46;
      this.checkBox3.Text = "No Stock";
      this.checkBox3.UseVisualStyleBackColor = true;
      // 
      // refreshNotify
      // 
      this.refreshNotify.Enabled = true;
      this.refreshNotify.Interval = 30000;
      this.refreshNotify.Tick += new System.EventHandler(this.refreshNotify_Tick);
      // 
      // creditNotify
      // 
      this.creditNotify.BackColor = System.Drawing.Color.White;
      this.creditNotify.Image = global::workshop_orders.Properties.Resources.circle;
      this.creditNotify.Location = new System.Drawing.Point(156, 44);
      this.creditNotify.Name = "creditNotify";
      this.creditNotify.Size = new System.Drawing.Size(13, 13);
      this.creditNotify.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
      this.creditNotify.TabIndex = 47;
      this.creditNotify.TabStop = false;
      this.creditNotify.Visible = false;
      // 
      // autoNotify
      // 
      this.autoNotify.BackColor = System.Drawing.Color.White;
      this.autoNotify.Image = global::workshop_orders.Properties.Resources.circle;
      this.autoNotify.Location = new System.Drawing.Point(242, 44);
      this.autoNotify.Name = "autoNotify";
      this.autoNotify.Size = new System.Drawing.Size(23, 14);
      this.autoNotify.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
      this.autoNotify.TabIndex = 30;
      this.autoNotify.TabStop = false;
      this.autoNotify.Visible = false;
      // 
      // ViewPartsForm
      // 
      this.AllowDrop = true;
      this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.AutoScroll = true;
      this.BackColor = System.Drawing.Color.White;
      this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
      this.ClientSize = new System.Drawing.Size(1904, 1006);
      this.ControlBox = false;
      this.Controls.Add(this.creditNotify);
      this.Controls.Add(this.autoNotify);
      this.Controls.Add(this.checkBox3);
      this.Controls.Add(this.checkBox2);
      this.Controls.Add(this.checkBox1);
      this.Controls.Add(this.comboBox1);
      this.Controls.Add(this.Stock);
      this.Controls.Add(this.label4);
      this.Controls.Add(this.stockSearchText);
      this.Controls.Add(this.label3);
      this.Controls.Add(this.label2);
      this.Controls.Add(this.label1);
      this.Controls.Add(this.addPartButton);
      this.Controls.Add(this.refreshButton);
      this.Cursor = System.Windows.Forms.Cursors.Default;
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.Margin = new System.Windows.Forms.Padding(4);
      this.MaximizeBox = false;
      this.Name = "ViewPartsForm";
      this.ShowIcon = false;
      this.ShowInTaskbar = false;
      this.Text = "BMS - Stock";
      this.Load += new System.EventHandler(this.Form1_Load);
      this.Resize += new System.EventHandler(this.ViewJobForm_Resize);
      ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
      this.Stock.ResumeLayout(false);
      this.tabPage7.ResumeLayout(false);
      this.tabPage7.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.recentDataGrid)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.onDataGrid)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.notDataGrid)).EndInit();
      this.tabPage4.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
      this.tabPage5.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
      this.tabPage6.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.autoDataGrid)).EndInit();
      this.tabPage1.ResumeLayout(false);
      this.tabPage2.ResumeLayout(false);
      this.tabPage3.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.creditNotify)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.autoNotify)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

        }

        #endregion
        private Button refreshButton;
        private DataGridView dataGridView1;
        private Button addPartButton;
        private DataGridView dataGridView3;
        private Label label1;
        private DataGridView dataGridView2;
        private Label label2;
        private Label label3;
        private TextBox stockSearchText;
        private Label label4;
        private TabControl Stock;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private TabPage tabPage3;
        private TabPage tabPage4;
        private DataGridView dataGridView4;
        private TabPage tabPage5;
        private DataGridView dataGridView5;
        private ComboBox comboBox1;
        private CheckBox checkBox1;
        private CheckBox checkBox2;
        private CheckBox checkBox3;
        private TabPage tabPage6;
        private DataGridView autoDataGrid;
        private PictureBox autoNotify;
        private PictureBox creditNotify;
        private Timer refreshNotify;
        private TabPage tabPage7;
        private Label label7;
        private Label label6;
        private Label label5;
        private DataGridView recentDataGrid;
        private DataGridView onDataGrid;
        private DataGridView notDataGrid;
    }
}

