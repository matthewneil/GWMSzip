﻿
namespace workshop_orders
{
  partial class Home
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
      System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
      System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
      System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
      this.panel1 = new System.Windows.Forms.Panel();
      this.label2 = new System.Windows.Forms.Label();
      this.imgSales = new System.Windows.Forms.PictureBox();
      this.label1 = new System.Windows.Forms.Label();
      this.imgProduction = new System.Windows.Forms.PictureBox();
      this.btnProduction = new System.Windows.Forms.Button();
      this.btnNewJob = new System.Windows.Forms.Button();
      this.btnSearchJob = new System.Windows.Forms.Button();
      this.btnFindJob = new System.Windows.Forms.Button();
      this.txtFindJob = new System.Windows.Forms.TextBox();
      this.pnlProduction = new System.Windows.Forms.Panel();
      this.panel3 = new System.Windows.Forms.Panel();
      this.label3 = new System.Windows.Forms.Label();
      this.pnlSales = new System.Windows.Forms.Panel();
      this.pnlFindQuote = new System.Windows.Forms.Panel();
      this.label4 = new System.Windows.Forms.Label();
      this.txtFindQuote = new System.Windows.Forms.TextBox();
      this.btnFindQuote = new System.Windows.Forms.Button();
      this.btnNewQuote = new System.Windows.Forms.Button();
      this.btnManageQuote = new System.Windows.Forms.Button();
      this.chAutoCount = new System.Windows.Forms.DataVisualization.Charting.Chart();
      this.panel1.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.imgSales)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.imgProduction)).BeginInit();
      this.pnlProduction.SuspendLayout();
      this.panel3.SuspendLayout();
      this.pnlSales.SuspendLayout();
      this.pnlFindQuote.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.chAutoCount)).BeginInit();
      this.SuspendLayout();
      // 
      // panel1
      // 
      this.panel1.BackColor = System.Drawing.SystemColors.Control;
      this.panel1.Controls.Add(this.label2);
      this.panel1.Controls.Add(this.imgSales);
      this.panel1.Controls.Add(this.label1);
      this.panel1.Controls.Add(this.imgProduction);
      this.panel1.Location = new System.Drawing.Point(12, 12);
      this.panel1.Name = "panel1";
      this.panel1.Size = new System.Drawing.Size(206, 325);
      this.panel1.TabIndex = 1;
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label2.Location = new System.Drawing.Point(76, 167);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(49, 20);
      this.label2.TabIndex = 3;
      this.label2.Text = "Sales";
      // 
      // imgSales
      // 
      this.imgSales.BackgroundImage = global::workshop_orders.Properties.Resources.sales128;
      this.imgSales.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
      this.imgSales.Location = new System.Drawing.Point(17, 190);
      this.imgSales.Name = "imgSales";
      this.imgSales.Size = new System.Drawing.Size(175, 112);
      this.imgSales.TabIndex = 2;
      this.imgSales.TabStop = false;
      this.imgSales.Click += new System.EventHandler(this.imgSales_Click);
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label1.Location = new System.Drawing.Point(37, 11);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(136, 20);
      this.label1.TabIndex = 1;
      this.label1.Text = "Jobs + Production";
      // 
      // imgProduction
      // 
      this.imgProduction.BackgroundImage = global::workshop_orders.Properties.Resources.production;
      this.imgProduction.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
      this.imgProduction.Location = new System.Drawing.Point(17, 34);
      this.imgProduction.Name = "imgProduction";
      this.imgProduction.Size = new System.Drawing.Size(175, 112);
      this.imgProduction.TabIndex = 0;
      this.imgProduction.TabStop = false;
      this.imgProduction.Click += new System.EventHandler(this.imgProduction_Click);
      // 
      // btnProduction
      // 
      this.btnProduction.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnProduction.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnProduction.Image = global::workshop_orders.Properties.Resources.calendar_work32;
      this.btnProduction.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
      this.btnProduction.Location = new System.Drawing.Point(10, 12);
      this.btnProduction.Name = "btnProduction";
      this.btnProduction.Size = new System.Drawing.Size(190, 44);
      this.btnProduction.TabIndex = 2;
      this.btnProduction.Text = "Production Plan  ";
      this.btnProduction.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      this.btnProduction.UseVisualStyleBackColor = false;
      this.btnProduction.Click += new System.EventHandler(this.btnProduction_Click);
      // 
      // btnNewJob
      // 
      this.btnNewJob.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnNewJob.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnNewJob.Image = global::workshop_orders.Properties.Resources.addnew;
      this.btnNewJob.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
      this.btnNewJob.Location = new System.Drawing.Point(10, 62);
      this.btnNewJob.Name = "btnNewJob";
      this.btnNewJob.Size = new System.Drawing.Size(190, 44);
      this.btnNewJob.TabIndex = 3;
      this.btnNewJob.Text = "New Job          ";
      this.btnNewJob.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      this.btnNewJob.UseVisualStyleBackColor = false;
      this.btnNewJob.Click += new System.EventHandler(this.btnNewJob_Click);
      // 
      // btnSearchJob
      // 
      this.btnSearchJob.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnSearchJob.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnSearchJob.Image = global::workshop_orders.Properties.Resources.detail32;
      this.btnSearchJob.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
      this.btnSearchJob.Location = new System.Drawing.Point(10, 112);
      this.btnSearchJob.Name = "btnSearchJob";
      this.btnSearchJob.Size = new System.Drawing.Size(190, 44);
      this.btnSearchJob.TabIndex = 4;
      this.btnSearchJob.Text = "Search Job       ";
      this.btnSearchJob.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      this.btnSearchJob.UseVisualStyleBackColor = false;
      this.btnSearchJob.Click += new System.EventHandler(this.btnSearchJob_Click);
      // 
      // btnFindJob
      // 
      this.btnFindJob.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnFindJob.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnFindJob.Image = global::workshop_orders.Properties.Resources.find;
      this.btnFindJob.Location = new System.Drawing.Point(3, 4);
      this.btnFindJob.Name = "btnFindJob";
      this.btnFindJob.Size = new System.Drawing.Size(44, 44);
      this.btnFindJob.TabIndex = 5;
      this.btnFindJob.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      this.btnFindJob.UseVisualStyleBackColor = false;
      this.btnFindJob.Click += new System.EventHandler(this.btnFindJob_Click);
      // 
      // txtFindJob
      // 
      this.txtFindJob.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtFindJob.Location = new System.Drawing.Point(50, 21);
      this.txtFindJob.Name = "txtFindJob";
      this.txtFindJob.Size = new System.Drawing.Size(128, 24);
      this.txtFindJob.TabIndex = 6;
      // 
      // pnlProduction
      // 
      this.pnlProduction.BackColor = System.Drawing.SystemColors.Control;
      this.pnlProduction.Controls.Add(this.panel3);
      this.pnlProduction.Controls.Add(this.btnProduction);
      this.pnlProduction.Controls.Add(this.btnNewJob);
      this.pnlProduction.Controls.Add(this.btnSearchJob);
      this.pnlProduction.Location = new System.Drawing.Point(240, 12);
      this.pnlProduction.Name = "pnlProduction";
      this.pnlProduction.Size = new System.Drawing.Size(212, 230);
      this.pnlProduction.TabIndex = 7;
      this.pnlProduction.Visible = false;
      // 
      // panel3
      // 
      this.panel3.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.panel3.Controls.Add(this.label3);
      this.panel3.Controls.Add(this.txtFindJob);
      this.panel3.Controls.Add(this.btnFindJob);
      this.panel3.Location = new System.Drawing.Point(10, 165);
      this.panel3.Name = "panel3";
      this.panel3.Size = new System.Drawing.Size(190, 54);
      this.panel3.TabIndex = 8;
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label3.Location = new System.Drawing.Point(48, 3);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(65, 18);
      this.label3.TabIndex = 7;
      this.label3.Text = "Find Job";
      // 
      // pnlSales
      // 
      this.pnlSales.BackColor = System.Drawing.SystemColors.Control;
      this.pnlSales.Controls.Add(this.pnlFindQuote);
      this.pnlSales.Controls.Add(this.btnNewQuote);
      this.pnlSales.Controls.Add(this.btnManageQuote);
      this.pnlSales.Location = new System.Drawing.Point(240, 12);
      this.pnlSales.Name = "pnlSales";
      this.pnlSales.Size = new System.Drawing.Size(212, 176);
      this.pnlSales.TabIndex = 9;
      this.pnlSales.Visible = false;
      // 
      // pnlFindQuote
      // 
      this.pnlFindQuote.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.pnlFindQuote.Controls.Add(this.label4);
      this.pnlFindQuote.Controls.Add(this.txtFindQuote);
      this.pnlFindQuote.Controls.Add(this.btnFindQuote);
      this.pnlFindQuote.Location = new System.Drawing.Point(10, 112);
      this.pnlFindQuote.Name = "pnlFindQuote";
      this.pnlFindQuote.Size = new System.Drawing.Size(190, 53);
      this.pnlFindQuote.TabIndex = 8;
      // 
      // label4
      // 
      this.label4.AutoSize = true;
      this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label4.Location = new System.Drawing.Point(48, 3);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(81, 18);
      this.label4.TabIndex = 7;
      this.label4.Text = "Find Quote";
      // 
      // txtFindQuote
      // 
      this.txtFindQuote.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtFindQuote.Location = new System.Drawing.Point(50, 22);
      this.txtFindQuote.Name = "txtFindQuote";
      this.txtFindQuote.Size = new System.Drawing.Size(128, 24);
      this.txtFindQuote.TabIndex = 6;
      // 
      // btnFindQuote
      // 
      this.btnFindQuote.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnFindQuote.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnFindQuote.Image = global::workshop_orders.Properties.Resources.find;
      this.btnFindQuote.Location = new System.Drawing.Point(3, 4);
      this.btnFindQuote.Name = "btnFindQuote";
      this.btnFindQuote.Size = new System.Drawing.Size(44, 44);
      this.btnFindQuote.TabIndex = 5;
      this.btnFindQuote.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      this.btnFindQuote.UseVisualStyleBackColor = false;
      this.btnFindQuote.Click += new System.EventHandler(this.btnFindQuote_Click);
      // 
      // btnNewQuote
      // 
      this.btnNewQuote.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnNewQuote.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnNewQuote.Image = global::workshop_orders.Properties.Resources.addnew;
      this.btnNewQuote.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
      this.btnNewQuote.Location = new System.Drawing.Point(10, 62);
      this.btnNewQuote.Name = "btnNewQuote";
      this.btnNewQuote.Size = new System.Drawing.Size(190, 44);
      this.btnNewQuote.TabIndex = 3;
      this.btnNewQuote.Text = "New Quote         ";
      this.btnNewQuote.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      this.btnNewQuote.UseVisualStyleBackColor = false;
      this.btnNewQuote.Click += new System.EventHandler(this.btnNewQuote_Click);
      // 
      // btnManageQuote
      // 
      this.btnManageQuote.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnManageQuote.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnManageQuote.Image = global::workshop_orders.Properties.Resources.product32;
      this.btnManageQuote.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
      this.btnManageQuote.Location = new System.Drawing.Point(10, 12);
      this.btnManageQuote.Name = "btnManageQuote";
      this.btnManageQuote.Size = new System.Drawing.Size(190, 44);
      this.btnManageQuote.TabIndex = 4;
      this.btnManageQuote.Text = "Manage Quotes   ";
      this.btnManageQuote.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      this.btnManageQuote.UseVisualStyleBackColor = false;
      this.btnManageQuote.Click += new System.EventHandler(this.btnSearchQuote_Click);
      // 
      // chAutoCount
      // 
      chartArea1.AxisX.Title = "Month";
      chartArea1.AxisY.Title = "Count";
      chartArea1.Name = "ChartArea1";
      this.chAutoCount.ChartAreas.Add(chartArea1);
      legend1.Name = "Legend1";
      this.chAutoCount.Legends.Add(legend1);
      this.chAutoCount.Location = new System.Drawing.Point(449, 610);
      this.chAutoCount.Name = "chAutoCount";
      series1.ChartArea = "ChartArea1";
      series1.Legend = "Legend1";
      series1.Name = "Auto";
      series2.ChartArea = "ChartArea1";
      series2.Legend = "Legend1";
      series2.Name = "Glass";
      this.chAutoCount.Series.Add(series1);
      this.chAutoCount.Series.Add(series2);
      this.chAutoCount.Size = new System.Drawing.Size(845, 221);
      this.chAutoCount.TabIndex = 10;
      this.chAutoCount.Text = "chart1";
      // 
      // Home
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.ClientSize = new System.Drawing.Size(1787, 881);
      this.Controls.Add(this.chAutoCount);
      this.Controls.Add(this.pnlSales);
      this.Controls.Add(this.pnlProduction);
      this.Controls.Add(this.panel1);
      this.Name = "Home";
      this.Text = "Home";
      this.panel1.ResumeLayout(false);
      this.panel1.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.imgSales)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.imgProduction)).EndInit();
      this.pnlProduction.ResumeLayout(false);
      this.panel3.ResumeLayout(false);
      this.panel3.PerformLayout();
      this.pnlSales.ResumeLayout(false);
      this.pnlFindQuote.ResumeLayout(false);
      this.pnlFindQuote.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.chAutoCount)).EndInit();
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.PictureBox imgProduction;
    private System.Windows.Forms.Panel panel1;
    private System.Windows.Forms.PictureBox imgSales;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Button btnProduction;
    private System.Windows.Forms.Button btnNewJob;
    private System.Windows.Forms.Button btnSearchJob;
    private System.Windows.Forms.Button btnFindJob;
    private System.Windows.Forms.TextBox txtFindJob;
    private System.Windows.Forms.Panel pnlProduction;
    private System.Windows.Forms.Panel panel3;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.Panel pnlSales;
    private System.Windows.Forms.Panel pnlFindQuote;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.TextBox txtFindQuote;
    private System.Windows.Forms.Button btnFindQuote;
    private System.Windows.Forms.Button btnNewQuote;
    private System.Windows.Forms.Button btnManageQuote;
    private System.Windows.Forms.DataVisualization.Charting.Chart chAutoCount;
  }
}