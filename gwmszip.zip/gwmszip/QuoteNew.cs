﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workshop_orders
{
  public partial class QuoteNew : Form
  {
    public static int CustomerID = -1;


    public static int partID;
    private int timepos = 0;


    public bool _load = true;
    public QuoteNew()
    {
      InitializeComponent();
      DisplaySection();
      LoadJobTypes();

      CustomerID = -1;

      _load = false;
      SetButtonState(DataAccess.FormState(this.AccessibilityObject.Name, tsSave));
    }

    private void SetButtonState(Boolean bState)
    {
      btnSave.Visible = bState;
    }


    private void LoadJobTypes()
    {

      DataTable dt = DataAccess.ExecuteDataTable(
        "SELECT TypeID AS datafield, TypeName AS textfield FROM JobType WHERE TypeGroup = 'Quote' ORDER BY TypeName");
      //DataAccess.AddSelect(dt);
      cmbType.DataSource = dt;
      //cmbType.Items.Add("Basic Quote");
      cmbType.SelectedIndex = cmbType.FindString("Retrofit");

    }



    private void LoadCustomerFromID()
    {
      if (CustomerID > 0)
      {
        DataTable dt = DataAccess.ExecuteDataTable(
          "SELECT * FROM customer WHERE CustomerID = " + CustomerID);
        txtCustomer.Text = dt.Rows[0]["CustomerName"].ToString();

        DataTable dtVehicle = DataAccess.ExecuteDataTable(
          "SELECT v.VehicleID, v.Registration, v.vMake, v.vModel, v.vYear FROM Vehicle v " +
          "INNER JOIN job j ON v.VehicleID = j.VehicleID " +
          "WHERE CustomerID = " + CustomerID);

      }
      else
      {
        txtCustomer.Text = "";
      }
    }



    private void ValidateType()
    {
      if (_load) return;

      rbType.ForeColor = Color.Lime;
    }

    private void ValidateCustomer()
    {
      if (_load) return;

      if (CustomerID > 0)
      {
        rbCustomer.ForeColor = Color.Lime;
      }
      else
      {
        rbCustomer.ForeColor = Color.Yellow;
      }
    }

 
    private void ValidateNote()
    {
      if (_load) return;
      if (txtReference.Text != "" || txtNote.Text != "")
      {
        rbReference.ForeColor = Color.Lime;
      }
      else
      {
        rbReference.ForeColor = Color.Yellow;
      }

    }
    private void ValidateItem()
    {


    }

    private void DisplaySection()
    {
      tsPrevious.Enabled = true;
      tsNext.Enabled = true;
      if (rbType.Checked)
      {
        gbType.BringToFront();     
      }
      else if (rbCustomer.Checked)
      {
        gbCustomer.BringToFront();
        tsPrevious.Enabled = false;
      }
      else if (rbReference.Checked)
      {
        gbReference.BringToFront();
      }

    }


    private void rbType_CheckedChanged(object sender, EventArgs e)
    {
      DisplaySection();
      ValidateType();
    }

    private void rbCustomer_CheckedChanged(object sender, EventArgs e)
    {
      DisplaySection();
      ValidateCustomer();
    }


    private void rbReference_CheckedChanged(object sender, EventArgs e)
    {
      DisplaySection();
      ValidateNote();
    }



    private void tsPrevious_Click(object sender, EventArgs e)
    {
      if (rbType.Checked)
      {
        rbCustomer.Checked = true;
      }
      else if (rbReference.Checked)
      {
        rbType.Checked = true;
        tsNext.Visible = true;
        tsSave.Visible = false;
      }

    }

    private void tsNext_Click(object sender, EventArgs e)
    {
      if (rbCustomer.Checked)
      {
        if (CustomerID < 1)
        {
          DataAccess.ShowMessage("You must select a customer first!");
        }
        else
        {
          rbType.Checked = true;
          btnSave.Enabled = true;
          
        }
      }
      else if (rbType.Checked)
      {
        rbReference.Checked = true;
        tsNext.Visible = false;
        tsSave.Visible = true;
      }


    }





    private void btnCustomer_Click(object sender, EventArgs e)
    {
      SearchCustomer form = new SearchCustomer(CustomerID, 4);
      FormManagement.ShowDialogForm(form);

      if(CustomerID > 0)
      {
        LoadCustomerFromID();
        EnableRadioOnPanel(true);
      }
      else
      {
        txtCustomer.Text = "";
      }
      ValidateCustomer();
    }






    private void txtReference_TextChanged(object sender, EventArgs e)
    {
      ValidateNote();
    }

    private void txtNote_TextChanged(object sender, EventArgs e)
    {
      ValidateNote();
    }

 
    private void SaveJob()
    {
      String warnings = "Before creating this job, please review the following warnings:\n\n";

      warnings += "\nAre you sure you want to continue?";

      if (warnings != "Before creating this job, please review the following warnings:\n\n\nAre you sure you want to continue?")
      {
        bool save = DataAccess.ShowMessage(warnings, "Warning", true);
        if (!save) return;
      }

      //Add Quote data
      DataAccess.QuoteManage(0, cmbType.Text, txtReference.Text, CustomerID, GWMS.StaffID, 1, 0, 1, 8, 1, txtNote.Text, 0, "");

      if (cmbType.Text == "Basic Quote")
      {
        int quoteno = DataAccess.ExecuteScalarInt("SELECT MAX(quoteno) FROM Quote");

        DataAccess.ExecuteNonQuery("INSERT INTO quoteitemgroup (quoteno, GroupName) VALUES (" + quoteno + ", 'Basic Quote')");
        int itemgroupID = DataAccess.ExecuteScalarInt("SELECT MAX(quoteitemgroupID) FROM quoteitemgroup WHERE quoteno = " + quoteno + " AND GroupName = 'Basic Quote'");

        int iLinkID = DataAccess.ExecuteScalarInt("SELECT MAX(quoteitemID) FROM quoteitems") + 1;
        DataAccess.QuoteItemManage(quoteno, 0, 0, 1, 0, 0, 0, nudCost.Value, nudPrice.Value, itemgroupID, iLinkID, "Basic Quote", txtBasicDescription.Text);
      }

      DataAccess.ShowMessage("Quote saved successfully");
      int maxID = DataAccess.ExecuteScalarInt("SELECT MAX(QuoteNo) FROM Quote;");
      if (maxID > 0)
      {
        FormManagement.ShowChildForm(new QuoteDetail(maxID, null));
      }
      this.Close();
    }
    private void btnSave_Click(object sender, EventArgs e)
    {
      SaveJob();
    }

    private void button2_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private void EnableRadioOnPanel(bool enabled)
    {
      rbCustomer.Enabled = enabled;
      rbType.Enabled = enabled;

      rbReference.Enabled = enabled;
    }


    private void tsSave_Click_1(object sender, EventArgs e)
    {
      SaveJob();
    }

    private void cmbType_SelectedIndexChanged(object sender, EventArgs e)
    {
      if(cmbType.Text == "Basic Quote")
      {
        gbBasic.Visible = true;
      }
      else
      {
        gbBasic.Visible = false;
        txtBasicDescription.Text = "";
        nudCost.Value = 0;
        nudPrice.Value = 0;
      }
    }

    private void label2_Click(object sender, EventArgs e)
    {

    }
  }
}
