﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace workshop_orders
{
  /*A form for adding a customer to the database, so their details can be retrieved if they were to come back.
   */
  public partial class JobItem : Form
  {
    public int quoteNo = -1;
    public int vehicleID = -1;
    private int itemID = -1;
    private bool update = true;

    public static decimal quantity = -1;
    public static int ItemStockID = -1;

    private int type = 1; // 1 = Job, 2 = Basic Quote
    public static BasicQuote frm;

    public JobItem(int type)
    {
      this.type = type;
      InitializeComponent();
      SearchItems();

      if (type == 2)
      {
        btnAddItem.Visible = false;
        btnRemoveItem.Visible = false;
        gbItemsAdded.Visible = false;
        this.Width = 705;
      }
      DataAccess.FormState(this.AccessibilityObject.Name, tsSave);
    }

  private void CreateJobForm_Load(object sender, EventArgs e)
    {
      if (quoteNo > 0)
      {
        tsCreateJob.Text = "Update Job";
      }
      
      LoadItemGroup();
      SearchItems();
    }

    private void SearchItems()
    {
      if (txtSearch.Text == "")
      {
        lblItem.Text = "Please type in the search bar above to get item results";
        if (vehicleID > -1)
        {
          
          lblItem.Text = "Items used with this Vehicle Previously:";
          String sql = String.Format("SELECT c.ItemCostID, Cost, igSubGroup, icCode, icDescription, s.quantity, icCost FROM itemcost c " +
            "INNER JOIN itemgroup ig ON c.ItemGroupID = ig.ItemGroupID " +
            "INNER JOIN JobItem i ON c.ItemCostID = i.ItemCostID " +
            "INNER JOIN job j ON i.JobID = j.JobID " +
            "LEFT JOIN itemstock s ON c.ItemCostID = s.ItemCostID " +
            "LEFT JOIN itemcode ic ON ic.LinkID = c.ItemCostID " +
            "WHERE VehicleID = {0} GROUP BY ItemCostID ORDER BY icCode;", vehicleID);
          DataTable dt = DataAccess.ExecuteDataTable(sql);
          dgvItems.DataSource = dt;

        }
        return;
      }

      lblItem.Text = "Search Results:";
      itemID = 0;
      update = true;
     
      try
      {
        String sql = null;

        this.itemID = 0;

        gbResult.Visible = true;

        String group = cmbField.SelectedValue.ToString();
        if (group == "-1")
        {
          group = "%";
        }

            sql = String.Format("SELECT ic.ItemCostID, c.Code, igSubGroup, icCode, icDescription, s.quantity, icCost FROM itemcost ic " +
              "INNER JOIN itemgroup ig ON ic.ItemGroupID = ig.ItemGroupID " +
              "LEFT JOIN itemcode c ON c.LinkID = ic.ItemCostID " +
              "LEFT JOIN itemstock s ON ic.ItemCostID = s.ItemCostID " + 
              "WHERE (icCode LIKE '{0}%' OR c.Code LIKE '{0}%') AND ic.ItemCostID > 0 and igSubGroup LIKE '{1}';", txtSearch.Text, group);


        if (sql != null)
        {
          DataTable dt = DataAccess.ExecuteDataTable(sql);
          dgvItems.DataSource = dt;

          int amount = dgvItems.Rows.Count;
          if (amount == 0)
          {
            //DataAccess.ShowMessage("No Items Found. Please change your selection or add new item.");
          }
          else if (amount == 1)
          {
            //searchText.Text = rdr["cSurname"].ToString();
            //LoadCustomer(rdr["cID"].ToString());
          }
        }
      }
      catch (Exception ex)
      {
        DataAccess.ShowMessage("Error: Couldn't fetch customer data.");
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                  System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }

    }

    public void LoadItemGroup()
    {
      DataTable dt = DataAccess.ExecuteDataTable(
        "SELECT igSubGroup AS datafield, igSubGroup AS textfield FROM ItemGroup GROUP BY igSubGroup ORDER BY igDescription");
      DataAccess.AddSelect(dt);
      cmbField.DataSource = dt;
    }

    private void textBox1_TextChanged(object sender, EventArgs e)
    {
      SearchItems();
    }

    private void toolStripButton1_Click_1(object sender, EventArgs e)
    {
      this.Close();
    }

   

    private void addtoolStripButton_Click(object sender, EventArgs e)
    {
      ItemEdit frm = new ItemEdit(0);
      frm.ShowDialog();
    }

    private void saveToolStripButton2_Click(object sender, EventArgs e)
    {
      SaveItems();
    }

    private void SaveItems()
    {
      foreach (DataGridViewRow row in dgvItemsAdded.Rows)
      {
        int i = 0;
        int itemstatus = 12; //not ordered
        if ((int)row.Cells["chItemStockID"].Value != -1) itemstatus = 16; //Reservation
        if (itemstatus == 16)
        {
          DataAccess.ItemMovementManage((int)row.Cells["chItemStockID"].Value, 4, -1, DataAccess.InternalIDType.Job, 1, 0, "Allocated to Job: ", 0);
        }
        while (i < (decimal)row.Cells["chQuantity"].Value)
        {
          DataAccess.JobItemManage(0, (int)row.Cells[0].Value, quoteNo, itemstatus, 0, 0, (int)row.Cells["chItemStockID"].Value);
          i++;
        }
        
      }

      DataAccess.ShowMessage("Items successfully added to job.");
      this.Close();
    }

    private void customerDataGrid_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      AddItem();

    }
    
    private void AddItem()
    {
      if (dgvItems.SelectedRows.Count > 0 && dgvItems.SelectedRows[0].Index > -1)
      {
        ItemStockID = -1;
        quantity = -1;

        DataTable dtLocations = DataAccess.ExecuteDataTable("" +
         "SELECT s.ItemStockID, SUM(imQuantity) AS Quantity, LocationGroup, LocationSubGroup, LocationCode, LocationDescription " +
         "FROM itemstock s " +
         "INNER JOIN location l ON s.LocationID = l.LocationID " +
         "INNER JOIN itemmovement m ON s.ItemStockID = m.ItemStockID " +
         "WHERE ItemCostID = " + dgvItems.SelectedRows[0].Cells[0].Value + " " +
         "GROUP BY s.ItemStockID " +
         "HAVING SUM(imQuantity) > 0 " +
         "ORDER BY LocationGroup, LocationSubGroup, LocationCode ");

        if(dtLocations != null && dtLocations.Rows.Count > 0)
        {
          new SelectLocation((int)dgvItems.SelectedRows[0].Cells[0].Value).ShowDialog();
        }
        else
        {
          Quantity quantityfrm = new Quantity();
          quantityfrm.ShowDialog();
        }
        if (quantity > 0)
        {
          if (type == 1)
          {
            try
            {
              int changeqty = 0;
              if (dgvItems.SelectedRows[0].Cells[5].Value.ToString() != "") changeqty = int.Parse(dgvItems.SelectedRows[0].Cells[5].Value.ToString());

              dgvItems.SelectedRows[0].Cells[5].Value = changeqty - quantity;

              if (int.Parse(dgvItems.SelectedRows[0].Cells[5].Value.ToString()) < 0)
              {
                dgvItems.SelectedRows[0].Cells[5].Value = 0;
              }
              /*
              foreach (DataGridViewRow row in dgvItemsAdded.Rows) //Check if record is already in Added table, and add to quantity
              {
                if ((int)row.Cells[0].Value == (int)dgvItems.SelectedRows[0].Cells[0].Value)
                {
                  row.Cells[4].Value = (decimal)row.Cells[4].Value + quantity;
                  return;
                }
              }*/
              dgvItemsAdded.Rows.Add(dgvItems.SelectedRows[0].Cells[0].Value, ItemStockID, dgvItems.SelectedRows[0].Cells[1].Value, dgvItems.SelectedRows[0].Cells[2].Value, dgvItems.SelectedRows[0].Cells[3].Value, dgvItems.SelectedRows[0].Cells[4].Value, quantity);

            }
            catch (Exception ex)
            {
              DataAccess.ShowMessage("Failed to add item onto 'Items Added' section");
              DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                      System.Reflection.MethodBase.GetCurrentMethod().Name, "");
            }
          }
          else if (type == 2)
          {
            try
            {

              frm.LoadItemData(dgvItems.SelectedRows[0].Cells["chCode"].Value.ToString(), dgvItems.SelectedRows[0].Cells["chDesc"].Value.ToString(), (decimal)dgvItems.SelectedRows[0].Cells["chCost"].Value, quantity);
            }
            catch (Exception ex)
            {
              DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                      System.Reflection.MethodBase.GetCurrentMethod().Name, "");
            }
            this.Close();

          }
        }
        
      }
    }

    private void RemoveItem()
    {
      if (dgvItemsAdded.SelectedRows.Count > 0 && dgvItemsAdded.SelectedRows[0].Index > -1)
      {
        dgvItemsAdded.Rows.RemoveAt(dgvItemsAdded.SelectedRows[0].Index);
      }
    }


    private void tsJob_Click(object sender, EventArgs e)
    {

    }

    private void dgvItemsAdded_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      if (dgvItemsAdded.SelectedRows.Count > 0 && dgvItemsAdded.SelectedRows[0].Index > -1)
      {
        ItemEdit frm = new ItemEdit((int)dgvItemsAdded.SelectedRows[0].Cells[0].Value);
        frm.ShowDialog();
      }
    }

    private void btnAddItem_Click(object sender, EventArgs e)
    {
      AddItem();
    }

    private void btnRemoveItem_Click(object sender, EventArgs e)
    {
      RemoveItem();
    }

    private void cmbField_SelectedIndexChanged(object sender, EventArgs e)
    {
      SearchItems();
    }
  }
}
