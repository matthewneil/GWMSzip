﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Windows.Forms;
//using DocumentFormat.OpenXml.Drawing.Charts;
using System.Diagnostics;

namespace workshop_orders
{
  public partial class JobView : Form
  {
    private void JobView_Load(object sender, EventArgs e)
    {
      refresh();
    }

    public JobView()
    {
      InitializeComponent();
      refresh();
    }



    public MySqlConnection connectMySql()
    {
      using (MySqlConnection conn = new MySqlConnection(GWMS.connStr))
      {
        try
        {
          Console.WriteLine("Connecting to MySQL...");
          return conn;
        }
        catch (Exception ex)
        {
          MessageBox.Show("Error connecting to server, please contact the administrator.", "Error!");
          return null;
        }

      }
    }

    public void refresh()
    {

      DateTime todayDate = DateTime.Parse(calDate.SelectionStart.ToString("yyyy-MM-dd"));
      int offset = (int)todayDate.DayOfWeek - 1;
      DateTime date = todayDate.AddDays(-offset);



      if (tcProduction.SelectedTab == tpVehicle)
      {
        dgvVehicleMorning.AutoGenerateColumns = false;
        DataTable dtMorn = DataAccess.ExecuteDataTable(String.Format(
          "SELECT JobBookingDate, JobID, JobReference, CustomerName, Vehicle, vRecalibration, StatusName, JobNote, AreaName, Payment, TypeName, TypeColor FROM vwjob " +
          "WHERE JobBookingDate BETWEEN '{0}' AND '{0} 11:59:59' " +
          "AND TypeGroup = 'Auto' " +
          "ORDER BY JobBookingDate, JobID",
          todayDate.ToString("yyyy-MM-dd")));
        dgvVehicleMorning.DataSource = dtMorn;

        foreach (DataGridViewRow drow in dgvVehicleMorning.Rows)
        {
          drow.Cells[5].Style.BackColor = Color.White;
          if(drow.Cells[5].Value.ToString() == "1")
          {
            drow.Cells[5].Style.BackColor = Color.Blue;
          }
          
          drow.Cells[6].Style.BackColor = Color.White;
          drow.Cells[6].Style.BackColor = Color.FromName(drow.Cells[11].Value.ToString());

          drow.Cells[8].Style.BackColor = Color.White;
          if (drow.Cells[8].Value.ToString() == "Cash Sale")
          {
            drow.Cells[8].Style.BackColor = Color.IndianRed;
          }

          drow.Cells[9].Style.BackColor = Color.White;
          if (drow.Cells[9].Value.ToString() != "")
          {
            drow.Cells[9].Style.BackColor = Color.MediumPurple;
          }
        }

        dgvVehicleAfternoon.AutoGenerateColumns = false;
        DataTable dtAfter = DataAccess.ExecuteDataTable(String.Format(
          "SELECT JobBookingDate, JobID, JobReference, CustomerName, Vehicle, vRecalibration, StatusName, JobNote, AreaName, Payment, TypeName, TypeColor FROM vwjob " +
          "WHERE JobBookingDate BETWEEN '{0} 12:00:00' AND '{0} 23:59:59' " +
          "AND TypeGroup = 'Auto' " +
          "ORDER BY JobBookingDate, JobID",
          todayDate.ToString("yyyy-MM-dd")));
        dgvVehicleAfternoon.DataSource = dtAfter;

        foreach (DataGridViewRow drow in dgvVehicleAfternoon.Rows)
        {
          drow.Cells[5].Style.BackColor = Color.White;
          if (drow.Cells[5].Value.ToString() == "1")
          {
            drow.Cells[5].Style.BackColor = Color.Blue;
          }

          drow.Cells[6].Style.BackColor = Color.White;
          drow.Cells[6].Style.BackColor = Color.FromName(drow.Cells[11].Value.ToString());

          drow.Cells[8].Style.BackColor = Color.White;
          if (drow.Cells[8].Value.ToString() == "Cash Sale")
          {
            drow.Cells[8].Style.BackColor = Color.IndianRed;
          }

          drow.Cells[9].Style.BackColor = Color.White;
          if (drow.Cells[9].Value.ToString() != "")
          {
            drow.Cells[9].Style.BackColor = Color.MediumPurple;
          }
        }

      }

      else if (tcProduction.SelectedTab == tpGlass)
      {
        dgvGlassMorning.AutoGenerateColumns = false;
        DataTable dtMorn2 = DataAccess.ExecuteDataTable(String.Format(
          "SELECT JobBookingDate, JobID, JobReference, CustomerName, StatusName, JobNote, AreaName, Payment, TypeName, TypeColor FROM vwjob " +
          "WHERE JobBookingDate BETWEEN '{0}' AND '{0} 11:59:59' " +
          "AND TypeGroup = 'Glass' " +
          "ORDER BY JobBookingDate, JobID",
          todayDate.ToString("yyyy-MM-dd")));
        dgvGlassMorning.DataSource = dtMorn2;

        foreach (DataGridViewRow drow in dgvGlassMorning.Rows)
        {
          drow.Cells[4].Style.BackColor = Color.White;
          drow.Cells[4].Style.BackColor = Color.FromName(drow.Cells[9].Value.ToString());

          drow.Cells[6].Style.BackColor = Color.White;
          if (drow.Cells[6].Value.ToString() == "Cash Sale")
          {
            drow.Cells[6].Style.BackColor = Color.IndianRed;
          }

          drow.Cells[7].Style.BackColor = Color.White;
          if (drow.Cells[7].Value.ToString() != "")
          {
            drow.Cells[7].Style.BackColor = Color.MediumPurple;
          }
        }

        dgvGlassAfternoon.AutoGenerateColumns = false;
        DataTable dtAfter2 = DataAccess.ExecuteDataTable(String.Format(
          "SELECT JobBookingDate, JobID, JobReference, CustomerName, StatusName, JobNote, AreaName, Payment, TypeName, TypeColor FROM vwjob " +
          "WHERE JobBookingDate BETWEEN '{0} 12:00:00' AND '{0} 23:59:59' " +
          "AND TypeGroup = 'Glass' " +
          "ORDER BY JobBookingDate, JobID",
          todayDate.ToString("yyyy-MM-dd")));
        dgvGlassAfternoon.DataSource = dtAfter2;

        foreach (DataGridViewRow drow in dgvGlassAfternoon.Rows)
        {
          drow.Cells[4].Style.BackColor = Color.White;
          drow.Cells[4].Style.BackColor = Color.FromName(drow.Cells[9].Value.ToString());

          drow.Cells[6].Style.BackColor = Color.White;
          if (drow.Cells[6].Value.ToString() == "Cash Sale")
          {
            drow.Cells[6].Style.BackColor = Color.IndianRed;
          }

          drow.Cells[7].Style.BackColor = Color.White;
          if (drow.Cells[7].Value.ToString() != "")
          {
            drow.Cells[7].Style.BackColor = Color.MediumPurple;
          }
        }

      }

      

      int offsets = (int)todayDate.DayOfWeek - 1;
      DateTime weekday = calDate.SelectionStart;

      chHours.Series["A"].Points.Clear();
      chHours.Series["T"].Points.Clear();

      string[] weekdays = { "MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN" };

      for (int i = 0; i < 7; i++)
      {
        string sql = String.Format("SELECT TypeName FROM vwjob WHERE JobBookingDate BETWEEN '{0}' AND '{0} 23:59:59';",
                    weekday.AddDays(i - offsets).ToString("yyyy-MM-dd"));


        double time = 0.0;
        using (MySqlConnection conn = connectMySql())
        {
          conn.Open();
          MySqlCommand cmd = new MySqlCommand(sql, conn);
          MySqlDataReader rdr = cmd.ExecuteReader();
          while (rdr.Read())
          {
            if (rdr["TypeName"].ToString() == "Car Screen")
            {
              //1:30
              time += 1.5;
            }
            else if (rdr["TypeName"].ToString() == "Chip")
            {
              time += 0.5;
            }
            else if (rdr["TypeName"].ToString() == "Truck Screen")
            {
              time += 2;
            }
          }
        }

        chHours.Series["A"].Points.AddXY(weekdays[i], time);
        chHours.Series["T"].Points.AddXY(weekdays[i], 18);
      }
      dgvGlassMorning.CurrentCell = null;
      dgvGlassAfternoon.CurrentCell = null;
      dgvVehicleMorning.CurrentCell = null;
      dgvVehicleAfternoon.CurrentCell = null;
    }

    private void monthCalendar1_DateSelected(object sender, DateRangeEventArgs e)
    {
      refresh();
    }

    private void mornDataGrid_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      DisplayJobDetails(dgvVehicleMorning);
    }

    private void dgvVehicleAfternoon_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      DisplayJobDetails(dgvVehicleAfternoon);
    }

    private void DisplayJobDetails(DataGridView dgv)
    {
      

        if (dgv.SelectedRows.Count == 1 && dgv.SelectedRows[0].Index > -1)
        {
        if (FormManagement.IsFormOpen("JobEdit") == true)
        {
          DataAccess.ShowMessage("You are currently editing a job. Please save and close before creating a new job.");
          FormManagement.ShowChildForm("JobEdit");
        }
        else
        {
          try
          {
            FormManagement.ShowChildForm(new JobEdit((int)dgv.SelectedRows[0].Cells[1].Value));
          }
          catch (Exception ex) { }
        }
      }
      
    }

  

    private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
    {
      refresh();
    }

    private void timer1_Tick(object sender, EventArgs e)
    {
      refresh();
    }

    private void tsRefresh_Click(object sender, EventArgs e)
    {
      refresh();
    }

    private void tsReport_Click(object sender, EventArgs e)
    {

      ReportView frm = new ReportView(String.Format("SELECT * FROM vwjobitem WHERE JobBookingDate BETWEEN '{0}' AND '{0} 23:59:59' AND TypeGroup = 'Auto'", 
        calDate.SelectionStart.ToString("yyyy-MM-dd")), "dayreport.rdlc");
      FormManagement.ShowDialogForm(frm);
    }

    private void tsToday_Click(object sender, EventArgs e)
    {
      calDate.SetDate(calDate.TodayDate);
      refresh();
    }

    private void tsPrevious_Click(object sender, EventArgs e)
    {
      calDate.SetDate(calDate.SelectionStart.AddDays(-1));
      refresh();
    }

    private void tsNext_Click(object sender, EventArgs e)
    {
      calDate.SetDate(calDate.SelectionStart.AddDays(1));
      refresh();
    }

    private void VehicleReport()
    {
      ReportView frm = new ReportView(
        String.Format("SELECT * FROM vwproduction WHERE booking BETWEEN '{0}' AND '{0} 11:29:59'", calDate.SelectionStart.ToString("yyyy-MM-dd")), "Report1.rdlc");

      FormManagement.ShowDialogForm(frm);
      return;
      String html = "";
      DateTime week = DateTime.Parse(calDate.SelectionStart.ToString().Split(' ')[0]);
      int offset = (int)week.DayOfWeek - 1;

      int totalCar = 0;
      int totalTruck = 0;
      int totalChip = 0;
      int totalGlass = 0;
      int unknown = 0;
      week.AddDays(-offset);
      html += "<!doctype html>" +
          "<html lang='en'>" +
          "<head>" +
          "<meta charset = 'utf-8'>" +
          "<title>Day Sheet - Gore Windscreens and Glass</title>" +
          "<meta name='description' content='The HTML5 Herald'>" +
          "<meta name = 'author' content = 'SitePoint'>" +
          "<link rel = 'shortcut icon' href = 'gwgicon.png'>" +
          "<link rel = 'stylesheet' href = 'css/styles.css?v=1.0'>" +
          "</head>" +
          "<style>" +
          "html {" +
          "font-family: arial;" +
          "font-size: 12px;" +
          "}" +
          "section { width: 365px; }" +
          "#morning { float: left; }" +
          "#afternoon { float: left; margin-left: 10px; }" +
          "h3 { border-top: 1px solid black }" +
          "#title { font-size: 15px }" +
          "h1 { margin: 0px; }" +
          "p { margin: 5px; }" +
          "</style>" +
          "<body>" +
          "<p id='title'><strong>" + week.ToLongDateString() + "</strong> <em>As Of: " + DateTime.Now.ToLongDateString() + " " + DateTime.Now.ToLongTimeString() + "</em></p>" +
          "<section id='morning'>" +
          "<h1>Morning(8am - 12pm)</h1>";

      using (MySqlConnection conn = connectMySql())
      {
        String sql = String.Format("SELECT job.jobNo, bookingDate, type, registration.registration, vehicleMake, vehicleModel, vehicleYear, cFirstName, cSurname, cCompany, cPhone, cPhone2, cEmail FROM job INNER " +
                "JOIN jobStatus ON jobStatus.jobNo = job.jobNo INNER JOIN " +
                "(SELECT jobNo, MAX(date) AS maxdate FROM jobStatus GROUP BY jobNo) jS ON jobStatus.jobNo = jS.jobNo AND " +
                "jobStatus.date = jS.maxdate INNER JOIN customer ON customer.cID = job.customerID " +
                "LEFT JOIN registration ON registration.registration = job.registration WHERE " +
                "bookingDate BETWEEN '{0}' AND '{0} 11:29:59' AND onsite = false AND type NOT LIKE 'GLASS %' ORDER BY bookingDate, job.jobNo;",
                week.ToString("yyyy-MM-dd"));
        try
        {
          conn.Open();
          MySqlCommand cmd = new MySqlCommand(sql, conn);
          MySqlDataReader rdr = cmd.ExecuteReader();
          while (rdr.Read())
          {
            html += String.Format("<h3>{11} - {10} - {0} - {6}</h3>" +
            "<p><strong>{1} {2}</strong> - {3} - {4} - {5}</p>" +
            "<p><strong>{6}</strong> - {7} {8} {9}</p>",
            rdr["type"].ToString(), rdr["cFirstName"].ToString(), rdr["cSurname"].ToString(),
            rdr["cCompany"].ToString(), rdr["cPhone"].ToString(), rdr["cEmail"].ToString(),
            rdr["registration"].ToString(), rdr["vehicleMake"].ToString(), rdr["vehicleModel"].ToString(),
            rdr["vehicleYear"].ToString(), rdr["jobNo"].ToString(),
            rdr["bookingDate"].ToString().Split(' ')[1] + ' ' + rdr["bookingDate"].ToString().Split(' ')[2]);
            if (rdr["type"].ToString() == "Truck Screen")
            {
              totalTruck++;
            }
            else if (rdr["type"].ToString() == "Chip")
            {
              totalChip++;
            }
            else if (rdr["type"].ToString() == "Body Glass" || rdr["type"].ToString() == "Glass")
            {
              totalGlass++;
            }
            else if (rdr["type"].ToString() == "Car Screen" || rdr["type"].ToString() == "Windscreen")
            {
              totalCar++;
            }
            else
            {
              unknown++;
            }
            using (MySqlConnection conn2 = connectMySql())
            {
              try
              {
                conn2.Open();
                String product = String.Format("SELECT pType, pCode, pAltCode, pDesc FROM jobPart INNER JOIN " +
                           "(SELECT objID, MAX(date) AS maxdate FROM jobPart GROUP BY objID) jP " +
                           "ON jobPart.objID = jP.objID AND date = maxdate INNER JOIN part ON part.pID = jobPart.pID WHERE pAllocated = {0};",
                           rdr["jobNo"].ToString());
                MySqlCommand cmd2 = new MySqlCommand(product, conn2);
                MySqlDataReader rdr2 = cmd2.ExecuteReader();
                while (rdr2.Read())
                {
                  html += String.Format("<p>{0} - {1} - {2} ({3})</p>",
                  rdr2["pType"].ToString(), rdr2["pCode"].ToString(), rdr2["pAltCode"].ToString(), rdr2["pDesc"].ToString());
                }
              }
              catch (Exception ex)
              {
                DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name, System.Reflection.MethodBase.GetCurrentMethod().Name, "");
              }
            }
          }
        }
        catch (Exception ex)
        {
          DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name, System.Reflection.MethodBase.GetCurrentMethod().Name, "");
        }
      }

      html += String.Format("<h3>Total: {0}</h3><p>| ", totalCar + totalTruck + totalChip + totalGlass + unknown);
      if (totalCar > 0) html += String.Format("Car Screens: {0} | ", totalCar);
      if (totalTruck > 0) html += String.Format("Truck Screens: {0} | ", totalTruck);
      if (totalChip > 0) html += String.Format("Chips: {0} | ", totalChip);
      if (totalGlass > 0) html += String.Format("Body Glass: {0} | ", totalGlass);
      html += "</p>";
      totalCar = 0;
      totalTruck = 0;
      totalChip = 0;
      totalGlass = 0;

      html += "</section>" +
                  "<section id='afternoon'><h1>Afternoon(12pm - 4:30pm)</h1>";

      using (MySqlConnection conn = connectMySql())
      {
        String sql = String.Format("SELECT job.jobNo, bookingDate,type, registration.registration, vehicleMake, vehicleModel, vehicleYear, cFirstName, cSurname, cCompany, cPhone, cPhone2, cEmail FROM job INNER " +
                "JOIN jobStatus ON jobStatus.jobNo = job.jobNo INNER JOIN " +
                "(SELECT jobNo, MAX(date) AS maxdate FROM jobStatus GROUP BY jobNo) jS ON jobStatus.jobNo = jS.jobNo AND " +
                "jobStatus.date = jS.maxdate INNER JOIN customer ON customer.cID = job.customerID " +
                "LEFT JOIN registration ON registration.registration = job.registration WHERE " +
                "bookingDate BETWEEN '{0} 11:30:00' AND '{0} 23:59:59' AND onsite = false AND type NOT LIKE 'GLASS %' ORDER BY bookingDate, job.jobNo;",
                week.ToString("yyyy-MM-dd"));
        try
        {
          conn.Open();
          MySqlCommand cmd = new MySqlCommand(sql, conn);
          MySqlDataReader rdr = cmd.ExecuteReader();
          while (rdr.Read())
          {
            html += String.Format("<h3>{11} - {10} - {0} - {6}</h3>" +
            "<p><strong>{1} {2}</strong> - {3} - {4} - {5}</p>" +
            "<p><strong>{6}</strong> - {7} {8} {9}</p>",
            rdr["type"].ToString(), rdr["cFirstName"].ToString(), rdr["cSurname"].ToString(),
            rdr["cCompany"].ToString(), rdr["cPhone"].ToString(), rdr["cEmail"].ToString(),
            rdr["registration"].ToString(), rdr["vehicleMake"].ToString(), rdr["vehicleModel"].ToString(),
            rdr["vehicleYear"].ToString(), rdr["jobNo"].ToString(),
            rdr["bookingDate"].ToString().Split(' ')[1] + ' ' + rdr["bookingDate"].ToString().Split(' ')[2]);
            if (rdr["type"].ToString() == "Truck Screen")
            {
              totalTruck++;
            }
            else if (rdr["type"].ToString() == "Chip")
            {
              totalChip++;
            }
            else if (rdr["type"].ToString() == "Body Glass" || rdr["type"].ToString() == "Glass")
            {
              totalGlass++;
            }
            else if (rdr["type"].ToString() == "Car Screen" || rdr["type"].ToString() == "Windscreen")
            {
              totalCar++;
            }
            else
            {
              unknown++;
            }
            using (MySqlConnection conn2 = connectMySql())
            {
              try
              {
                conn2.Open();
                String product = String.Format("SELECT pType, pCode, pAltCode, pDesc FROM jobPart INNER JOIN " +
                           "(SELECT objID, MAX(date) AS maxdate FROM jobPart GROUP BY objID) jP " +
                           "ON jobPart.objID = jP.objID AND date = maxdate INNER JOIN part ON part.pID = jobPart.pID WHERE pAllocated = {0};",
                           rdr["jobNo"].ToString());
                MySqlCommand cmd2 = new MySqlCommand(product, conn2);
                MySqlDataReader rdr2 = cmd2.ExecuteReader();
                while (rdr2.Read())
                {
                  html += String.Format("<p>{0} - {1} - {2} ({3})</p>",
                  rdr2["pType"].ToString(), rdr2["pCode"].ToString(), rdr2["pAltCode"].ToString(), rdr2["pDesc"].ToString());
                }
              }
              catch (Exception ex)
              {
                DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name, System.Reflection.MethodBase.GetCurrentMethod().Name, "");
              }
            }
          }
        }
        catch (Exception ex)
        {
        }
      }
      html += String.Format("<h3>Total: {0}</h3><p>| ", totalCar + totalTruck + totalChip + totalGlass + unknown);
      if (totalCar > 0) html += String.Format("Car Screens: {0} | ", totalCar);
      if (totalTruck > 0) html += String.Format("Truck Screens: {0} | ", totalTruck);
      if (totalChip > 0) html += String.Format("Chips: {0} | ", totalChip);
      if (totalGlass > 0) html += String.Format("Body Glass: {0} | ", totalGlass);
      html += "</p>";
      html += "</section></body></html>";
      File.Delete(@"C:\Forms\Day.html");
      using (System.IO.StreamWriter file = new System.IO.StreamWriter(@"C:\Forms\Day.html", true))
      {
        file.WriteLine(html);
      }
      Process.Start("chrome.exe", @"C:\Forms\Day.html");
    }

    private void tsBack_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private void tsNew_Click(object sender, EventArgs e)
    {
      //Check if job sheet open
      if (FormManagement.IsFormOpen("JobEdit") == true)
      {
        DataAccess.ShowMessage("You are currently editing a job. Please save and close before creating a new job.");
        FormManagement.ShowChildForm("JobEdit");
      }
      else
      {
        JobNew frm = new JobNew(0);
        FormManagement.ShowDialogForm(frm);
      }
    }
    private void tsEdit_Click(object sender, EventArgs e)
    {
      FormManagement.ShowChildForm(new JobEdit(10000));
    }

    private void dgvGlassMorning_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      DisplayJobDetails(dgvGlassMorning);
    }

    private void dgvGlassAfternoon_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      DisplayJobDetails(dgvGlassAfternoon);
    }

    private void dgvGlassMorning_Click(object sender, EventArgs e)
    {

    }

    private void dgvGlassAfternoon_Click(object sender, EventArgs e)
    {

    }

    private void dgvVehicleMorning_Click(object sender, EventArgs e)
    {

    }

    private void dgvVehicleAfternoon_CellClick(object sender, DataGridViewCellEventArgs e)
    {

    }
  }
}

  
