﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workshop_orders
{
  public partial class SelectLocation : Form
  {
    public static decimal Quantity = -1;
    public SelectLocation(int ItemCostID)
    {
      InitializeComponent();

      DataTable dtLocations = DataAccess.ExecuteDataTable("" +
          "SELECT s.ItemStockID, SUM(imQuantity) AS Quantity, LocationGroup, LocationSubGroup, LocationCode, LocationDescription " +
          "FROM itemstock s " +
          "INNER JOIN location l ON s.LocationID = l.LocationID " +
          "INNER JOIN itemmovement m ON s.ItemStockID = m.ItemStockID " +
          "WHERE ItemCostID = " + ItemCostID + " " +
          "GROUP BY s.ItemStockID " +
          "HAVING SUM(imQuantity) > 0 " +
          "ORDER BY LocationGroup, LocationSubGroup, LocationCode ");

      dgvLocations.DataSource = dtLocations;
      DataAccess.FormState(this.AccessibilityObject.Name, tsSelect);
    }



    private void tsBack_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private void dgvLocations_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      SelectItemLocation(false);
    }

    private void tsSelect_Click(object sender, EventArgs e)
    {
      SelectItemLocation(false);
    }

    private void SelectItemLocation(bool newitem)
    {
      if (dgvLocations.SelectedRows.Count > 0 && dgvLocations.SelectedRows[0].Index > -1)
      {
        
        Quantity quantityfrm = new Quantity();
        FormManagement.ShowDialogForm(quantityfrm);

        if (Quantity > 0)
        {
          JobItem.quantity = Quantity;

          if(newitem) JobItem.ItemStockID = -1; //If no location used, set to -1
          else JobItem.ItemStockID = (int)dgvLocations.SelectedRows[0].Cells["chItemStockID"].Value;

          this.Close();
        }        
      }
    }

    private void tsNew_Click(object sender, EventArgs e)
    {
      SelectItemLocation(true);
    }
  }
}
