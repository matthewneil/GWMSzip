﻿using System;
using System.IO;
using System.Windows.Forms;

namespace workshop_orders
{
    partial class ChangeJobPart
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.partButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.partCodeText = new System.Windows.Forms.TextBox();
            this.partTypeCombo = new System.Windows.Forms.ComboBox();
            this.altCodeText = new System.Windows.Forms.TextBox();
            this.nagCodeText = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.allocateCheck = new System.Windows.Forms.CheckBox();
            this.infoText = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.statusCombo = new System.Windows.Forms.ComboBox();
            this.dealloCheck = new System.Windows.Forms.CheckBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.reorderCheck = new System.Windows.Forms.CheckBox();
            this.jobLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // partButton
            // 
            this.partButton.Location = new System.Drawing.Point(168, 354);
            this.partButton.Name = "partButton";
            this.partButton.Size = new System.Drawing.Size(249, 41);
            this.partButton.TabIndex = 6;
            this.partButton.Text = "Change ";
            this.partButton.UseVisualStyleBackColor = true;
            this.partButton.Click += new System.EventHandler(this.partButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Enabled = false;
            this.label1.Location = new System.Drawing.Point(23, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 20);
            this.label1.TabIndex = 36;
            this.label1.Text = "Part Type";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Enabled = false;
            this.label2.Location = new System.Drawing.Point(257, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(165, 20);
            this.label2.TabIndex = 37;
            this.label2.Text = "Eurocode (New Code)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Enabled = false;
            this.label4.Location = new System.Drawing.Point(257, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(160, 20);
            this.label4.TabIndex = 39;
            this.label4.Text = "Part Code (Old Code)";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // partCodeText
            // 
            this.partCodeText.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.partCodeText.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.partCodeText.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.partCodeText.Enabled = false;
            this.partCodeText.Location = new System.Drawing.Point(261, 108);
            this.partCodeText.Name = "partCodeText";
            this.partCodeText.Size = new System.Drawing.Size(305, 26);
            this.partCodeText.TabIndex = 2;
            // 
            // partTypeCombo
            // 
            this.partTypeCombo.Enabled = false;
            this.partTypeCombo.FormattingEnabled = true;
            this.partTypeCombo.Location = new System.Drawing.Point(25, 47);
            this.partTypeCombo.Name = "partTypeCombo";
            this.partTypeCombo.Size = new System.Drawing.Size(214, 28);
            this.partTypeCombo.TabIndex = 1;
            // 
            // altCodeText
            // 
            this.altCodeText.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.altCodeText.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.altCodeText.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.altCodeText.Enabled = false;
            this.altCodeText.Location = new System.Drawing.Point(261, 47);
            this.altCodeText.MaxLength = 6;
            this.altCodeText.Name = "altCodeText";
            this.altCodeText.Size = new System.Drawing.Size(305, 26);
            this.altCodeText.TabIndex = 4;
            this.altCodeText.TextChanged += new System.EventHandler(this.altCodeText_TextChanged);
            // 
            // nagCodeText
            // 
            this.nagCodeText.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.nagCodeText.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.nagCodeText.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.nagCodeText.Enabled = false;
            this.nagCodeText.Location = new System.Drawing.Point(25, 108);
            this.nagCodeText.MaxLength = 6;
            this.nagCodeText.Name = "nagCodeText";
            this.nagCodeText.Size = new System.Drawing.Size(214, 26);
            this.nagCodeText.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Enabled = false;
            this.label5.Location = new System.Drawing.Point(21, 87);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 20);
            this.label5.TabIndex = 44;
            this.label5.Text = "Nags Code";
            // 
            // allocateCheck
            // 
            this.allocateCheck.AutoSize = true;
            this.allocateCheck.Location = new System.Drawing.Point(188, 267);
            this.allocateCheck.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.allocateCheck.Name = "allocateCheck";
            this.allocateCheck.Size = new System.Drawing.Size(181, 24);
            this.allocateCheck.TabIndex = 51;
            this.allocateCheck.Text = "Allocate to Other Job:";
            this.allocateCheck.UseVisualStyleBackColor = true;
            this.allocateCheck.Visible = false;
            // 
            // infoText
            // 
            this.infoText.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.infoText.Location = new System.Drawing.Point(25, 307);
            this.infoText.MaxLength = 150;
            this.infoText.Name = "infoText";
            this.infoText.Size = new System.Drawing.Size(540, 26);
            this.infoText.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(22, 284);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 20);
            this.label7.TabIndex = 55;
            this.label7.Text = "Comments";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(22, 194);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(120, 20);
            this.label8.TabIndex = 56;
            this.label8.Text = "Change Status:";
            // 
            // statusCombo
            // 
            this.statusCombo.FormattingEnabled = true;
            this.statusCombo.Location = new System.Drawing.Point(148, 191);
            this.statusCombo.Name = "statusCombo";
            this.statusCombo.Size = new System.Drawing.Size(274, 28);
            this.statusCombo.TabIndex = 57;
            this.statusCombo.SelectedIndexChanged += new System.EventHandler(this.statusCombo_SelectedIndexChanged);
            this.statusCombo.TextChanged += new System.EventHandler(this.statusCombo_TextChanged);
            // 
            // dealloCheck
            // 
            this.dealloCheck.AutoSize = true;
            this.dealloCheck.Location = new System.Drawing.Point(25, 227);
            this.dealloCheck.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dealloCheck.Name = "dealloCheck";
            this.dealloCheck.Size = new System.Drawing.Size(175, 24);
            this.dealloCheck.TabIndex = 58;
            this.dealloCheck.Text = "Deallocate From Job";
            this.dealloCheck.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox1.Location = new System.Drawing.Point(372, 265);
            this.textBox1.MaxLength = 6;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(157, 26);
            this.textBox1.TabIndex = 59;
            this.textBox1.Visible = false;
            // 
            // reorderCheck
            // 
            this.reorderCheck.AutoSize = true;
            this.reorderCheck.Enabled = false;
            this.reorderCheck.Location = new System.Drawing.Point(439, 191);
            this.reorderCheck.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.reorderCheck.Name = "reorderCheck";
            this.reorderCheck.Size = new System.Drawing.Size(127, 24);
            this.reorderCheck.TabIndex = 60;
            this.reorderCheck.Text = "Re-Order Part";
            this.reorderCheck.UseVisualStyleBackColor = true;
            // 
            // jobLabel
            // 
            this.jobLabel.AutoSize = true;
            this.jobLabel.Location = new System.Drawing.Point(21, 157);
            this.jobLabel.Name = "jobLabel";
            this.jobLabel.Size = new System.Drawing.Size(136, 20);
            this.jobLabel.TabIndex = 61;
            this.jobLabel.Text = "Allocated to Job #";
            // 
            // ChangeJobPart
            // 
            this.AcceptButton = this.partButton;
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(606, 419);
            this.Controls.Add(this.jobLabel);
            this.Controls.Add(this.reorderCheck);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.dealloCheck);
            this.Controls.Add(this.statusCombo);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.infoText);
            this.Controls.Add(this.allocateCheck);
            this.Controls.Add(this.nagCodeText);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.altCodeText);
            this.Controls.Add(this.partTypeCombo);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.partCodeText);
            this.Controls.Add(this.partButton);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.MaximizeBox = false;
            this.Name = "ChangeJobPart";
            this.Text = "BMS - Product Status";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Resize += new System.EventHandler(this.ViewJobForm_Resize);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Button partButton;
        private Label label1;
        private Label label2;
        private Label label4;
        private TextBox partCodeText;
        private ComboBox partTypeCombo;
        private TextBox altCodeText;
        private TextBox nagCodeText;
        private Label label5;
        private CheckBox allocateCheck;
        private TextBox infoText;
        private Label label7;
        private Label label8;
        private ComboBox statusCombo;
        private CheckBox dealloCheck;
        private TextBox textBox1;
        private CheckBox reorderCheck;
        private Label jobLabel;
    }
}

