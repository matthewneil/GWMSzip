﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workshop_orders
{
  public partial class ItemLocation : Form
  {
    private int ItemStockID = -1;
    private int ItemCostID = -1;
    private int JobItemID = -1;
    private int OldLocationID = -1;
    public static int NewLocationID = -1;
    private int mode = 1; //1 = Move, 2 = Add, 3 = delete
    public ItemLocation(int ItemStockID, int ItemCostID, int JobItemID, int mode)
    {
      InitializeComponent();
      this.ItemStockID = ItemStockID;
      this.ItemCostID = ItemCostID;
      this.JobItemID = JobItemID;
      this.mode = mode;

      //UOM
      String uom = DataAccess.ExecuteScalarString("SELECT UOM FROM itemcost WHERE itemcostID = " + ItemCostID);
      if (uom == "5") // each 
      {
        nudQuantity1.DecimalPlaces = 0;
        nudQuantity2.DecimalPlaces = 0;
      }

      if (mode == 1 || mode == 3) //Move or Delete
      {
        DataTable dt = DataAccess.ExecuteDataTable("SELECT * FROM ItemStock s INNER JOIN Location l ON s.LocationID = l.LocationID WHERE ItemStockID = " + ItemStockID);

        if (dt != null && dt.Rows.Count > 0)
        {
          OldLocationID = (int)dt.Rows[0]["LocationID"];
          txtGroup1.Text = dt.Rows[0]["LocationGroup"].ToString();
          txtSubGroup1.Text = dt.Rows[0]["LocationSubGroup"].ToString();
          txtCode1.Text = dt.Rows[0]["LocationCode"].ToString();
          txtDescription1.Text = dt.Rows[0]["LocationDescription"].ToString();
        }
        decimal qty = DataAccess.ExecuteScalarDec("SELECT SUM(imQuantity) AS qty FROM ItemMovement WHERE ItemStockID = " + ItemStockID + " GROUP BY ItemStockID");
        if (mode == 3)
        {
          nudQuantity1.Maximum = qty;
        }
        else
        {
          try { nudQuantity1.Value = qty; } catch { } //So program doesnt crash if quantity is higher than maximum
          nudQuantity2.Maximum = qty;
        }
      }


      switch (mode)
      {
        case 1: //Move
          this.Text = "Move Stock";
          break;

        case 2: //Add
          txtGroup1.Text = "Inwards";
          txtSubGroup1.Text = "Inwards";
          txtCode1.Text = "Inwards";
          txtDescription1.Text = "Stock Increase";
          try { nudQuantity1.Value = 0; } catch { }
          nudQuantity2.Maximum = 50;
          this.Text = "Add Stock";
          break;

        case 3: //Delete
          tsFind.Enabled = false;
          btnFindLocation.Enabled = false;
          gbTo.Visible = false;
          tsSave.Enabled = true;
          nudQuantity1.ReadOnly = false;
          lblReference1.Visible = true;
          txtReference1.Visible = true;
          nudQuantity1.Minimum = 1;
          this.Width = 345;
          this.Text = "Remove Stock";
          break;
      }

      if (mode != 3)
      {
        nudQuantity1.BackColor = Color.White;
      }
      DataAccess.FormState(this.AccessibilityObject.Name, tsSave);
    }



  private void tsFind_Click(object sender, EventArgs e)
    {
      LoadLocation();
    }

    private void LoadLocation()
    {
      MultiSearch frm = new MultiSearch(2);
      FormManagement.ShowDialogForm(frm);
      LoadNewLocation();
      if (NewLocationID != -1 && OldLocationID != NewLocationID)
      {
        tsSave.Enabled = true;
      }
      else
      {
        tsSave.Enabled = false;
      }
    }

    private void tsBack_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private void tsSave_Click(object sender, EventArgs e)
    {
      //Error checking
      if(mode == 3)
      {
        if(txtReference1.Text.Trim() == "")
        {
          DataAccess.ShowMessage("You need to enter a reason for removal!");
          return;
        }
      }
      /*Try to find StockItemID in new Location, if not found, then create a new one*/
      int newitemstockID = DataAccess.ExecuteScalarInt("SELECT ItemStockID FROM ItemStock WHERE ItemCostID = " + ItemCostID + " AND LocationID = " + NewLocationID);
      if(newitemstockID == 0)
      {
        DataAccess.ItemStockManage(0, ItemCostID, NewLocationID, 0);
        newitemstockID = DataAccess.ExecuteScalarInt("SELECT ItemStockID FROM ItemStock WHERE ItemCostID = " + ItemCostID + " AND LocationID = " + NewLocationID);
      }
      if(newitemstockID != 0)
      {
        if(mode == 1) //move
        {
          int moveType = 5; //movetype 5 = normal internal movement
          if (OldLocationID == 3)//If previous location is ONORDER...
          {
            moveType = 1;//...then make movementtype = recepting INWARDS STOCK
            DataAccess.JobItemManage(JobItemID, -1, -1, 17, 0, 0, newitemstockID); //Item is here
          }

          DataAccess.ItemMovementManage(ItemStockID, moveType, -1, DataAccess.InternalIDType.Item, 0 - nudQuantity2.Value, nudCost.Value, txtReference2.Text, newitemstockID);
          DataAccess.ShowMessage(nudQuantity2.Value + " items moved successfully.");
        }
        else if (mode == 2) //add
        {
          DataAccess.ItemMovementManage(newitemstockID, 10, -1, DataAccess.InternalIDType.Item, nudQuantity2.Value, nudCost.Value, txtReference2.Text, 0);
          DataAccess.ShowMessage(nudQuantity2.Value + " items added successfully.");
        }
        else if (mode == 3) //remove
        {
          DataAccess.ItemMovementManage(ItemStockID, 11, -1, DataAccess.InternalIDType.Item, 0 - nudQuantity1.Value, nudCost.Value, txtReference1.Text, 0);
          DataAccess.ShowMessage(nudQuantity2.Value + " items deleted successfully.");
        }
           
        this.Close();
      }     
    }

    private void LoadNewLocation()
    {
      if(NewLocationID > 0)
      {
        DataTable dt = DataAccess.ExecuteDataTable("SELECT * FROM Location WHERE LocationID = " + NewLocationID);

        if (dt != null && dt.Rows.Count > 0)
        {
          txtGroup2.Text = dt.Rows[0]["LocationGroup"].ToString();
          txtSubGroup2.Text = dt.Rows[0]["LocationSubGroup"].ToString();
          txtCode2.Text = dt.Rows[0]["LocationCode"].ToString();
          txtDescription2.Text = dt.Rows[0]["LocationDescription"].ToString();
          gbTo.Visible = true;
          btnFindLocation.Visible = false;
        }
      }
    }

    private void btnFindLocation_Click(object sender, EventArgs e)
    {
      LoadLocation();
    }
  }
}
