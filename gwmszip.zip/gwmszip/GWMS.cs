﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Security.Principal;

namespace workshop_orders
{
  /**This is the Central Hub of the program. This is where the user can access different subforms. When GWMS is opened it requires a Username
   * and Password to run. If it cannot find the user it will exit the program to prevent unauthorised access. If the user exists, it will
   * get information from the database and determine what permission that user should have.
   */
  public partial class GWMS : Form
  {
    public static GenericPrincipal Roles;
    public static bool _fbTesting = true;
    //private GraphForm graphForm;

    /*Sub-Form creation*/

    public static String errorLogFile = @"\\DATABASE\GWGFiles\BMS\logs\errorlog\";
    public static string connStr = "";
    public String version = "v2.1";

    /*User login details*/
    private String[] user = new String[10];
    public static int StaffID = 0;
    public static int Dev = -1;
    private String StaffFullName = "";
    private static bool admin = false;

    /*determine wether the user is admin or not*/


    public static bool getAdminStatus()
    {
      return admin;
    }

    public GWMS()
    {
      InitializeComponent();
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
      Text = "BMS " + version;
      miUsername.Text = "";

    }
   
    private void Login()
    {
      if (_fbTesting && txtUsername.Text.Trim() == "")
      {
        txtUsername.Text = "matt";
        txtPassword.Text = "crewe2020";
      }
      try
      {
        DataTable dt = DataAccess.ExecuteDataTable(String.Format("SELECT * FROM staff WHERE StaffUsername = '{0}' AND StaffPassword = '{1}';",
          txtUsername.Text, txtPassword.Text));

        if (dt == null)
        {
          DataAccess.ShowMessage("Incorrect Username or Password");
          return;
        }
        if (dt != null && dt.Rows.Count == 0)
        {
          DataAccess.ShowMessage("Incorrect Username or Password");
          return;
        }
        if (dt.Rows[0]["StaffActive"].ToString() == "0")
        {
          DataAccess.ShowMessage("This user has been set as inactive.");
          return;
        }

        StaffID = int.Parse(dt.Rows[0]["StaffID"].ToString());
        StaffFullName = dt.Rows[0]["StaffFullname"].ToString();

        miUsername.Text = StaffFullName;

        

        miLogout.Visible = true;
        miJobs.Visible = true;
        miQuotes.Visible = true;
        miStock.Visible = true;
        miWorkshop.Visible = true;
        miHome.Visible = true;
        miWindows.Visible = true;

        LoadRoles();

        if (dt.Rows[0]["StaffDev"].ToString() == "1")
        {
          miDev.Visible = true;
          Dev = 1;
        }
        else
        {
          miDev.Visible = false;
          Dev = -1;
        }
        
        if (dt.Rows[0]["StaffAdmin"].ToString() == "1")
        {
          admin = true;
          miUsername.Text += " (Admin)";
          miAdmin.Visible = true;
        }
        else
        {
          admin = false;
          miAdmin.Visible = false;
        }
        pnlLogin.Visible = false;
        txtUsername.Text = "";
        txtPassword.Text = "";
        btnLogin.Enabled = false;
        btnWorkshop.Visible = false;

        FormManagement.ShowChildForm("Home");

      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                 System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }
      
    }

    private void LoadRoles()
    {
      ArrayList rolelist = new ArrayList();
      try
      {
        DataTable dtRole = DataAccess.ExecuteDataTable("SELECT * FROM staffrole WHERE staffID = " + GWMS.StaffID);
        if (dtRole.Rows.Count > 0)
        {
          foreach (DataRow row in dtRole.Rows)
          {
            rolelist.Add("R" + row["RoleID"].ToString() + "-" + row["ReadOnly"].ToString());
          }
          GenericIdentity wIdentity = new GenericIdentity(StaffFullName);

          string[] rolelistarray = (string[])rolelist.ToArray(typeof(string));
          Roles = new GenericPrincipal(wIdentity, rolelistarray);
          System.Threading.Thread.CurrentPrincipal = Roles;
        }
      }
      catch (Exception ex)
      {

      }
    }


    /*When closing the program, this method will activate.
     * It will ask the user if they want to quit the program or not
     */
    protected override void OnFormClosing(FormClosingEventArgs e)
    {
      base.OnFormClosing(e);

      if (e.CloseReason == CloseReason.WindowsShutDown) return;


      // Confirm user wants to close
      switch (DataAccess.ShowMessage("Are you sure you want to close?", "Closing", true))
      {
        case false:
          e.Cancel = true;
          break;
        default:
          System.Environment.Exit(1);
          break;
      }
    }

    private void reportsToolStripMenuItem_Click(object sender, EventArgs e)
    {
      FormManagement.ShowDialogForm("Reports");
    }


    public static int HeaderPanelPosition(Panel pnl, Form frm)
    {
      return frm.Width - pnl.Width - 25;
    }


    private void btnLogin_Click(object sender, EventArgs e)
    {
      Login();
    }


    public void Logout(bool ask)
    {
      bool res = true;  
      if (ask)
      {
        res = DataAccess.ShowMessage("Are you sure you want to logout?", "Logout", true);
      }
      
      if (res)
      {
        Roles = null;
        System.Threading.Thread.CurrentPrincipal = null;

        miLogout.Visible = false;
        miJobs.Visible = false;
        miQuotes.Visible = false;
        miStock.Visible = false;
        miWorkshop.Visible = false;
        miAdmin.Visible = false;
        miHome.Visible = false;
        miDev.Visible = false;
        miWindows.Visible = false;

        pnlLogin.Visible = true;
        btnLogin.Enabled = true;
        btnWorkshop.Visible = true;

        StaffID = -1;
        admin = false;
        miUsername.Text = "";

        FormManagement.CloseAll();
      }
    }



    private void btnWorkshop_Click(object sender, EventArgs e)
    {
      StaffID = 15; //Workshop
      StaffFullName = "Workshop";

      miUsername.Text = StaffFullName;

      miLogout.Visible = true;
      btnWorkshop.Visible = false;

      pnlLogin.Visible = false;
      txtUsername.Text = "";
      txtPassword.Text = "";
      btnLogin.Enabled = false;

      LoadRoles();

      FormManagement.ShowChildForm("Workshop");
      Workshop.frm = this;
    }


    private void tsMultiLocation_Click(object sender, EventArgs e)
    {
      FormManagement.ShowDialogForm(new MultiSearch(2));
    }

    private void tsMultiItem_Click(object sender, EventArgs e)
    {
      FormManagement.ShowDialogForm(new MultiSearch(1));
    }

    private void tsDev_Click(object sender, EventArgs e) 
    {

    }

    private void messageBoxToolStripMenuItem_Click(object sender, EventArgs e)
    {
      bool result = DataAccess.ShowMessage("This is an example ShowMessage box.\n\n YES = ShowMessage\n\n NO = MessageBox.Show", "Title", false);
      if (result)
      {
        DataAccess.ShowMessage("You clicked yes");
      }
      else
      {
        MessageBox.Show("You clicked no");
      }
    }

    private void newLocationToolStripMenuItem_Click(object sender, EventArgs e)
    {
      FormManagement.ShowDialogForm("LocationNew");
    }


    private void miCloseAllWindows_Click(object sender, EventArgs e)
    {
      FormManagement.CloseAll();
    }

    private void miHome_Click(object sender, EventArgs e)
    {
      FormManagement.ShowChildForm("Home");
    }

    private void miLogout_Click(object sender, EventArgs e)
    {
      Logout(true);
    }

    private void miCloseBMS_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private void miProductionPlan_Click(object sender, EventArgs e)
    {
      FormManagement.ShowChildForm("JobView");
    }

    private void miSearchJob_Click(object sender, EventArgs e)
    {
      FormManagement.ShowChildForm("JobSearch");
    }

    private void miNewJob_Click(object sender, EventArgs e)
    {
      if (FormManagement.IsFormOpen("JobEdit") == true)
      {
        DataAccess.ShowMessage("You are currently editing a job. Please save and close before creating a new job.");
        FormManagement.ShowChildForm("JobEdit");
      }
      else
      {
        FormManagement.ShowDialogForm(new JobNew(0));
        //new JobNew(0).ShowDialog();

      }
    }

    private void miViewQuotes_Click(object sender, EventArgs e)
    {
      FormManagement.ShowChildForm("Quotes");
    }

    private void miNewQuotes_Click(object sender, EventArgs e)
    {
      if (FormManagement.IsFormOpen("QuoteDetail") == true)
      {
        DataAccess.ShowMessage("You are currently editing a quote. Please save and close before creating a new quote.");
        FormManagement.ShowChildForm("QuoteDetail");
      }
      else
      {
        try
        {
          FormManagement.ShowDialogForm("QuoteNew");
        }
        catch (Exception ex)
        {
          DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
            System.Reflection.MethodBase.GetCurrentMethod().Name, "");
        }
      }
    }

    private void miStockList_Click(object sender, EventArgs e)
    {
      FormManagement.ShowChildForm("Stock");
    }

    private void miLocations_Click(object sender, EventArgs e)
    {
      FormManagement.ShowChildForm("LocationView");
    }

    private void miNewItem_Click(object sender, EventArgs e)
    {
      FormManagement.ShowDialogForm(new ItemEdit(0));
    }

    private void miWorkshop_Click(object sender, EventArgs e)
    {
      FormManagement.ShowChildForm("Workshop");
    }

    private void miUsers_Click(object sender, EventArgs e)
    {
      FormManagement.ShowChildForm("StaffView");
    }

    private void miErrors_Click(object sender, EventArgs e)
    {
      FormManagement.ShowChildForm("ErrorView");
    }

    private void miInsuranceProviders_Click(object sender, EventArgs e)
    {
      FormManagement.ShowChildForm("InsuranceView");
    }

    private void ordersToolStripMenuItem_Click(object sender, EventArgs e)
    {
      FormManagement.ShowChildForm("Orders");
    }

    private void customerDetailToolStripMenuItem_Click(object sender, EventArgs e)
    {
      FormManagement.ShowChildForm("CustomerView");
    }

    private void supplierListToolStripMenuItem_Click(object sender, EventArgs e)
    {
      FormManagement.ShowChildForm("SupplierView");
    }

    private void GWMS_Load(object sender, EventArgs e)
    {

    }

    private void tsSuppliersearch_Click(object sender, EventArgs e)
    {
      FormManagement.ShowDialogForm(new SupplierSearch(0, 1));
    }

    private void onsiteToolStripMenuItem_Click(object sender, EventArgs e)
    {
      //FormManagement.ShowChildForm(new Onsite(GWMS.StaffID));
    }

    private void onsiteDateToolStripMenuItem_Click(object sender, EventArgs e)
    {
      FormManagement.ShowDialogForm(new OnsiteDate(GWMS.StaffID));
    }

    private void reportsToolStripMenuItem_Click_1(object sender, EventArgs e)
    {
      FormManagement.ShowChildForm("ReportGeneration");
    }
  }
}
