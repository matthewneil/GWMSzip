﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workshop_orders
{
  public partial class Workshop : Form
  {

    public static int StaffID = -1;
    private String CurrentStage = "User"; //User, JobGroup, JobList, Job
    private String type = "";
    public int JobID = -1;
    public static GWMS frm;

    public Workshop()
    {
      InitializeComponent();
      LoadUsers();
    }

    private void tsBack_Click(object sender, EventArgs e)
    {
      tsReport.Visible = false;
      switch (CurrentStage)
      {
        case "User":
          if (GWMS.StaffID != 15)
          {
            this.Close();//15 workshop
          }
          else
          {
            frm.Logout(false);
          }

          break;

        case "JobGroup":
          LoadUsers();
          //tsBack.Enabled = false;
          return;

        case "JobList":
          
          dtpSearchDate.Value = DateTime.Today;
          dtpSearchDate.Visible = false;
          tsRefresh.Visible = false;
          tslblSearch.Visible = false;
          tsSearchBar.Visible = false;
          tsPrev.Visible = false;
          tsNext.Visible = false;
          tsSearchBar.Text = "";
          ShowJobGroups();
          return;

        case "JobCard":
          dtpSearchDate.Visible = true;
          tsRefresh.Visible = true;
          tslblSearch.Visible = true;
          tsSearchBar.Visible = true;
          tsPrev.Visible = true;
          tsNext.Visible = true;
          dtpSearchDate.Visible = true;
          pnlJobDetails.Visible = false;

          CurrentStage = "JobList";
          
          return;
      }
    }

    public ucLabour CreateUserControl(String data, String section)
    {
      ucLabour uc = new ucLabour(data, section);
      ucLabour.frm = this;
      this.flpMenu.Controls.Add(uc);
      return uc;
    }

    public void CreateUserControlJob()
    {
      
    }

    public void LoadUsers()
    {
      tsReport.Visible = false;
      dtpSearchDate.Value = DateTime.Today;
      dtpSearchDate.Visible = false;
      flpMenu.Controls.Clear();
      StaffID = -1;
      tsUser.Text = "";
      CurrentStage = "User";
      //tsBack.Enabled = false;
      tsRefresh.Visible = false;
      tslblSearch.Visible = false;
      tsSearchBar.Visible = false;
      pnlJobDetails.Visible = false;
      tsPrev.Visible = false;
      tsNext.Visible = false;


      try
      {
        DataTable dtStaff = DataAccess.ExecuteDataTable("SELECT StaffID FROM staff WHERE StaffWorkshop = 1 AND StaffUserName != 'workshop' ORDER BY StaffFullName");
        for (int i = 0; i < dtStaff.Rows.Count; i++)
        {
          CreateUserControl(dtStaff.Rows[i][0].ToString(), "user");
          
        }
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, "Workshop",
                  System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }
    }

    public bool CheckDayCurrent()
    {
      String sql = String.Format("SELECT COUNT(0) AS count FROM labour " +
        "WHERE StaffID = {0} " +
        "AND StartTime BETWEEN '{1}' AND '{1} 23:59:59' " +
        "GROUP BY StaffID", StaffID, DateTime.Now.ToString("yyyy-MM-dd"));
      int TodayCount = DataAccess.ExecuteScalarInt(sql);

      if(TodayCount == 0)
      {
        bool res = DataAccess.ShowMessage("Do you want to start your day?", "Start Day", true);
        if (res) 
        {
          DataAccess.ExecuteNonQuery("UPDATE job SET JobReference = 'test2' WHERE jobID = 1000");
          DataAccess.LabourManage(StaffID, -1, 0, ""); //Add start day record (blank)
          DataAccess.ShowMessage("Welcome " + GetUserName() + "!");
          return true;
        }        
      }
      else
      {
        return true;
      }
      return false;
    }

    public String GetUserName()
    {
      if (StaffID > 0)
      {
        return DataAccess.ExecuteScalarString("SELECT StaffFullName FROM staff WHERE StaffID = " + StaffID);
      }
      else
      {
        return "";
      }
    }

    public void ShowJobGroups()
    {     
      if (!CheckDayCurrent())
      {
        //LoadUsers();
        return;
      }
      tsUser.Text = GetUserName();
      flpMenu.Controls.Clear();
      CurrentStage = "JobGroup";
      tsBack.Enabled = true;
      String[] Groups = new string[] { "All\n(Search)", "Auto\n(Workshop)", "Auto\n(Onsite)", "Glass\n(Workshop)", "Glass\n(Onsite)", "Onsite", "Admin"};
      foreach (String s in Groups)
      {
        CreateUserControl(s, "jobgroup");
      }
    }

    public void ShowJobs(String type)
    {
      this.type = type;
      dtpSearchDate.Visible = true;
      flpMenu.Controls.Clear();
      CurrentStage = "JobList";
      tsRefresh.Visible = true;
      tslblSearch.Visible = true;
      tsSearchBar.Visible = true;
      tsPrev.Visible = true;
      tsNext.Visible = true;
      tsReport.Visible = false;
      try
      {
        switch (type)
        {
          case "All\n(Search)":
            
            if (tsSearchBar.Text.Trim().Length > 2)
            {
              DataTable dtJobAll = DataAccess.ExecuteDataTable(
              String.Format("SELECT JobID, TypeName, CustomerName, Vehicle, AreaName, JobBookingDate, JobReference, TypeColor " +
              "FROM vwjob " +
              "WHERE (JobID LIKE '{0}%' OR CustomerName LIKE '{0}%' OR Vehicle LIKE '{0}%' OR cSurname LIKE '{0}') LIMIT 30;", tsSearchBar.Text));//StatusID 9 = Current
              this.flpMenu.Controls.Add(new ucLabourHeader("All Jobs"));
              CreateJobCards(dtJobAll);
            }
            else
            {
              this.flpMenu.Controls.Add(new ucLabourHeader("Type into the search bar above to find a Job"));
            }
            
            break;

          case "Auto\n(Workshop)":
            this.flpMenu.Controls.Add(new ucLabourHeader("Auto - Workshop"));
            tsReport.Visible = true;
            if (tsSearchBar.Text == "")
            {
             
              DataTable dtAutoWSMorn = DataAccess.ExecuteDataTable(
                String.Format("SELECT JobID, TypeName, CustomerName, Vehicle, AreaName, JobBookingDate, JobReference, TypeColor " +
                "FROM vwjob " +
                "WHERE JobBookingDate BETWEEN '{0}' AND '{0} 11:59:59' " +
                "AND TypeGroup = 'Auto' " +
                "AND (StatusName = 'Current' " +
                "OR StatusName = 'New') " +
                "AND AreaName IS NULL " +
                "ORDER BY JobBookingDate", dtpSearchDate.Value.ToString("yyyy-MM-dd")));
              this.flpMenu.Controls.Add(new ucLabourSubHeader("Morning"));
              CreateJobCards(dtAutoWSMorn);

              DataTable dtAutoWSAfter = DataAccess.ExecuteDataTable(
                String.Format("SELECT JobID, TypeName, CustomerName, Vehicle, AreaName, JobBookingDate, JobReference, TypeColor " +
                "FROM vwjob " +
                "WHERE JobBookingDate BETWEEN '{0} 12:00:00' AND '{0} 23:59:59' " +
                "AND TypeGroup = 'Auto' " +
                "AND (StatusName = 'Current' " +
                "OR StatusName = 'New') " +
                "AND AreaName IS NULL " +
                "ORDER BY JobBookingDate", dtpSearchDate.Value.ToString("yyyy-MM-dd")));

              this.flpMenu.Controls.Add(new ucLabourSubHeader("Afternoon"));
              CreateJobCards(dtAutoWSAfter);

              DataTable dtAutoWSComplete = DataAccess.ExecuteDataTable(
                String.Format("SELECT JobID, TypeName, CustomerName, Vehicle, AreaName, JobBookingDate, JobReference, TypeColor " +
                "FROM vwjob " +
                "WHERE JobBookingDate BETWEEN '2020-01-01' AND '{0}' " +
                "AND TypeGroup = 'Auto' " +
                "AND (StatusName = 'Current' " +
                "OR StatusName = 'New') " +
                "AND AreaName IS NULL " +
                "ORDER BY JobBookingDate", DateTime.Today.ToString("yyyy-MM-dd")));

              this.flpMenu.Controls.Add(new ucLabourSubHeader("Old Jobs"));
              CreateJobCards(dtAutoWSComplete);
            }
            else
            {
              DataTable dtAutoWSSearch = DataAccess.ExecuteDataTable(
                String.Format("SELECT JobID, TypeName, CustomerName, Vehicle, AreaName, JobBookingDate, JobReference, TypeColor " +
                "FROM vwjob " +
                "WHERE TypeGroup = 'Auto' " +
                "AND AreaName IS NULL " +
                "AND  (JobID LIKE '{0}%' OR CustomerName LIKE '{0}%' OR Vehicle LIKE '{0}%' OR cSurname LIKE '{0}')", tsSearchBar.Text));
              this.flpMenu.Controls.Add(new ucLabourSubHeader("Auto Search (Workshop)"));
              CreateJobCards(dtAutoWSSearch);
            }
            break;

          case "Auto\n(Onsite)":
            this.flpMenu.Controls.Add(new ucLabourHeader("Auto - Onsite"));
            if (tsSearchBar.Text == "")
            {

              DataTable dtAutoOSMorn = DataAccess.ExecuteDataTable(
                String.Format("SELECT JobID, TypeName, CustomerName, Vehicle, AreaName, JobBookingDate, JobReference, TypeColor " +
                "FROM vwjob " +
                "WHERE JobBookingDate BETWEEN '{0}' AND '{0} 11:59:59' " +
                "AND TypeGroup = 'Auto' " +
                "AND (StatusName = 'Current' " +
                "OR StatusName = 'New') " +
                "AND AreaName IS NOT NULL " +
                "ORDER BY JobBookingDate", dtpSearchDate.Value.ToString("yyyy-MM-dd")));
              this.flpMenu.Controls.Add(new ucLabourSubHeader("Morning"));
              CreateJobCards(dtAutoOSMorn);

              DataTable dtAutoOSAfter = DataAccess.ExecuteDataTable(
                String.Format("SELECT JobID, TypeName, CustomerName, Vehicle, AreaName, JobBookingDate, JobReference, TypeColor " +
                "FROM vwjob " +
                "WHERE JobBookingDate BETWEEN '{0} 12:00:00' AND '{0} 23:59:59' " +
                "AND TypeGroup = 'Auto' " +
                "AND (StatusName = 'Current' " +
                "OR StatusName = 'New') " +
                "AND AreaName IS NOT NULL " +
                "ORDER BY JobBookingDate", dtpSearchDate.Value.ToString("yyyy-MM-dd")));
              this.flpMenu.Controls.Add(new ucLabourSubHeader("Afternoon"));
              CreateJobCards(dtAutoOSAfter);

              DataTable dtAutoOSComplete = DataAccess.ExecuteDataTable(
                String.Format("SELECT JobID, TypeName, CustomerName, Vehicle, AreaName, JobBookingDate, JobReference, TypeColor " +
                "FROM vwjob " +
                "WHERE JobBookingDate BETWEEN '2020-01-01' AND '{0}' " +
                "AND TypeGroup = 'Auto' " +
                "AND (StatusName = 'Current' " +
                "OR StatusName = 'New') " +
                "AND AreaName IS NOT NULL " +
                "ORDER BY JobBookingDate", DateTime.Today.ToString("yyyy-MM-dd")));
              this.flpMenu.Controls.Add(new ucLabourSubHeader("Old Jobs"));
              CreateJobCards(dtAutoOSComplete);
            }
            else
            {
              DataTable dtAutoWSSearch = DataAccess.ExecuteDataTable(
                String.Format("SELECT JobID, TypeName, CustomerName, Vehicle, AreaName, JobBookingDate, JobReference, TypeColor " +
                "FROM vwjob " +
                "WHERE TypeGroup = 'Auto' " +
                "AND AreaName IS NOT NULL " +
                "AND  (JobID LIKE '{0}%' OR CustomerName LIKE '{0}%' OR Vehicle LIKE '{0}%' OR cSurname LIKE '{0}')", tsSearchBar.Text));
              this.flpMenu.Controls.Add(new ucLabourSubHeader("Auto Search (Onsite)"));
              CreateJobCards(dtAutoWSSearch);
            }
            break;

          case "Glass\n(Workshop)":
            this.flpMenu.Controls.Add(new ucLabourHeader("Glass - Workshop"));
            DataTable dtGlassWSDay = DataAccess.ExecuteDataTable(
              String.Format("SELECT JobID, TypeName, CustomerName, Vehicle, AreaName, JobBookingDate, JobReference, TypeColor " +
              "FROM vwjob " +
              "WHERE JobBookingDate BETWEEN '{0}' AND '{0} 23:59:59' " +
              "AND TypeGroup = 'Glass' " +
              "AND (StatusName = 'Current' " +
                "OR StatusName = 'New') " +
              "AND AreaName IS NULL " +
              "ORDER BY JobBookingDate", dtpSearchDate.Value.ToString("yyyy-MM-dd")));
            this.flpMenu.Controls.Add(new ucLabourSubHeader("Booked On Select Date"));
            CreateJobCards(dtGlassWSDay);

            DataTable dtGlassWSAll = DataAccess.ExecuteDataTable(
              String.Format("SELECT JobID, TypeName, CustomerName, Vehicle, AreaName, JobBookingDate, JobReference, TypeColor " +
              "FROM vwjob " +
              "WHERE TypeGroup = 'Glass' " +
              "AND AreaName IS NULL " +
              "AND (StatusName = 'Current' " +
                "OR StatusName = 'New') " +
              "AND  (JobID LIKE '{0}%' OR CustomerName LIKE '{0}%' OR Vehicle LIKE '{0}%' OR cSurname LIKE '{0}')", tsSearchBar.Text));
            this.flpMenu.Controls.Add(new ucLabourSubHeader("Workshop (All)"));
            CreateJobCards(dtGlassWSAll);
            break;

          case "Glass\n(Onsite)":
            
            this.flpMenu.Controls.Add(new ucLabourHeader("Glass - Onsite"));
            DataTable dtGlassOSDay = DataAccess.ExecuteDataTable(
              String.Format("SELECT JobID, TypeName, CustomerName, Vehicle, AreaName, JobBookingDate, JobReference, TypeColor " +
              "FROM vwjob " +
              "WHERE JobBookingDate BETWEEN '{0}' AND '{0} 23:59:59' " +
              "AND TypeGroup = 'Glass' " +
              "AND (StatusName = 'Current' " +
                "OR StatusName = 'New') " +
              "AND AreaName IS NOT NULL " +
              "ORDER BY JobBookingDate", dtpSearchDate.Value.ToString("yyyy-MM-dd")));
            this.flpMenu.Controls.Add(new ucLabourSubHeader("Booked On Select Date"));
            CreateJobCards(dtGlassOSDay);

            DataTable dtGlassOSAll = DataAccess.ExecuteDataTable(
              String.Format("SELECT JobID, TypeName, CustomerName, Vehicle, AreaName, JobBookingDate, JobReference, TypeColor " +
              "FROM vwjob " +
              "WHERE TypeGroup = 'Glass' " +
              "AND AreaName IS NOT NULL " +
              "AND (StatusName = 'Current' " +
                "OR StatusName = 'New') " +
              "AND  (JobID LIKE '{0}%' OR CustomerName LIKE '{0}%' OR Vehicle LIKE '{0}%' OR cSurname LIKE '{0}')", tsSearchBar.Text));
            this.flpMenu.Controls.Add(new ucLabourSubHeader("Workshop (All)"));
            CreateJobCards(dtGlassOSAll);
            break;

          case "Onsite":
            //FormManagement.ShowChildForm(new Onsite(StaffID));
            break;

          case "Admin":
            this.flpMenu.Controls.Add(new ucLabourHeader("Admin Tasks"));
            DataTable dtAdmin = DataAccess.ExecuteDataTable(
              String.Format("SELECT AdminTaskID " +
              "FROM AdminTask " +
              "WHERE AdminTaskName LIKE '{0}%'", tsSearchBar.Text));
            for (int i = 0; i < dtAdmin.Rows.Count; i++)
            {
              CreateUserControl(dtAdmin.Rows[i][0].ToString(), "admin");
            }          
            break;
        }
        ucLabourHeader.frm = this;
      } catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, "Workshop",
                  System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }
    }

    

    public void OpenAdminTask(int AdminID)
    {
      AdminTask frm = new AdminTask(AdminID, StaffID);
      AdminTask.frm = this;
      FormManagement.ShowDialogForm(frm);

    }

    public void LoadJob()
    {
      CurrentStage = "JobCard";
      //tslblSearch.Visible = false;
      //tsSearchBar.Visible = false;
      //tsRefresh.Visible = false;

      //dtpSearchDate.Visible = false;
      //pnlJobDetails.Visible = true;

      //LoadJobDetails();
      FormManagement.ShowChildForm(new JobEdit(JobID, 1));
    }

    public void CreateJobCards(DataTable dt)
    {
      for (int i = 0; i < dt.Rows.Count; i++)
      {
        ucLabourJob uc = new ucLabourJob(dt.Rows[i]["JobID"].ToString(), dt.Rows[i]["TypeName"].ToString(), 
          FormatDate(dt.Rows[i]["JobBookingDate"].ToString()).Split('\n')[0], FormatDate(dt.Rows[i]["JobBookingDate"].ToString()).Split('\n')[1], 
          dt.Rows[i]["Vehicle"].ToString(), dt.Rows[i]["CustomerName"].ToString(), dt.Rows[i]["AreaName"].ToString(), dt.Rows[i]["JobReference"].ToString(), dt.Rows[i]["TypeColor"].ToString());
        ucLabourJob.frm = this;
        this.flpMenu.Controls.Add(uc);
      }
      
    }

    public String FormatDate(String date)
    {
      if(DateTime.Parse(date) < DateTime.Parse("2000-01-01"))
      {
        return "No Booking\n";
      }
      return DateTime.Parse(date).ToString("dd MMMM yyyy\nddd, hh:mmtt");
    }

    

    private void LoadJobDetails()
    {
      try
      {
        DataTable dt = DataAccess.ExecuteDataTable("SELECT * FROM vwJob WHERE JobID = " + JobID);
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, "Workshop",
                  System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }
    }



    private void flpMenu_Click(object sender, EventArgs e)
    {
      int i = 0;
    }

    private void tsStart_Click(object sender, EventArgs e)
    {
      LoadUsers();
    }

    private void tsLabour_Click(object sender, EventArgs e)
    {
      WorkshopLabour frm = new WorkshopLabour(JobID, StaffID);
      WorkshopLabour.frm = this;
      FormManagement.ShowDialogForm(frm);
    }

    private void dtpSearchDate_ValueChanged(object sender, EventArgs e)
    {

      ShowJobs(this.type);
    }

    private void tsSearchBar_TextChanged(object sender, EventArgs e)
    {
      ShowJobs(this.type);
    }

    private void tsRefresh_Click(object sender, EventArgs e)
    {
      ShowJobs(this.type);
    }

    private void timer1_Tick(object sender, EventArgs e)
    {
      if(CurrentStage == "JobList") ShowJobs(this.type);
    }

    private void tsReport_Click(object sender, EventArgs e)
    {
      ReportView frm = new ReportView(String.Format("SELECT * FROM vwjobitem WHERE JobBookingDate BETWEEN '{0}' AND '{0} 23:59:59' AND TypeGroup = 'Auto'",
        dtpSearchDate.Value.ToString("yyyy-MM-dd")), "dayreport.rdlc");
      FormManagement.ShowDialogForm(frm);
    }

    private void tsPrev_Click(object sender, EventArgs e)
    {
      dtpSearchDate.Value = dtpSearchDate.Value.AddDays(-1);
    }

    private void tsNext_Click(object sender, EventArgs e)
    {
      dtpSearchDate.Value = dtpSearchDate.Value.AddDays(1);
    }
  }
}
