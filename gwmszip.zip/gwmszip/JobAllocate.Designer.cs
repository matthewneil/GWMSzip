﻿
namespace workshop_orders
{
  partial class JobAllocate
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.nudJobTime = new System.Windows.Forms.NumericUpDown();
      this.label2 = new System.Windows.Forms.Label();
      this.btnContinue = new System.Windows.Forms.Button();
      this.btnCancel = new System.Windows.Forms.Button();
      this.rbYes = new System.Windows.Forms.RadioButton();
      this.rbNo = new System.Windows.Forms.RadioButton();
      this.panel1 = new System.Windows.Forms.Panel();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.label6 = new System.Windows.Forms.Label();
      this.label5 = new System.Windows.Forms.Label();
      this.label4 = new System.Windows.Forms.Label();
      this.label3 = new System.Windows.Forms.Label();
      this.nudDistance = new System.Windows.Forms.NumericUpDown();
      this.label1 = new System.Windows.Forms.Label();
      this.nudTravelTime = new System.Windows.Forms.NumericUpDown();
      this.groupBox2 = new System.Windows.Forms.GroupBox();
      this.groupBox3 = new System.Windows.Forms.GroupBox();
      this.txtNote = new System.Windows.Forms.TextBox();
      this.toolStrip1 = new System.Windows.Forms.ToolStrip();
      this.tsBack = new System.Windows.Forms.ToolStripButton();
      this.tsContinue = new System.Windows.Forms.ToolStripButton();
      this.panel2 = new System.Windows.Forms.Panel();
      this.lblJobID = new System.Windows.Forms.Label();
      this.label9 = new System.Windows.Forms.Label();
      this.txtCustomer = new System.Windows.Forms.TextBox();
      this.label10 = new System.Windows.Forms.Label();
      this.label11 = new System.Windows.Forms.Label();
      this.label12 = new System.Windows.Forms.Label();
      this.label13 = new System.Windows.Forms.Label();
      this.label14 = new System.Windows.Forms.Label();
      this.label15 = new System.Windows.Forms.Label();
      this.txtReference = new System.Windows.Forms.TextBox();
      this.txtVehicle = new System.Windows.Forms.TextBox();
      this.txtAddress = new System.Windows.Forms.TextBox();
      this.txtJobNote = new System.Windows.Forms.TextBox();
      this.txtBooking = new System.Windows.Forms.TextBox();
      this.txtArea = new System.Windows.Forms.TextBox();
      this.txtPayment = new System.Windows.Forms.TextBox();
      ((System.ComponentModel.ISupportInitialize)(this.nudJobTime)).BeginInit();
      this.panel1.SuspendLayout();
      this.groupBox1.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.nudDistance)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudTravelTime)).BeginInit();
      this.groupBox2.SuspendLayout();
      this.groupBox3.SuspendLayout();
      this.toolStrip1.SuspendLayout();
      this.panel2.SuspendLayout();
      this.SuspendLayout();
      // 
      // nudJobTime
      // 
      this.nudJobTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.nudJobTime.Location = new System.Drawing.Point(96, 36);
      this.nudJobTime.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
      this.nudJobTime.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
      this.nudJobTime.Name = "nudJobTime";
      this.nudJobTime.Size = new System.Drawing.Size(97, 26);
      this.nudJobTime.TabIndex = 1;
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label2.Location = new System.Drawing.Point(200, 38);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(34, 20);
      this.label2.TabIndex = 2;
      this.label2.Text = "min";
      // 
      // btnContinue
      // 
      this.btnContinue.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnContinue.Location = new System.Drawing.Point(871, 3);
      this.btnContinue.Name = "btnContinue";
      this.btnContinue.Size = new System.Drawing.Size(94, 35);
      this.btnContinue.TabIndex = 3;
      this.btnContinue.Text = "Continue";
      this.btnContinue.UseVisualStyleBackColor = false;
      this.btnContinue.Click += new System.EventHandler(this.btnContinue_Click);
      // 
      // btnCancel
      // 
      this.btnCancel.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnCancel.Location = new System.Drawing.Point(771, 3);
      this.btnCancel.Name = "btnCancel";
      this.btnCancel.Size = new System.Drawing.Size(94, 35);
      this.btnCancel.TabIndex = 4;
      this.btnCancel.Text = "Cancel";
      this.btnCancel.UseVisualStyleBackColor = false;
      this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
      // 
      // rbYes
      // 
      this.rbYes.AutoSize = true;
      this.rbYes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.rbYes.Location = new System.Drawing.Point(35, 28);
      this.rbYes.Name = "rbYes";
      this.rbYes.Size = new System.Drawing.Size(55, 24);
      this.rbYes.TabIndex = 6;
      this.rbYes.TabStop = true;
      this.rbYes.Text = "Yes";
      this.rbYes.UseVisualStyleBackColor = true;
      // 
      // rbNo
      // 
      this.rbNo.AutoSize = true;
      this.rbNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.rbNo.Location = new System.Drawing.Point(96, 28);
      this.rbNo.Name = "rbNo";
      this.rbNo.Size = new System.Drawing.Size(47, 24);
      this.rbNo.TabIndex = 7;
      this.rbNo.TabStop = true;
      this.rbNo.Text = "No";
      this.rbNo.UseVisualStyleBackColor = true;
      // 
      // panel1
      // 
      this.panel1.Controls.Add(this.btnContinue);
      this.panel1.Controls.Add(this.btnCancel);
      this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
      this.panel1.Location = new System.Drawing.Point(0, 582);
      this.panel1.Name = "panel1";
      this.panel1.Size = new System.Drawing.Size(976, 41);
      this.panel1.TabIndex = 8;
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.Add(this.label6);
      this.groupBox1.Controls.Add(this.label5);
      this.groupBox1.Controls.Add(this.label4);
      this.groupBox1.Controls.Add(this.label3);
      this.groupBox1.Controls.Add(this.nudDistance);
      this.groupBox1.Controls.Add(this.label1);
      this.groupBox1.Controls.Add(this.nudTravelTime);
      this.groupBox1.Controls.Add(this.label2);
      this.groupBox1.Controls.Add(this.nudJobTime);
      this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
      this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.groupBox1.Location = new System.Drawing.Point(0, 39);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(476, 146);
      this.groupBox1.TabIndex = 9;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Time and Distance";
      // 
      // label6
      // 
      this.label6.AutoSize = true;
      this.label6.Location = new System.Drawing.Point(12, 107);
      this.label6.Name = "label6";
      this.label6.Size = new System.Drawing.Size(80, 20);
      this.label6.TabIndex = 9;
      this.label6.Text = "Distance";
      // 
      // label5
      // 
      this.label5.AutoSize = true;
      this.label5.Location = new System.Drawing.Point(35, 72);
      this.label5.Name = "label5";
      this.label5.Size = new System.Drawing.Size(57, 20);
      this.label5.TabIndex = 8;
      this.label5.Text = "Travel";
      // 
      // label4
      // 
      this.label4.AutoSize = true;
      this.label4.Location = new System.Drawing.Point(54, 38);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(38, 20);
      this.label4.TabIndex = 7;
      this.label4.Text = "Job";
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label3.Location = new System.Drawing.Point(200, 107);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(30, 20);
      this.label3.TabIndex = 6;
      this.label3.Text = "km";
      // 
      // nudDistance
      // 
      this.nudDistance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.nudDistance.Location = new System.Drawing.Point(96, 105);
      this.nudDistance.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
      this.nudDistance.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
      this.nudDistance.Name = "nudDistance";
      this.nudDistance.Size = new System.Drawing.Size(97, 26);
      this.nudDistance.TabIndex = 5;
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label1.Location = new System.Drawing.Point(200, 72);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(34, 20);
      this.label1.TabIndex = 4;
      this.label1.Text = "min";
      // 
      // nudTravelTime
      // 
      this.nudTravelTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.nudTravelTime.Location = new System.Drawing.Point(96, 70);
      this.nudTravelTime.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
      this.nudTravelTime.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
      this.nudTravelTime.Name = "nudTravelTime";
      this.nudTravelTime.Size = new System.Drawing.Size(97, 26);
      this.nudTravelTime.TabIndex = 3;
      // 
      // groupBox2
      // 
      this.groupBox2.Controls.Add(this.rbYes);
      this.groupBox2.Controls.Add(this.rbNo);
      this.groupBox2.Dock = System.Windows.Forms.DockStyle.Top;
      this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.groupBox2.Location = new System.Drawing.Point(0, 185);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new System.Drawing.Size(476, 66);
      this.groupBox2.TabIndex = 10;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Job is Completed";
      // 
      // groupBox3
      // 
      this.groupBox3.Controls.Add(this.txtNote);
      this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
      this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.groupBox3.Location = new System.Drawing.Point(0, 251);
      this.groupBox3.Name = "groupBox3";
      this.groupBox3.Size = new System.Drawing.Size(476, 331);
      this.groupBox3.TabIndex = 11;
      this.groupBox3.TabStop = false;
      this.groupBox3.Text = "Job Note";
      // 
      // txtNote
      // 
      this.txtNote.AcceptsReturn = true;
      this.txtNote.Dock = System.Windows.Forms.DockStyle.Fill;
      this.txtNote.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtNote.Location = new System.Drawing.Point(3, 22);
      this.txtNote.Multiline = true;
      this.txtNote.Name = "txtNote";
      this.txtNote.Size = new System.Drawing.Size(470, 306);
      this.txtNote.TabIndex = 0;
      // 
      // toolStrip1
      // 
      this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsBack,
            this.tsContinue});
      this.toolStrip1.Location = new System.Drawing.Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new System.Drawing.Size(976, 39);
      this.toolStrip1.TabIndex = 3;
      this.toolStrip1.Text = "toolStrip1";
      this.toolStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.toolStrip1_ItemClicked_1);
      // 
      // tsBack
      // 
      this.tsBack.Image = global::workshop_orders.Properties.Resources.back;
      this.tsBack.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsBack.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsBack.Name = "tsBack";
      this.tsBack.Size = new System.Drawing.Size(68, 36);
      this.tsBack.Text = "Back";
      this.tsBack.Click += new System.EventHandler(this.tsBack_Click);
      // 
      // tsContinue
      // 
      this.tsContinue.Image = global::workshop_orders.Properties.Resources.tick32;
      this.tsContinue.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsContinue.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsContinue.Name = "tsContinue";
      this.tsContinue.Size = new System.Drawing.Size(92, 36);
      this.tsContinue.Text = "Continue";
      this.tsContinue.Click += new System.EventHandler(this.tsContinue_Click);
      // 
      // panel2
      // 
      this.panel2.BackColor = System.Drawing.SystemColors.ControlLight;
      this.panel2.Controls.Add(this.txtPayment);
      this.panel2.Controls.Add(this.txtArea);
      this.panel2.Controls.Add(this.txtBooking);
      this.panel2.Controls.Add(this.txtJobNote);
      this.panel2.Controls.Add(this.txtAddress);
      this.panel2.Controls.Add(this.txtVehicle);
      this.panel2.Controls.Add(this.txtReference);
      this.panel2.Controls.Add(this.label15);
      this.panel2.Controls.Add(this.label14);
      this.panel2.Controls.Add(this.label13);
      this.panel2.Controls.Add(this.label12);
      this.panel2.Controls.Add(this.label11);
      this.panel2.Controls.Add(this.label10);
      this.panel2.Controls.Add(this.txtCustomer);
      this.panel2.Controls.Add(this.label9);
      this.panel2.Controls.Add(this.lblJobID);
      this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
      this.panel2.Location = new System.Drawing.Point(476, 39);
      this.panel2.Name = "panel2";
      this.panel2.Size = new System.Drawing.Size(500, 543);
      this.panel2.TabIndex = 1;
      this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
      // 
      // lblJobID
      // 
      this.lblJobID.AutoSize = true;
      this.lblJobID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblJobID.Location = new System.Drawing.Point(22, 15);
      this.lblJobID.Name = "lblJobID";
      this.lblJobID.Size = new System.Drawing.Size(210, 20);
      this.lblJobID.TabIndex = 1;
      this.lblJobID.Text = "Job ID: 1000 - Flat Glass";
      // 
      // label9
      // 
      this.label9.AutoSize = true;
      this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label9.Location = new System.Drawing.Point(22, 52);
      this.label9.Name = "label9";
      this.label9.Size = new System.Drawing.Size(82, 20);
      this.label9.TabIndex = 2;
      this.label9.Text = "Customer:";
      // 
      // txtCustomer
      // 
      this.txtCustomer.Location = new System.Drawing.Point(120, 49);
      this.txtCustomer.Name = "txtCustomer";
      this.txtCustomer.ReadOnly = true;
      this.txtCustomer.Size = new System.Drawing.Size(368, 26);
      this.txtCustomer.TabIndex = 3;
      // 
      // label10
      // 
      this.label10.AutoSize = true;
      this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label10.Location = new System.Drawing.Point(16, 84);
      this.label10.Name = "label10";
      this.label10.Size = new System.Drawing.Size(88, 20);
      this.label10.TabIndex = 4;
      this.label10.Text = "Reference:";
      // 
      // label11
      // 
      this.label11.AutoSize = true;
      this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label11.Location = new System.Drawing.Point(29, 116);
      this.label11.Name = "label11";
      this.label11.Size = new System.Drawing.Size(75, 20);
      this.label11.TabIndex = 5;
      this.label11.Text = "Payment:";
      // 
      // label12
      // 
      this.label12.AutoSize = true;
      this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label12.Location = new System.Drawing.Point(38, 212);
      this.label12.Name = "label12";
      this.label12.Size = new System.Drawing.Size(65, 20);
      this.label12.TabIndex = 6;
      this.label12.Text = "Vehicle:";
      // 
      // label13
      // 
      this.label13.AutoSize = true;
      this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label13.Location = new System.Drawing.Point(29, 148);
      this.label13.Name = "label13";
      this.label13.Size = new System.Drawing.Size(72, 20);
      this.label13.TabIndex = 7;
      this.label13.Text = "Address:";
      // 
      // label14
      // 
      this.label14.AutoSize = true;
      this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label14.Location = new System.Drawing.Point(32, 177);
      this.label14.Name = "label14";
      this.label14.Size = new System.Drawing.Size(71, 20);
      this.label14.TabIndex = 8;
      this.label14.Text = "Booking:";
      // 
      // label15
      // 
      this.label15.AutoSize = true;
      this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label15.Location = new System.Drawing.Point(58, 244);
      this.label15.Name = "label15";
      this.label15.Size = new System.Drawing.Size(47, 20);
      this.label15.TabIndex = 9;
      this.label15.Text = "Note:";
      // 
      // txtReference
      // 
      this.txtReference.Location = new System.Drawing.Point(120, 81);
      this.txtReference.Name = "txtReference";
      this.txtReference.ReadOnly = true;
      this.txtReference.Size = new System.Drawing.Size(368, 26);
      this.txtReference.TabIndex = 10;
      // 
      // txtVehicle
      // 
      this.txtVehicle.Location = new System.Drawing.Point(121, 209);
      this.txtVehicle.Name = "txtVehicle";
      this.txtVehicle.ReadOnly = true;
      this.txtVehicle.Size = new System.Drawing.Size(368, 26);
      this.txtVehicle.TabIndex = 11;
      // 
      // txtAddress
      // 
      this.txtAddress.Location = new System.Drawing.Point(258, 145);
      this.txtAddress.Name = "txtAddress";
      this.txtAddress.ReadOnly = true;
      this.txtAddress.Size = new System.Drawing.Size(230, 26);
      this.txtAddress.TabIndex = 12;
      // 
      // txtJobNote
      // 
      this.txtJobNote.Location = new System.Drawing.Point(121, 241);
      this.txtJobNote.Multiline = true;
      this.txtJobNote.Name = "txtJobNote";
      this.txtJobNote.ReadOnly = true;
      this.txtJobNote.Size = new System.Drawing.Size(368, 296);
      this.txtJobNote.TabIndex = 13;
      // 
      // txtBooking
      // 
      this.txtBooking.Location = new System.Drawing.Point(120, 177);
      this.txtBooking.Name = "txtBooking";
      this.txtBooking.ReadOnly = true;
      this.txtBooking.Size = new System.Drawing.Size(368, 26);
      this.txtBooking.TabIndex = 16;
      // 
      // txtArea
      // 
      this.txtArea.Location = new System.Drawing.Point(120, 145);
      this.txtArea.Name = "txtArea";
      this.txtArea.ReadOnly = true;
      this.txtArea.Size = new System.Drawing.Size(132, 26);
      this.txtArea.TabIndex = 17;
      // 
      // txtPayment
      // 
      this.txtPayment.Location = new System.Drawing.Point(120, 113);
      this.txtPayment.Name = "txtPayment";
      this.txtPayment.ReadOnly = true;
      this.txtPayment.Size = new System.Drawing.Size(132, 26);
      this.txtPayment.TabIndex = 18;
      // 
      // JobAllocate
      // 
      this.AcceptButton = this.btnContinue;
      this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.ClientSize = new System.Drawing.Size(976, 623);
      this.ControlBox = false;
      this.Controls.Add(this.groupBox3);
      this.Controls.Add(this.groupBox2);
      this.Controls.Add(this.groupBox1);
      this.Controls.Add(this.panel2);
      this.Controls.Add(this.toolStrip1);
      this.Controls.Add(this.panel1);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
      this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
      this.Name = "JobAllocate";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
      this.Text = "Time";
      ((System.ComponentModel.ISupportInitialize)(this.nudJobTime)).EndInit();
      this.panel1.ResumeLayout(false);
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.nudDistance)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudTravelTime)).EndInit();
      this.groupBox2.ResumeLayout(false);
      this.groupBox2.PerformLayout();
      this.groupBox3.ResumeLayout(false);
      this.groupBox3.PerformLayout();
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.panel2.ResumeLayout(false);
      this.panel2.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion
    private System.Windows.Forms.NumericUpDown nudJobTime;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Button btnContinue;
    private System.Windows.Forms.Button btnCancel;
    private System.Windows.Forms.RadioButton rbYes;
    private System.Windows.Forms.RadioButton rbNo;
    private System.Windows.Forms.Panel panel1;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.GroupBox groupBox2;
    private System.Windows.Forms.GroupBox groupBox3;
    private System.Windows.Forms.TextBox txtNote;
    private System.Windows.Forms.ToolStrip toolStrip1;
    private System.Windows.Forms.ToolStripButton tsBack;
    private System.Windows.Forms.ToolStripButton tsContinue;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.NumericUpDown nudDistance;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.NumericUpDown nudTravelTime;
    private System.Windows.Forms.Label label6;
    private System.Windows.Forms.Label label5;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.Panel panel2;
    private System.Windows.Forms.Label lblJobID;
    private System.Windows.Forms.Label label9;
    private System.Windows.Forms.Label label10;
    private System.Windows.Forms.TextBox txtCustomer;
    private System.Windows.Forms.Label label15;
    private System.Windows.Forms.Label label14;
    private System.Windows.Forms.Label label13;
    private System.Windows.Forms.Label label12;
    private System.Windows.Forms.Label label11;
    private System.Windows.Forms.TextBox txtJobNote;
    private System.Windows.Forms.TextBox txtAddress;
    private System.Windows.Forms.TextBox txtVehicle;
    private System.Windows.Forms.TextBox txtReference;
    private System.Windows.Forms.TextBox txtArea;
    private System.Windows.Forms.TextBox txtBooking;
    private System.Windows.Forms.TextBox txtPayment;
  }
}