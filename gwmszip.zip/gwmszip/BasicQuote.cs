﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workshop_orders
{
  public partial class BasicQuote : Form
  {
    private int QuoteItemID = -1;
    private int QuoteNo = -1;
    private int type = 1; //1 = Basic Quote, 2 = Installation
    public BasicQuote(int QuoteNo, int QuoteItemID, int type)
    {
      InitializeComponent();
      this.QuoteNo = QuoteNo;
      this.QuoteItemID = QuoteItemID;
      this.type = type;
      DataTable dt = DataAccess.ExecuteDataTable("SELECT quoteitemID, description, quoteitemPrice, quoteitemCost, quantity, quoteitemtype FROM quoteitems WHERE QuoteItemGroupID = " + QuoteItemID);
      if (type == 1) //basic
      {
        if (QuoteItemID > 0)
        {
          this.Text = "Basic Quote - Edit";

          if (dt != null && dt.Rows.Count > 0)
          {
            this.QuoteItemID = (int)dt.Rows[0]["quoteitemID"];
            txtDescription.Text = dt.Rows[0]["description"].ToString();
            nudCost.Value = (decimal)dt.Rows[0]["quoteitemCost"];
            nudQuote.Value = (decimal)dt.Rows[0]["quoteitemPrice"];
          }
        }
        else
        {
          this.Text = "Basic Quote - New";
          txtDescription.Text = "Basic Quote Item";
        }
      }
      else if (type == 2) //installation
      {
        tsItem.Visible = false;
        lblCostPrice.Text = "Labour Hours:";
        lblQuotePrice.Visible = false;
        nudQuote.Visible = false;
        if (QuoteItemID > 0)
        {
          this.Text = "Installation Costs - Edit";
          if (dt != null && dt.Rows.Count > 0)
          {
            nudCost.Value = (decimal)dt.Rows[0]["quantity"];

            txtDescription.Text = dt.Rows[0]["description"].ToString();
            this.Text = "Installation Costs - Edit";
            
          }
        }
        else
        {
          this.Text = "Installation Costs - New";
          groupBox1.Text = "Installation Details";
          txtDescription.Text = "Installation Cost";         
        }
      }
      DataAccess.FormState(this.AccessibilityObject.Name, tsSave);
    }


    private void tsBack_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private void tsSave_Click(object sender, EventArgs e)
    {
      decimal labourCost = DataAccess.ExecuteScalarDec("SELECT icCost FROM itemcost WHERE icCode = 'Labour'");
      decimal labourPrice = DataAccess.ExecuteScalarDec("SELECT icPrice FROM itemcost WHERE icCode = 'Labour'");
      if (QuoteItemID > 0)
      {
        if(type == 1) // basic
        {
          if(nudCost.Value >= nudQuote.Value)
          {
            bool res = DataAccess.ShowMessage("Warning: The Cost price is lower or equal to the Quote Price\n\n" +
              "Do you want to continue?", "Warning", true);
            if (!res) return;
          }
          DataAccess.QuoteItemManage(0, QuoteItemID, 0, 1, 0, 0, 0, nudCost.Value, nudQuote.Value, 0, QuoteItemID, "Basic Quote", txtDescription.Text);
        }
        else if (type == 2) //install
        {
          DataAccess.QuoteItemManage(0, QuoteItemID, 365, nudCost.Value, 0, 0, 0, labourCost, labourPrice, 0, QuoteItemID, "Installation", txtDescription.Text);
        }
        
      }
      else
      {
        int iLinkID = DataAccess.ExecuteScalarInt("SELECT MAX(quoteitemID) FROM quoteitems") + 1;
        if (type == 1) // basic
        {
          if (nudCost.Value >= nudQuote.Value)
          {
            bool res = DataAccess.ShowMessage("Warning: The Cost price is lower or equal to the Quote Price\n\n" +
              "Do you want to continue?", "Warning", true);
            if (!res) return;
          }
          DataAccess.ExecuteNonQuery("INSERT INTO quoteitemgroup (quoteno, GroupName) VALUES (" + QuoteNo + ", 'Basic Quote')");
          int itemgroupID = DataAccess.ExecuteScalarInt("SELECT MAX(quoteitemgroupID) FROM quoteitemgroup WHERE quoteno = " + QuoteNo + " AND GroupName = 'Basic Quote'");

          
          DataAccess.QuoteItemManage(QuoteNo, QuoteItemID, 0, 1, 0, 0, 0, nudCost.Value, nudQuote.Value, itemgroupID, iLinkID, "Basic Quote", txtDescription.Text);
        }
        else if (type == 2) //install
        {
          DataAccess.ExecuteNonQuery("INSERT INTO quoteitemgroup (quoteno, GroupName) VALUES (" + QuoteNo + ", 'Installation')");
          int itemgroupID = DataAccess.ExecuteScalarInt("SELECT MAX(quoteitemgroupID) FROM quoteitemgroup WHERE quoteno = " + QuoteNo + " AND GroupName = 'Installation'");

          DataAccess.QuoteItemManage(QuoteNo, QuoteItemID, 365, nudCost.Value, 0, 0, 0, labourCost, labourPrice, itemgroupID, iLinkID, "Installation", txtDescription.Text);
        }      
        
      }
      this.Close();
    }

    private void lblCostPrice_Click(object sender, EventArgs e)
    {

    }

    private void lblQuotePrice_Click(object sender, EventArgs e)
    {

    }

    private void nudCost_ValueChanged(object sender, EventArgs e)
    {
      nudQuote.Value = (decimal)nudCost.Value * (decimal)1.5;
    }

    private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
    {

    }

    private void tsItem_Click(object sender, EventArgs e)
    {
      JobItem form = new JobItem(2);
      JobItem.frm = this;
      form.quoteNo = QuoteNo;

      FormManagement.ShowDialogForm(form);
    }

    public void LoadItemData(String code, String description, decimal cost, decimal quantity)
    {
      txtDescription.Text = code + " - " + description;
      nudCost.Value = cost * quantity;
    }
  }
}
