﻿using System;
using System.IO;
using System.Windows.Forms;

namespace workshop_orders
{
    partial class Costings
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series7 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series8 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title4 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea5 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend5 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series9 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series10 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title5 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea6 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend6 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series11 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series12 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title6 = new System.Windows.Forms.DataVisualization.Charting.Title();
            this.refreshButton = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dateStart = new System.Windows.Forms.DateTimePicker();
            this.dateEnd = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.equalText = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.dateCheckBox = new System.Windows.Forms.CheckBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.pageLabel = new System.Windows.Forms.Label();
            this.downButton = new System.Windows.Forms.Button();
            this.upButton = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.pageLabel2 = new System.Windows.Forms.Label();
            this.downButton2 = new System.Windows.Forms.Button();
            this.upButton2 = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label2 = new System.Windows.Forms.Label();
            this.recentChart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.label1 = new System.Windows.Forms.Label();
            this.monthChart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.weekChart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.jobLabel = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.recentChart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.monthChart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.weekChart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // refreshButton
            // 
            this.refreshButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.refreshButton.Location = new System.Drawing.Point(342, 10);
            this.refreshButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.refreshButton.Name = "refreshButton";
            this.refreshButton.Size = new System.Drawing.Size(179, 47);
            this.refreshButton.TabIndex = 22;
            this.refreshButton.Text = "Refresh";
            this.refreshButton.UseVisualStyleBackColor = true;
            this.refreshButton.Click += new System.EventHandler(this.refreshButton_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(7, 41);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1862, 832);
            this.dataGridView1.TabIndex = 26;
            this.dataGridView1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            // 
            // dateStart
            // 
            this.dateStart.Enabled = false;
            this.dateStart.Location = new System.Drawing.Point(1059, 20);
            this.dateStart.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dateStart.Name = "dateStart";
            this.dateStart.Size = new System.Drawing.Size(300, 26);
            this.dateStart.TabIndex = 31;
            // 
            // dateEnd
            // 
            this.dateEnd.Enabled = false;
            this.dateEnd.Location = new System.Drawing.Point(1450, 20);
            this.dateEnd.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dateEnd.Name = "dateEnd";
            this.dateEnd.Size = new System.Drawing.Size(300, 26);
            this.dateEnd.TabIndex = 32;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Enabled = false;
            this.label3.Location = new System.Drawing.Point(1007, 25);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 20);
            this.label3.TabIndex = 33;
            this.label3.Text = "Start";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Enabled = false;
            this.label4.Location = new System.Drawing.Point(1393, 23);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 20);
            this.label4.TabIndex = 34;
            this.label4.Text = "End";
            // 
            // equalText
            // 
            this.equalText.Location = new System.Drawing.Point(100, 14);
            this.equalText.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.equalText.Name = "equalText";
            this.equalText.Size = new System.Drawing.Size(203, 26);
            this.equalText.TabIndex = 36;
            this.equalText.TextChanged += new System.EventHandler(this.equalText_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(13, 14);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 20);
            this.label7.TabIndex = 41;
            this.label7.Text = "Search";
            // 
            // dateCheckBox
            // 
            this.dateCheckBox.AutoSize = true;
            this.dateCheckBox.Enabled = false;
            this.dateCheckBox.Location = new System.Drawing.Point(1768, 21);
            this.dateCheckBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dateCheckBox.Name = "dateCheckBox";
            this.dateCheckBox.Size = new System.Drawing.Size(122, 24);
            this.dateCheckBox.TabIndex = 43;
            this.dateCheckBox.Text = "Custom Date";
            this.dateCheckBox.UseVisualStyleBackColor = true;
            this.dateCheckBox.CheckedChanged += new System.EventHandler(this.dateCheckBox_Select);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(8, 60);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1884, 915);
            this.tabControl1.TabIndex = 46;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            this.tabControl1.TabIndexChanged += new System.EventHandler(this.tabControl1_TabIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.pageLabel);
            this.tabPage1.Controls.Add(this.downButton);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Controls.Add(this.upButton);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1876, 882);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Current Jobs";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // pageLabel
            // 
            this.pageLabel.AutoSize = true;
            this.pageLabel.Location = new System.Drawing.Point(170, 9);
            this.pageLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.pageLabel.Name = "pageLabel";
            this.pageLabel.Size = new System.Drawing.Size(59, 20);
            this.pageLabel.TabIndex = 47;
            this.pageLabel.Text = "Page 1";
            // 
            // downButton
            // 
            this.downButton.Location = new System.Drawing.Point(88, 6);
            this.downButton.Name = "downButton";
            this.downButton.Size = new System.Drawing.Size(75, 27);
            this.downButton.TabIndex = 49;
            this.downButton.Text = ">>";
            this.downButton.UseVisualStyleBackColor = true;
            this.downButton.Click += new System.EventHandler(this.downButton_Click);
            // 
            // upButton
            // 
            this.upButton.Location = new System.Drawing.Point(7, 6);
            this.upButton.Name = "upButton";
            this.upButton.Size = new System.Drawing.Size(75, 27);
            this.upButton.TabIndex = 48;
            this.upButton.Text = "<<";
            this.upButton.UseVisualStyleBackColor = true;
            this.upButton.Click += new System.EventHandler(this.upButton_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.pageLabel2);
            this.tabPage2.Controls.Add(this.downButton2);
            this.tabPage2.Controls.Add(this.upButton2);
            this.tabPage2.Controls.Add(this.dataGridView2);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1876, 882);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Completed";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // pageLabel2
            // 
            this.pageLabel2.AutoSize = true;
            this.pageLabel2.Location = new System.Drawing.Point(170, 9);
            this.pageLabel2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.pageLabel2.Name = "pageLabel2";
            this.pageLabel2.Size = new System.Drawing.Size(59, 20);
            this.pageLabel2.TabIndex = 52;
            this.pageLabel2.Text = "Page 1";
            // 
            // downButton2
            // 
            this.downButton2.Location = new System.Drawing.Point(88, 6);
            this.downButton2.Name = "downButton2";
            this.downButton2.Size = new System.Drawing.Size(75, 27);
            this.downButton2.TabIndex = 51;
            this.downButton2.Text = ">>";
            this.downButton2.UseVisualStyleBackColor = true;
            this.downButton2.Click += new System.EventHandler(this.downButton2_Click);
            // 
            // upButton2
            // 
            this.upButton2.Location = new System.Drawing.Point(7, 6);
            this.upButton2.Name = "upButton2";
            this.upButton2.Size = new System.Drawing.Size(75, 27);
            this.upButton2.TabIndex = 50;
            this.upButton2.Text = "<<";
            this.upButton2.UseVisualStyleBackColor = true;
            this.upButton2.Click += new System.EventHandler(this.upButton2_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label2);
            this.tabPage3.Controls.Add(this.recentChart);
            this.tabPage3.Controls.Add(this.monthCalendar1);
            this.tabPage3.Controls.Add(this.label1);
            this.tabPage3.Controls.Add(this.monthChart);
            this.tabPage3.Controls.Add(this.weekChart);
            this.tabPage3.Controls.Add(this.jobLabel);
            this.tabPage3.Location = new System.Drawing.Point(4, 29);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1876, 882);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Graphs";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 412);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 20);
            this.label2.TabIndex = 65;
            this.label2.Text = "Recent Jobs";
            // 
            // recentChart
            // 
            chartArea4.Name = "ChartArea1";
            this.recentChart.ChartAreas.Add(chartArea4);
            legend4.Name = "Legend1";
            this.recentChart.Legends.Add(legend4);
            this.recentChart.Location = new System.Drawing.Point(28, 435);
            this.recentChart.Name = "recentChart";
            series7.ChartArea = "ChartArea1";
            series7.Legend = "Legend1";
            series7.Name = "Actual Cost";
            series8.ChartArea = "ChartArea1";
            series8.Legend = "Legend1";
            series8.Name = "Charge Out";
            this.recentChart.Series.Add(series7);
            this.recentChart.Series.Add(series8);
            this.recentChart.Size = new System.Drawing.Size(1482, 300);
            this.recentChart.TabIndex = 64;
            this.recentChart.Text = "chart2";
            title4.Name = "Title1";
            this.recentChart.Titles.Add(title4);
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(1526, 20);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 63;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(807, 39);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 20);
            this.label1.TabIndex = 62;
            this.label1.Text = "Monthly";
            // 
            // monthChart
            // 
            chartArea5.Name = "ChartArea1";
            this.monthChart.ChartAreas.Add(chartArea5);
            legend5.Name = "Legend1";
            this.monthChart.Legends.Add(legend5);
            this.monthChart.Location = new System.Drawing.Point(783, 62);
            this.monthChart.Name = "monthChart";
            series9.ChartArea = "ChartArea1";
            series9.Legend = "Legend1";
            series9.Name = "Actual Cost";
            series10.ChartArea = "ChartArea1";
            series10.Legend = "Legend1";
            series10.Name = "Charge Out";
            this.monthChart.Series.Add(series9);
            this.monthChart.Series.Add(series10);
            this.monthChart.Size = new System.Drawing.Size(675, 300);
            this.monthChart.TabIndex = 61;
            this.monthChart.Text = "chart2";
            title5.Name = "Title1";
            this.monthChart.Titles.Add(title5);
            // 
            // weekChart
            // 
            chartArea6.Name = "ChartArea1";
            this.weekChart.ChartAreas.Add(chartArea6);
            legend6.Name = "Legend1";
            this.weekChart.Legends.Add(legend6);
            this.weekChart.Location = new System.Drawing.Point(28, 62);
            this.weekChart.Name = "weekChart";
            series11.ChartArea = "ChartArea1";
            series11.Legend = "Legend1";
            series11.Name = "Actual Cost";
            series12.ChartArea = "ChartArea1";
            series12.Legend = "Legend1";
            series12.Name = "Charge Out";
            this.weekChart.Series.Add(series11);
            this.weekChart.Series.Add(series12);
            this.weekChart.Size = new System.Drawing.Size(675, 300);
            this.weekChart.TabIndex = 60;
            this.weekChart.Text = "chart1";
            title6.Name = "Title1";
            this.weekChart.Titles.Add(title6);
            // 
            // jobLabel
            // 
            this.jobLabel.AutoSize = true;
            this.jobLabel.Location = new System.Drawing.Point(24, 20);
            this.jobLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.jobLabel.Name = "jobLabel";
            this.jobLabel.Size = new System.Drawing.Size(60, 20);
            this.jobLabel.TabIndex = 59;
            this.jobLabel.Text = "Weekly";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(7, 41);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(1862, 833);
            this.dataGridView2.TabIndex = 47;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            this.dataGridView2.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellDoubleClick);
            // 
            // Costings
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1904, 1046);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.dateCheckBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.equalText);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dateEnd);
            this.Controls.Add(this.dateStart);
            this.Controls.Add(this.refreshButton);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximizeBox = false;
            this.Name = "Costings";
            this.Text = "BMS - View Jobs";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Resize += new System.EventHandler(this.ViewJobForm_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.recentChart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.monthChart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.weekChart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Button refreshButton;
        private DataGridView dataGridView1;
        private DateTimePicker dateStart;
        private DateTimePicker dateEnd;
        private Label label3;
        private Label label4;
        private TextBox equalText;
        private Label label7;
        private CheckBox dateCheckBox;
        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private Button downButton;
        private Button upButton;
        private Button downButton2;
        private Button upButton2;
        private Label pageLabel;
        private Label pageLabel2;
        private TabPage tabPage3;
        private Label label1;
        private System.Windows.Forms.DataVisualization.Charting.Chart monthChart;
        private System.Windows.Forms.DataVisualization.Charting.Chart weekChart;
        private Label jobLabel;
        private MonthCalendar monthCalendar1;
        private System.Windows.Forms.DataVisualization.Charting.Chart recentChart;
        private Label label2;
        private DataGridView dataGridView2;
    }
}

