﻿using System;
using System.IO;
using System.Windows.Forms;

namespace workshop_orders
{
    partial class JobView

    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
      this.components = new System.ComponentModel.Container();
      System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
      System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
      System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
      System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
      this.calDate = new System.Windows.Forms.MonthCalendar();
      this.chHours = new System.Windows.Forms.DataVisualization.Charting.Chart();
      this.timer1 = new System.Windows.Forms.Timer(this.components);
      this.toolStrip1 = new System.Windows.Forms.ToolStrip();
      this.tsBack = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
      this.tsNew = new System.Windows.Forms.ToolStripButton();
      this.tsEdit = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
      this.tsRefresh = new System.Windows.Forms.ToolStripButton();
      this.tsToday = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
      this.tsPrevious = new System.Windows.Forms.ToolStripButton();
      this.tsNext = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
      this.tsReport = new System.Windows.Forms.ToolStripButton();
      this.pnlProduction = new System.Windows.Forms.Panel();
      this.panel2 = new System.Windows.Forms.Panel();
      this.tcProduction = new System.Windows.Forms.TabControl();
      this.tpVehicle = new System.Windows.Forms.TabPage();
      this.gbVehicleAfternoon = new System.Windows.Forms.GroupBox();
      this.dgvVehicleAfternoon = new System.Windows.Forms.DataGridView();
      this.gbVehicleMorning = new System.Windows.Forms.GroupBox();
      this.dgvVehicleMorning = new System.Windows.Forms.DataGridView();
      this.label1 = new System.Windows.Forms.Label();
      this.dataGridView1 = new System.Windows.Forms.DataGridView();
      this.tpGlass = new System.Windows.Forms.TabPage();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.dgvGlassAfternoon = new System.Windows.Forms.DataGridView();
      this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.TypeColor4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.groupBox2 = new System.Windows.Forms.GroupBox();
      this.dgvGlassMorning = new System.Windows.Forms.DataGridView();
      this.colGlassTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.colGlassJob = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.colGlassReference = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.colGlassType = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.TypeColor3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.label2 = new System.Windows.Forms.Label();
      this.dataGridView4 = new System.Windows.Forms.DataGridView();
      this.Time = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Job = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Reference = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Customer = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Vehicle = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chRecal = new System.Windows.Forms.DataGridViewCheckBoxColumn();
      this.Type = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Payment = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Location = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Note = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.TypeColor = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.colAfterTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.colAfterJob = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.colAfterReference = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.colAfterCustomer = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.colAfterVehicle = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chRecalAfter = new System.Windows.Forms.DataGridViewCheckBoxColumn();
      this.colAfterType = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.colAfterStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.colAfterPayment = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.colAfterLocation = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.colAfterNote = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.TypeColor2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      ((System.ComponentModel.ISupportInitialize)(this.chHours)).BeginInit();
      this.toolStrip1.SuspendLayout();
      this.pnlProduction.SuspendLayout();
      this.panel2.SuspendLayout();
      this.tcProduction.SuspendLayout();
      this.tpVehicle.SuspendLayout();
      this.gbVehicleAfternoon.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgvVehicleAfternoon)).BeginInit();
      this.gbVehicleMorning.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgvVehicleMorning)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
      this.tpGlass.SuspendLayout();
      this.groupBox1.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgvGlassAfternoon)).BeginInit();
      this.groupBox2.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgvGlassMorning)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
      this.SuspendLayout();
      // 
      // calDate
      // 
      this.calDate.CalendarDimensions = new System.Drawing.Size(1, 2);
      this.calDate.FirstDayOfWeek = System.Windows.Forms.Day.Sunday;
      this.calDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.calDate.Location = new System.Drawing.Point(9, 9);
      this.calDate.MaxSelectionCount = 1;
      this.calDate.MinDate = new System.DateTime(2020, 8, 1, 0, 0, 0, 0);
      this.calDate.Name = "calDate";
      this.calDate.ShowWeekNumbers = true;
      this.calDate.TabIndex = 0;
      this.calDate.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar1_DateSelected);
      // 
      // chHours
      // 
      chartArea1.Name = "ChartArea1";
      this.chHours.ChartAreas.Add(chartArea1);
      legend1.Name = "Legend1";
      this.chHours.Legends.Add(legend1);
      this.chHours.Location = new System.Drawing.Point(9, 317);
      this.chHours.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
      this.chHours.Name = "chHours";
      series1.ChartArea = "ChartArea1";
      series1.Legend = "Legend1";
      series1.Name = "A";
      series2.ChartArea = "ChartArea1";
      series2.Legend = "Legend1";
      series2.Name = "T";
      this.chHours.Series.Add(series1);
      this.chHours.Series.Add(series2);
      this.chHours.Size = new System.Drawing.Size(249, 182);
      this.chHours.TabIndex = 1;
      this.chHours.Text = "chart1";
      // 
      // timer1
      // 
      this.timer1.Enabled = true;
      this.timer1.Interval = 60000;
      this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
      // 
      // toolStrip1
      // 
      this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
      this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsBack,
            this.toolStripSeparator1,
            this.tsNew,
            this.tsEdit,
            this.toolStripSeparator2,
            this.tsRefresh,
            this.tsToday,
            this.toolStripSeparator3,
            this.tsPrevious,
            this.tsNext,
            this.toolStripSeparator4,
            this.tsReport});
      this.toolStrip1.Location = new System.Drawing.Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new System.Drawing.Size(1880, 39);
      this.toolStrip1.TabIndex = 53;
      this.toolStrip1.Text = "toolStrip1";
      // 
      // tsBack
      // 
      this.tsBack.Image = global::workshop_orders.Properties.Resources.back;
      this.tsBack.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsBack.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsBack.Name = "tsBack";
      this.tsBack.Size = new System.Drawing.Size(68, 36);
      this.tsBack.Text = "Back";
      this.tsBack.Click += new System.EventHandler(this.tsBack_Click);
      // 
      // toolStripSeparator1
      // 
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
      // 
      // tsNew
      // 
      this.tsNew.Image = global::workshop_orders.Properties.Resources.addnew;
      this.tsNew.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsNew.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsNew.Name = "tsNew";
      this.tsNew.Size = new System.Drawing.Size(88, 36);
      this.tsNew.Text = "New Job";
      this.tsNew.Click += new System.EventHandler(this.tsNew_Click);
      // 
      // tsEdit
      // 
      this.tsEdit.Image = global::workshop_orders.Properties.Resources.edit;
      this.tsEdit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsEdit.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsEdit.Name = "tsEdit";
      this.tsEdit.Size = new System.Drawing.Size(84, 36);
      this.tsEdit.Text = "Edit Job";
      this.tsEdit.Visible = false;
      this.tsEdit.Click += new System.EventHandler(this.tsEdit_Click);
      // 
      // toolStripSeparator2
      // 
      this.toolStripSeparator2.Name = "toolStripSeparator2";
      this.toolStripSeparator2.Size = new System.Drawing.Size(6, 39);
      // 
      // tsRefresh
      // 
      this.tsRefresh.Image = global::workshop_orders.Properties.Resources.refresh;
      this.tsRefresh.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsRefresh.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsRefresh.Name = "tsRefresh";
      this.tsRefresh.Size = new System.Drawing.Size(82, 36);
      this.tsRefresh.Text = "Refresh";
      this.tsRefresh.Click += new System.EventHandler(this.tsRefresh_Click);
      // 
      // tsToday
      // 
      this.tsToday.Image = global::workshop_orders.Properties.Resources.calendar_day32_v1;
      this.tsToday.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsToday.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsToday.Name = "tsToday";
      this.tsToday.Size = new System.Drawing.Size(74, 36);
      this.tsToday.Text = "Today";
      this.tsToday.Click += new System.EventHandler(this.tsToday_Click);
      // 
      // toolStripSeparator3
      // 
      this.toolStripSeparator3.Name = "toolStripSeparator3";
      this.toolStripSeparator3.Size = new System.Drawing.Size(6, 39);
      // 
      // tsPrevious
      // 
      this.tsPrevious.Image = global::workshop_orders.Properties.Resources.arrow_back32;
      this.tsPrevious.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsPrevious.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsPrevious.Name = "tsPrevious";
      this.tsPrevious.Size = new System.Drawing.Size(92, 36);
      this.tsPrevious.Text = "Prev. Day";
      this.tsPrevious.Click += new System.EventHandler(this.tsPrevious_Click);
      // 
      // tsNext
      // 
      this.tsNext.Image = global::workshop_orders.Properties.Resources.arrow_next32;
      this.tsNext.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsNext.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsNext.Name = "tsNext";
      this.tsNext.Size = new System.Drawing.Size(91, 36);
      this.tsNext.Text = "Next Day";
      this.tsNext.Click += new System.EventHandler(this.tsNext_Click);
      // 
      // toolStripSeparator4
      // 
      this.toolStripSeparator4.Name = "toolStripSeparator4";
      this.toolStripSeparator4.Size = new System.Drawing.Size(6, 39);
      // 
      // tsReport
      // 
      this.tsReport.Image = global::workshop_orders.Properties.Resources.report32;
      this.tsReport.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsReport.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsReport.Name = "tsReport";
      this.tsReport.Size = new System.Drawing.Size(101, 36);
      this.tsReport.Text = "Day Report";
      this.tsReport.Click += new System.EventHandler(this.tsReport_Click);
      // 
      // pnlProduction
      // 
      this.pnlProduction.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(210)))));
      this.pnlProduction.Controls.Add(this.calDate);
      this.pnlProduction.Controls.Add(this.chHours);
      this.pnlProduction.Dock = System.Windows.Forms.DockStyle.Left;
      this.pnlProduction.Location = new System.Drawing.Point(0, 39);
      this.pnlProduction.Name = "pnlProduction";
      this.pnlProduction.Size = new System.Drawing.Size(267, 937);
      this.pnlProduction.TabIndex = 54;
      // 
      // panel2
      // 
      this.panel2.Controls.Add(this.tcProduction);
      this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
      this.panel2.Location = new System.Drawing.Point(267, 39);
      this.panel2.Name = "panel2";
      this.panel2.Size = new System.Drawing.Size(1613, 937);
      this.panel2.TabIndex = 55;
      // 
      // tcProduction
      // 
      this.tcProduction.Controls.Add(this.tpVehicle);
      this.tcProduction.Controls.Add(this.tpGlass);
      this.tcProduction.Dock = System.Windows.Forms.DockStyle.Fill;
      this.tcProduction.Location = new System.Drawing.Point(0, 0);
      this.tcProduction.Name = "tcProduction";
      this.tcProduction.SelectedIndex = 0;
      this.tcProduction.Size = new System.Drawing.Size(1613, 937);
      this.tcProduction.TabIndex = 49;
      this.tcProduction.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
      // 
      // tpVehicle
      // 
      this.tpVehicle.Controls.Add(this.gbVehicleAfternoon);
      this.tpVehicle.Controls.Add(this.gbVehicleMorning);
      this.tpVehicle.Location = new System.Drawing.Point(4, 29);
      this.tpVehicle.Name = "tpVehicle";
      this.tpVehicle.Padding = new System.Windows.Forms.Padding(3);
      this.tpVehicle.Size = new System.Drawing.Size(1605, 904);
      this.tpVehicle.TabIndex = 0;
      this.tpVehicle.Text = "Vehicle";
      this.tpVehicle.UseVisualStyleBackColor = true;
      // 
      // gbVehicleAfternoon
      // 
      this.gbVehicleAfternoon.Controls.Add(this.dgvVehicleAfternoon);
      this.gbVehicleAfternoon.Dock = System.Windows.Forms.DockStyle.Fill;
      this.gbVehicleAfternoon.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbVehicleAfternoon.Location = new System.Drawing.Point(3, 416);
      this.gbVehicleAfternoon.Name = "gbVehicleAfternoon";
      this.gbVehicleAfternoon.Size = new System.Drawing.Size(1599, 485);
      this.gbVehicleAfternoon.TabIndex = 61;
      this.gbVehicleAfternoon.TabStop = false;
      this.gbVehicleAfternoon.Text = "Afternoon";
      // 
      // dgvVehicleAfternoon
      // 
      this.dgvVehicleAfternoon.AllowUserToAddRows = false;
      this.dgvVehicleAfternoon.AllowUserToDeleteRows = false;
      dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
      this.dgvVehicleAfternoon.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
      this.dgvVehicleAfternoon.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      this.dgvVehicleAfternoon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvVehicleAfternoon.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colAfterTime,
            this.colAfterJob,
            this.colAfterReference,
            this.colAfterCustomer,
            this.colAfterVehicle,
            this.chRecalAfter,
            this.colAfterType,
            this.colAfterStatus,
            this.colAfterPayment,
            this.colAfterLocation,
            this.colAfterNote,
            this.TypeColor2});
      this.dgvVehicleAfternoon.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dgvVehicleAfternoon.GridColor = System.Drawing.SystemColors.AppWorkspace;
      this.dgvVehicleAfternoon.Location = new System.Drawing.Point(3, 22);
      this.dgvVehicleAfternoon.MultiSelect = false;
      this.dgvVehicleAfternoon.Name = "dgvVehicleAfternoon";
      this.dgvVehicleAfternoon.ReadOnly = true;
      this.dgvVehicleAfternoon.RowHeadersWidth = 5;
      dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.dgvVehicleAfternoon.RowsDefaultCellStyle = dataGridViewCellStyle9;
      this.dgvVehicleAfternoon.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
      this.dgvVehicleAfternoon.Size = new System.Drawing.Size(1593, 460);
      this.dgvVehicleAfternoon.TabIndex = 52;
      this.dgvVehicleAfternoon.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvVehicleAfternoon_CellClick);
      this.dgvVehicleAfternoon.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvVehicleAfternoon_CellDoubleClick);
      // 
      // gbVehicleMorning
      // 
      this.gbVehicleMorning.Controls.Add(this.dgvVehicleMorning);
      this.gbVehicleMorning.Controls.Add(this.label1);
      this.gbVehicleMorning.Controls.Add(this.dataGridView1);
      this.gbVehicleMorning.Dock = System.Windows.Forms.DockStyle.Top;
      this.gbVehicleMorning.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbVehicleMorning.Location = new System.Drawing.Point(3, 3);
      this.gbVehicleMorning.Name = "gbVehicleMorning";
      this.gbVehicleMorning.Size = new System.Drawing.Size(1599, 413);
      this.gbVehicleMorning.TabIndex = 60;
      this.gbVehicleMorning.TabStop = false;
      this.gbVehicleMorning.Text = "Morning";
      // 
      // dgvVehicleMorning
      // 
      this.dgvVehicleMorning.AllowUserToAddRows = false;
      this.dgvVehicleMorning.AllowUserToDeleteRows = false;
      dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
      this.dgvVehicleMorning.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle10;
      this.dgvVehicleMorning.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      this.dgvVehicleMorning.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvVehicleMorning.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Time,
            this.Job,
            this.Reference,
            this.Customer,
            this.Vehicle,
            this.chRecal,
            this.Type,
            this.Status,
            this.Payment,
            this.Location,
            this.Note,
            this.TypeColor});
      this.dgvVehicleMorning.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dgvVehicleMorning.GridColor = System.Drawing.SystemColors.AppWorkspace;
      this.dgvVehicleMorning.Location = new System.Drawing.Point(3, 22);
      this.dgvVehicleMorning.MultiSelect = false;
      this.dgvVehicleMorning.Name = "dgvVehicleMorning";
      this.dgvVehicleMorning.ReadOnly = true;
      this.dgvVehicleMorning.RowHeadersWidth = 5;
      dataGridViewCellStyle18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.dgvVehicleMorning.RowsDefaultCellStyle = dataGridViewCellStyle18;
      this.dgvVehicleMorning.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
      this.dgvVehicleMorning.Size = new System.Drawing.Size(1593, 388);
      this.dgvVehicleMorning.TabIndex = 51;
      this.dgvVehicleMorning.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.mornDataGrid_CellDoubleClick);
      this.dgvVehicleMorning.Click += new System.EventHandler(this.dgvVehicleMorning_Click);
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label1.Location = new System.Drawing.Point(693, 46);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(21, 31);
      this.label1.TabIndex = 50;
      this.label1.Text = " ";
      // 
      // dataGridView1
      // 
      this.dataGridView1.AllowUserToAddRows = false;
      this.dataGridView1.AllowUserToDeleteRows = false;
      this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
      this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dataGridView1.GridColor = System.Drawing.SystemColors.AppWorkspace;
      this.dataGridView1.Location = new System.Drawing.Point(720, 25);
      this.dataGridView1.Name = "dataGridView1";
      this.dataGridView1.ReadOnly = true;
      this.dataGridView1.Size = new System.Drawing.Size(761, 330);
      this.dataGridView1.TabIndex = 56;
      // 
      // tpGlass
      // 
      this.tpGlass.Controls.Add(this.groupBox1);
      this.tpGlass.Controls.Add(this.groupBox2);
      this.tpGlass.Location = new System.Drawing.Point(4, 29);
      this.tpGlass.Name = "tpGlass";
      this.tpGlass.Size = new System.Drawing.Size(1605, 904);
      this.tpGlass.TabIndex = 3;
      this.tpGlass.Text = "Glass";
      this.tpGlass.UseVisualStyleBackColor = true;
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.Add(this.dgvGlassAfternoon);
      this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.groupBox1.Location = new System.Drawing.Point(0, 413);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(1605, 491);
      this.groupBox1.TabIndex = 63;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Afternoon";
      // 
      // dgvGlassAfternoon
      // 
      this.dgvGlassAfternoon.AllowUserToAddRows = false;
      this.dgvGlassAfternoon.AllowUserToDeleteRows = false;
      dataGridViewCellStyle19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
      this.dgvGlassAfternoon.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle19;
      this.dgvGlassAfternoon.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      this.dgvGlassAfternoon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvGlassAfternoon.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.TypeColor4});
      this.dgvGlassAfternoon.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dgvGlassAfternoon.GridColor = System.Drawing.SystemColors.AppWorkspace;
      this.dgvGlassAfternoon.Location = new System.Drawing.Point(3, 22);
      this.dgvGlassAfternoon.MultiSelect = false;
      this.dgvGlassAfternoon.Name = "dgvGlassAfternoon";
      this.dgvGlassAfternoon.ReadOnly = true;
      this.dgvGlassAfternoon.RowHeadersWidth = 5;
      dataGridViewCellStyle26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.dgvGlassAfternoon.RowsDefaultCellStyle = dataGridViewCellStyle26;
      this.dgvGlassAfternoon.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
      this.dgvGlassAfternoon.Size = new System.Drawing.Size(1599, 466);
      this.dgvGlassAfternoon.TabIndex = 52;
      this.dgvGlassAfternoon.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvGlassAfternoon_CellDoubleClick);
      this.dgvGlassAfternoon.Click += new System.EventHandler(this.dgvGlassAfternoon_Click);
      // 
      // dataGridViewTextBoxColumn1
      // 
      this.dataGridViewTextBoxColumn1.DataPropertyName = "JobBookingDate";
      dataGridViewCellStyle20.Format = "t";
      dataGridViewCellStyle20.NullValue = null;
      this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle20;
      this.dataGridViewTextBoxColumn1.HeaderText = "Time";
      this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
      this.dataGridViewTextBoxColumn1.ReadOnly = true;
      this.dataGridViewTextBoxColumn1.Width = 80;
      // 
      // dataGridViewTextBoxColumn2
      // 
      this.dataGridViewTextBoxColumn2.DataPropertyName = "JobID";
      this.dataGridViewTextBoxColumn2.HeaderText = "Job";
      this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
      this.dataGridViewTextBoxColumn2.ReadOnly = true;
      this.dataGridViewTextBoxColumn2.Width = 70;
      // 
      // dataGridViewTextBoxColumn4
      // 
      this.dataGridViewTextBoxColumn4.DataPropertyName = "JobReference";
      this.dataGridViewTextBoxColumn4.HeaderText = "Reference";
      this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
      this.dataGridViewTextBoxColumn4.ReadOnly = true;
      this.dataGridViewTextBoxColumn4.Width = 120;
      // 
      // dataGridViewTextBoxColumn5
      // 
      this.dataGridViewTextBoxColumn5.DataPropertyName = "CustomerName";
      this.dataGridViewTextBoxColumn5.HeaderText = "Customer";
      this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
      this.dataGridViewTextBoxColumn5.ReadOnly = true;
      this.dataGridViewTextBoxColumn5.Width = 220;
      // 
      // dataGridViewTextBoxColumn3
      // 
      this.dataGridViewTextBoxColumn3.DataPropertyName = "TypeName";
      dataGridViewCellStyle21.SelectionBackColor = System.Drawing.Color.Transparent;
      dataGridViewCellStyle21.SelectionForeColor = System.Drawing.Color.Black;
      this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle21;
      this.dataGridViewTextBoxColumn3.HeaderText = "Type";
      this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
      this.dataGridViewTextBoxColumn3.ReadOnly = true;
      this.dataGridViewTextBoxColumn3.Width = 150;
      // 
      // dataGridViewTextBoxColumn7
      // 
      this.dataGridViewTextBoxColumn7.DataPropertyName = "StatusName";
      dataGridViewCellStyle22.SelectionBackColor = System.Drawing.Color.Transparent;
      dataGridViewCellStyle22.SelectionForeColor = System.Drawing.Color.Black;
      this.dataGridViewTextBoxColumn7.DefaultCellStyle = dataGridViewCellStyle22;
      this.dataGridViewTextBoxColumn7.HeaderText = "Status";
      this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
      this.dataGridViewTextBoxColumn7.ReadOnly = true;
      this.dataGridViewTextBoxColumn7.Width = 120;
      // 
      // dataGridViewTextBoxColumn8
      // 
      this.dataGridViewTextBoxColumn8.DataPropertyName = "Payment";
      dataGridViewCellStyle23.SelectionBackColor = System.Drawing.Color.Transparent;
      dataGridViewCellStyle23.SelectionForeColor = System.Drawing.Color.Black;
      this.dataGridViewTextBoxColumn8.DefaultCellStyle = dataGridViewCellStyle23;
      this.dataGridViewTextBoxColumn8.HeaderText = "Payment";
      this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
      this.dataGridViewTextBoxColumn8.ReadOnly = true;
      // 
      // dataGridViewTextBoxColumn9
      // 
      this.dataGridViewTextBoxColumn9.DataPropertyName = "AreaName";
      dataGridViewCellStyle24.SelectionBackColor = System.Drawing.Color.Transparent;
      dataGridViewCellStyle24.SelectionForeColor = System.Drawing.Color.Black;
      this.dataGridViewTextBoxColumn9.DefaultCellStyle = dataGridViewCellStyle24;
      this.dataGridViewTextBoxColumn9.HeaderText = "Location";
      this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
      this.dataGridViewTextBoxColumn9.ReadOnly = true;
      // 
      // dataGridViewTextBoxColumn10
      // 
      this.dataGridViewTextBoxColumn10.DataPropertyName = "JobNote";
      dataGridViewCellStyle25.ForeColor = System.Drawing.Color.Black;
      dataGridViewCellStyle25.SelectionBackColor = System.Drawing.Color.Transparent;
      dataGridViewCellStyle25.SelectionForeColor = System.Drawing.Color.Black;
      this.dataGridViewTextBoxColumn10.DefaultCellStyle = dataGridViewCellStyle25;
      this.dataGridViewTextBoxColumn10.HeaderText = "Note";
      this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
      this.dataGridViewTextBoxColumn10.ReadOnly = true;
      this.dataGridViewTextBoxColumn10.Width = 280;
      // 
      // TypeColor4
      // 
      this.TypeColor4.DataPropertyName = "TypeColor";
      this.TypeColor4.HeaderText = "Color";
      this.TypeColor4.Name = "TypeColor4";
      this.TypeColor4.ReadOnly = true;
      this.TypeColor4.Visible = false;
      // 
      // groupBox2
      // 
      this.groupBox2.Controls.Add(this.dgvGlassMorning);
      this.groupBox2.Controls.Add(this.label2);
      this.groupBox2.Controls.Add(this.dataGridView4);
      this.groupBox2.Dock = System.Windows.Forms.DockStyle.Top;
      this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.groupBox2.Location = new System.Drawing.Point(0, 0);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new System.Drawing.Size(1605, 413);
      this.groupBox2.TabIndex = 62;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Morning";
      // 
      // dgvGlassMorning
      // 
      this.dgvGlassMorning.AllowUserToAddRows = false;
      this.dgvGlassMorning.AllowUserToDeleteRows = false;
      dataGridViewCellStyle27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
      this.dgvGlassMorning.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle27;
      this.dgvGlassMorning.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      this.dgvGlassMorning.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvGlassMorning.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colGlassTime,
            this.colGlassJob,
            this.colGlassReference,
            this.dataGridViewTextBoxColumn15,
            this.colGlassType,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18,
            this.dataGridViewTextBoxColumn19,
            this.dataGridViewTextBoxColumn20,
            this.TypeColor3});
      this.dgvGlassMorning.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dgvGlassMorning.GridColor = System.Drawing.SystemColors.AppWorkspace;
      this.dgvGlassMorning.Location = new System.Drawing.Point(3, 22);
      this.dgvGlassMorning.MultiSelect = false;
      this.dgvGlassMorning.Name = "dgvGlassMorning";
      this.dgvGlassMorning.ReadOnly = true;
      this.dgvGlassMorning.RowHeadersWidth = 5;
      dataGridViewCellStyle34.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.dgvGlassMorning.RowsDefaultCellStyle = dataGridViewCellStyle34;
      this.dgvGlassMorning.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
      this.dgvGlassMorning.Size = new System.Drawing.Size(1599, 388);
      this.dgvGlassMorning.TabIndex = 51;
      this.dgvGlassMorning.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvGlassMorning_CellDoubleClick);
      this.dgvGlassMorning.Click += new System.EventHandler(this.dgvGlassMorning_Click);
      // 
      // colGlassTime
      // 
      this.colGlassTime.DataPropertyName = "JobBookingDate";
      dataGridViewCellStyle28.Format = "t";
      dataGridViewCellStyle28.NullValue = null;
      this.colGlassTime.DefaultCellStyle = dataGridViewCellStyle28;
      this.colGlassTime.HeaderText = "Time";
      this.colGlassTime.Name = "colGlassTime";
      this.colGlassTime.ReadOnly = true;
      this.colGlassTime.Width = 80;
      // 
      // colGlassJob
      // 
      this.colGlassJob.DataPropertyName = "JobID";
      this.colGlassJob.HeaderText = "Job";
      this.colGlassJob.Name = "colGlassJob";
      this.colGlassJob.ReadOnly = true;
      this.colGlassJob.Width = 70;
      // 
      // colGlassReference
      // 
      this.colGlassReference.DataPropertyName = "JobReference";
      this.colGlassReference.HeaderText = "Reference";
      this.colGlassReference.Name = "colGlassReference";
      this.colGlassReference.ReadOnly = true;
      this.colGlassReference.Width = 120;
      // 
      // dataGridViewTextBoxColumn15
      // 
      this.dataGridViewTextBoxColumn15.DataPropertyName = "CustomerName";
      this.dataGridViewTextBoxColumn15.HeaderText = "Customer";
      this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
      this.dataGridViewTextBoxColumn15.ReadOnly = true;
      this.dataGridViewTextBoxColumn15.Width = 220;
      // 
      // colGlassType
      // 
      this.colGlassType.DataPropertyName = "TypeName";
      dataGridViewCellStyle29.SelectionBackColor = System.Drawing.Color.Transparent;
      dataGridViewCellStyle29.SelectionForeColor = System.Drawing.Color.Black;
      this.colGlassType.DefaultCellStyle = dataGridViewCellStyle29;
      this.colGlassType.HeaderText = "Type";
      this.colGlassType.Name = "colGlassType";
      this.colGlassType.ReadOnly = true;
      this.colGlassType.Width = 150;
      // 
      // dataGridViewTextBoxColumn17
      // 
      this.dataGridViewTextBoxColumn17.DataPropertyName = "StatusName";
      dataGridViewCellStyle30.ForeColor = System.Drawing.Color.Black;
      dataGridViewCellStyle30.SelectionBackColor = System.Drawing.Color.Transparent;
      dataGridViewCellStyle30.SelectionForeColor = System.Drawing.Color.Black;
      this.dataGridViewTextBoxColumn17.DefaultCellStyle = dataGridViewCellStyle30;
      this.dataGridViewTextBoxColumn17.HeaderText = "Status";
      this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
      this.dataGridViewTextBoxColumn17.ReadOnly = true;
      this.dataGridViewTextBoxColumn17.Width = 120;
      // 
      // dataGridViewTextBoxColumn18
      // 
      this.dataGridViewTextBoxColumn18.DataPropertyName = "Payment";
      dataGridViewCellStyle31.ForeColor = System.Drawing.Color.Black;
      dataGridViewCellStyle31.SelectionBackColor = System.Drawing.Color.Transparent;
      dataGridViewCellStyle31.SelectionForeColor = System.Drawing.Color.Black;
      this.dataGridViewTextBoxColumn18.DefaultCellStyle = dataGridViewCellStyle31;
      this.dataGridViewTextBoxColumn18.HeaderText = "Payment";
      this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
      this.dataGridViewTextBoxColumn18.ReadOnly = true;
      // 
      // dataGridViewTextBoxColumn19
      // 
      this.dataGridViewTextBoxColumn19.DataPropertyName = "AreaName";
      dataGridViewCellStyle32.ForeColor = System.Drawing.Color.Black;
      dataGridViewCellStyle32.SelectionBackColor = System.Drawing.Color.Transparent;
      dataGridViewCellStyle32.SelectionForeColor = System.Drawing.Color.Black;
      this.dataGridViewTextBoxColumn19.DefaultCellStyle = dataGridViewCellStyle32;
      this.dataGridViewTextBoxColumn19.HeaderText = "Location";
      this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
      this.dataGridViewTextBoxColumn19.ReadOnly = true;
      // 
      // dataGridViewTextBoxColumn20
      // 
      this.dataGridViewTextBoxColumn20.DataPropertyName = "JobNote";
      dataGridViewCellStyle33.ForeColor = System.Drawing.Color.Black;
      dataGridViewCellStyle33.SelectionBackColor = System.Drawing.Color.Transparent;
      dataGridViewCellStyle33.SelectionForeColor = System.Drawing.Color.Black;
      this.dataGridViewTextBoxColumn20.DefaultCellStyle = dataGridViewCellStyle33;
      this.dataGridViewTextBoxColumn20.HeaderText = "Note";
      this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
      this.dataGridViewTextBoxColumn20.ReadOnly = true;
      this.dataGridViewTextBoxColumn20.Width = 280;
      // 
      // TypeColor3
      // 
      this.TypeColor3.DataPropertyName = "TypeColor";
      this.TypeColor3.HeaderText = "Color";
      this.TypeColor3.Name = "TypeColor3";
      this.TypeColor3.ReadOnly = true;
      this.TypeColor3.Visible = false;
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label2.Location = new System.Drawing.Point(693, 46);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(21, 31);
      this.label2.TabIndex = 50;
      this.label2.Text = " ";
      // 
      // dataGridView4
      // 
      this.dataGridView4.AllowUserToAddRows = false;
      this.dataGridView4.AllowUserToDeleteRows = false;
      this.dataGridView4.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
      this.dataGridView4.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dataGridView4.GridColor = System.Drawing.SystemColors.AppWorkspace;
      this.dataGridView4.Location = new System.Drawing.Point(720, 25);
      this.dataGridView4.Name = "dataGridView4";
      this.dataGridView4.ReadOnly = true;
      this.dataGridView4.Size = new System.Drawing.Size(761, 330);
      this.dataGridView4.TabIndex = 56;
      // 
      // Time
      // 
      this.Time.DataPropertyName = "JobBookingDate";
      dataGridViewCellStyle11.Format = "t";
      dataGridViewCellStyle11.NullValue = null;
      this.Time.DefaultCellStyle = dataGridViewCellStyle11;
      this.Time.HeaderText = "Time";
      this.Time.Name = "Time";
      this.Time.ReadOnly = true;
      this.Time.Width = 80;
      // 
      // Job
      // 
      this.Job.DataPropertyName = "JobID";
      this.Job.HeaderText = "Job";
      this.Job.Name = "Job";
      this.Job.ReadOnly = true;
      this.Job.Width = 70;
      // 
      // Reference
      // 
      this.Reference.DataPropertyName = "JobReference";
      this.Reference.HeaderText = "Reference";
      this.Reference.Name = "Reference";
      this.Reference.ReadOnly = true;
      this.Reference.Width = 120;
      // 
      // Customer
      // 
      this.Customer.DataPropertyName = "CustomerName";
      this.Customer.HeaderText = "Customer";
      this.Customer.Name = "Customer";
      this.Customer.ReadOnly = true;
      this.Customer.Width = 220;
      // 
      // Vehicle
      // 
      this.Vehicle.DataPropertyName = "Vehicle";
      this.Vehicle.HeaderText = "Vehicle";
      this.Vehicle.Name = "Vehicle";
      this.Vehicle.ReadOnly = true;
      this.Vehicle.Width = 280;
      // 
      // chRecal
      // 
      this.chRecal.DataPropertyName = "vRecalibration";
      dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
      dataGridViewCellStyle12.NullValue = false;
      dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.Transparent;
      dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
      this.chRecal.DefaultCellStyle = dataGridViewCellStyle12;
      this.chRecal.HeaderText = "Recal";
      this.chRecal.Name = "chRecal";
      this.chRecal.ReadOnly = true;
      this.chRecal.Width = 50;
      // 
      // Type
      // 
      this.Type.DataPropertyName = "TypeName";
      dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.Transparent;
      dataGridViewCellStyle13.SelectionForeColor = System.Drawing.Color.Black;
      this.Type.DefaultCellStyle = dataGridViewCellStyle13;
      this.Type.HeaderText = "Type";
      this.Type.Name = "Type";
      this.Type.ReadOnly = true;
      this.Type.Width = 150;
      // 
      // Status
      // 
      this.Status.DataPropertyName = "StatusName";
      dataGridViewCellStyle14.SelectionBackColor = System.Drawing.Color.Transparent;
      dataGridViewCellStyle14.SelectionForeColor = System.Drawing.Color.Black;
      this.Status.DefaultCellStyle = dataGridViewCellStyle14;
      this.Status.HeaderText = "Status";
      this.Status.Name = "Status";
      this.Status.ReadOnly = true;
      this.Status.Width = 120;
      // 
      // Payment
      // 
      this.Payment.DataPropertyName = "Payment";
      dataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.Transparent;
      dataGridViewCellStyle15.SelectionForeColor = System.Drawing.Color.Black;
      this.Payment.DefaultCellStyle = dataGridViewCellStyle15;
      this.Payment.HeaderText = "Payment";
      this.Payment.Name = "Payment";
      this.Payment.ReadOnly = true;
      // 
      // Location
      // 
      this.Location.DataPropertyName = "AreaName";
      dataGridViewCellStyle16.SelectionBackColor = System.Drawing.Color.Transparent;
      dataGridViewCellStyle16.SelectionForeColor = System.Drawing.Color.Black;
      this.Location.DefaultCellStyle = dataGridViewCellStyle16;
      this.Location.HeaderText = "Location";
      this.Location.Name = "Location";
      this.Location.ReadOnly = true;
      // 
      // Note
      // 
      this.Note.DataPropertyName = "JobNote";
      dataGridViewCellStyle17.SelectionBackColor = System.Drawing.Color.Transparent;
      dataGridViewCellStyle17.SelectionForeColor = System.Drawing.Color.Black;
      this.Note.DefaultCellStyle = dataGridViewCellStyle17;
      this.Note.HeaderText = "Note";
      this.Note.Name = "Note";
      this.Note.ReadOnly = true;
      this.Note.Width = 280;
      // 
      // TypeColor
      // 
      this.TypeColor.DataPropertyName = "TypeColor";
      this.TypeColor.HeaderText = "TypeColor";
      this.TypeColor.Name = "TypeColor";
      this.TypeColor.ReadOnly = true;
      this.TypeColor.Visible = false;
      // 
      // colAfterTime
      // 
      this.colAfterTime.DataPropertyName = "JobBookingDate";
      dataGridViewCellStyle2.Format = "t";
      dataGridViewCellStyle2.NullValue = null;
      this.colAfterTime.DefaultCellStyle = dataGridViewCellStyle2;
      this.colAfterTime.HeaderText = "Time";
      this.colAfterTime.Name = "colAfterTime";
      this.colAfterTime.ReadOnly = true;
      this.colAfterTime.Width = 80;
      // 
      // colAfterJob
      // 
      this.colAfterJob.DataPropertyName = "JobID";
      this.colAfterJob.HeaderText = "Job";
      this.colAfterJob.Name = "colAfterJob";
      this.colAfterJob.ReadOnly = true;
      this.colAfterJob.Width = 70;
      // 
      // colAfterReference
      // 
      this.colAfterReference.DataPropertyName = "JobReference";
      this.colAfterReference.HeaderText = "Reference";
      this.colAfterReference.Name = "colAfterReference";
      this.colAfterReference.ReadOnly = true;
      this.colAfterReference.Width = 120;
      // 
      // colAfterCustomer
      // 
      this.colAfterCustomer.DataPropertyName = "CustomerName";
      this.colAfterCustomer.HeaderText = "Customer";
      this.colAfterCustomer.Name = "colAfterCustomer";
      this.colAfterCustomer.ReadOnly = true;
      this.colAfterCustomer.Width = 220;
      // 
      // colAfterVehicle
      // 
      this.colAfterVehicle.DataPropertyName = "Vehicle";
      this.colAfterVehicle.HeaderText = "Vehicle";
      this.colAfterVehicle.Name = "colAfterVehicle";
      this.colAfterVehicle.ReadOnly = true;
      this.colAfterVehicle.Width = 280;
      // 
      // chRecalAfter
      // 
      this.chRecalAfter.DataPropertyName = "vRecalibration";
      dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
      dataGridViewCellStyle3.NullValue = false;
      dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Transparent;
      dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
      this.chRecalAfter.DefaultCellStyle = dataGridViewCellStyle3;
      this.chRecalAfter.HeaderText = "Recal";
      this.chRecalAfter.Name = "chRecalAfter";
      this.chRecalAfter.ReadOnly = true;
      this.chRecalAfter.Width = 50;
      // 
      // colAfterType
      // 
      this.colAfterType.DataPropertyName = "TypeName";
      dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.Transparent;
      dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black;
      this.colAfterType.DefaultCellStyle = dataGridViewCellStyle4;
      this.colAfterType.HeaderText = "Type";
      this.colAfterType.Name = "colAfterType";
      this.colAfterType.ReadOnly = true;
      this.colAfterType.Width = 150;
      // 
      // colAfterStatus
      // 
      this.colAfterStatus.DataPropertyName = "StatusName";
      dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.Transparent;
      dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.Black;
      this.colAfterStatus.DefaultCellStyle = dataGridViewCellStyle5;
      this.colAfterStatus.HeaderText = "Status";
      this.colAfterStatus.Name = "colAfterStatus";
      this.colAfterStatus.ReadOnly = true;
      this.colAfterStatus.Width = 120;
      // 
      // colAfterPayment
      // 
      this.colAfterPayment.DataPropertyName = "Payment";
      dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.Transparent;
      dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.Black;
      this.colAfterPayment.DefaultCellStyle = dataGridViewCellStyle6;
      this.colAfterPayment.HeaderText = "Payment";
      this.colAfterPayment.Name = "colAfterPayment";
      this.colAfterPayment.ReadOnly = true;
      // 
      // colAfterLocation
      // 
      this.colAfterLocation.DataPropertyName = "AreaName";
      dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.Transparent;
      dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.Black;
      this.colAfterLocation.DefaultCellStyle = dataGridViewCellStyle7;
      this.colAfterLocation.HeaderText = "Location";
      this.colAfterLocation.Name = "colAfterLocation";
      this.colAfterLocation.ReadOnly = true;
      // 
      // colAfterNote
      // 
      this.colAfterNote.DataPropertyName = "JobNote";
      dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.Transparent;
      dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.Black;
      this.colAfterNote.DefaultCellStyle = dataGridViewCellStyle8;
      this.colAfterNote.HeaderText = "Note";
      this.colAfterNote.Name = "colAfterNote";
      this.colAfterNote.ReadOnly = true;
      this.colAfterNote.Width = 280;
      // 
      // TypeColor2
      // 
      this.TypeColor2.DataPropertyName = "TypeColor";
      this.TypeColor2.HeaderText = "Color";
      this.TypeColor2.Name = "TypeColor2";
      this.TypeColor2.ReadOnly = true;
      this.TypeColor2.Visible = false;
      // 
      // JobView
      // 
      this.AllowDrop = true;
      this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.AutoScroll = true;
      this.BackColor = System.Drawing.Color.White;
      this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
      this.ClientSize = new System.Drawing.Size(1880, 976);
      this.ControlBox = false;
      this.Controls.Add(this.panel2);
      this.Controls.Add(this.pnlProduction);
      this.Controls.Add(this.toolStrip1);
      this.Cursor = System.Windows.Forms.Cursors.Default;
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
      this.MaximizeBox = false;
      this.Name = "JobView";
      this.ShowIcon = false;
      this.ShowInTaskbar = false;
      this.Text = "Production Plan";
      this.Load += new System.EventHandler(this.JobView_Load);
      ((System.ComponentModel.ISupportInitialize)(this.chHours)).EndInit();
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.pnlProduction.ResumeLayout(false);
      this.panel2.ResumeLayout(false);
      this.tcProduction.ResumeLayout(false);
      this.tpVehicle.ResumeLayout(false);
      this.gbVehicleAfternoon.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.dgvVehicleAfternoon)).EndInit();
      this.gbVehicleMorning.ResumeLayout(false);
      this.gbVehicleMorning.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgvVehicleMorning)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
      this.tpGlass.ResumeLayout(false);
      this.groupBox1.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.dgvGlassAfternoon)).EndInit();
      this.groupBox2.ResumeLayout(false);
      this.groupBox2.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgvGlassMorning)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

        }

        #endregion
        private MonthCalendar calDate;
        private System.Windows.Forms.DataVisualization.Charting.Chart chHours;
        private Timer timer1;
    private ToolStrip toolStrip1;
    private ToolStripButton tsBack;
    private ToolStripButton tsRefresh;
    private ToolStripButton tsReport;
    private ToolStripButton tsPrevious;
    private ToolStripButton tsNext;
    private ToolStripButton tsToday;
    private ToolStripButton tsNew;
    private ToolStripButton tsEdit;
    private Panel pnlProduction;
    private Panel panel2;
    private TabControl tcProduction;
    private TabPage tpVehicle;
    private GroupBox gbVehicleAfternoon;
    private GroupBox gbVehicleMorning;
    private DataGridView dgvVehicleMorning;
    private Label label1;
    private DataGridView dataGridView1;
    private TabPage tpGlass;
    private ToolStripSeparator toolStripSeparator1;
    private ToolStripSeparator toolStripSeparator2;
    private ToolStripSeparator toolStripSeparator3;
    private ToolStripSeparator toolStripSeparator4;
    private DataGridView dgvVehicleAfternoon;
    private GroupBox groupBox1;
    private DataGridView dgvGlassAfternoon;
    private GroupBox groupBox2;
    private DataGridView dgvGlassMorning;
    private Label label2;
    private DataGridView dataGridView4;
    private DataGridViewTextBoxColumn colGlassTime;
    private DataGridViewTextBoxColumn colGlassJob;
    private DataGridViewTextBoxColumn colGlassReference;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
    private DataGridViewTextBoxColumn colGlassType;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
    private DataGridViewTextBoxColumn TypeColor3;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
    private DataGridViewTextBoxColumn TypeColor4;
    private DataGridViewTextBoxColumn Time;
    private DataGridViewTextBoxColumn Job;
    private DataGridViewTextBoxColumn Reference;
    private DataGridViewTextBoxColumn Customer;
    private DataGridViewTextBoxColumn Vehicle;
    private DataGridViewCheckBoxColumn chRecal;
    private DataGridViewTextBoxColumn Type;
    private DataGridViewTextBoxColumn Status;
    private DataGridViewTextBoxColumn Payment;
    private DataGridViewTextBoxColumn Location;
    private DataGridViewTextBoxColumn Note;
    private DataGridViewTextBoxColumn TypeColor;
    private DataGridViewTextBoxColumn colAfterTime;
    private DataGridViewTextBoxColumn colAfterJob;
    private DataGridViewTextBoxColumn colAfterReference;
    private DataGridViewTextBoxColumn colAfterCustomer;
    private DataGridViewTextBoxColumn colAfterVehicle;
    private DataGridViewCheckBoxColumn chRecalAfter;
    private DataGridViewTextBoxColumn colAfterType;
    private DataGridViewTextBoxColumn colAfterStatus;
    private DataGridViewTextBoxColumn colAfterPayment;
    private DataGridViewTextBoxColumn colAfterLocation;
    private DataGridViewTextBoxColumn colAfterNote;
    private DataGridViewTextBoxColumn TypeColor2;
  }
}

