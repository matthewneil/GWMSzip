﻿
namespace workshop_orders
{
  partial class MaterialMovement
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.btnCancel = new System.Windows.Forms.Button();
      this.btnContinue1 = new System.Windows.Forms.Button();
      this.label1 = new System.Windows.Forms.Label();
      this.txtReference = new System.Windows.Forms.TextBox();
      this.groupBox1.SuspendLayout();
      this.SuspendLayout();
      // 
      // groupBox1
      // 
      this.groupBox1.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.groupBox1.Controls.Add(this.btnCancel);
      this.groupBox1.Controls.Add(this.btnContinue1);
      this.groupBox1.Controls.Add(this.label1);
      this.groupBox1.Controls.Add(this.txtReference);
      this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.groupBox1.Location = new System.Drawing.Point(0, 0);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(459, 279);
      this.groupBox1.TabIndex = 0;
      this.groupBox1.TabStop = false;
      // 
      // btnCancel
      // 
      this.btnCancel.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnCancel.Location = new System.Drawing.Point(268, 239);
      this.btnCancel.Name = "btnCancel";
      this.btnCancel.Size = new System.Drawing.Size(88, 31);
      this.btnCancel.TabIndex = 4;
      this.btnCancel.Text = "Cancel";
      this.btnCancel.UseVisualStyleBackColor = false;
      this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
      // 
      // btnContinue1
      // 
      this.btnContinue1.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnContinue1.Location = new System.Drawing.Point(362, 239);
      this.btnContinue1.Name = "btnContinue1";
      this.btnContinue1.Size = new System.Drawing.Size(88, 31);
      this.btnContinue1.TabIndex = 3;
      this.btnContinue1.Text = "Continue";
      this.btnContinue1.UseVisualStyleBackColor = false;
      this.btnContinue1.Click += new System.EventHandler(this.btnContinue);
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label1.Location = new System.Drawing.Point(8, 18);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(183, 20);
      this.label1.TabIndex = 1;
      this.label1.Text = "Please enter a reference";
      // 
      // txtReference
      // 
      this.txtReference.AcceptsReturn = true;
      this.txtReference.Location = new System.Drawing.Point(12, 41);
      this.txtReference.MaxLength = 45;
      this.txtReference.Multiline = true;
      this.txtReference.Name = "txtReference";
      this.txtReference.Size = new System.Drawing.Size(438, 192);
      this.txtReference.TabIndex = 0;
      this.txtReference.TextChanged += new System.EventHandler(this.txtReference_TextChanged);
      // 
      // MaterialMovement
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(459, 279);
      this.Controls.Add(this.groupBox1);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
      this.Name = "MaterialMovement";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
      this.Text = "Material Movement";
      this.Load += new System.EventHandler(this.MaterialMovement_Load);
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.TextBox txtReference;
    private System.Windows.Forms.Button btnCancel;
    private System.Windows.Forms.Button btnContinue1;
  }
}