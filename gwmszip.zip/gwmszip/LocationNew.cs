﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workshop_orders
{
  public partial class LocationNew : Form
  {
    public LocationNew()
    {
      InitializeComponent();
      DataAccess.FormState(this.AccessibilityObject.Name, tsSave);
    }


    private void btnNewGroup_Click(object sender, EventArgs e)
    {
      cmbGroup.Visible = false;
      cmbSubGroup.Visible = false;
      txtGroup.Visible = true;     
      txtSubGroup.Visible = true;
    }

    private void btnNewSubGroup_Click(object sender, EventArgs e)
    {
      cmbSubGroup.Visible = false;
      txtSubGroup.Visible = true;
    }

    private void tsBack_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private void tsSave_Click(object sender, EventArgs e)
    {
      String group = "Gore";
      String subGroup = "";
      if (txtSubGroup.Visible) subGroup = txtSubGroup.Text;
      else subGroup = cmbSubGroup.SelectedValue.ToString();

      DataAccess.LocationManage(0, group, subGroup, txtCode.Text, txtDescription.Text);
    }

    private void txtGroup_TextChanged(object sender, EventArgs e)
    {

    }
  }
}
