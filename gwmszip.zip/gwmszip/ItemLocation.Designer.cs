﻿
namespace workshop_orders
{
  partial class ItemLocation
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.gbFrom = new System.Windows.Forms.GroupBox();
      this.lblReference1 = new System.Windows.Forms.Label();
      this.txtReference1 = new System.Windows.Forms.TextBox();
      this.nudQuantity1 = new System.Windows.Forms.NumericUpDown();
      this.label9 = new System.Windows.Forms.Label();
      this.label4 = new System.Windows.Forms.Label();
      this.label3 = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this.label1 = new System.Windows.Forms.Label();
      this.txtDescription1 = new System.Windows.Forms.TextBox();
      this.txtSubGroup1 = new System.Windows.Forms.TextBox();
      this.txtCode1 = new System.Windows.Forms.TextBox();
      this.txtGroup1 = new System.Windows.Forms.TextBox();
      this.gbTo = new System.Windows.Forms.GroupBox();
      this.label11 = new System.Windows.Forms.Label();
      this.nudQuantity2 = new System.Windows.Forms.NumericUpDown();
      this.txtReference2 = new System.Windows.Forms.TextBox();
      this.label10 = new System.Windows.Forms.Label();
      this.label5 = new System.Windows.Forms.Label();
      this.label6 = new System.Windows.Forms.Label();
      this.label7 = new System.Windows.Forms.Label();
      this.label8 = new System.Windows.Forms.Label();
      this.txtDescription2 = new System.Windows.Forms.TextBox();
      this.txtSubGroup2 = new System.Windows.Forms.TextBox();
      this.txtCode2 = new System.Windows.Forms.TextBox();
      this.txtGroup2 = new System.Windows.Forms.TextBox();
      this.toolStrip1 = new System.Windows.Forms.ToolStrip();
      this.tsBack = new System.Windows.Forms.ToolStripButton();
      this.tsSave = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
      this.tsFind = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
      this.btnFindLocation = new System.Windows.Forms.Button();
      this.nudCost = new System.Windows.Forms.NumericUpDown();
      this.label12 = new System.Windows.Forms.Label();
      this.gbFrom.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.nudQuantity1)).BeginInit();
      this.gbTo.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.nudQuantity2)).BeginInit();
      this.toolStrip1.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.nudCost)).BeginInit();
      this.SuspendLayout();
      // 
      // gbFrom
      // 
      this.gbFrom.Controls.Add(this.lblReference1);
      this.gbFrom.Controls.Add(this.txtReference1);
      this.gbFrom.Controls.Add(this.nudQuantity1);
      this.gbFrom.Controls.Add(this.label9);
      this.gbFrom.Controls.Add(this.label4);
      this.gbFrom.Controls.Add(this.label3);
      this.gbFrom.Controls.Add(this.label2);
      this.gbFrom.Controls.Add(this.label1);
      this.gbFrom.Controls.Add(this.txtDescription1);
      this.gbFrom.Controls.Add(this.txtSubGroup1);
      this.gbFrom.Controls.Add(this.txtCode1);
      this.gbFrom.Controls.Add(this.txtGroup1);
      this.gbFrom.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbFrom.Location = new System.Drawing.Point(12, 43);
      this.gbFrom.Name = "gbFrom";
      this.gbFrom.Size = new System.Drawing.Size(306, 422);
      this.gbFrom.TabIndex = 0;
      this.gbFrom.TabStop = false;
      this.gbFrom.Text = "From";
      // 
      // lblReference1
      // 
      this.lblReference1.AutoSize = true;
      this.lblReference1.Location = new System.Drawing.Point(7, 328);
      this.lblReference1.Name = "lblReference1";
      this.lblReference1.Size = new System.Drawing.Size(233, 20);
      this.lblReference1.TabIndex = 19;
      this.lblReference1.Text = "Reason for Removal (Required)";
      this.lblReference1.Visible = false;
      // 
      // txtReference1
      // 
      this.txtReference1.AcceptsReturn = true;
      this.txtReference1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
      this.txtReference1.Location = new System.Drawing.Point(6, 351);
      this.txtReference1.MaxLength = 45;
      this.txtReference1.Multiline = true;
      this.txtReference1.Name = "txtReference1";
      this.txtReference1.Size = new System.Drawing.Size(294, 65);
      this.txtReference1.TabIndex = 18;
      this.txtReference1.Visible = false;
      // 
      // nudQuantity1
      // 
      this.nudQuantity1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
      this.nudQuantity1.DecimalPlaces = 4;
      this.nudQuantity1.Location = new System.Drawing.Point(110, 265);
      this.nudQuantity1.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
      this.nudQuantity1.Name = "nudQuantity1";
      this.nudQuantity1.ReadOnly = true;
      this.nudQuantity1.Size = new System.Drawing.Size(82, 26);
      this.nudQuantity1.TabIndex = 17;
      this.nudQuantity1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
      // 
      // label9
      // 
      this.label9.AutoSize = true;
      this.label9.Location = new System.Drawing.Point(36, 267);
      this.label9.Name = "label9";
      this.label9.Size = new System.Drawing.Size(68, 20);
      this.label9.TabIndex = 9;
      this.label9.Text = "Quantity";
      // 
      // label4
      // 
      this.label4.AutoSize = true;
      this.label4.Location = new System.Drawing.Point(17, 60);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(87, 20);
      this.label4.TabIndex = 7;
      this.label4.Text = "Sub Group";
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Location = new System.Drawing.Point(57, 92);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(47, 20);
      this.label3.TabIndex = 6;
      this.label3.Text = "Code";
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Location = new System.Drawing.Point(15, 124);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(89, 20);
      this.label2.TabIndex = 5;
      this.label2.Text = "Description";
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(50, 28);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(54, 20);
      this.label1.TabIndex = 4;
      this.label1.Text = "Group";
      // 
      // txtDescription1
      // 
      this.txtDescription1.Location = new System.Drawing.Point(110, 121);
      this.txtDescription1.Multiline = true;
      this.txtDescription1.Name = "txtDescription1";
      this.txtDescription1.ReadOnly = true;
      this.txtDescription1.Size = new System.Drawing.Size(180, 138);
      this.txtDescription1.TabIndex = 3;
      // 
      // txtSubGroup1
      // 
      this.txtSubGroup1.Location = new System.Drawing.Point(110, 57);
      this.txtSubGroup1.Name = "txtSubGroup1";
      this.txtSubGroup1.ReadOnly = true;
      this.txtSubGroup1.Size = new System.Drawing.Size(180, 26);
      this.txtSubGroup1.TabIndex = 2;
      // 
      // txtCode1
      // 
      this.txtCode1.Location = new System.Drawing.Point(110, 89);
      this.txtCode1.Name = "txtCode1";
      this.txtCode1.ReadOnly = true;
      this.txtCode1.Size = new System.Drawing.Size(180, 26);
      this.txtCode1.TabIndex = 1;
      // 
      // txtGroup1
      // 
      this.txtGroup1.Location = new System.Drawing.Point(110, 25);
      this.txtGroup1.Name = "txtGroup1";
      this.txtGroup1.ReadOnly = true;
      this.txtGroup1.Size = new System.Drawing.Size(180, 26);
      this.txtGroup1.TabIndex = 0;
      // 
      // gbTo
      // 
      this.gbTo.Controls.Add(this.nudCost);
      this.gbTo.Controls.Add(this.label12);
      this.gbTo.Controls.Add(this.label11);
      this.gbTo.Controls.Add(this.nudQuantity2);
      this.gbTo.Controls.Add(this.txtReference2);
      this.gbTo.Controls.Add(this.label10);
      this.gbTo.Controls.Add(this.label5);
      this.gbTo.Controls.Add(this.label6);
      this.gbTo.Controls.Add(this.label7);
      this.gbTo.Controls.Add(this.label8);
      this.gbTo.Controls.Add(this.txtDescription2);
      this.gbTo.Controls.Add(this.txtSubGroup2);
      this.gbTo.Controls.Add(this.txtCode2);
      this.gbTo.Controls.Add(this.txtGroup2);
      this.gbTo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbTo.Location = new System.Drawing.Point(324, 43);
      this.gbTo.Name = "gbTo";
      this.gbTo.Size = new System.Drawing.Size(301, 422);
      this.gbTo.TabIndex = 1;
      this.gbTo.TabStop = false;
      this.gbTo.Text = "To";
      this.gbTo.Visible = false;
      // 
      // label11
      // 
      this.label11.AutoSize = true;
      this.label11.Location = new System.Drawing.Point(10, 331);
      this.label11.Name = "label11";
      this.label11.Size = new System.Drawing.Size(84, 20);
      this.label11.TabIndex = 11;
      this.label11.Text = "Reference";
      // 
      // nudQuantity2
      // 
      this.nudQuantity2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
      this.nudQuantity2.DecimalPlaces = 4;
      this.nudQuantity2.Location = new System.Drawing.Point(103, 268);
      this.nudQuantity2.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
      this.nudQuantity2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
      this.nudQuantity2.Name = "nudQuantity2";
      this.nudQuantity2.Size = new System.Drawing.Size(82, 26);
      this.nudQuantity2.TabIndex = 16;
      this.nudQuantity2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
      // 
      // txtReference2
      // 
      this.txtReference2.AcceptsReturn = true;
      this.txtReference2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
      this.txtReference2.Location = new System.Drawing.Point(6, 354);
      this.txtReference2.MaxLength = 45;
      this.txtReference2.Multiline = true;
      this.txtReference2.Name = "txtReference2";
      this.txtReference2.Size = new System.Drawing.Size(289, 62);
      this.txtReference2.TabIndex = 10;
      // 
      // label10
      // 
      this.label10.AutoSize = true;
      this.label10.Location = new System.Drawing.Point(28, 269);
      this.label10.Name = "label10";
      this.label10.Size = new System.Drawing.Size(68, 20);
      this.label10.TabIndex = 11;
      this.label10.Text = "Quantity";
      // 
      // label5
      // 
      this.label5.AutoSize = true;
      this.label5.Location = new System.Drawing.Point(10, 63);
      this.label5.Name = "label5";
      this.label5.Size = new System.Drawing.Size(87, 20);
      this.label5.TabIndex = 15;
      this.label5.Text = "Sub Group";
      // 
      // label6
      // 
      this.label6.AutoSize = true;
      this.label6.Location = new System.Drawing.Point(50, 95);
      this.label6.Name = "label6";
      this.label6.Size = new System.Drawing.Size(47, 20);
      this.label6.TabIndex = 14;
      this.label6.Text = "Code";
      // 
      // label7
      // 
      this.label7.AutoSize = true;
      this.label7.Location = new System.Drawing.Point(8, 127);
      this.label7.Name = "label7";
      this.label7.Size = new System.Drawing.Size(89, 20);
      this.label7.TabIndex = 13;
      this.label7.Text = "Description";
      // 
      // label8
      // 
      this.label8.AutoSize = true;
      this.label8.Location = new System.Drawing.Point(43, 31);
      this.label8.Name = "label8";
      this.label8.Size = new System.Drawing.Size(54, 20);
      this.label8.TabIndex = 12;
      this.label8.Text = "Group";
      // 
      // txtDescription2
      // 
      this.txtDescription2.Location = new System.Drawing.Point(103, 124);
      this.txtDescription2.Multiline = true;
      this.txtDescription2.Name = "txtDescription2";
      this.txtDescription2.ReadOnly = true;
      this.txtDescription2.Size = new System.Drawing.Size(180, 138);
      this.txtDescription2.TabIndex = 11;
      // 
      // txtSubGroup2
      // 
      this.txtSubGroup2.Location = new System.Drawing.Point(103, 60);
      this.txtSubGroup2.Name = "txtSubGroup2";
      this.txtSubGroup2.ReadOnly = true;
      this.txtSubGroup2.Size = new System.Drawing.Size(180, 26);
      this.txtSubGroup2.TabIndex = 10;
      // 
      // txtCode2
      // 
      this.txtCode2.Location = new System.Drawing.Point(103, 92);
      this.txtCode2.Name = "txtCode2";
      this.txtCode2.ReadOnly = true;
      this.txtCode2.Size = new System.Drawing.Size(180, 26);
      this.txtCode2.TabIndex = 9;
      // 
      // txtGroup2
      // 
      this.txtGroup2.Location = new System.Drawing.Point(103, 28);
      this.txtGroup2.Name = "txtGroup2";
      this.txtGroup2.ReadOnly = true;
      this.txtGroup2.Size = new System.Drawing.Size(180, 26);
      this.txtGroup2.TabIndex = 8;
      // 
      // toolStrip1
      // 
      this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsBack,
            this.tsSave,
            this.toolStripSeparator1,
            this.tsFind,
            this.toolStripSeparator2});
      this.toolStrip1.Location = new System.Drawing.Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new System.Drawing.Size(635, 39);
      this.toolStrip1.TabIndex = 2;
      this.toolStrip1.Text = "toolStrip1";
      // 
      // tsBack
      // 
      this.tsBack.Image = global::workshop_orders.Properties.Resources.back;
      this.tsBack.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsBack.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsBack.Name = "tsBack";
      this.tsBack.Size = new System.Drawing.Size(68, 36);
      this.tsBack.Text = "Back";
      this.tsBack.Click += new System.EventHandler(this.tsBack_Click);
      // 
      // tsSave
      // 
      this.tsSave.Enabled = false;
      this.tsSave.Image = global::workshop_orders.Properties.Resources.save;
      this.tsSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsSave.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsSave.Name = "tsSave";
      this.tsSave.Size = new System.Drawing.Size(67, 36);
      this.tsSave.Text = "Save";
      this.tsSave.Click += new System.EventHandler(this.tsSave_Click);
      // 
      // toolStripSeparator1
      // 
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
      // 
      // tsFind
      // 
      this.tsFind.Image = global::workshop_orders.Properties.Resources.find;
      this.tsFind.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsFind.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsFind.Name = "tsFind";
      this.tsFind.Size = new System.Drawing.Size(115, 36);
      this.tsFind.Text = "Find Location";
      this.tsFind.Click += new System.EventHandler(this.tsFind_Click);
      // 
      // toolStripSeparator2
      // 
      this.toolStripSeparator2.Name = "toolStripSeparator2";
      this.toolStripSeparator2.Size = new System.Drawing.Size(6, 39);
      // 
      // btnFindLocation
      // 
      this.btnFindLocation.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
      this.btnFindLocation.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnFindLocation.Image = global::workshop_orders.Properties.Resources.find;
      this.btnFindLocation.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
      this.btnFindLocation.Location = new System.Drawing.Point(379, 200);
      this.btnFindLocation.Name = "btnFindLocation";
      this.btnFindLocation.Size = new System.Drawing.Size(201, 55);
      this.btnFindLocation.TabIndex = 3;
      this.btnFindLocation.Text = "Click to find a location";
      this.btnFindLocation.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      this.btnFindLocation.UseVisualStyleBackColor = false;
      this.btnFindLocation.Click += new System.EventHandler(this.btnFindLocation_Click);
      // 
      // nudCost
      // 
      this.nudCost.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
      this.nudCost.DecimalPlaces = 2;
      this.nudCost.Location = new System.Drawing.Point(103, 300);
      this.nudCost.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
      this.nudCost.Name = "nudCost";
      this.nudCost.Size = new System.Drawing.Size(82, 26);
      this.nudCost.TabIndex = 18;
      // 
      // label12
      // 
      this.label12.AutoSize = true;
      this.label12.Location = new System.Drawing.Point(50, 302);
      this.label12.Name = "label12";
      this.label12.Size = new System.Drawing.Size(42, 20);
      this.label12.TabIndex = 17;
      this.label12.Text = "Cost";
      // 
      // ItemLocation
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.ClientSize = new System.Drawing.Size(635, 477);
      this.Controls.Add(this.btnFindLocation);
      this.Controls.Add(this.toolStrip1);
      this.Controls.Add(this.gbTo);
      this.Controls.Add(this.gbFrom);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
      this.Name = "ItemLocation";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
      this.Text = "Item Location";
      this.gbFrom.ResumeLayout(false);
      this.gbFrom.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.nudQuantity1)).EndInit();
      this.gbTo.ResumeLayout(false);
      this.gbTo.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.nudQuantity2)).EndInit();
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.nudCost)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.GroupBox gbFrom;
    private System.Windows.Forms.GroupBox gbTo;
    private System.Windows.Forms.TextBox txtDescription1;
    private System.Windows.Forms.TextBox txtSubGroup1;
    private System.Windows.Forms.TextBox txtCode1;
    private System.Windows.Forms.TextBox txtGroup1;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label label5;
    private System.Windows.Forms.Label label6;
    private System.Windows.Forms.Label label7;
    private System.Windows.Forms.Label label8;
    private System.Windows.Forms.TextBox txtDescription2;
    private System.Windows.Forms.TextBox txtSubGroup2;
    private System.Windows.Forms.TextBox txtCode2;
    private System.Windows.Forms.TextBox txtGroup2;
    private System.Windows.Forms.ToolStrip toolStrip1;
    private System.Windows.Forms.ToolStripButton tsBack;
    private System.Windows.Forms.ToolStripButton tsFind;
    private System.Windows.Forms.ToolStripButton tsSave;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
    private System.Windows.Forms.Label label9;
    private System.Windows.Forms.NumericUpDown nudQuantity2;
    private System.Windows.Forms.Label label10;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
    private System.Windows.Forms.Label label11;
    private System.Windows.Forms.TextBox txtReference2;
    private System.Windows.Forms.Label lblReference1;
    private System.Windows.Forms.TextBox txtReference1;
    private System.Windows.Forms.NumericUpDown nudQuantity1;
    private System.Windows.Forms.Button btnFindLocation;
    private System.Windows.Forms.NumericUpDown nudCost;
    private System.Windows.Forms.Label label12;
  }
}