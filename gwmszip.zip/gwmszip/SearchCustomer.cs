﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace workshop_orders
{
  /*A form for adding a customer to the database, so their details can be retrieved if they were to come back.
   */
  public partial class SearchCustomer : Form
  {
    public int quoteNo = 0;
    private int customerID = 0;
    private bool update = true;
    private int form = 0; //1 = JobEdit, 2 = JobNew, 3 = QuoteDetail, 4 = QuoteNew

    public SearchCustomer(int cID, int form)
    {
      InitializeComponent();
      
      this.customerID = cID;
      this.form = form;

      if(form > 0) tsSave.Text = "Select";

      if (cID < 1)
      {
        gbResult.Visible = true;
        gbMainDetails.Visible = false;
      }
      else
      {
        LoadCustomer(cID.ToString());
      }

      DataAccess.FormState(this.AccessibilityObject.Name, tsSave);
    }




    private void CreateJobForm_Load(object sender, EventArgs e)
    {

    }

    private void LoadCustomer(String customerID)
    {
      gbResult.Visible = false;
      gbMainDetails.Visible = true;

      DataTable dt = DataAccess.ExecuteDataTable(String.Format("SELECT * FROM customer WHERE CustomerID = {0};", customerID));
      txtFullName.Text = dt.Rows[0]["CustomerName"].ToString();
      txtSurname.Text = dt.Rows[0]["cSurname"].ToString();

      txtPhone1.Text = dt.Rows[0]["cMobilePhone"].ToString();
      txtPhone2.Text = dt.Rows[0]["cPhone2"].ToString();
      txtEmail.Text = dt.Rows[0]["cEmail"].ToString();

      txtAccountName.Text = dt.Rows[0]["cAccountName"].ToString();
      txtAccountNo.Text = dt.Rows[0]["cAccountNo"].ToString();

      txtAddress.Text = dt.Rows[0]["cAddress"].ToString();
      txtSuburb.Text = dt.Rows[0]["cSuburb"].ToString();
      txtCity.Text = dt.Rows[0]["cCity"].ToString();
      txtPostcode.Text = dt.Rows[0]["cPostcode"].ToString();

      if((int)dt.Rows[0]["cBusiness"] == 1)
      {
        chkBusiness.Checked = true;
      }
    }


    private void textBox1_TextChanged(object sender, EventArgs e)
    {
      customerID = 0;
      update = true;
      chkBusiness.Checked = false;
      dgvCustomer.Rows.Clear();
      try
      {
        String sql = null;

        this.customerID = 0;
        
        gbResult.Visible = true;
        gbMainDetails.Visible = false;

        switch (cmbField.Text)
        {
          case "Name":
            sql = String.Format("SELECT * FROM customer WHERE CustomerName LIKE '{0}%' AND CustomerID > 0;", txtSearch.Text);
            break;
          case "Surname":
            sql = String.Format("SELECT * FROM customer WHERE cSurname LIKE '{0}%' AND CustomerID > 0;", txtSearch.Text);
            break;
          case "Phone No.":
            sql = String.Format("SELECT * FROM customer WHERE cMobilePhone LIKE '{0}%' OR cPhone2 LIKE '{0}%' AND CustomerID > 0;", txtSearch.Text);
            break;
          case "Email":
            sql = String.Format("SELECT * FROM customer WHERE cEmail LIKE '{0}%' AND CustomerID > 0;", txtSearch.Text);
            break;
        }

        if (sql != null)
        {
          int amount = 0;
          DataTable dt = DataAccess.ExecuteDataTable(sql);
          foreach (DataRow row in dt.Rows)
          {
            amount++;
            dgvCustomer.Rows.Add(row["CustomerID"].ToString(), row["CustomerName"].ToString(), row["cMobilePhone"].ToString(), row["cAddress"].ToString(), row["cEmail"].ToString());
          }

          if (amount == 0)
          {
            DataAccess.ShowMessage("No Customer Records Found.\nPlease change your selection or add new customer.");
          }
          else if (amount == 1)
          {
            //searchText.Text = rdr["cSurname"].ToString();
            //LoadCustomer(rdr["cID"].ToString());
          }
        }
      }
      catch (Exception ex)
      {
        DataAccess.ShowMessage("Error: Couldn't fetch customer data.");
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                  System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }

    }

    private void toolStripButton1_Click_1(object sender, EventArgs e)
    {
      this.Close();
    }

    private void ClearAllFields()
    {
      txtFullName.Text = "";
      txtSurname.Text = "";

      txtPhone1.Text = "";
      txtPhone2.Text = "";
      txtEmail.Text = "";

      txtAccountName.Text = "";
      txtAccountNo.Text = "";

      txtAddress.Text = "";
      txtPostcode.Text = "";
      txtCity.Text = "";
      txtPostcode.Text = "";
    }

    private void addtoolStripButton_Click(object sender, EventArgs e)
    {
      gbMainDetails.Visible = true;
      gbResult.Visible = false;
      gbsearch.Enabled = false;
      chkBusiness.Checked = false;

      update = false;
      customerID = 0;
      ClearAllFields();
    }

    private void saveToolStripButton2_Click(object sender, EventArgs e)
    {
      SaveCustomer();      
    }

    private void SaveCustomer()
    {
      if (this.customerID == 0 && update == true)
      {
        DataAccess.ShowMessage("You haven't selected a customer!");
        return;
      }

      String errors = "Unable to save customer details due to the following issues:\n\n";

      if (txtFullName.Text == "")
      {
        errors += " - You must enter in a Customer Name.\n";
      }

      if (txtEmail.Text != "" && !(DataAccess.ValidateEmail(txtEmail.Text)))
      {
        errors += " - Invalid email has been entered.\n";
      }

      if (!(DataAccess.IsNumeric(txtPostcode.Text)))
      {
        errors += " - Postcode isn't a valid number.\n";
      }

      if (errors != "Unable to save customer details due to the following issues:\n\n")
      {
        DataAccess.ShowMessage(errors);
        return;
      }

      try
      {
        DataAccess.CustomerManage(customerID, txtFullName.Text, txtSurname.Text, 0, txtPhone1.Text, txtPhone2.Text, txtAddress.Text, txtSuburb.Text, txtCity.Text,
        txtPostcode.Text, txtEmail.Text, txtAccountName.Text, txtAccountNo.Text);
      }
      catch (Exception ex)
      {
        DataAccess.ShowMessage("Customer failed to save, please contact the administrator");
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                  System.Reflection.MethodBase.GetCurrentMethod().Name, "");
        return;
      }

      if(form == 0) DataAccess.ShowMessage("Customer saved Successfully");
 
      if (!update)
      {
        DataTable dt = DataAccess.ExecuteDataTable("SELECT MAX(CustomerID) AS MaxID FROM customer");
        customerID = (int)dt.Rows[0]["MaxID"];
      }

      if (this.customerID > 0)
      {
        if (form == 1)
        {
          JobEdit.CustomerID = customerID;
        }
        else if (form == 2)
        {
          JobNew.CustomerID = customerID;
        }
        else if (form == 3)
        {
          QuoteDetail.fiCustomerID = customerID;
        }
        else if (form == 4)
        {
          QuoteNew.CustomerID = customerID;
        }
        this.Close();
      }
      else
      {
        DataAccess.ShowMessage("No Customer has been selected.");
      }
    }

    private void customerDataGrid_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      if (e.RowIndex >= 0)
      {
        update = true;

        gbResult.Visible = false;
        gbMainDetails.Visible = true;
        //searchText.Enabled = false;
        DataGridViewRow row = this.dgvCustomer.Rows[e.RowIndex];
        this.customerID = int.Parse(row.Cells["ID"].Value.ToString());
        LoadCustomer(row.Cells["ID"].Value.ToString());
      }

    }


    private void txtFullName_TextChanged(object sender, EventArgs e)
    {
      SetSurname();
    }

    private void SetSurname()
    {
      if (!chkBusiness.Checked)
      {
        String[] Name = txtFullName.Text.Split(new[] { ' ' }, 2);
        if (Name.Length > 1)
        {
          txtSurname.Text = Name[1];
        }
      }
    }

    private void chkBusiness_CheckedChanged(object sender, EventArgs e)
    {
      if (chkBusiness.Checked)
      {
        lblCustomerName.Text = "Business:";
        lblSurname.Visible = false;
        txtSurname.Visible = false;
        txtSurname.Text = "";
      }
      else
      {
        lblCustomerName.Text = "Full Name:";
        lblSurname.Visible = true;
        txtSurname.Visible = true;
        SetSurname();
      }
    }
  }
}
