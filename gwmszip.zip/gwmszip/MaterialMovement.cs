﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workshop_orders
{
  public partial class MaterialMovement : Form
  {
    private int JobItemID = -1;
    private int ItemCostID = -1;
    public MaterialMovement()
    {
      InitializeComponent();
    }

    private void SetButtonState(Boolean bState)
    {
      btnContinue1.Visible = bState;
    }


    private void btnContinue(object sender, EventArgs e)
    {
      DataAccess.ItemStockManage(0, ItemCostID, 3, 1); //Create Item Stock record
      int stockID = DataAccess.ExecuteScalarInt("SELECT MAX(ItemStockID) FROM ItemStock WHERE ItemCostID = " + ItemCostID); //get stockID from newly created stock record
      DataAccess.ExecuteNonQuery("UPDATE jobitem SET StatusID = 13, ItemStockID = " + stockID + " WHERE JobItemID = " + JobItemID);
      DataAccess.ItemMovementManage(stockID, 12, -1, DataAccess.InternalIDType.Job, 1, 0, txtReference.Text, 0);

      this.Close();

    }

    private void btnCancel_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private void txtReference_TextChanged(object sender, EventArgs e)
    {
      if (txtReference.Text.Length >= 4) btnContinue1.Enabled = true;
      else btnContinue1.Enabled = false;
    }

    private void MaterialMovement_Load(object sender, EventArgs e)
    {
      this.JobItemID = FormManagement.globalID;
      this.ItemCostID = DataAccess.ExecuteScalarInt("SELECT ItemCostID FROM JobItem WHERE JobItemID = " + JobItemID);
      SetButtonState(DataAccess.FormState(this.AccessibilityObject.Name, null));
    }
  }
}
