﻿
namespace workshop_orders
{
	partial class ReportView
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.components = new System.ComponentModel.Container();
      Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
      this.vwquoteitemBindingSource = new System.Windows.Forms.BindingSource(this.components);
      this.gwgjobsDataSet1 = new workshop_orders.gwgjobsDataSet1();
      this.tsMenu = new System.Windows.Forms.ToolStrip();
      this.tsEmail = new System.Windows.Forms.ToolStripButton();
      this.ToolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
      this.txtEmail = new System.Windows.Forms.ToolStripTextBox();
      this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
      this.vwquoteitemTableAdapter = new workshop_orders.gwgjobsDataSet1TableAdapters.vwquoteitemTableAdapter();
      ((System.ComponentModel.ISupportInitialize)(this.vwquoteitemBindingSource)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.gwgjobsDataSet1)).BeginInit();
      this.tsMenu.SuspendLayout();
      this.SuspendLayout();
      // 
      // vwquoteitemBindingSource
      // 
      this.vwquoteitemBindingSource.DataMember = "vwquoteitem";
      this.vwquoteitemBindingSource.DataSource = this.gwgjobsDataSet1;
      // 
      // gwgjobsDataSet1
      // 
      this.gwgjobsDataSet1.DataSetName = "gwgjobsDataSet1";
      this.gwgjobsDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // tsMenu
      // 
      this.tsMenu.BackColor = System.Drawing.SystemColors.Control;
      this.tsMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsEmail,
            this.ToolStripLabel1,
            this.txtEmail});
      this.tsMenu.Location = new System.Drawing.Point(0, 0);
      this.tsMenu.Name = "tsMenu";
      this.tsMenu.Size = new System.Drawing.Size(1071, 39);
      this.tsMenu.TabIndex = 2;
      this.tsMenu.Text = "ToolStrip1";
      this.tsMenu.Visible = false;
      // 
      // tsEmail
      // 
      this.tsEmail.Image = global::workshop_orders.Properties.Resources.email32_2;
      this.tsEmail.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsEmail.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsEmail.Name = "tsEmail";
      this.tsEmail.Size = new System.Drawing.Size(72, 36);
      this.tsEmail.Text = "eMail";
      this.tsEmail.Click += new System.EventHandler(this.tsEmail_Click);
      // 
      // ToolStripLabel1
      // 
      this.ToolStripLabel1.Name = "ToolStripLabel1";
      this.ToolStripLabel1.Size = new System.Drawing.Size(114, 36);
      this.ToolStripLabel1.Text = "          eMail Address:";
      // 
      // txtEmail
      // 
      this.txtEmail.Name = "txtEmail";
      this.txtEmail.Size = new System.Drawing.Size(500, 39);
      // 
      // reportViewer1
      // 
      this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
      reportDataSource1.Name = "QuoteItems";
      reportDataSource1.Value = this.vwquoteitemBindingSource;
      this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
      this.reportViewer1.LocalReport.ReportEmbeddedResource = "workshop_orders.reports.Components.rdlc";
      this.reportViewer1.Location = new System.Drawing.Point(0, 0);
      this.reportViewer1.Name = "reportViewer1";
      this.reportViewer1.ServerReport.BearerToken = null;
      this.reportViewer1.ShowFindControls = false;
      this.reportViewer1.ShowParameterPrompts = false;
      this.reportViewer1.Size = new System.Drawing.Size(1071, 701);
      this.reportViewer1.TabIndex = 3;
      // 
      // vwquoteitemTableAdapter
      // 
      this.vwquoteitemTableAdapter.ClearBeforeFill = true;
      // 
      // ReportView
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(1071, 701);
      this.Controls.Add(this.reportViewer1);
      this.Controls.Add(this.tsMenu);
      this.Name = "ReportView";
      this.Text = "ReportView";
      this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ReportView_FormClosing);
      this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.ReportView_FormClosed);
      this.Load += new System.EventHandler(this.ReportView_Load);
      ((System.ComponentModel.ISupportInitialize)(this.vwquoteitemBindingSource)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.gwgjobsDataSet1)).EndInit();
      this.tsMenu.ResumeLayout(false);
      this.tsMenu.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

		}

		#endregion
		internal System.Windows.Forms.ToolStrip tsMenu;
		internal System.Windows.Forms.ToolStripButton tsEmail;
		internal System.Windows.Forms.ToolStripLabel ToolStripLabel1;
		internal System.Windows.Forms.ToolStripTextBox txtEmail;
		private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
		private System.Windows.Forms.BindingSource vwquoteitemBindingSource;
		private gwgjobsDataSet1 gwgjobsDataSet1;
		private gwgjobsDataSet1TableAdapters.vwquoteitemTableAdapter vwquoteitemTableAdapter;
	}
}