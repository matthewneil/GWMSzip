﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workshop_orders
{
  public partial class ucLabourHeader : UserControl
  {
    public static Workshop frm;
    
    public ucLabourHeader(String data)
    {
      InitializeComponent();
      lblInfo.Text = data;
    }

    private void lblInfo_Click(object sender, EventArgs e)
    {

    }

  }
}
