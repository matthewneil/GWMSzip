﻿namespace workshop_orders
{
    partial class GWMS
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GWMS));
      this.pnlLogin = new System.Windows.Forms.Panel();
      this.btnLogin = new System.Windows.Forms.Button();
      this.txtPassword = new System.Windows.Forms.TextBox();
      this.label1 = new System.Windows.Forms.Label();
      this.txtUsername = new System.Windows.Forms.TextBox();
      this.lblUsername = new System.Windows.Forms.Label();
      this.pbGWG = new System.Windows.Forms.PictureBox();
      this.timer1 = new System.Windows.Forms.Timer(this.components);
      this.btnWorkshop = new System.Windows.Forms.Button();
      this.menuStrip1 = new System.Windows.Forms.MenuStrip();
      this.miFile = new System.Windows.Forms.ToolStripMenuItem();
      this.miLogout = new System.Windows.Forms.ToolStripMenuItem();
      this.miCloseBMS = new System.Windows.Forms.ToolStripMenuItem();
      this.miHome = new System.Windows.Forms.ToolStripMenuItem();
      this.miJobs = new System.Windows.Forms.ToolStripMenuItem();
      this.miProductionPlan = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
      this.miSearchJob = new System.Windows.Forms.ToolStripMenuItem();
      this.miNewJob = new System.Windows.Forms.ToolStripMenuItem();
      this.miQuotes = new System.Windows.Forms.ToolStripMenuItem();
      this.miViewQuotes = new System.Windows.Forms.ToolStripMenuItem();
      this.miNewQuotes = new System.Windows.Forms.ToolStripMenuItem();
      this.miStock = new System.Windows.Forms.ToolStripMenuItem();
      this.miStockList = new System.Windows.Forms.ToolStripMenuItem();
      this.miLocations = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
      this.miNewItem = new System.Windows.Forms.ToolStripMenuItem();
      this.miWorkshop = new System.Windows.Forms.ToolStripMenuItem();
      this.miWindows = new System.Windows.Forms.ToolStripMenuItem();
      this.miCloseAllWindows = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
      this.miAdmin = new System.Windows.Forms.ToolStripMenuItem();
      this.miUsers = new System.Windows.Forms.ToolStripMenuItem();
      this.miErrors = new System.Windows.Forms.ToolStripMenuItem();
      this.miDev = new System.Windows.Forms.ToolStripMenuItem();
      this.imIndividualForms = new System.Windows.Forms.ToolStripMenuItem();
      this.miInsuranceProviders = new System.Windows.Forms.ToolStripMenuItem();
      this.ordersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.customerDetailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.supplierListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.tsSuppliersearch = new System.Windows.Forms.ToolStripMenuItem();
      this.onsiteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.onsiteDateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.miUsername = new System.Windows.Forms.ToolStripMenuItem();
      this.reportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.pnlLogin.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.pbGWG)).BeginInit();
      this.menuStrip1.SuspendLayout();
      this.SuspendLayout();
      // 
      // pnlLogin
      // 
      this.pnlLogin.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.pnlLogin.Controls.Add(this.btnLogin);
      this.pnlLogin.Controls.Add(this.txtPassword);
      this.pnlLogin.Controls.Add(this.label1);
      this.pnlLogin.Controls.Add(this.txtUsername);
      this.pnlLogin.Controls.Add(this.lblUsername);
      this.pnlLogin.Controls.Add(this.pbGWG);
      this.pnlLogin.Location = new System.Drawing.Point(744, 315);
      this.pnlLogin.Name = "pnlLogin";
      this.pnlLogin.Padding = new System.Windows.Forms.Padding(5);
      this.pnlLogin.Size = new System.Drawing.Size(428, 257);
      this.pnlLogin.TabIndex = 11;
      // 
      // btnLogin
      // 
      this.btnLogin.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnLogin.Location = new System.Drawing.Point(295, 202);
      this.btnLogin.Name = "btnLogin";
      this.btnLogin.Size = new System.Drawing.Size(115, 40);
      this.btnLogin.TabIndex = 5;
      this.btnLogin.Text = "Login";
      this.btnLogin.UseVisualStyleBackColor = false;
      this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
      // 
      // txtPassword
      // 
      this.txtPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtPassword.Location = new System.Drawing.Point(159, 151);
      this.txtPassword.Name = "txtPassword";
      this.txtPassword.Size = new System.Drawing.Size(251, 26);
      this.txtPassword.TabIndex = 4;
      this.txtPassword.UseSystemPasswordChar = true;
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label1.Location = new System.Drawing.Point(56, 157);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(82, 20);
      this.label1.TabIndex = 3;
      this.label1.Text = "Password:";
      // 
      // txtUsername
      // 
      this.txtUsername.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtUsername.Location = new System.Drawing.Point(159, 111);
      this.txtUsername.Name = "txtUsername";
      this.txtUsername.Size = new System.Drawing.Size(251, 26);
      this.txtUsername.TabIndex = 2;
      // 
      // lblUsername
      // 
      this.lblUsername.AutoSize = true;
      this.lblUsername.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblUsername.Location = new System.Drawing.Point(51, 114);
      this.lblUsername.Name = "lblUsername";
      this.lblUsername.Size = new System.Drawing.Size(87, 20);
      this.lblUsername.TabIndex = 1;
      this.lblUsername.Text = "Username:";
      // 
      // pbGWG
      // 
      this.pbGWG.BackgroundImage = global::workshop_orders.Properties.Resources.Gore_Windscreens_and_Glass_Logo;
      this.pbGWG.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
      this.pbGWG.Dock = System.Windows.Forms.DockStyle.Top;
      this.pbGWG.Location = new System.Drawing.Point(5, 5);
      this.pbGWG.Name = "pbGWG";
      this.pbGWG.Size = new System.Drawing.Size(418, 78);
      this.pbGWG.TabIndex = 0;
      this.pbGWG.TabStop = false;
      // 
      // btnWorkshop
      // 
      this.btnWorkshop.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnWorkshop.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnWorkshop.Location = new System.Drawing.Point(888, 633);
      this.btnWorkshop.Name = "btnWorkshop";
      this.btnWorkshop.Size = new System.Drawing.Size(166, 83);
      this.btnWorkshop.TabIndex = 6;
      this.btnWorkshop.Text = "Workshop";
      this.btnWorkshop.UseVisualStyleBackColor = false;
      this.btnWorkshop.Click += new System.EventHandler(this.btnWorkshop_Click);
      // 
      // menuStrip1
      // 
      this.menuStrip1.AllowMerge = false;
      this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miFile,
            this.miHome,
            this.miJobs,
            this.miQuotes,
            this.miStock,
            this.miWorkshop,
            this.miWindows,
            this.miAdmin,
            this.miDev,
            this.miUsername});
      this.menuStrip1.Location = new System.Drawing.Point(0, 0);
      this.menuStrip1.MdiWindowListItem = this.miWindows;
      this.menuStrip1.Name = "menuStrip1";
      this.menuStrip1.ShowItemToolTips = true;
      this.menuStrip1.Size = new System.Drawing.Size(1923, 29);
      this.menuStrip1.TabIndex = 13;
      this.menuStrip1.Text = "menuStrip1";
      // 
      // miFile
      // 
      this.miFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miLogout,
            this.miCloseBMS});
      this.miFile.Name = "miFile";
      this.miFile.Size = new System.Drawing.Size(46, 25);
      this.miFile.Text = "File";
      // 
      // miLogout
      // 
      this.miLogout.Image = global::workshop_orders.Properties.Resources.logout;
      this.miLogout.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.miLogout.Name = "miLogout";
      this.miLogout.Size = new System.Drawing.Size(170, 38);
      this.miLogout.Text = "Logout";
      this.miLogout.Click += new System.EventHandler(this.miLogout_Click);
      // 
      // miCloseBMS
      // 
      this.miCloseBMS.Image = global::workshop_orders.Properties.Resources.cancel32;
      this.miCloseBMS.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.miCloseBMS.Name = "miCloseBMS";
      this.miCloseBMS.Size = new System.Drawing.Size(170, 38);
      this.miCloseBMS.Text = "Close BMS";
      this.miCloseBMS.Click += new System.EventHandler(this.miCloseBMS_Click);
      // 
      // miHome
      // 
      this.miHome.Name = "miHome";
      this.miHome.Size = new System.Drawing.Size(64, 25);
      this.miHome.Text = "Home";
      this.miHome.Visible = false;
      this.miHome.Click += new System.EventHandler(this.miHome_Click);
      // 
      // miJobs
      // 
      this.miJobs.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miProductionPlan,
            this.toolStripSeparator2,
            this.miSearchJob,
            this.miNewJob});
      this.miJobs.Name = "miJobs";
      this.miJobs.Size = new System.Drawing.Size(53, 25);
      this.miJobs.Text = "Jobs";
      this.miJobs.Visible = false;
      // 
      // miProductionPlan
      // 
      this.miProductionPlan.Image = global::workshop_orders.Properties.Resources.calendar_day32_v1;
      this.miProductionPlan.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.miProductionPlan.Name = "miProductionPlan";
      this.miProductionPlan.Size = new System.Drawing.Size(206, 38);
      this.miProductionPlan.Text = "Production Plan";
      this.miProductionPlan.Click += new System.EventHandler(this.miProductionPlan_Click);
      // 
      // toolStripSeparator2
      // 
      this.toolStripSeparator2.Name = "toolStripSeparator2";
      this.toolStripSeparator2.Size = new System.Drawing.Size(203, 6);
      // 
      // miSearchJob
      // 
      this.miSearchJob.Image = global::workshop_orders.Properties.Resources.find;
      this.miSearchJob.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.miSearchJob.Name = "miSearchJob";
      this.miSearchJob.Size = new System.Drawing.Size(206, 38);
      this.miSearchJob.Text = "Search Job";
      this.miSearchJob.Click += new System.EventHandler(this.miSearchJob_Click);
      // 
      // miNewJob
      // 
      this.miNewJob.Image = global::workshop_orders.Properties.Resources.addnew;
      this.miNewJob.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.miNewJob.Name = "miNewJob";
      this.miNewJob.Size = new System.Drawing.Size(206, 38);
      this.miNewJob.Text = "New Job";
      this.miNewJob.Click += new System.EventHandler(this.miNewJob_Click);
      // 
      // miQuotes
      // 
      this.miQuotes.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miViewQuotes,
            this.miNewQuotes});
      this.miQuotes.Name = "miQuotes";
      this.miQuotes.Size = new System.Drawing.Size(72, 25);
      this.miQuotes.Text = "Quotes";
      this.miQuotes.Visible = false;
      // 
      // miViewQuotes
      // 
      this.miViewQuotes.Image = global::workshop_orders.Properties.Resources.detail32;
      this.miViewQuotes.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.miViewQuotes.Name = "miViewQuotes";
      this.miViewQuotes.Size = new System.Drawing.Size(184, 38);
      this.miViewQuotes.Text = "View Quotes";
      this.miViewQuotes.Click += new System.EventHandler(this.miViewQuotes_Click);
      // 
      // miNewQuotes
      // 
      this.miNewQuotes.Image = global::workshop_orders.Properties.Resources.addnew;
      this.miNewQuotes.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.miNewQuotes.Name = "miNewQuotes";
      this.miNewQuotes.Size = new System.Drawing.Size(184, 38);
      this.miNewQuotes.Text = "New Quote";
      this.miNewQuotes.Click += new System.EventHandler(this.miNewQuotes_Click);
      // 
      // miStock
      // 
      this.miStock.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miStockList,
            this.miLocations,
            this.toolStripSeparator3,
            this.miNewItem});
      this.miStock.Name = "miStock";
      this.miStock.Size = new System.Drawing.Size(59, 25);
      this.miStock.Text = "Stock";
      this.miStock.Visible = false;
      // 
      // miStockList
      // 
      this.miStockList.Image = global::workshop_orders.Properties.Resources.item32;
      this.miStockList.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.miStockList.Name = "miStockList";
      this.miStockList.Size = new System.Drawing.Size(163, 38);
      this.miStockList.Text = "Stock List";
      this.miStockList.Click += new System.EventHandler(this.miStockList_Click);
      // 
      // miLocations
      // 
      this.miLocations.Image = global::workshop_orders.Properties.Resources.supplier32;
      this.miLocations.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.miLocations.Name = "miLocations";
      this.miLocations.Size = new System.Drawing.Size(163, 38);
      this.miLocations.Text = "Locations";
      this.miLocations.Click += new System.EventHandler(this.miLocations_Click);
      // 
      // toolStripSeparator3
      // 
      this.toolStripSeparator3.Name = "toolStripSeparator3";
      this.toolStripSeparator3.Size = new System.Drawing.Size(160, 6);
      // 
      // miNewItem
      // 
      this.miNewItem.Image = global::workshop_orders.Properties.Resources.addnew;
      this.miNewItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.miNewItem.Name = "miNewItem";
      this.miNewItem.Size = new System.Drawing.Size(163, 38);
      this.miNewItem.Text = "New Item";
      this.miNewItem.Click += new System.EventHandler(this.miNewItem_Click);
      // 
      // miWorkshop
      // 
      this.miWorkshop.Name = "miWorkshop";
      this.miWorkshop.Size = new System.Drawing.Size(93, 25);
      this.miWorkshop.Text = "Workshop";
      this.miWorkshop.Visible = false;
      this.miWorkshop.Click += new System.EventHandler(this.miWorkshop_Click);
      // 
      // miWindows
      // 
      this.miWindows.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miCloseAllWindows,
            this.toolStripSeparator1});
      this.miWindows.Name = "miWindows";
      this.miWindows.Size = new System.Drawing.Size(87, 25);
      this.miWindows.Text = "Windows";
      this.miWindows.Visible = false;
      // 
      // miCloseAllWindows
      // 
      this.miCloseAllWindows.Image = global::workshop_orders.Properties.Resources.close_all;
      this.miCloseAllWindows.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.miCloseAllWindows.Name = "miCloseAllWindows";
      this.miCloseAllWindows.Size = new System.Drawing.Size(225, 38);
      this.miCloseAllWindows.Text = "Close All Windows";
      this.miCloseAllWindows.Click += new System.EventHandler(this.miCloseAllWindows_Click);
      // 
      // toolStripSeparator1
      // 
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      this.toolStripSeparator1.Size = new System.Drawing.Size(222, 6);
      // 
      // miAdmin
      // 
      this.miAdmin.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miUsers,
            this.miErrors});
      this.miAdmin.Name = "miAdmin";
      this.miAdmin.Size = new System.Drawing.Size(68, 25);
      this.miAdmin.Text = "Admin";
      this.miAdmin.Visible = false;
      // 
      // miUsers
      // 
      this.miUsers.Image = global::workshop_orders.Properties.Resources.group_add32;
      this.miUsers.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.miUsers.Name = "miUsers";
      this.miUsers.Size = new System.Drawing.Size(138, 38);
      this.miUsers.Text = "Users";
      this.miUsers.Click += new System.EventHandler(this.miUsers_Click);
      // 
      // miErrors
      // 
      this.miErrors.Image = global::workshop_orders.Properties.Resources.cross32;
      this.miErrors.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.miErrors.Name = "miErrors";
      this.miErrors.Size = new System.Drawing.Size(138, 38);
      this.miErrors.Text = "Errors";
      this.miErrors.Click += new System.EventHandler(this.miErrors_Click);
      // 
      // miDev
      // 
      this.miDev.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.imIndividualForms});
      this.miDev.ForeColor = System.Drawing.Color.Red;
      this.miDev.Name = "miDev";
      this.miDev.Size = new System.Drawing.Size(49, 25);
      this.miDev.Text = "Dev";
      this.miDev.Visible = false;
      // 
      // imIndividualForms
      // 
      this.imIndividualForms.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miInsuranceProviders,
            this.ordersToolStripMenuItem,
            this.customerDetailToolStripMenuItem,
            this.supplierListToolStripMenuItem,
            this.tsSuppliersearch,
            this.onsiteToolStripMenuItem,
            this.onsiteDateToolStripMenuItem,
            this.reportsToolStripMenuItem});
      this.imIndividualForms.Image = global::workshop_orders.Properties.Resources.nav_panel321;
      this.imIndividualForms.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.imIndividualForms.Name = "imIndividualForms";
      this.imIndividualForms.Size = new System.Drawing.Size(212, 38);
      this.imIndividualForms.Text = "Individual Forms";
      // 
      // miInsuranceProviders
      // 
      this.miInsuranceProviders.Name = "miInsuranceProviders";
      this.miInsuranceProviders.Size = new System.Drawing.Size(217, 26);
      this.miInsuranceProviders.Text = "Insurance Providers";
      this.miInsuranceProviders.Click += new System.EventHandler(this.miInsuranceProviders_Click);
      // 
      // ordersToolStripMenuItem
      // 
      this.ordersToolStripMenuItem.Name = "ordersToolStripMenuItem";
      this.ordersToolStripMenuItem.Size = new System.Drawing.Size(217, 26);
      this.ordersToolStripMenuItem.Text = "Orders";
      this.ordersToolStripMenuItem.Click += new System.EventHandler(this.ordersToolStripMenuItem_Click);
      // 
      // customerDetailToolStripMenuItem
      // 
      this.customerDetailToolStripMenuItem.Name = "customerDetailToolStripMenuItem";
      this.customerDetailToolStripMenuItem.Size = new System.Drawing.Size(217, 26);
      this.customerDetailToolStripMenuItem.Text = "Customer List";
      this.customerDetailToolStripMenuItem.Click += new System.EventHandler(this.customerDetailToolStripMenuItem_Click);
      // 
      // supplierListToolStripMenuItem
      // 
      this.supplierListToolStripMenuItem.Name = "supplierListToolStripMenuItem";
      this.supplierListToolStripMenuItem.Size = new System.Drawing.Size(217, 26);
      this.supplierListToolStripMenuItem.Text = "Supplier List";
      this.supplierListToolStripMenuItem.Click += new System.EventHandler(this.supplierListToolStripMenuItem_Click);
      // 
      // tsSuppliersearch
      // 
      this.tsSuppliersearch.Name = "tsSuppliersearch";
      this.tsSuppliersearch.Size = new System.Drawing.Size(217, 26);
      this.tsSuppliersearch.Text = "Supplier Search";
      this.tsSuppliersearch.Click += new System.EventHandler(this.tsSuppliersearch_Click);
      // 
      // onsiteToolStripMenuItem
      // 
      this.onsiteToolStripMenuItem.Name = "onsiteToolStripMenuItem";
      this.onsiteToolStripMenuItem.Size = new System.Drawing.Size(217, 26);
      this.onsiteToolStripMenuItem.Text = "Onsite";
      this.onsiteToolStripMenuItem.Click += new System.EventHandler(this.onsiteToolStripMenuItem_Click);
      // 
      // onsiteDateToolStripMenuItem
      // 
      this.onsiteDateToolStripMenuItem.Name = "onsiteDateToolStripMenuItem";
      this.onsiteDateToolStripMenuItem.Size = new System.Drawing.Size(217, 26);
      this.onsiteDateToolStripMenuItem.Text = "Onsite Date";
      this.onsiteDateToolStripMenuItem.Click += new System.EventHandler(this.onsiteDateToolStripMenuItem_Click);
      // 
      // miUsername
      // 
      this.miUsername.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
      this.miUsername.Enabled = false;
      this.miUsername.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.miUsername.Name = "miUsername";
      this.miUsername.Size = new System.Drawing.Size(83, 25);
      this.miUsername.Text = "No User";
      // 
      // reportsToolStripMenuItem
      // 
      this.reportsToolStripMenuItem.Name = "reportsToolStripMenuItem";
      this.reportsToolStripMenuItem.Size = new System.Drawing.Size(217, 26);
      this.reportsToolStripMenuItem.Text = "reports";
      this.reportsToolStripMenuItem.Click += new System.EventHandler(this.reportsToolStripMenuItem_Click_1);
      // 
      // GWMS
      // 
      this.AcceptButton = this.btnLogin;
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
      this.BackColor = System.Drawing.SystemColors.Control;
      this.ClientSize = new System.Drawing.Size(1923, 1041);
      this.Controls.Add(this.btnWorkshop);
      this.Controls.Add(this.pnlLogin);
      this.Controls.Add(this.menuStrip1);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.IsMdiContainer = true;
      this.KeyPreview = true;
      this.MainMenuStrip = this.menuStrip1;
      this.MaximumSize = new System.Drawing.Size(2574, 2605);
      this.Name = "GWMS";
      this.Text = "BMS";
      this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
      this.Load += new System.EventHandler(this.GWMS_Load);
      this.pnlLogin.ResumeLayout(false);
      this.pnlLogin.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.pbGWG)).EndInit();
      this.menuStrip1.ResumeLayout(false);
      this.menuStrip1.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

        }

        #endregion
    private System.Windows.Forms.Panel pnlLogin;
    private System.Windows.Forms.Button btnLogin;
    private System.Windows.Forms.TextBox txtPassword;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.TextBox txtUsername;
    private System.Windows.Forms.Label lblUsername;
    private System.Windows.Forms.PictureBox pbGWG;
    private System.Windows.Forms.Timer timer1;
    private System.Windows.Forms.Button btnWorkshop;
    private System.Windows.Forms.MenuStrip menuStrip1;
    private System.Windows.Forms.ToolStripMenuItem miWindows;
    private System.Windows.Forms.ToolStripMenuItem miCloseAllWindows;
    private System.Windows.Forms.ToolStripMenuItem miFile;
    private System.Windows.Forms.ToolStripMenuItem miHome;
    private System.Windows.Forms.ToolStripMenuItem miJobs;
    private System.Windows.Forms.ToolStripMenuItem miQuotes;
    private System.Windows.Forms.ToolStripMenuItem miStock;
    private System.Windows.Forms.ToolStripMenuItem miWorkshop;
    private System.Windows.Forms.ToolStripMenuItem miAdmin;
    private System.Windows.Forms.ToolStripMenuItem miDev;
    private System.Windows.Forms.ToolStripMenuItem miLogout;
    private System.Windows.Forms.ToolStripMenuItem miCloseBMS;
    private System.Windows.Forms.ToolStripMenuItem miProductionPlan;
    private System.Windows.Forms.ToolStripMenuItem miSearchJob;
    private System.Windows.Forms.ToolStripMenuItem miNewJob;
    private System.Windows.Forms.ToolStripMenuItem miViewQuotes;
    private System.Windows.Forms.ToolStripMenuItem miNewQuotes;
    private System.Windows.Forms.ToolStripMenuItem miStockList;
    private System.Windows.Forms.ToolStripMenuItem miNewItem;
    private System.Windows.Forms.ToolStripMenuItem miLocations;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
    private System.Windows.Forms.ToolStripMenuItem miUsers;
    private System.Windows.Forms.ToolStripMenuItem miErrors;
    private System.Windows.Forms.ToolStripMenuItem imIndividualForms;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
    private System.Windows.Forms.ToolStripMenuItem miInsuranceProviders;
    private System.Windows.Forms.ToolStripMenuItem miUsername;
    private System.Windows.Forms.ToolStripMenuItem ordersToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem customerDetailToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem supplierListToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem tsSuppliersearch;
    private System.Windows.Forms.ToolStripMenuItem onsiteToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem onsiteDateToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem reportsToolStripMenuItem;
  }
}

