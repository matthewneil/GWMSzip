﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workshop_orders
{
  public partial class LocationEdit : Form
  {
    private int LocationID;

    public LocationEdit(int LocationID)
    {
      InitializeComponent();
      this.LocationID = LocationID;
      LoadGroups();
      Text = "New Location";
      if (LocationID > 0)
      {
        Text = "Edit Location";
        LoadData();
      }
      DataAccess.FormState(this.AccessibilityObject.Name, tsSave);
    }



    public void LoadData()
    {
      DataTable dt = DataAccess.ExecuteDataTable("SELECT * FROM location WHERE LocationID = " + LocationID);
      try
      {
        if (dt != null && dt.Rows.Count > 0)
        {

          cmbGroup.SelectedValue = dt.Rows[0]["LocationGroup"].ToString();
          cmbSubGroup.SelectedValue = dt.Rows[0]["LocationSubGroup"].ToString();
          txtCode.Text = dt.Rows[0]["LocationCode"].ToString();
          txtDescription.Text = dt.Rows[0]["LocationDescription"].ToString();

        }
      }
      catch (Exception ex)
      {
        MessageBox.Show("There was an error loading Location Data");
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name, 
          System.Reflection.MethodBase.GetCurrentMethod().Name, "SELECT * FROM location WHERE LocationID = " + LocationID);
      }

      DataTable dtItems = DataAccess.ExecuteDataTable(
        "SELECT c.ItemCostID, icCode, icDescription, icCost, Quantity, JobID " +
        "FROM itemcost c " +
        "INNER JOIN itemstock s ON c.ItemCostID = s.ItemCostID " +
        "LEFT JOIN jobitem j ON j.ItemStockID = s.ItemStockID " +
        "WHERE LocationID = " + LocationID + " ORDER BY icCode DESC");
      dgvItems.DataSource = dtItems;
    }

    public void LoadGroups()
    {
      //Group
      try
      {
        DataTable dt = DataAccess.ExecuteDataTable("SELECT LocationGroup AS datafield, LocationGroup AS textfield FROM location GROUP BY LocationGroup");
        DataAccess.AddSelect(dt);
        cmbGroup.DataSource = dt;
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
          System.Reflection.MethodBase.GetCurrentMethod().Name, "SELECT LocationGroup FROM location GROUP BY LocationGroup");
      }
    }

    private void LoadSubGroups()
    {
      //SubGroup
      try
      {
        DataTable dt;
        if (cmbGroup.SelectedValue.ToString() != "-1")
        {
          dt = DataAccess.ExecuteDataTable("SELECT LocationSubGroup AS datafield, LocationSubGroup AS textfield FROM location WHERE LocationGroup = '" + cmbGroup.SelectedValue + "' GROUP BY LocationSubGroup");
        }
        else
        {
          dt = DataAccess.ExecuteDataTable("SELECT LocationSubGroup AS datafield, LocationSubGroup AS textfield FROM location GROUP BY LocationSubGroup");
        }
        DataAccess.AddSelect(dt);
        cmbSubGroup.DataSource = dt;
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
          System.Reflection.MethodBase.GetCurrentMethod().Name, "SELECT LocationSubGroup FROM location WHERE LocationGroup = '" + cmbGroup.SelectedValue + "' GROUP BY LocationSubGroup");
      }
    }

    private void tsClose_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private void tsSave_Click(object sender, EventArgs e)
    {
      //ERROR CHECK
      String errors = "Can not save Location Details due to the following issues:\n\n";

      if(cmbGroup.SelectedIndex == 0)
      {
        errors += "- No Group Selected\n";
      }

      if (cmbSubGroup.SelectedIndex == 0)
      {
        errors += "- No Sub Group Selected\n";
      }
      if (txtCode.Text.Trim() == "")
      {
        errors += "- No Code Entered\n";
      }
      if (txtDescription.Text == "")
      {
        errors += "- No Description Entered\n";
      }

      if (errors == "Can not save Location Details due to the following issues:\n\n")
      {
        DataAccess.LocationManage(LocationID, cmbGroup.SelectedValue.ToString(), cmbSubGroup.SelectedValue.ToString(), txtCode.Text, txtDescription.Text);
        DataAccess.ShowMessage("Location data saved");
        this.Close();
      }
      else
      {
        DataAccess.ShowMessage(errors);
      }
    }

    public bool IsCurrency(string value)
    {
      value.Remove('.').All(char.IsNumber);
      return true;
    }

    private void cmbGroup_SelectedIndexChanged(object sender, EventArgs e)
    {
      LoadSubGroups();
    }

    private void dgvItems_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      if (dgvItems.SelectedRows.Count > 0 && dgvItems.SelectedRows[0].Index > -1)
      {
        FormManagement.ShowChildForm(new ItemEdit((int)dgvItems.SelectedRows[0].Cells["chID"].Value));
      }
    }
  }
}
