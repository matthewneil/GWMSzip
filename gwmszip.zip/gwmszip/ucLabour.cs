﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workshop_orders
{
  public partial class ucLabour : UserControl
  {
    public String data = "";
    private String section = "";
    public static Workshop frm;
    
    public ucLabour(String data, String section)
    {
      InitializeComponent();
      this.data = data;
      this.section = section;
      switch (section)
      {
        case "user":
          lblInfo.Text = DataAccess.ExecuteScalarString("SELECT StaffFullName FROM staff WHERE StaffID = " + data);
          break;

        case "jobgroup":
          lblInfo.Text = data;
          break;

        case "joblist":
          lblInfo.Text = data;
          break;

        case "admin":
          lblInfo.Text = DataAccess.ExecuteScalarString("SELECT AdminTaskName FROM AdminTask WHERE AdminTaskID = " + data);
          break;

      }     
    }

    private void lblInfo_Click(object sender, EventArgs e)
    {
      switch (section)
      {
        case "user":
          Workshop.StaffID = int.Parse(data);
          frm.ShowJobGroups();
          break;

        case "jobgroup":
          
          frm.ShowJobs(data);
          break;

        case "joblist":
          break;

        case "admin":
          frm.OpenAdminTask(int.Parse(data));
          break;
      }
    }
  }
}
