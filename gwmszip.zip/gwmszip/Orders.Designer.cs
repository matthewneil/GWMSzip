﻿
namespace workshop_orders
{
	partial class Orders
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
      this.chQuote = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chDateRequired = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chOrderDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chSupplier = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chOrder = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Label5 = new System.Windows.Forms.Label();
      this.txtInternalID = new System.Windows.Forms.TextBox();
      this.Label4 = new System.Windows.Forms.Label();
      this.Label3 = new System.Windows.Forms.Label();
      this.cmbStaff = new System.Windows.Forms.ComboBox();
      this.Label1 = new System.Windows.Forms.Label();
      this.txtOrder = new System.Windows.Forms.TextBox();
      this.dgvData = new System.Windows.Forms.DataGridView();
      this.chReference = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chInstructions = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chCreatedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chBranch = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chType = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chBusiness = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chEmailDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chEmailed = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.scData = new System.Windows.Forms.SplitContainer();
      this.DataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.DataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.DataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.DataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.DataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.DataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.DataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.DataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.DataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.DataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.DataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.DataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.cmbType = new System.Windows.Forms.ComboBox();
      this.ToolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
      this.dtpEndDate = new System.Windows.Forms.DateTimePicker();
      this.dtpStartDate = new System.Windows.Forms.DateTimePicker();
      this.ToolStrip1 = new System.Windows.Forms.ToolStrip();
      this.lblHeader = new System.Windows.Forms.Label();
      this.txtID = new System.Windows.Forms.TextBox();
      this.scMain = new System.Windows.Forms.SplitContainer();
      this.Panel3 = new System.Windows.Forms.Panel();
      this.lnkFind = new System.Windows.Forms.LinkLabel();
      this.txtOrder1 = new System.Windows.Forms.TextBox();
      this.Label2 = new System.Windows.Forms.Label();
      this.gbFilters = new System.Windows.Forms.GroupBox();
      this.lblType = new System.Windows.Forms.Label();
      this.cmbSupplier = new System.Windows.Forms.ComboBox();
      this.lblStartDate = new System.Windows.Forms.Label();
      this.lblEndDate = new System.Windows.Forms.Label();
      this.pnlHeader = new System.Windows.Forms.Panel();
      this.DataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.btnFind = new System.Windows.Forms.Button();
      this.pbHide = new System.Windows.Forms.PictureBox();
      this.btnReset = new System.Windows.Forms.Button();
      this.pbShow = new System.Windows.Forms.PictureBox();
      this.PictureBox1 = new System.Windows.Forms.PictureBox();
      this.tsClose = new System.Windows.Forms.ToolStripButton();
      this.tsAdd = new System.Windows.Forms.ToolStripButton();
      this.tsEdit = new System.Windows.Forms.ToolStripButton();
      this.tsRefresh = new System.Windows.Forms.ToolStripButton();
      this.tsDelete = new System.Windows.Forms.ToolStripButton();
      ((System.ComponentModel.ISupportInitialize)(this.dgvData)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.scData)).BeginInit();
      this.scData.Panel1.SuspendLayout();
      this.scData.Panel2.SuspendLayout();
      this.scData.SuspendLayout();
      this.ToolStrip1.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.scMain)).BeginInit();
      this.scMain.Panel1.SuspendLayout();
      this.scMain.Panel2.SuspendLayout();
      this.scMain.SuspendLayout();
      this.Panel3.SuspendLayout();
      this.gbFilters.SuspendLayout();
      this.pnlHeader.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.pbHide)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.pbShow)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).BeginInit();
      this.SuspendLayout();
      // 
      // chQuote
      // 
      this.chQuote.HeaderText = "Quote";
      this.chQuote.Name = "chQuote";
      this.chQuote.ReadOnly = true;
      this.chQuote.Width = 70;
      // 
      // chDateRequired
      // 
      dataGridViewCellStyle1.Format = "dd/MM/yyyy";
      this.chDateRequired.DefaultCellStyle = dataGridViewCellStyle1;
      this.chDateRequired.HeaderText = "Date Required";
      this.chDateRequired.Name = "chDateRequired";
      this.chDateRequired.ReadOnly = true;
      this.chDateRequired.Width = 105;
      // 
      // chOrderDate
      // 
      dataGridViewCellStyle2.Format = "dd/MM/yyyy";
      dataGridViewCellStyle2.NullValue = null;
      this.chOrderDate.DefaultCellStyle = dataGridViewCellStyle2;
      this.chOrderDate.HeaderText = "Order Date";
      this.chOrderDate.Name = "chOrderDate";
      this.chOrderDate.ReadOnly = true;
      // 
      // chSupplier
      // 
      this.chSupplier.HeaderText = "Supplier";
      this.chSupplier.Name = "chSupplier";
      this.chSupplier.ReadOnly = true;
      this.chSupplier.Width = 200;
      // 
      // chOrder
      // 
      this.chOrder.HeaderText = "Order";
      this.chOrder.Name = "chOrder";
      this.chOrder.ReadOnly = true;
      this.chOrder.Width = 65;
      // 
      // Label5
      // 
      this.Label5.AutoSize = true;
      this.Label5.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.Label5.ForeColor = System.Drawing.Color.White;
      this.Label5.Location = new System.Drawing.Point(9, 314);
      this.Label5.Name = "Label5";
      this.Label5.Size = new System.Drawing.Size(118, 18);
      this.Label5.TabIndex = 44;
      this.Label5.Text = "Job / Quote ID";
      // 
      // txtInternalID
      // 
      this.txtInternalID.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtInternalID.Location = new System.Drawing.Point(12, 334);
      this.txtInternalID.Name = "txtInternalID";
      this.txtInternalID.Size = new System.Drawing.Size(158, 26);
      this.txtInternalID.TabIndex = 43;
      this.txtInternalID.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtInternalID_KeyDown);
      // 
      // Label4
      // 
      this.Label4.AutoSize = true;
      this.Label4.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.Label4.ForeColor = System.Drawing.Color.White;
      this.Label4.Location = new System.Drawing.Point(9, 123);
      this.Label4.Name = "Label4";
      this.Label4.Size = new System.Drawing.Size(71, 18);
      this.Label4.TabIndex = 42;
      this.Label4.Text = "Supplier";
      // 
      // Label3
      // 
      this.Label3.AutoSize = true;
      this.Label3.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.Label3.ForeColor = System.Drawing.Color.White;
      this.Label3.Location = new System.Drawing.Point(9, 170);
      this.Label3.Name = "Label3";
      this.Label3.Size = new System.Drawing.Size(90, 18);
      this.Label3.TabIndex = 40;
      this.Label3.Text = "Created By";
      // 
      // cmbStaff
      // 
      this.cmbStaff.DisplayMember = "textfield";
      this.cmbStaff.DropDownHeight = 400;
      this.cmbStaff.DropDownWidth = 250;
      this.cmbStaff.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbStaff.FormattingEnabled = true;
      this.cmbStaff.IntegralHeight = false;
      this.cmbStaff.Location = new System.Drawing.Point(12, 190);
      this.cmbStaff.Name = "cmbStaff";
      this.cmbStaff.Size = new System.Drawing.Size(158, 26);
      this.cmbStaff.TabIndex = 39;
      this.cmbStaff.ValueMember = "datafield";
      this.cmbStaff.SelectedIndexChanged += new System.EventHandler(this.cmbStaff_SelectedIndexChanged);
      // 
      // Label1
      // 
      this.Label1.AutoSize = true;
      this.Label1.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.Label1.ForeColor = System.Drawing.Color.White;
      this.Label1.Location = new System.Drawing.Point(9, 218);
      this.Label1.Name = "Label1";
      this.Label1.Size = new System.Drawing.Size(77, 18);
      this.Label1.TabIndex = 38;
      this.Label1.Text = "Order No";
      // 
      // txtOrder
      // 
      this.txtOrder.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtOrder.Location = new System.Drawing.Point(12, 238);
      this.txtOrder.Name = "txtOrder";
      this.txtOrder.Size = new System.Drawing.Size(158, 26);
      this.txtOrder.TabIndex = 37;
      this.txtOrder.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtOrder_KeyDown);
      // 
      // dgvData
      // 
      this.dgvData.AllowUserToAddRows = false;
      this.dgvData.AllowUserToDeleteRows = false;
      this.dgvData.AllowUserToResizeRows = false;
      dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
      this.dgvData.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
      this.dgvData.BackgroundColor = System.Drawing.Color.White;
      this.dgvData.BorderStyle = System.Windows.Forms.BorderStyle.None;
      this.dgvData.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
      dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
      dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
      dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
      dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
      dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
      dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
      dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
      this.dgvData.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
      this.dgvData.ColumnHeadersHeight = 28;
      this.dgvData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
      this.dgvData.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.chOrder,
            this.chSupplier,
            this.chOrderDate,
            this.chDateRequired,
            this.chQuote,
            this.chReference,
            this.chInstructions,
            this.chCreatedBy,
            this.chBranch,
            this.chType,
            this.chBusiness,
            this.chEmailDate,
            this.chEmailed});
      dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
      dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
      dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
      dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
      dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
      dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
      dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
      this.dgvData.DefaultCellStyle = dataGridViewCellStyle6;
      this.dgvData.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dgvData.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
      this.dgvData.Location = new System.Drawing.Point(0, 0);
      this.dgvData.MultiSelect = false;
      this.dgvData.Name = "dgvData";
      dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
      dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
      dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
      dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
      dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
      dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
      dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
      this.dgvData.RowHeadersDefaultCellStyle = dataGridViewCellStyle7;
      this.dgvData.RowHeadersVisible = false;
      this.dgvData.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
      this.dgvData.ShowEditingIcon = false;
      this.dgvData.Size = new System.Drawing.Size(1349, 767);
      this.dgvData.TabIndex = 73;
      // 
      // chReference
      // 
      this.chReference.HeaderText = "Reference";
      this.chReference.Name = "chReference";
      this.chReference.ReadOnly = true;
      this.chReference.Width = 200;
      // 
      // chInstructions
      // 
      this.chInstructions.HeaderText = "Instructions";
      this.chInstructions.Name = "chInstructions";
      this.chInstructions.ReadOnly = true;
      this.chInstructions.Width = 250;
      // 
      // chCreatedBy
      // 
      this.chCreatedBy.HeaderText = "Created By";
      this.chCreatedBy.Name = "chCreatedBy";
      this.chCreatedBy.ReadOnly = true;
      this.chCreatedBy.Width = 120;
      // 
      // chBranch
      // 
      this.chBranch.HeaderText = "Branch";
      this.chBranch.Name = "chBranch";
      this.chBranch.ReadOnly = true;
      this.chBranch.Width = 180;
      // 
      // chType
      // 
      this.chType.HeaderText = "Type";
      this.chType.Name = "chType";
      this.chType.ReadOnly = true;
      this.chType.Width = 90;
      // 
      // chBusiness
      // 
      this.chBusiness.HeaderText = "Business";
      this.chBusiness.Name = "chBusiness";
      this.chBusiness.ReadOnly = true;
      this.chBusiness.Width = 130;
      // 
      // chEmailDate
      // 
      dataGridViewCellStyle5.Format = "g";
      dataGridViewCellStyle5.NullValue = null;
      this.chEmailDate.DefaultCellStyle = dataGridViewCellStyle5;
      this.chEmailDate.HeaderText = "eMail Date";
      this.chEmailDate.Name = "chEmailDate";
      this.chEmailDate.ReadOnly = true;
      this.chEmailDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
      this.chEmailDate.Width = 130;
      // 
      // chEmailed
      // 
      this.chEmailed.HeaderText = "eMail";
      this.chEmailed.Name = "chEmailed";
      this.chEmailed.ReadOnly = true;
      this.chEmailed.Visible = false;
      this.chEmailed.Width = 40;
      // 
      // scData
      // 
      this.scData.Dock = System.Windows.Forms.DockStyle.Fill;
      this.scData.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
      this.scData.IsSplitterFixed = true;
      this.scData.Location = new System.Drawing.Point(0, 0);
      this.scData.Name = "scData";
      // 
      // scData.Panel1
      // 
      this.scData.Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(210)))));
      this.scData.Panel1.Controls.Add(this.pbShow);
      this.scData.Panel1MinSize = 0;
      // 
      // scData.Panel2
      // 
      this.scData.Panel2.Controls.Add(this.dgvData);
      this.scData.Panel2MinSize = 800;
      this.scData.Size = new System.Drawing.Size(1375, 767);
      this.scData.SplitterDistance = 25;
      this.scData.SplitterWidth = 1;
      this.scData.TabIndex = 21;
      // 
      // DataGridViewTextBoxColumn13
      // 
      this.DataGridViewTextBoxColumn13.HeaderText = "eMail";
      this.DataGridViewTextBoxColumn13.Name = "DataGridViewTextBoxColumn13";
      this.DataGridViewTextBoxColumn13.ReadOnly = true;
      this.DataGridViewTextBoxColumn13.Visible = false;
      this.DataGridViewTextBoxColumn13.Width = 40;
      // 
      // DataGridViewTextBoxColumn11
      // 
      this.DataGridViewTextBoxColumn11.HeaderText = "Business";
      this.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11";
      this.DataGridViewTextBoxColumn11.ReadOnly = true;
      this.DataGridViewTextBoxColumn11.Width = 130;
      // 
      // DataGridViewTextBoxColumn10
      // 
      this.DataGridViewTextBoxColumn10.HeaderText = "Type";
      this.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10";
      this.DataGridViewTextBoxColumn10.ReadOnly = true;
      this.DataGridViewTextBoxColumn10.Width = 90;
      // 
      // DataGridViewTextBoxColumn9
      // 
      this.DataGridViewTextBoxColumn9.HeaderText = "Branch";
      this.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9";
      this.DataGridViewTextBoxColumn9.ReadOnly = true;
      this.DataGridViewTextBoxColumn9.Width = 180;
      // 
      // DataGridViewTextBoxColumn8
      // 
      this.DataGridViewTextBoxColumn8.HeaderText = "Created By";
      this.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8";
      this.DataGridViewTextBoxColumn8.ReadOnly = true;
      this.DataGridViewTextBoxColumn8.Width = 150;
      // 
      // DataGridViewTextBoxColumn7
      // 
      this.DataGridViewTextBoxColumn7.HeaderText = "Instructions";
      this.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7";
      this.DataGridViewTextBoxColumn7.ReadOnly = true;
      this.DataGridViewTextBoxColumn7.Width = 150;
      // 
      // DataGridViewTextBoxColumn6
      // 
      this.DataGridViewTextBoxColumn6.HeaderText = "Reference";
      this.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6";
      this.DataGridViewTextBoxColumn6.ReadOnly = true;
      this.DataGridViewTextBoxColumn6.Width = 150;
      // 
      // DataGridViewTextBoxColumn5
      // 
      this.DataGridViewTextBoxColumn5.HeaderText = "Quote";
      this.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5";
      this.DataGridViewTextBoxColumn5.ReadOnly = true;
      this.DataGridViewTextBoxColumn5.Width = 70;
      // 
      // DataGridViewTextBoxColumn4
      // 
      dataGridViewCellStyle8.Format = "dd/MM/yyyy";
      this.DataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle8;
      this.DataGridViewTextBoxColumn4.HeaderText = "Date Required";
      this.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4";
      this.DataGridViewTextBoxColumn4.ReadOnly = true;
      this.DataGridViewTextBoxColumn4.Width = 90;
      // 
      // DataGridViewTextBoxColumn3
      // 
      dataGridViewCellStyle9.Format = "dd/MM/yyyy";
      dataGridViewCellStyle9.NullValue = null;
      this.DataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle9;
      this.DataGridViewTextBoxColumn3.HeaderText = "Order Date";
      this.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3";
      this.DataGridViewTextBoxColumn3.ReadOnly = true;
      this.DataGridViewTextBoxColumn3.Width = 90;
      // 
      // DataGridViewTextBoxColumn2
      // 
      this.DataGridViewTextBoxColumn2.HeaderText = "Supplier";
      this.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2";
      this.DataGridViewTextBoxColumn2.ReadOnly = true;
      this.DataGridViewTextBoxColumn2.Width = 150;
      // 
      // DataGridViewTextBoxColumn1
      // 
      this.DataGridViewTextBoxColumn1.HeaderText = "Order";
      this.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1";
      this.DataGridViewTextBoxColumn1.ReadOnly = true;
      this.DataGridViewTextBoxColumn1.Width = 65;
      // 
      // cmbType
      // 
      this.cmbType.DisplayMember = "textfield";
      this.cmbType.DropDownHeight = 150;
      this.cmbType.DropDownWidth = 250;
      this.cmbType.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbType.FormattingEnabled = true;
      this.cmbType.IntegralHeight = false;
      this.cmbType.Location = new System.Drawing.Point(12, 284);
      this.cmbType.Name = "cmbType";
      this.cmbType.Size = new System.Drawing.Size(158, 26);
      this.cmbType.TabIndex = 36;
      this.cmbType.ValueMember = "datafield";
      this.cmbType.SelectedIndexChanged += new System.EventHandler(this.cmbType_SelectedIndexChanged);
      // 
      // ToolStripSeparator1
      // 
      this.ToolStripSeparator1.Name = "ToolStripSeparator1";
      this.ToolStripSeparator1.Size = new System.Drawing.Size(6, 39);
      // 
      // dtpEndDate
      // 
      this.dtpEndDate.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.dtpEndDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
      this.dtpEndDate.Location = new System.Drawing.Point(12, 86);
      this.dtpEndDate.Name = "dtpEndDate";
      this.dtpEndDate.Size = new System.Drawing.Size(99, 26);
      this.dtpEndDate.TabIndex = 6;
      // 
      // dtpStartDate
      // 
      this.dtpStartDate.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.dtpStartDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
      this.dtpStartDate.Location = new System.Drawing.Point(12, 38);
      this.dtpStartDate.Name = "dtpStartDate";
      this.dtpStartDate.Size = new System.Drawing.Size(99, 26);
      this.dtpStartDate.TabIndex = 5;
      // 
      // ToolStrip1
      // 
      this.ToolStrip1.BackColor = System.Drawing.SystemColors.Control;
      this.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
      this.ToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsClose,
            this.tsAdd,
            this.tsEdit,
            this.tsRefresh,
            this.ToolStripSeparator1,
            this.tsDelete});
      this.ToolStrip1.Location = new System.Drawing.Point(0, 0);
      this.ToolStrip1.Name = "ToolStrip1";
      this.ToolStrip1.Size = new System.Drawing.Size(1576, 39);
      this.ToolStrip1.TabIndex = 82;
      this.ToolStrip1.Text = "ToolStrip1";
      // 
      // lblHeader
      // 
      this.lblHeader.AutoSize = true;
      this.lblHeader.BackColor = System.Drawing.Color.Transparent;
      this.lblHeader.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblHeader.ForeColor = System.Drawing.Color.Black;
      this.lblHeader.Location = new System.Drawing.Point(3, 5);
      this.lblHeader.MinimumSize = new System.Drawing.Size(480, 0);
      this.lblHeader.Name = "lblHeader";
      this.lblHeader.Size = new System.Drawing.Size(480, 23);
      this.lblHeader.TabIndex = 18;
      this.lblHeader.Text = "Purchase Orders";
      this.lblHeader.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // txtID
      // 
      this.txtID.BackColor = System.Drawing.SystemColors.Control;
      this.txtID.BorderStyle = System.Windows.Forms.BorderStyle.None;
      this.txtID.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtID.ForeColor = System.Drawing.Color.YellowGreen;
      this.txtID.Location = new System.Drawing.Point(640, 10);
      this.txtID.Name = "txtID";
      this.txtID.ReadOnly = true;
      this.txtID.Size = new System.Drawing.Size(57, 17);
      this.txtID.TabIndex = 80;
      this.txtID.TabStop = false;
      this.txtID.Visible = false;
      // 
      // scMain
      // 
      this.scMain.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(210)))));
      this.scMain.Dock = System.Windows.Forms.DockStyle.Fill;
      this.scMain.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
      this.scMain.IsSplitterFixed = true;
      this.scMain.Location = new System.Drawing.Point(0, 39);
      this.scMain.Name = "scMain";
      // 
      // scMain.Panel1
      // 
      this.scMain.Panel1.AutoScroll = true;
      this.scMain.Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(210)))));
      this.scMain.Panel1.Controls.Add(this.Panel3);
      this.scMain.Panel1.Controls.Add(this.Label2);
      this.scMain.Panel1.Controls.Add(this.pbHide);
      this.scMain.Panel1.Controls.Add(this.gbFilters);
      this.scMain.Panel1MinSize = 200;
      // 
      // scMain.Panel2
      // 
      this.scMain.Panel2.Controls.Add(this.scData);
      this.scMain.Panel2MinSize = 600;
      this.scMain.Size = new System.Drawing.Size(1576, 767);
      this.scMain.SplitterDistance = 200;
      this.scMain.SplitterWidth = 1;
      this.scMain.TabIndex = 83;
      // 
      // Panel3
      // 
      this.Panel3.BackColor = System.Drawing.Color.White;
      this.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.Panel3.Controls.Add(this.btnFind);
      this.Panel3.Controls.Add(this.lnkFind);
      this.Panel3.Controls.Add(this.txtOrder1);
      this.Panel3.Location = new System.Drawing.Point(10, 503);
      this.Panel3.Name = "Panel3";
      this.Panel3.Size = new System.Drawing.Size(180, 58);
      this.Panel3.TabIndex = 82;
      // 
      // lnkFind
      // 
      this.lnkFind.AutoSize = true;
      this.lnkFind.DisabledLinkColor = System.Drawing.Color.White;
      this.lnkFind.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lnkFind.LinkColor = System.Drawing.Color.Black;
      this.lnkFind.Location = new System.Drawing.Point(61, 8);
      this.lnkFind.Name = "lnkFind";
      this.lnkFind.Size = new System.Drawing.Size(88, 18);
      this.lnkFind.TabIndex = 58;
      this.lnkFind.TabStop = true;
      this.lnkFind.Text = "Find Order";
      // 
      // txtOrder1
      // 
      this.txtOrder1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtOrder1.Location = new System.Drawing.Point(59, 30);
      this.txtOrder1.Name = "txtOrder1";
      this.txtOrder1.Size = new System.Drawing.Size(110, 24);
      this.txtOrder1.TabIndex = 59;
      // 
      // Label2
      // 
      this.Label2.AutoSize = true;
      this.Label2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.Label2.ForeColor = System.Drawing.Color.White;
      this.Label2.Location = new System.Drawing.Point(11, 22);
      this.Label2.Name = "Label2";
      this.Label2.Size = new System.Drawing.Size(42, 13);
      this.Label2.TabIndex = 80;
      this.Label2.Text = "Filters";
      // 
      // gbFilters
      // 
      this.gbFilters.Controls.Add(this.btnReset);
      this.gbFilters.Controls.Add(this.Label5);
      this.gbFilters.Controls.Add(this.txtInternalID);
      this.gbFilters.Controls.Add(this.Label4);
      this.gbFilters.Controls.Add(this.Label3);
      this.gbFilters.Controls.Add(this.cmbStaff);
      this.gbFilters.Controls.Add(this.Label1);
      this.gbFilters.Controls.Add(this.txtOrder);
      this.gbFilters.Controls.Add(this.cmbType);
      this.gbFilters.Controls.Add(this.lblType);
      this.gbFilters.Controls.Add(this.cmbSupplier);
      this.gbFilters.Controls.Add(this.dtpEndDate);
      this.gbFilters.Controls.Add(this.lblStartDate);
      this.gbFilters.Controls.Add(this.lblEndDate);
      this.gbFilters.Controls.Add(this.dtpStartDate);
      this.gbFilters.Location = new System.Drawing.Point(10, 31);
      this.gbFilters.Name = "gbFilters";
      this.gbFilters.Size = new System.Drawing.Size(180, 454);
      this.gbFilters.TabIndex = 81;
      this.gbFilters.TabStop = false;
      // 
      // lblType
      // 
      this.lblType.AutoSize = true;
      this.lblType.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblType.ForeColor = System.Drawing.Color.White;
      this.lblType.Location = new System.Drawing.Point(9, 265);
      this.lblType.Name = "lblType";
      this.lblType.Size = new System.Drawing.Size(44, 18);
      this.lblType.TabIndex = 34;
      this.lblType.Text = "Type";
      // 
      // cmbSupplier
      // 
      this.cmbSupplier.DisplayMember = "textfield";
      this.cmbSupplier.DropDownHeight = 400;
      this.cmbSupplier.DropDownWidth = 250;
      this.cmbSupplier.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbSupplier.FormattingEnabled = true;
      this.cmbSupplier.IntegralHeight = false;
      this.cmbSupplier.Location = new System.Drawing.Point(12, 143);
      this.cmbSupplier.Name = "cmbSupplier";
      this.cmbSupplier.Size = new System.Drawing.Size(158, 26);
      this.cmbSupplier.TabIndex = 33;
      this.cmbSupplier.ValueMember = "datafield";
      this.cmbSupplier.SelectedIndexChanged += new System.EventHandler(this.cmbSupplier_SelectedIndexChanged);
      // 
      // lblStartDate
      // 
      this.lblStartDate.AutoSize = true;
      this.lblStartDate.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblStartDate.ForeColor = System.Drawing.Color.White;
      this.lblStartDate.Location = new System.Drawing.Point(9, 18);
      this.lblStartDate.Name = "lblStartDate";
      this.lblStartDate.Size = new System.Drawing.Size(85, 18);
      this.lblStartDate.TabIndex = 15;
      this.lblStartDate.Text = "From Date";
      // 
      // lblEndDate
      // 
      this.lblEndDate.AutoSize = true;
      this.lblEndDate.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblEndDate.ForeColor = System.Drawing.Color.White;
      this.lblEndDate.Location = new System.Drawing.Point(9, 66);
      this.lblEndDate.Name = "lblEndDate";
      this.lblEndDate.Size = new System.Drawing.Size(65, 18);
      this.lblEndDate.TabIndex = 16;
      this.lblEndDate.Text = "To Date";
      // 
      // pnlHeader
      // 
      this.pnlHeader.BackColor = System.Drawing.Color.Transparent;
      this.pnlHeader.Controls.Add(this.lblHeader);
      this.pnlHeader.Controls.Add(this.PictureBox1);
      this.pnlHeader.Location = new System.Drawing.Point(1043, 1);
      this.pnlHeader.Name = "pnlHeader";
      this.pnlHeader.Size = new System.Drawing.Size(533, 32);
      this.pnlHeader.TabIndex = 81;
      // 
      // DataGridViewTextBoxColumn12
      // 
      dataGridViewCellStyle10.Format = "dd/MM/yyyy";
      this.DataGridViewTextBoxColumn12.DefaultCellStyle = dataGridViewCellStyle10;
      this.DataGridViewTextBoxColumn12.HeaderText = "eMail Date";
      this.DataGridViewTextBoxColumn12.Name = "DataGridViewTextBoxColumn12";
      this.DataGridViewTextBoxColumn12.ReadOnly = true;
      this.DataGridViewTextBoxColumn12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
      this.DataGridViewTextBoxColumn12.Width = 90;
      // 
      // btnFind
      // 
      this.btnFind.BackColor = System.Drawing.Color.Transparent;
      this.btnFind.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
      this.btnFind.Cursor = System.Windows.Forms.Cursors.Hand;
      this.btnFind.Image = global::workshop_orders.Properties.Resources.find;
      this.btnFind.Location = new System.Drawing.Point(5, 5);
      this.btnFind.Name = "btnFind";
      this.btnFind.Size = new System.Drawing.Size(48, 48);
      this.btnFind.TabIndex = 0;
      this.btnFind.UseVisualStyleBackColor = false;
      // 
      // pbHide
      // 
      this.pbHide.Image = global::workshop_orders.Properties.Resources.doublearrowleft16;
      this.pbHide.Location = new System.Drawing.Point(181, 7);
      this.pbHide.Name = "pbHide";
      this.pbHide.Size = new System.Drawing.Size(17, 20);
      this.pbHide.TabIndex = 1;
      this.pbHide.TabStop = false;
      this.pbHide.Click += new System.EventHandler(this.pbHide_Click);
      // 
      // btnReset
      // 
      this.btnReset.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnReset.Image = global::workshop_orders.Properties.Resources.reset;
      this.btnReset.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
      this.btnReset.Location = new System.Drawing.Point(28, 369);
      this.btnReset.Name = "btnReset";
      this.btnReset.Padding = new System.Windows.Forms.Padding(5, 0, 5, 0);
      this.btnReset.Size = new System.Drawing.Size(118, 36);
      this.btnReset.TabIndex = 80;
      this.btnReset.Text = "Reset";
      this.btnReset.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      this.btnReset.UseVisualStyleBackColor = true;
      this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
      // 
      // pbShow
      // 
      this.pbShow.Image = global::workshop_orders.Properties.Resources.doublearrowright16;
      this.pbShow.Location = new System.Drawing.Point(4, 7);
      this.pbShow.Name = "pbShow";
      this.pbShow.Size = new System.Drawing.Size(17, 20);
      this.pbShow.TabIndex = 0;
      this.pbShow.TabStop = false;
      this.pbShow.Click += new System.EventHandler(this.pbShow_Click);
      // 
      // PictureBox1
      // 
      this.PictureBox1.BackColor = System.Drawing.Color.Transparent;
      this.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
      this.PictureBox1.Image = global::workshop_orders.Properties.Resources.purchase_order_32;
      this.PictureBox1.Location = new System.Drawing.Point(497, -1);
      this.PictureBox1.Name = "PictureBox1";
      this.PictureBox1.Size = new System.Drawing.Size(32, 32);
      this.PictureBox1.TabIndex = 17;
      this.PictureBox1.TabStop = false;
      // 
      // tsClose
      // 
      this.tsClose.Image = global::workshop_orders.Properties.Resources.back;
      this.tsClose.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsClose.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsClose.Name = "tsClose";
      this.tsClose.Size = new System.Drawing.Size(72, 36);
      this.tsClose.Text = "Close";
      this.tsClose.Click += new System.EventHandler(this.tsClose_Click);
      // 
      // tsAdd
      // 
      this.tsAdd.Image = global::workshop_orders.Properties.Resources.addnew;
      this.tsAdd.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsAdd.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsAdd.Name = "tsAdd";
      this.tsAdd.Size = new System.Drawing.Size(65, 36);
      this.tsAdd.Text = "Add";
      this.tsAdd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      this.tsAdd.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
      this.tsAdd.ToolTipText = "Create New Purchase Order";
      this.tsAdd.Click += new System.EventHandler(this.tsAdd_Click);
      // 
      // tsEdit
      // 
      this.tsEdit.Image = global::workshop_orders.Properties.Resources.edit;
      this.tsEdit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsEdit.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsEdit.Name = "tsEdit";
      this.tsEdit.Size = new System.Drawing.Size(63, 36);
      this.tsEdit.Text = "Edit";
      this.tsEdit.ToolTipText = "Edit Selected Purchase Order";
      this.tsEdit.Click += new System.EventHandler(this.tsEdit_Click);
      // 
      // tsRefresh
      // 
      this.tsRefresh.Image = global::workshop_orders.Properties.Resources.refresh;
      this.tsRefresh.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsRefresh.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsRefresh.Name = "tsRefresh";
      this.tsRefresh.Size = new System.Drawing.Size(82, 36);
      this.tsRefresh.Text = "Refresh";
      this.tsRefresh.Click += new System.EventHandler(this.tsRefresh_Click);
      // 
      // tsDelete
      // 
      this.tsDelete.Image = global::workshop_orders.Properties.Resources.delete;
      this.tsDelete.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsDelete.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsDelete.Name = "tsDelete";
      this.tsDelete.Size = new System.Drawing.Size(76, 36);
      this.tsDelete.Text = "Delete";
      this.tsDelete.ToolTipText = "Delete Selected Purchase Order";
      this.tsDelete.Click += new System.EventHandler(this.tsDelete_Click);
      // 
      // Orders
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(1576, 806);
      this.Controls.Add(this.txtID);
      this.Controls.Add(this.scMain);
      this.Controls.Add(this.pnlHeader);
      this.Controls.Add(this.ToolStrip1);
      this.Name = "Orders";
      this.Text = "Orders";
      this.Load += new System.EventHandler(this.Orders_Load);
      ((System.ComponentModel.ISupportInitialize)(this.dgvData)).EndInit();
      this.scData.Panel1.ResumeLayout(false);
      this.scData.Panel2.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.scData)).EndInit();
      this.scData.ResumeLayout(false);
      this.ToolStrip1.ResumeLayout(false);
      this.ToolStrip1.PerformLayout();
      this.scMain.Panel1.ResumeLayout(false);
      this.scMain.Panel1.PerformLayout();
      this.scMain.Panel2.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.scMain)).EndInit();
      this.scMain.ResumeLayout(false);
      this.Panel3.ResumeLayout(false);
      this.Panel3.PerformLayout();
      this.gbFilters.ResumeLayout(false);
      this.gbFilters.PerformLayout();
      this.pnlHeader.ResumeLayout(false);
      this.pnlHeader.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.pbHide)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.pbShow)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

		}

		#endregion

		internal System.Windows.Forms.PictureBox pbShow;
		internal System.Windows.Forms.DataGridViewTextBoxColumn chQuote;
		internal System.Windows.Forms.DataGridViewTextBoxColumn chDateRequired;
		internal System.Windows.Forms.DataGridViewTextBoxColumn chOrderDate;
		internal System.Windows.Forms.DataGridViewTextBoxColumn chSupplier;
		internal System.Windows.Forms.DataGridViewTextBoxColumn chOrder;
		internal System.Windows.Forms.Button btnReset;
		internal System.Windows.Forms.Label Label5;
		internal System.Windows.Forms.TextBox txtInternalID;
		internal System.Windows.Forms.Label Label4;
		internal System.Windows.Forms.Label Label3;
		internal System.Windows.Forms.ComboBox cmbStaff;
		internal System.Windows.Forms.Label Label1;
		internal System.Windows.Forms.TextBox txtOrder;
		internal System.Windows.Forms.DataGridView dgvData;
		internal System.Windows.Forms.DataGridViewTextBoxColumn chReference;
		internal System.Windows.Forms.DataGridViewTextBoxColumn chInstructions;
		internal System.Windows.Forms.DataGridViewTextBoxColumn chCreatedBy;
		internal System.Windows.Forms.DataGridViewTextBoxColumn chBranch;
		internal System.Windows.Forms.DataGridViewTextBoxColumn chType;
		internal System.Windows.Forms.DataGridViewTextBoxColumn chBusiness;
		internal System.Windows.Forms.DataGridViewTextBoxColumn chEmailDate;
		internal System.Windows.Forms.DataGridViewTextBoxColumn chEmailed;
		internal System.Windows.Forms.SplitContainer scData;
		internal System.Windows.Forms.DataGridViewTextBoxColumn DataGridViewTextBoxColumn13;
		internal System.Windows.Forms.DataGridViewTextBoxColumn DataGridViewTextBoxColumn11;
		internal System.Windows.Forms.DataGridViewTextBoxColumn DataGridViewTextBoxColumn10;
		internal System.Windows.Forms.DataGridViewTextBoxColumn DataGridViewTextBoxColumn9;
		internal System.Windows.Forms.DataGridViewTextBoxColumn DataGridViewTextBoxColumn8;
		internal System.Windows.Forms.DataGridViewTextBoxColumn DataGridViewTextBoxColumn7;
		internal System.Windows.Forms.DataGridViewTextBoxColumn DataGridViewTextBoxColumn6;
		internal System.Windows.Forms.DataGridViewTextBoxColumn DataGridViewTextBoxColumn5;
		internal System.Windows.Forms.DataGridViewTextBoxColumn DataGridViewTextBoxColumn4;
		internal System.Windows.Forms.DataGridViewTextBoxColumn DataGridViewTextBoxColumn3;
		internal System.Windows.Forms.DataGridViewTextBoxColumn DataGridViewTextBoxColumn2;
		internal System.Windows.Forms.DataGridViewTextBoxColumn DataGridViewTextBoxColumn1;
		internal System.Windows.Forms.ComboBox cmbType;
		internal System.Windows.Forms.ToolStripButton tsDelete;
		internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator1;
		internal System.Windows.Forms.ToolStripButton tsRefresh;
		internal System.Windows.Forms.ToolStripButton tsAdd;
		internal System.Windows.Forms.DateTimePicker dtpEndDate;
		internal System.Windows.Forms.DateTimePicker dtpStartDate;
		internal System.Windows.Forms.ToolStripButton tsClose;
		internal System.Windows.Forms.ToolStrip ToolStrip1;
		internal System.Windows.Forms.ToolStripButton tsEdit;
		internal System.Windows.Forms.Label lblHeader;
		internal System.Windows.Forms.TextBox txtID;
		internal System.Windows.Forms.PictureBox PictureBox1;
		internal System.Windows.Forms.SplitContainer scMain;
		internal System.Windows.Forms.Panel Panel3;
		internal System.Windows.Forms.Button btnFind;
		internal System.Windows.Forms.LinkLabel lnkFind;
		internal System.Windows.Forms.TextBox txtOrder1;
		internal System.Windows.Forms.Label Label2;
		internal System.Windows.Forms.PictureBox pbHide;
		internal System.Windows.Forms.GroupBox gbFilters;
		internal System.Windows.Forms.Label lblType;
		internal System.Windows.Forms.ComboBox cmbSupplier;
		internal System.Windows.Forms.Label lblStartDate;
		internal System.Windows.Forms.Label lblEndDate;
		internal System.Windows.Forms.Panel pnlHeader;
		internal System.Windows.Forms.DataGridViewTextBoxColumn DataGridViewTextBoxColumn12;
	}
}