﻿using System;
using System.Data;
using MySql.Data.MySqlClient;
using System.Linq;
using System.Net.Mail;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace workshop_orders

{

  public class DataAccess
  {
    public static bool _bMessageReturn = false;

    public enum InternalIDType
    {
      Item,
      Job,
      Quote,
      Order
    }

    public static Boolean FormState(string sName, ToolStripButton save)
    {
      if (save == null)
      {
        if  ( sName.Contains("Read Only"))
        {
          return false;
        }
        else
        {
          return true;
        }
      }

      save.Enabled = true;
      if (sName.Contains("Read Only")) { 
        save.Enabled = false;
        return false;
      }
      return true;
    }

    public static bool ValidateEmail(string sEmailAddress)
    {
      // Dim email As New Regex("^(?<user>[^@]+)@(?<host>.+)$")
      Regex email = new Regex(@"([\w-+]+(?:\.[\w-+]+)*@(?:[\w-]+\.)+[a-zA-Z]{2,7})");
      if (email.IsMatch(sEmailAddress))
        return true;
      else
        return false;
    }
    public static void AddSelect(DataTable dt)
    {//ADD SELECT VALUE TO DATATABLE
      if (dt != null)
      {
        DataRow dr = dt.NewRow();
        dr[0] = "-1";
        dr[1] = "<select>";
        dt.Rows.InsertAt(dr, 0);
      }
    }
    public static void AddSelectInt(DataTable dt)
    {//ADD SELECT VALUE TO DATATABLE
      if (dt != null)
      {
        DataRow dr = dt.NewRow();
        dr[0] = -1;
        dr[1] = "<select>";
        dt.Rows.InsertAt(dr, 0);
      }
    }

    public static void FilterPanel(bool bShow, SplitContainer scMain, SplitContainer scData)
    {
      if (bShow == false)
      {
        scMain.Panel1Collapsed = true;
        scData.Panel1Collapsed = false;
      }
      else
      {
        scMain.Panel1Collapsed = false;
        scData.Panel1Collapsed = true;
      }
    }

    public static void QuoteItemDelete(int iQuoteItemGroupID)
    {
      ExecuteNonQuery("DELETE FROM quoteitems WHERE QuoteItemGroupID = " + iQuoteItemGroupID);
      ExecuteNonQuery("DELETE FROM quoteitemgroup WHERE QuoteItemGroupID = " + iQuoteItemGroupID);
    }
    public static DataTable ExecuteDataTable(string sCommand, bool bShowError = true)
    {
      DataTable dt = new DataTable();
      try
      {
        MySqlConnection conn = new MySqlConnection(GWMS.connStr);
        MySqlDataAdapter da = new MySqlDataAdapter(sCommand, conn);
        
        try
        {
          da.Fill(dt);
        }
        catch
        {
          dt = null;
        }
        finally
        {
          if (conn.State != ConnectionState.Closed)
            conn.Close();
        }
        
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, "DataAccess", System.Reflection.MethodBase.GetCurrentMethod().Name, "");
        dt = null;
      }

      return dt;
    }
    public static DataTable GetGlassCodes(int iThickness, int iGlassType)
    {
      using (MySqlConnection conn = new MySqlConnection(GWMS.connStr))
      {
        MySqlCommand cmd = new MySqlCommand("SELECT * FROM vwitemcost WHERE ", conn);
        MySqlDataAdapter sqlDa = new MySqlDataAdapter("sp_", conn);
        DataTable dt = new DataTable();
        sqlDa.Fill(dt);
        return dt;
      }
    }
    public static void ExecuteNonQuery(string sCommand)
    {
      try
      {
        using (MySqlConnection conn = new MySqlConnection(GWMS.connStr))
        {
          conn.Open();
          MySqlCommand cmd = new MySqlCommand(sCommand, conn);
          cmd.ExecuteNonQuery();
        }
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, "DataAccess", System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }
    }

    public static int ExecuteScalarInt(string sCommand)
    {
      try
      {
        using (MySqlConnection conn = new MySqlConnection(GWMS.connStr))
        {
          conn.Open();
          MySqlCommand cmd = new MySqlCommand(sCommand, conn);
          try
          {
            return int.Parse(cmd.ExecuteScalar().ToString());
          }
          catch
          {
            return 0;
          }
        }
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, "DataAccess", System.Reflection.MethodBase.GetCurrentMethod().Name, "");
        return 0;
      }

    }
    public static decimal ExecuteScalarDec(string sCommand)
    {
      try
      {
        using (MySqlConnection conn = new MySqlConnection(GWMS.connStr))
        {
          conn.Open();
          MySqlCommand cmd = new MySqlCommand(sCommand, conn);
          return (decimal)cmd.ExecuteScalar();
        }
      }
      catch
      {
        return 0;
      }
    }
    public static string ExecuteScalarString(string sCommand)
    {
      try
      {
        using (MySqlConnection conn = new MySqlConnection(GWMS.connStr))
        {
          conn.Open();
          MySqlCommand cmd = new MySqlCommand(sCommand, conn);
          return cmd.ExecuteScalar().ToString();
        }
      }
      catch 
      {
        return "ERROR";
      }
    }
    public static MySqlParameter CreateParameter(string paramname, MySqlDbType paramtype, int paramsize, ParameterDirection paramdirection,
              object paramvalue, int paramScale = 0)

    {
      MySqlParameter myParameter = new MySqlParameter()

      {
        ParameterName = paramname,
        Value = paramvalue,
        MySqlDbType = paramtype,
        Size = paramsize,
        Direction = paramdirection
      };
      return myParameter;

    }
    public static bool QuoteManage(int iQuoteNo, string sType, string sReference, decimal dCustomerID, int iStaffID, int iWorkers, int iDistance,
                                       decimal dWorkDays, decimal dHoursPerDay, int iStatusID, string sComments, decimal dDiscount, string sQuoteLetter)
    {
      MySqlParameter[] param = new MySqlParameter[13];
      try
      {
        param[0] = CreateParameter("quoteid", MySqlDbType.Int32, 10, ParameterDirection.Input, iQuoteNo);
        param[1] = CreateParameter("type", MySqlDbType.VarChar, 20, ParameterDirection.Input, sType);
        param[2] = CreateParameter("reference", MySqlDbType.VarChar, 100, ParameterDirection.Input, sReference);
        param[3] = CreateParameter("customerid", MySqlDbType.Decimal, 10, ParameterDirection.Input, dCustomerID);
        param[4] = CreateParameter("staffid", MySqlDbType.Int32, 20, ParameterDirection.Input, iStaffID);
        param[5] = CreateParameter("workers", MySqlDbType.Int32, 10, ParameterDirection.Input, iWorkers);
        param[6] = CreateParameter("distance", MySqlDbType.Int32, 10, ParameterDirection.Input, iDistance);
        param[7] = CreateParameter("workdays", MySqlDbType.Decimal, 10, ParameterDirection.Input, dWorkDays);
        param[8] = CreateParameter("hoursperday", MySqlDbType.Decimal, 10, ParameterDirection.Input, dHoursPerDay);
        param[9] = CreateParameter("statusid", MySqlDbType.Int32, 10, ParameterDirection.Input, iStatusID);
        param[10] = CreateParameter("comments", MySqlDbType.VarChar, 1000, ParameterDirection.Input, sComments);
        param[11] = CreateParameter("discount", MySqlDbType.Decimal, 10, ParameterDirection.Input, dDiscount);
        param[12] = CreateParameter("QuoteLetterText", MySqlDbType.VarChar, 5000, ParameterDirection.Input, sQuoteLetter);

        ExecuteNonQuery(GWMS.connStr, CommandType.StoredProcedure, "sp_quotemanage", param);
        return true;
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, "DataAccess", System.Reflection.MethodBase.GetCurrentMethod().Name, "sp_quotemanage");
        return false;
      }
    }
    public static bool QuoteItemManage(int iQuoteNo, int iItemID, int iCostItemID, decimal dQuantity, decimal dSize, decimal dWidth, decimal dHeight,
                                       decimal dItemCost, decimal dItemPrice, int iGroupID, int iLinkID, string sQuoteItemType, string sDescription)
    {
      MySqlParameter[] param = new MySqlParameter[13];
      try
      {
        param[0] = CreateParameter("quoteid", MySqlDbType.Int32, 10, ParameterDirection.Input, iQuoteNo);
        param[1] = CreateParameter("itemid", MySqlDbType.Int32, 10, ParameterDirection.Input, iItemID);
        param[2] = CreateParameter("itemcostid", MySqlDbType.Int32, 10, ParameterDirection.Input, iCostItemID);
        param[3] = CreateParameter("quantity", MySqlDbType.Decimal, 10, ParameterDirection.Input, decimal.Round(dQuantity, 4));
        param[4] = CreateParameter("size", MySqlDbType.Decimal, 10, ParameterDirection.Input, decimal.Round(dSize, 4));
        param[5] = CreateParameter("width", MySqlDbType.Decimal, 10, ParameterDirection.Input, dWidth);
        param[6] = CreateParameter("height", MySqlDbType.Decimal, 10, ParameterDirection.Input, dHeight);
        param[7] = CreateParameter("quoteitemcost", MySqlDbType.Decimal, 10, ParameterDirection.Input, decimal.Round(dItemCost, 2));
        param[8] = CreateParameter("quoteitemprice", MySqlDbType.Decimal, 10, ParameterDirection.Input, decimal.Round(dItemPrice, 2));
        param[9] = CreateParameter("quoteitemgroupid", MySqlDbType.Int32, 10, ParameterDirection.Input, iGroupID);
        param[10] = CreateParameter("linkid", MySqlDbType.Int32, 10, ParameterDirection.Input, iLinkID);
        param[11] = CreateParameter("quoteitemtype", MySqlDbType.VarChar, 45, ParameterDirection.Input, sQuoteItemType);
        param[12] = CreateParameter("description", MySqlDbType.VarChar, 1000, ParameterDirection.Input, sDescription);

        ExecuteNonQuery(GWMS.connStr, CommandType.StoredProcedure, "sp_quoteitemmanage", param);
        return true;
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, "DataAccess", System.Reflection.MethodBase.GetCurrentMethod().Name, "sp_quoteitemmanage");
        return false;
      }
    }

    public static bool ItemCostManage(int iCostItemID, int iGroupItemID, string sCode, string sDescription,
                                        decimal dCost, decimal dPrice, int iUOM, int iMinQuantity, int iAllowance)
    {
      MySqlParameter[] param = new MySqlParameter[9];
      try
      {
        param[0] = CreateParameter("ItemID", MySqlDbType.Int32, 10, ParameterDirection.Input, iCostItemID);
        param[1] = CreateParameter("ItemGroupID", MySqlDbType.Int32, 10, ParameterDirection.Input, iGroupItemID);
        param[2] = CreateParameter("icCode", MySqlDbType.VarChar, 50, ParameterDirection.Input, sCode);
        param[3] = CreateParameter("icDescription", MySqlDbType.VarChar, 50, ParameterDirection.Input, sDescription);
        param[4] = CreateParameter("icCost", MySqlDbType.Decimal, 10, ParameterDirection.Input, decimal.Round(dCost, 2));
        param[5] = CreateParameter("icPrice", MySqlDbType.Decimal, 10, ParameterDirection.Input, decimal.Round(dPrice, 2));
        param[6] = CreateParameter("uom", MySqlDbType.Int32, 10, ParameterDirection.Input, iUOM);
        param[7] = CreateParameter("minQuantity", MySqlDbType.Int32, 10, ParameterDirection.Input, iMinQuantity);
        param[8] = CreateParameter("allowance", MySqlDbType.Int32, 10, ParameterDirection.Input, iAllowance);

        ExecuteNonQuery(GWMS.connStr, CommandType.StoredProcedure, "sp_itemcostmanage", param);
        return true;
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, "DataAccess", System.Reflection.MethodBase.GetCurrentMethod().Name, "sp_itemcostmanage");
        return false;
      }
    }

    public static bool QuoteCorrespondenceManage(int iCorrespondenceID, int iQuoteNo, int iCorrespondenceTypeID, DateTime dtDate,
      DateTime dtNextDate, String sDescription, String sSource, int iEmail, int iCalendar, int iStaffName, DateTime dtEmailSendDate,
      String sEmailStaffName, int iContactID)
    {
      MySqlParameter[] param = new MySqlParameter[13];
      try
      {
        param[0] = CreateParameter("CorrespondenceID", MySqlDbType.Int32, 10, ParameterDirection.Input, iCorrespondenceID);
        param[1] = CreateParameter("QuoteNo", MySqlDbType.Int32, 10, ParameterDirection.Input, iQuoteNo);
        param[2] = CreateParameter("CorrespondenceTypeID", MySqlDbType.Int32, 10, ParameterDirection.Input, iCorrespondenceTypeID);
        param[3] = CreateParameter("qcDate", MySqlDbType.DateTime, 10, ParameterDirection.Input, dtDate);
        param[4] = CreateParameter("qcNextDate", MySqlDbType.DateTime, 10, ParameterDirection.Input, dtNextDate);
        param[5] = CreateParameter("qcDescription", MySqlDbType.VarChar, 300, ParameterDirection.Input, sDescription);
        param[6] = CreateParameter("qcSource", MySqlDbType.VarChar, 50, ParameterDirection.Input, sSource);
        param[7] = CreateParameter("qcEmail", MySqlDbType.Int32, 10, ParameterDirection.Input, iEmail);
        param[8] = CreateParameter("qcCalendar", MySqlDbType.Int32, 10, ParameterDirection.Input, iCalendar);
        param[9] = CreateParameter("StaffID", MySqlDbType.Int32, 20, ParameterDirection.Input, iStaffName);
        param[10] = CreateParameter("qcEmailSendDate", MySqlDbType.DateTime, 10, ParameterDirection.Input, dtEmailSendDate);
        param[11] = CreateParameter("qcEmailStaffName", MySqlDbType.VarChar, 10, ParameterDirection.Input, sEmailStaffName);
        param[12] = CreateParameter("ContactID", MySqlDbType.Int32, 10, ParameterDirection.Input, iContactID);

        ExecuteNonQuery(GWMS.connStr, CommandType.StoredProcedure, "sp_quotecorrespondencemanage", param);
        return true;
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, "DataAccess", System.Reflection.MethodBase.GetCurrentMethod().Name, "sp_quotecorrespondencemanage");
        return false;
      }
    }

    public static bool ErrorManage(int iCode, string sMessage, string sModule, string sFunction, string sCommand)
    {
      MySqlParameter[] param = new MySqlParameter[6];
      try
      {
        param[0] = CreateParameter("errCode", MySqlDbType.Int32, 10, ParameterDirection.Input, iCode);
        param[1] = CreateParameter("errMessage", MySqlDbType.VarChar, 512, ParameterDirection.Input, sMessage);
        param[2] = CreateParameter("errModule", MySqlDbType.VarChar, 255, ParameterDirection.Input, sModule);
        param[3] = CreateParameter("errFunction", MySqlDbType.VarChar, 255, ParameterDirection.Input, sFunction);
        param[4] = CreateParameter("errCommand", MySqlDbType.VarChar, 255, ParameterDirection.Input, sCommand);
        param[5] = CreateParameter("StaffID", MySqlDbType.Int32, 20, ParameterDirection.Input, GWMS.StaffID);

        ExecuteNonQuery(GWMS.connStr, CommandType.StoredProcedure, "sp_errors", param);
        return true;
      }
      catch (Exception ex)
      {
        //DataAccess.ShowMessage(ex.Message);
        //DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, "DataAccess", System.Reflection.MethodBase.GetCurrentMethod().Name, "sp_errors");
        return false;
      }
    }

    public static bool JobManage(int iJobID, int iTypeID, int iCustomerID, int iPaymentID, int iVehicleID, int iStatusID, int iAreaID,
      int iInsuranceID, int iQuoteID, String sJobSiteAddress, DateTime dtJobBookingDate, String sJobNote, int iJobIviisNo, int iJobMilage, String sJobReference,
      String sAccountName, String sAccountNo, int iMilageRequired)
    {
      MySqlParameter[] param = new MySqlParameter[19];
      try
      {
        param[0] = CreateParameter("JobNo", MySqlDbType.Int32, 10, ParameterDirection.Input, iJobID);
        param[1] = CreateParameter("TypeID", MySqlDbType.Int32, 10, ParameterDirection.Input, iTypeID);
        param[2] = CreateParameter("CustomerID", MySqlDbType.Int32, 10, ParameterDirection.Input, iCustomerID);
        param[3] = CreateParameter("PaymentID", MySqlDbType.Int32, 10, ParameterDirection.Input, iPaymentID);
        param[4] = CreateParameter("VehicleID", MySqlDbType.Int32, 10, ParameterDirection.Input, iVehicleID);
        param[5] = CreateParameter("StaffID", MySqlDbType.Int32, 10, ParameterDirection.Input, GWMS.StaffID);
        param[6] = CreateParameter("StatusID", MySqlDbType.Int32, 10, ParameterDirection.Input, iStatusID);
        param[7] = CreateParameter("AreaID", MySqlDbType.Int32, 10, ParameterDirection.Input, iAreaID);
        param[8] = CreateParameter("InsuranceID", MySqlDbType.Int32, 10, ParameterDirection.Input, iInsuranceID);
        param[9] = CreateParameter("QuoteID", MySqlDbType.Int32, 10, ParameterDirection.Input, iQuoteID);

        param[10] = CreateParameter("JobSiteAddress", MySqlDbType.VarChar, 50, ParameterDirection.Input, sJobSiteAddress);
        param[11] = CreateParameter("JobBookingDate", MySqlDbType.DateTime, 10, ParameterDirection.Input, dtJobBookingDate);
        param[12] = CreateParameter("JobNote", MySqlDbType.VarChar, 5000, ParameterDirection.Input, sJobNote);
        param[13] = CreateParameter("JobIviisNo", MySqlDbType.Int32, 10, ParameterDirection.Input, iJobIviisNo);
        param[14] = CreateParameter("JobMilage", MySqlDbType.Int32, 10, ParameterDirection.Input, iJobMilage);
        param[15] = CreateParameter("JobReference", MySqlDbType.VarChar, 100, ParameterDirection.Input, sJobReference);
        param[16] = CreateParameter("AccountName", MySqlDbType.VarChar, 45, ParameterDirection.Input, sAccountName);
        param[17] = CreateParameter("AccountNo", MySqlDbType.VarChar, 45, ParameterDirection.Input, sAccountNo);
        param[18] = CreateParameter("MilageRequired", MySqlDbType.Int32, 10, ParameterDirection.Input, iMilageRequired);

        ExecuteNonQuery(GWMS.connStr, CommandType.StoredProcedure, "sp_jobmanage", param);
        return true;
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message,
          "DataAccess", System.Reflection.MethodBase.GetCurrentMethod().Name, "sp_jobmanage");
        return false;
      }

    }

    public static bool CustomerManage(int iCustomerID, String sCustomerName, String sSurname, int iBusiness, String sMobilePhone, String sPhone2, String sAddress,
      String sSuburb, String sCity, String sPostcode, String sEmail, String sAccountName, String sAccountNo)
    {
      MySqlParameter[] param = new MySqlParameter[13];
      try
      {
        param[0] = CreateParameter("CID", MySqlDbType.Int32, 10, ParameterDirection.Input, iCustomerID);
        param[1] = CreateParameter("CustomerName", MySqlDbType.VarChar, 150, ParameterDirection.Input, sCustomerName);
        param[2] = CreateParameter("cSurname", MySqlDbType.VarChar, 50, ParameterDirection.Input, sSurname);
        param[3] = CreateParameter("cBusiness", MySqlDbType.Int32, 10, ParameterDirection.Input, iBusiness);
        param[4] = CreateParameter("cMobilePhone", MySqlDbType.VarChar, 15, ParameterDirection.Input, sMobilePhone);
        param[5] = CreateParameter("cPhone2", MySqlDbType.VarChar, 15, ParameterDirection.Input, sPhone2);
        param[6] = CreateParameter("cAddress", MySqlDbType.VarChar, 100, ParameterDirection.Input, sAddress);
        param[7] = CreateParameter("cSuburb", MySqlDbType.VarChar, 45, ParameterDirection.Input, sSuburb);
        param[8] = CreateParameter("cCity", MySqlDbType.VarChar, 45, ParameterDirection.Input, sCity);
        param[9] = CreateParameter("cPostcode", MySqlDbType.VarChar, 6, ParameterDirection.Input, sPostcode);
        param[10] = CreateParameter("cEmail", MySqlDbType.VarChar, 100, ParameterDirection.Input, sEmail);
        param[11] = CreateParameter("cAccountName", MySqlDbType.VarChar, 45, ParameterDirection.Input, sAccountName);
        param[12] = CreateParameter("cAccountNo", MySqlDbType.VarChar, 45, ParameterDirection.Input, sAccountNo);

        ExecuteNonQuery(GWMS.connStr, CommandType.StoredProcedure, "sp_customermanage", param);
        return true;
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message,
          "DataAccess", System.Reflection.MethodBase.GetCurrentMethod().Name, "sp_customermanage");
        return false;
      }

    }

    public static bool VehicleManage(int iVehicleID, String sRegistration, String sMake, String sModel, int iYear, int iRecalibration)
    {
      MySqlParameter[] param = new MySqlParameter[6];
      try
      {
        param[0] = CreateParameter("VID", MySqlDbType.Int32, 10, ParameterDirection.Input, iVehicleID);
        param[1] = CreateParameter("vRegistration", MySqlDbType.VarChar, 10, ParameterDirection.Input, sRegistration);
        param[2] = CreateParameter("vMake", MySqlDbType.VarChar, 45, ParameterDirection.Input, sMake);
        param[3] = CreateParameter("vModel", MySqlDbType.VarChar, 45, ParameterDirection.Input, sModel);
        param[4] = CreateParameter("vYear", MySqlDbType.Int32, 10, ParameterDirection.Input, iYear);
        param[5] = CreateParameter("vRecalibration", MySqlDbType.Int32, 10, ParameterDirection.Input, iRecalibration);

        ExecuteNonQuery(GWMS.connStr, CommandType.StoredProcedure, "sp_vehiclemanage", param);
        return true;
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message,
          "DataAccess", System.Reflection.MethodBase.GetCurrentMethod().Name, "sp_vehiclemanage");
        return false;
      }
    }

    public static bool InvoiceManage(int iInvoiceID, int iJobID, int iInvoiceNo, decimal dPrice)
    {
      MySqlParameter[] param = new MySqlParameter[5];
      try
      {
        param[0] = CreateParameter("iID", MySqlDbType.Int32, 10, ParameterDirection.Input, iInvoiceID);
        param[1] = CreateParameter("JobID", MySqlDbType.Int32, 10, ParameterDirection.Input, iJobID);
        param[2] = CreateParameter("StaffID", MySqlDbType.Int32, 10, ParameterDirection.Input, GWMS.StaffID);
        param[3] = CreateParameter("invNo", MySqlDbType.Int32, 10, ParameterDirection.Input, iInvoiceNo);
        param[4] = CreateParameter("invPrice", MySqlDbType.Decimal, 10, ParameterDirection.Input, decimal.Round(dPrice, 2));

        ExecuteNonQuery(GWMS.connStr, CommandType.StoredProcedure, "sp_invoicemanage", param);
        return true;
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message,
          "DataAccess", System.Reflection.MethodBase.GetCurrentMethod().Name, "sp_invoicemanage");
        return false;
      }
    }

    public static bool JobItemManage(int iJobItemID, int iItemID, int iJobID, int iStatusID, decimal dCost, decimal dPrice, int iItemStockID)
    {
      MySqlParameter[] param = new MySqlParameter[7];
      try
      {
        param[0] = CreateParameter("jItemID", MySqlDbType.Int32, 10, ParameterDirection.Input, iJobItemID);
        param[1] = CreateParameter("ItemID", MySqlDbType.Int32, 10, ParameterDirection.Input, iItemID);
        param[2] = CreateParameter("JobID", MySqlDbType.Int32, 10, ParameterDirection.Input, iJobID);
        param[3] = CreateParameter("StatusID", MySqlDbType.Int32, 10, ParameterDirection.Input, iStatusID);
        param[4] = CreateParameter("Cost", MySqlDbType.Decimal, 10, ParameterDirection.Input, decimal.Round(dCost, 2));
        param[5] = CreateParameter("Price", MySqlDbType.Decimal, 10, ParameterDirection.Input, decimal.Round(dPrice, 2));
        param[6] = CreateParameter("ItemStockID", MySqlDbType.Int32, 10, ParameterDirection.Input, iItemStockID);

        ExecuteNonQuery(GWMS.connStr, CommandType.StoredProcedure, "sp_jobitemmanage", param);
        return true;
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message,
          "DataAccess", System.Reflection.MethodBase.GetCurrentMethod().Name, "sp_jobitemmanage");
        return false;
      }
    }

    public static bool JobItemDelete(int iJobItemID)
    {
      MySqlParameter[] param = new MySqlParameter[1];
      try
      {
        param[0] = CreateParameter("jItemID", MySqlDbType.Int32, 10, ParameterDirection.Input, iJobItemID);

        ExecuteNonQuery(GWMS.connStr, CommandType.StoredProcedure, "sp_jobitemdelete", param);
        return true;
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message,
          "DataAccess", System.Reflection.MethodBase.GetCurrentMethod().Name, "sp_jobitemdelete");
        return false;
      }
    }

    public static bool LabourManage(int iStaffID, int iJobTaskID, int iPercent, String sNote) //StaffID needs to be in this Manage method, do not remove
    {

      MySqlParameter[] param = new MySqlParameter[4];
      try
      {
        param[0] = CreateParameter("lStaffID", MySqlDbType.Int32, 10, ParameterDirection.Input, iStaffID); //Keep StaffID input param, doesnt use GWMS.StaffID
        param[1] = CreateParameter("JobTaskID", MySqlDbType.Int32, 10, ParameterDirection.Input, iJobTaskID);
        param[2] = CreateParameter("Percent", MySqlDbType.Int32, 10, ParameterDirection.Input, iPercent);
        param[3] = CreateParameter("Note", MySqlDbType.VarChar, 1000, ParameterDirection.Input, sNote);

        ExecuteNonQuery(GWMS.connStr, CommandType.StoredProcedure, "sp_labourmanage", param);
        return true;
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message,
          "DataAccess", System.Reflection.MethodBase.GetCurrentMethod().Name, "sp_labourmanage");
        return false;
      }
    }

    public static bool LabourOnsiteManage(int iStaffID, int iJobTaskID, String sMinutes, String sNote) //StaffID needs to be in this Manage method, do not remove
    {

      MySqlParameter[] param = new MySqlParameter[4];
      try
      {
        param[0] = CreateParameter("lStaffID", MySqlDbType.Int32, 10, ParameterDirection.Input, iStaffID); //Keep StaffID input param, doesnt use GWMS.StaffID
        param[1] = CreateParameter("JobTaskID", MySqlDbType.Int32, 10, ParameterDirection.Input, iJobTaskID);
        param[2] = CreateParameter("Minutes", MySqlDbType.VarChar, 6, ParameterDirection.Input, sMinutes);
        param[3] = CreateParameter("Note", MySqlDbType.VarChar, 1000, ParameterDirection.Input, sNote);

        ExecuteNonQuery(GWMS.connStr, CommandType.StoredProcedure, "sp_labouronsitemanage", param);
        return true;
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message,
          "DataAccess", System.Reflection.MethodBase.GetCurrentMethod().Name, "sp_labouronsitemanage");
        return false;
      }
    }

    public static bool StaffManage(int iStaffID, String sStaffUsername, String sStaffPassword, String sStaffFullName, String sStaffEmail,
      int iStaffActive, int iStaffAdmin, int iStaffWorkshop, decimal dStaffRate) //StaffID needs to be in this Manage method, do not remove
    {

      MySqlParameter[] param = new MySqlParameter[9];
      try
      {
        param[0] = CreateParameter("sID", MySqlDbType.Int32, 10, ParameterDirection.Input, iStaffID); //Keep StaffID input param, doesnt use GWMS.StaffID
        param[1] = CreateParameter("StaffUsername", MySqlDbType.VarChar, 20, ParameterDirection.Input, sStaffUsername);
        param[2] = CreateParameter("StaffPassword", MySqlDbType.VarChar, 512, ParameterDirection.Input, sStaffPassword);
        param[3] = CreateParameter("StaffFullName", MySqlDbType.VarChar, 45, ParameterDirection.Input, sStaffFullName);
        param[4] = CreateParameter("StaffEmail", MySqlDbType.VarChar, 100, ParameterDirection.Input, sStaffEmail);
        param[5] = CreateParameter("StaffActive", MySqlDbType.Int32, 10, ParameterDirection.Input, iStaffActive);
        param[6] = CreateParameter("StaffAdmin", MySqlDbType.Int32, 10, ParameterDirection.Input, iStaffAdmin);
        param[7] = CreateParameter("StaffWorkshop", MySqlDbType.Int32, 10, ParameterDirection.Input, iStaffWorkshop);
        param[8] = CreateParameter("StaffRate", MySqlDbType.Decimal, 10, ParameterDirection.Input, decimal.Round(dStaffRate, 2));

        ExecuteNonQuery(GWMS.connStr, CommandType.StoredProcedure, "sp_staffmanage", param);
        return true;
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message,
          "DataAccess", System.Reflection.MethodBase.GetCurrentMethod().Name, "sp_staffmanage");
        return false;
      }
    }

    public static bool ItemStockManage(int iItemStockID, int iItemID, int iLocationID, decimal dQuantity)
    {

      MySqlParameter[] param = new MySqlParameter[4];
      try
      {
        param[0] = CreateParameter("iStockID", MySqlDbType.Int32, 10, ParameterDirection.Input, iItemStockID);
        param[1] = CreateParameter("ItemID", MySqlDbType.Int32, 10, ParameterDirection.Input, iItemID);
        param[2] = CreateParameter("LocationID", MySqlDbType.Int32, 10, ParameterDirection.Input, iLocationID);
        param[3] = CreateParameter("Quantity", MySqlDbType.Decimal, 10, ParameterDirection.Input, decimal.Round(dQuantity, 0));

        ExecuteNonQuery(GWMS.connStr, CommandType.StoredProcedure, "sp_itemstockmanage", param);
        return true;
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message,
          "DataAccess", System.Reflection.MethodBase.GetCurrentMethod().Name, "sp_itemstockmanage");
        return false;
      }
    }

    public static bool LocationManage(int iLocationID, String sLocationGroup, String sLocationSubGroup, String sLocationCode, String sLocationDescription)
    {

      MySqlParameter[] param = new MySqlParameter[5];
      try
      {
        param[0] = CreateParameter("lID", MySqlDbType.Int32, 10, ParameterDirection.Input, iLocationID);
        param[1] = CreateParameter("LocationGroup", MySqlDbType.VarChar, 45, ParameterDirection.Input, sLocationGroup);
        param[2] = CreateParameter("LocationSubGroup", MySqlDbType.VarChar, 45, ParameterDirection.Input, sLocationSubGroup);
        param[3] = CreateParameter("LocationCode", MySqlDbType.VarChar, 45, ParameterDirection.Input, sLocationCode);
        param[4] = CreateParameter("LocationDescription", MySqlDbType.VarChar, 500, ParameterDirection.Input, sLocationDescription);

        ExecuteNonQuery(GWMS.connStr, CommandType.StoredProcedure, "sp_locationmanage", param);
        return true;
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message,
          "DataAccess", System.Reflection.MethodBase.GetCurrentMethod().Name, "sp_locationmanage");
        return false;
      }
    }

    public static bool ItemMovementManage(int iItemStockID, int iMovementTypeID, int iInternalID, InternalIDType sInternalIDType, decimal sImQuantity, decimal dImCost, 
                                             string sImReference, int iDestinationID)
    {

      MySqlParameter[] param = new MySqlParameter[9];
      try
      {
        param[0] = CreateParameter("ItemStockID", MySqlDbType.Int32, 10, ParameterDirection.Input, iItemStockID);
        param[1] = CreateParameter("MovementTypeID", MySqlDbType.Int32, 10, ParameterDirection.Input, iMovementTypeID);
        param[2] = CreateParameter("StaffID", MySqlDbType.Int32, 10, ParameterDirection.Input, GWMS.StaffID);
        param[3] = CreateParameter("InternalID", MySqlDbType.Int32, 10, ParameterDirection.Input, iInternalID);
        param[4] = CreateParameter("InternalIDType", MySqlDbType.VarChar, 45, ParameterDirection.Input, sInternalIDType.ToString());
        param[5] = CreateParameter("imQuantity", MySqlDbType.Decimal, 10, ParameterDirection.Input, decimal.Round(sImQuantity, 4));
        param[6] = CreateParameter("imCost", MySqlDbType.Decimal, 10, ParameterDirection.Input, decimal.Round(dImCost, 2));
        param[7] = CreateParameter("imReference", MySqlDbType.VarChar, 45, ParameterDirection.Input, sImReference);
        param[8] = CreateParameter("DestinationID", MySqlDbType.Int32, 10, ParameterDirection.Input, iDestinationID);
        
        ExecuteNonQuery(GWMS.connStr, CommandType.StoredProcedure, "sp_itemmovementmanage", param);
        return true;
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message,
          "DataAccess", System.Reflection.MethodBase.GetCurrentMethod().Name, "sp_itemmovementmanage");
        return false;
      }
    }

    public static bool MovementTypeManage(int iMovementTypeID, string sMtDescription, string sMtDirection)
    {

      MySqlParameter[] param = new MySqlParameter[3];
      try
      {
        param[0] = CreateParameter("mTypeID", MySqlDbType.Int32, 10, ParameterDirection.Input, iMovementTypeID);
        param[1] = CreateParameter("mtDescription", MySqlDbType.VarChar, 45, ParameterDirection.Input, sMtDescription);
        param[2] = CreateParameter("mtDirection", MySqlDbType.VarChar, 45, ParameterDirection.Input, sMtDirection);

        ExecuteNonQuery(GWMS.connStr, CommandType.StoredProcedure, "sp_movementtypemanage", param);
        return true;
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message,
          "DataAccess", System.Reflection.MethodBase.GetCurrentMethod().Name, "sp_movementtypemanage");
        return false;
      }
    }

    public static bool ItemStockQuantity(int iItemStockID, decimal dQuantity)
    {

      MySqlParameter[] param = new MySqlParameter[2];
      try
      {
        param[0] = CreateParameter("iStockID", MySqlDbType.Int32, 10, ParameterDirection.Input, iItemStockID);
        param[1] = CreateParameter("Quantity", MySqlDbType.Decimal, 10, ParameterDirection.Input, decimal.Round(dQuantity, 0));

        ExecuteNonQuery(GWMS.connStr, CommandType.StoredProcedure, "sp_itemstockquantity", param);
        return true;
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message,
          "DataAccess", System.Reflection.MethodBase.GetCurrentMethod().Name, "sp_itemstockquantity");
        return false;
      }
    }

    public static bool InsuranceManage(int iInsuranceID, string sInsuranceName)
    {

      MySqlParameter[] param = new MySqlParameter[2];
      try
      {
        param[0] = CreateParameter("InsurID", MySqlDbType.Int32, 10, ParameterDirection.Input, iInsuranceID);
        param[1] = CreateParameter("InsuranceName", MySqlDbType.VarChar, 45, ParameterDirection.Input, sInsuranceName);

        ExecuteNonQuery(GWMS.connStr, CommandType.StoredProcedure, "sp_insurancemanage", param);
        return true;
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message,
          "DataAccess", System.Reflection.MethodBase.GetCurrentMethod().Name, "sp_insurancemanage");
        return false;
      }
    }

    public static bool SupplierManage(int iSupplierID, String sSupplierName, String supAddress, String supAddress1, String supAddress2, String supCity, 
      int isupPostCode, String supPoBox, String supPostCentre, String supPhone, String supFax, String supMobile, String supEmail, String supContact,
      String supCode, int isupDisabled, int isupVoucher, String supAccounting)
    {

      MySqlParameter[] param = new MySqlParameter[18];
      try
      {
        param[0] = CreateParameter("sID", MySqlDbType.Int32, 10, ParameterDirection.Input, iSupplierID);
        param[1] = CreateParameter("SupplierName", MySqlDbType.VarChar, 80, ParameterDirection.Input, sSupplierName);
        param[2] = CreateParameter("supAddress", MySqlDbType.VarChar, 80, ParameterDirection.Input, supAddress);
        param[3] = CreateParameter("supAddress1", MySqlDbType.VarChar, 80, ParameterDirection.Input, supAddress1);
        param[4] = CreateParameter("supAddress2", MySqlDbType.VarChar, 80, ParameterDirection.Input, supAddress2);
        param[5] = CreateParameter("supCity", MySqlDbType.VarChar, 80, ParameterDirection.Input, supCity);
        param[6] = CreateParameter("supPostCode", MySqlDbType.Int32, 10, ParameterDirection.Input, isupPostCode);
        param[7] = CreateParameter("supPOBox", MySqlDbType.VarChar, 50, ParameterDirection.Input, supPoBox);
        param[8] = CreateParameter("supPostCentre", MySqlDbType.VarChar, 50, ParameterDirection.Input, supPostCentre);
        param[9] = CreateParameter("supPhone", MySqlDbType.VarChar, 50, ParameterDirection.Input, supPhone);
        param[10] = CreateParameter("supFax", MySqlDbType.VarChar, 50, ParameterDirection.Input, supFax);
        param[11] = CreateParameter("supMobile", MySqlDbType.VarChar, 50, ParameterDirection.Input, supMobile);
        param[12] = CreateParameter("supEmail", MySqlDbType.VarChar, 80, ParameterDirection.Input, supEmail);
        param[13] = CreateParameter("supContact", MySqlDbType.VarChar, 80, ParameterDirection.Input, supContact);
        param[14] = CreateParameter("supCode", MySqlDbType.VarChar, 80, ParameterDirection.Input, supCode);
        param[15] = CreateParameter("supDisabled", MySqlDbType.Int32, 10, ParameterDirection.Input, isupDisabled);
        param[16] = CreateParameter("supVoucher", MySqlDbType.Int32, 10, ParameterDirection.Input, isupVoucher);
        param[17] = CreateParameter("supAccounting", MySqlDbType.VarChar, 50, ParameterDirection.Input, supAccounting);

        ExecuteNonQuery(GWMS.connStr, CommandType.StoredProcedure, "sp_suppliermanage", param);
        return true;
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message,
          "DataAccess", System.Reflection.MethodBase.GetCurrentMethod().Name, "sp_suppliermanage");
        return false;
      }
    }



    public static bool DuplicateJob(int iJobID) 
    {

      MySqlParameter[] param = new MySqlParameter[2];
      try
      {
        param[0] = CreateParameter("jID", MySqlDbType.Int32, 10, ParameterDirection.Input, iJobID);
        param[1] = CreateParameter("StaffID", MySqlDbType.Int32, 10, ParameterDirection.Input, GWMS.StaffID);


        ExecuteNonQuery(GWMS.connStr, CommandType.StoredProcedure, "sp_duplicatejob", param);
        return true;
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message,
          "DataAccess", System.Reflection.MethodBase.GetCurrentMethod().Name, "sp_duplicatejob");
        return false;
      }
    }

    public static bool JobCancel(int iJobID)
    {

      MySqlParameter[] param = new MySqlParameter[1];
      try
      {
        param[0] = CreateParameter("jID", MySqlDbType.Int32, 10, ParameterDirection.Input, iJobID);



        ExecuteNonQuery(GWMS.connStr, CommandType.StoredProcedure, "sp_jobcancel", param);
        return true;
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message,
          "DataAccess", System.Reflection.MethodBase.GetCurrentMethod().Name, "sp_jobcancel");
        return false;
      }
    }

    public static object ExecuteScalar(string connectionString, CommandType commandType, string commandText, params MySqlParameter[] commandParameters)
    {
      // create & open a SqlConnection, and dispose of it after we are done.
      MySqlConnection cn = new MySqlConnection(connectionString);
      try
      {
        cn.Open();
        // call the overload that takes a connection in place of the connection string
        return ExecuteScalar(cn, commandType, commandText, commandParameters);
      }
      catch (Exception SqlEx)
      {
        throw SqlEx;
      }
      finally
      {
        cn.Dispose();
      }
    }


    public static int ExecuteNonQuery(string connectionString, CommandType commandType, string commandText, params MySqlParameter[] commandParameters)
    {
      MySqlConnection cn = new MySqlConnection(connectionString);
      try
      {
        cn.Open();
        // call the overload that takes a connection in place of the connection string
        return ExecuteNonQuery(cn, commandType, commandText, commandParameters);
      }
      catch (Exception SqlEx)
      {
        throw SqlEx;
      }
      finally
      {
        cn.Dispose();
      }
    }

    public static int ExecuteNonQuery(MySqlConnection connection, CommandType commandType, string commandText, params MySqlParameter[] commandParameters)
    {
      MySqlCommand cmd = new MySqlCommand();
      int retval;
      PrepareCommand(cmd, connection, commandType, commandText, commandParameters);
      try
      {
        // execute the command & return the results
        retval = cmd.ExecuteNonQuery();
      }
      catch (MySqlException SqlEx)
      {
        throw SqlEx;
      }
      finally
      {
        // detach the SqlParameters from the command object, so they can be used again
        cmd.Parameters.Clear();
      }
      return retval;
    }
    public static object ExecuteScalar(MySqlConnection connection, CommandType commandType, string commandText, params MySqlParameter[] commandParameters)
    {
      // create a command and prepare it for execution
      MySqlCommand cmd = new MySqlCommand();
      object retval;
      PrepareCommand(cmd, connection, commandType, commandText, commandParameters);
      // execute the command & return the results
      retval = cmd.ExecuteScalar();
      // detach the SqlParameters from the command object, so they can be used again
      cmd.Parameters.Clear();

      return retval;
    } // ExecuteScalar


    private static void PrepareCommand(MySqlCommand command, MySqlConnection connection, CommandType commandType, string commandText, MySqlParameter[] commandParameters)
    {
      // if the provided connection is not open, we will open it
      if (connection.State != ConnectionState.Open)
        connection.Open(); // associate the connection with the command
      command.Connection = connection; // set the command text (stored procedure name or SQL statement)
      command.CommandText = commandText; // if we were provided a transaction, assign it.
      command.CommandType = commandType;
      if (!(commandParameters == null))
        AttachParameters(command, commandParameters); return;
    } // PrepareCommand

    private static void AttachParameters(MySqlCommand command, MySqlParameter[] commandParameters)
    {
      foreach (MySqlParameter p in commandParameters)
      {
        command.Parameters.Add(p);
      }
    } // AttachParameters
    public static bool IsNumeric(string value)
    {
      bool bNumber;
      bNumber = value.All(char.IsNumber);
      if (bNumber == false)
      {
        decimal dNumber = 0;
        bool canConvert = decimal.TryParse(value, out dNumber);
        if (canConvert == true)
          bNumber = true;
        else
          bNumber = false;
      }
      return bNumber;
    }

    public static string SendEmail(string sFrom, string sTo, string sSubject, string sMessage, Attachment aAttachment = null/* TODO Change to default(_) if this is not a reference type */)
    {
      try
      {
        bool EMailSSL = true;
        SmtpClient smtpServer = new SmtpClient();
        MailMessage mmMessage = new MailMessage();
        smtpServer.UseDefaultCredentials = false;
        smtpServer.Credentials = new System.Net.NetworkCredential("", "");
        smtpServer.Port = 443;
        if (EMailSSL == true) { smtpServer.EnableSsl = true; } else { smtpServer.EnableSsl = false; }
        smtpServer.Host = "EmailServerName";///eMailServer;
        smtpServer.Timeout = 50000;
        mmMessage.From = new MailAddress(sFrom);
        // mmMessage.From = New MailAddress(sFrom)
        string[] sToEmail = sTo.Split(';');
        for (int i = 0; i <= sToEmail.Length - 1; i++)
          mmMessage.To.Add(sToEmail[i]);
        mmMessage.Subject = sSubject;
        mmMessage.IsBodyHtml = false;
        mmMessage.Body = sMessage;
        if (aAttachment != null)
          mmMessage.Attachments.Add(aAttachment);
        smtpServer.Send(mmMessage);
        return "";
      }
      catch (Exception ex)
      {
        return ex.Message;
      }
    }


    public static void ShowMessage(String message, String title = "")
    {
      new DisplayMessage(message, title).ShowDialog();
    }

    public static bool ShowMessage(String message, String title, bool Action)
    {
      new DisplayMessage(message, title, "").ShowDialog();
      return _bMessageReturn;
    }

    public static int OrderManage(int iOrderNo, int iSupplierID, int iInternalID, string sInternalType, int iCategoryID, int iOrderType, string sReference,
                                    string sDateRequired, string sInstructions, string sAccountNo, string sContact)
    {
      MySqlParameter[] param = new MySqlParameter[12];
      try
      {
        param[0] = CreateParameter("orderno", MySqlDbType.Int32, 10, ParameterDirection.Input, iOrderNo);
        param[1] = CreateParameter("supplierid", MySqlDbType.Int32, 10, ParameterDirection.Input, iSupplierID);
        param[2] = CreateParameter("internalid", MySqlDbType.Int32, 10, ParameterDirection.Input, iInternalID);
        param[3] = CreateParameter("internaltype", MySqlDbType.VarChar, 45, ParameterDirection.Input, sInternalType);
        param[4] = CreateParameter("staffid", MySqlDbType.Int32, 10, ParameterDirection.Input, GWMS.StaffID);
        param[5] = CreateParameter("categoryid", MySqlDbType.Int32, 10, ParameterDirection.Input, iCategoryID);
        param[6] = CreateParameter("ordtype", MySqlDbType.Int32, 10, ParameterDirection.Input, iOrderType);
        param[7] = CreateParameter("ordreference", MySqlDbType.VarChar, 100, ParameterDirection.Input, sReference);
        param[8] = CreateParameter("orddaterequired", MySqlDbType.DateTime, 10, ParameterDirection.Input, sDateRequired);
        param[9] = CreateParameter("ordinstructions", MySqlDbType.VarChar, 500, ParameterDirection.Input, sInstructions);
        param[10] = CreateParameter("ordaccountno", MySqlDbType.Int32, 10, ParameterDirection.Input, sAccountNo);
        param[11] = CreateParameter("ordcontact", MySqlDbType.VarChar, 100, ParameterDirection.Input, sContact);
        return (int)ExecuteScalar(GWMS.connStr, CommandType.StoredProcedure, "sp_ordermanage", param);
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message,
          "DataAccess", System.Reflection.MethodBase.GetCurrentMethod().Name, "sp_ordermanage");
        return -1;
      }
    }

    public static int StaffRoleManage(int iStaffID, int iRoleID, int iReadOnly, int iRemoveRole)
    {
      MySqlParameter[] param = new MySqlParameter[4];
      try
      {
        param[0] = CreateParameter("sID", MySqlDbType.Int32, 10, ParameterDirection.Input, iStaffID);
        param[1] = CreateParameter("rID", MySqlDbType.Int32, 10, ParameterDirection.Input, iRoleID);
        param[2] = CreateParameter("ReadOnly", MySqlDbType.Int32, 10, ParameterDirection.Input, iReadOnly);
        param[3] = CreateParameter("RemoveRole", MySqlDbType.Int32, 10, ParameterDirection.Input, iRemoveRole);

        return (int)ExecuteScalar(GWMS.connStr, CommandType.StoredProcedure, "sp_staffrolemanage", param);
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message,
          "DataAccess", System.Reflection.MethodBase.GetCurrentMethod().Name, "sp_staffrolemanage");
        return -1;
      }
    }

    public static void Audit(int iID, string sAction, string sField, string sOldValue, string sNewValue, string sSource)
    {
      MySqlParameter[] param = new MySqlParameter[7];
      try
      {
        param[0] = CreateParameter("JobID", MySqlDbType.Int32, 10, ParameterDirection.Input, iID);
        param[1] = CreateParameter("StaffID", MySqlDbType.Int32, 10, ParameterDirection.Input, GWMS.StaffID);
        param[2] = CreateParameter("AuditDate", MySqlDbType.DateTime, 50, ParameterDirection.Input, DateTime.Now.ToString("yyyy-MM-dd mm:hh:ss"));
        param[3] = CreateParameter("AuditAction", MySqlDbType.VarChar, 45, ParameterDirection.Input, sAction);
        param[4] = CreateParameter("AuditField", MySqlDbType.VarChar, 45, ParameterDirection.Input, sField);
        param[5] = CreateParameter("AuditOldValue", MySqlDbType.VarChar, 45, ParameterDirection.Input, sOldValue);
        param[6] = CreateParameter("AuditNewValue", MySqlDbType.VarChar, 45, ParameterDirection.Input, sNewValue);
        param[7] = CreateParameter("AuditSource", MySqlDbType.VarChar, 45, ParameterDirection.Input, sSource);

        ExecuteNonQuery(GWMS.connStr, CommandType.StoredProcedure, "sp_auditmanage", param);
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message,
          "DataAccess", System.Reflection.MethodBase.GetCurrentMethod().Name, "sp_auditmanage");
      }
    }
  }
}