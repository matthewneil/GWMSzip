﻿namespace workshop_orders
{
  partial class InsuranceEdit
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.toolStrip1 = new System.Windows.Forms.ToolStrip();
      this.tsClose = new System.Windows.Forms.ToolStripButton();
      this.tsSave = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
      this.tsActive = new System.Windows.Forms.ToolStripButton();
      this.gbItemDetails = new System.Windows.Forms.GroupBox();
      this.txtInsuranceName = new System.Windows.Forms.TextBox();
      this.label2 = new System.Windows.Forms.Label();
      this.toolStrip1.SuspendLayout();
      this.gbItemDetails.SuspendLayout();
      this.SuspendLayout();
      // 
      // toolStrip1
      // 
      this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsClose,
            this.tsSave,
            this.toolStripSeparator2,
            this.tsActive});
      this.toolStrip1.Location = new System.Drawing.Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new System.Drawing.Size(458, 39);
      this.toolStrip1.TabIndex = 14;
      this.toolStrip1.Text = "toolStrip1";
      // 
      // tsClose
      // 
      this.tsClose.Image = global::workshop_orders.Properties.Resources.back;
      this.tsClose.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsClose.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsClose.Name = "tsClose";
      this.tsClose.Size = new System.Drawing.Size(72, 36);
      this.tsClose.Text = "Close";
      this.tsClose.Click += new System.EventHandler(this.tsClose_Click);
      // 
      // tsSave
      // 
      this.tsSave.Image = global::workshop_orders.Properties.Resources.save;
      this.tsSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsSave.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsSave.Name = "tsSave";
      this.tsSave.Size = new System.Drawing.Size(67, 36);
      this.tsSave.Text = "Save";
      this.tsSave.Click += new System.EventHandler(this.tsSave_Click);
      // 
      // toolStripSeparator2
      // 
      this.toolStripSeparator2.Name = "toolStripSeparator2";
      this.toolStripSeparator2.Size = new System.Drawing.Size(6, 39);
      // 
      // tsActive
      // 
      this.tsActive.Image = global::workshop_orders.Properties.Resources.duplicate_remove32;
      this.tsActive.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsActive.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsActive.Name = "tsActive";
      this.tsActive.Size = new System.Drawing.Size(117, 36);
      this.tsActive.Text = "Set to Inactive";
      this.tsActive.Click += new System.EventHandler(this.tsActive_Click);
      // 
      // gbItemDetails
      // 
      this.gbItemDetails.Controls.Add(this.label2);
      this.gbItemDetails.Controls.Add(this.txtInsuranceName);
      this.gbItemDetails.Dock = System.Windows.Forms.DockStyle.Fill;
      this.gbItemDetails.Location = new System.Drawing.Point(0, 39);
      this.gbItemDetails.Name = "gbItemDetails";
      this.gbItemDetails.Size = new System.Drawing.Size(458, 74);
      this.gbItemDetails.TabIndex = 18;
      this.gbItemDetails.TabStop = false;
      this.gbItemDetails.Text = "Insurance Details";
      // 
      // txtInsuranceName
      // 
      this.txtInsuranceName.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtInsuranceName.Location = new System.Drawing.Point(80, 28);
      this.txtInsuranceName.MaxLength = 45;
      this.txtInsuranceName.Name = "txtInsuranceName";
      this.txtInsuranceName.Size = new System.Drawing.Size(353, 24);
      this.txtInsuranceName.TabIndex = 2;
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label2.Location = new System.Drawing.Point(26, 31);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(48, 18);
      this.label2.TabIndex = 1;
      this.label2.Text = "Name";
      // 
      // InsuranceEdit
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.ClientSize = new System.Drawing.Size(458, 113);
      this.Controls.Add(this.gbItemDetails);
      this.Controls.Add(this.toolStrip1);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
      this.Name = "InsuranceEdit";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
      this.Text = "Edit Insurance Provider";
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.gbItemDetails.ResumeLayout(false);
      this.gbItemDetails.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion
    private System.Windows.Forms.ToolStrip toolStrip1;
    private System.Windows.Forms.ToolStripButton tsClose;
    private System.Windows.Forms.ToolStripButton tsSave;
    private System.Windows.Forms.GroupBox gbItemDetails;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
    private System.Windows.Forms.ToolStripButton tsActive;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.TextBox txtInsuranceName;
  }
}