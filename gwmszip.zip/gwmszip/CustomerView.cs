﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workshop_orders
{
  public partial class CustomerView : Form
  {
    public CustomerView()
    {
      InitializeComponent();

      LoadData();
		}

    private void LoadData()
    {
      try
      {
        DataTable dt = DataAccess.ExecuteDataTable(
          String.Format("SELECT CustomerID, CustomerName, cBusiness, cMobilePhone, cPhone2, cEmail, cAddress, cCity FROM customer WHERE {0} LIKE '{1}%' {2};",
          GetSearchColumn(), txtSearch.Text, GetSearchGroup()));

        dgvCustomer.DataSource = dt;

      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
          System.Reflection.MethodBase.GetCurrentMethod().Name, "SELECT * FROM customer;");
      }
    }

    private string GetSearchColumn()
    {
      if (rbSurname.Checked) return "cSurname";
      return "CustomerName";
    }

    private string GetSearchGroup()
    {
      if (rbBusiness.Checked) return "AND cBusiness = 1";
      if (rbRegular.Checked) return "AND cBusiness = 0";
      return "";
    }

    private void cmbStatus_SelectedIndexChanged(object sender, EventArgs e)
    {
      LoadData();
    }


    private void tbClose_Click(object sender, EventArgs e)
    {
			this.Close();
    }

    private void dgvItems_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      EditItem();
    }

    private void EditItem()
    {
      if (dgvCustomer.SelectedRows.Count > 0 && dgvCustomer.SelectedRows[0].Index > -1)
      {
        //FormManagement.ShowChildForm(new ItemEdit((int)dgvItems.SelectedRows[0].Cells[0].Value));
        FormManagement.ShowChildForm(new CustomerDetail((int)dgvCustomer.SelectedRows[0].Cells[0].Value));
      }
    }

    private void tsNew_Click(object sender, EventArgs e)
    {
      ItemEdit frm = new ItemEdit(0);
      FormManagement.ShowDialogForm(frm);
    }

    private void tsRefresh_Click(object sender, EventArgs e)
    {
      LoadData();
    }

    private void tsEdit_Click(object sender, EventArgs e)
    {
      EditItem();
    }

   

    private void txtSearch_TextChanged(object sender, EventArgs e)
    {
      LoadData();
    }

    private void rbSurname_CheckedChanged(object sender, EventArgs e)
    {
      if(rbSurname.Checked) LoadData();
    }

    private void rbFirstName_CheckedChanged(object sender, EventArgs e)
    {
      if (rbFirstName.Checked) LoadData();
    }

    private void rbAll_CheckedChanged(object sender, EventArgs e)
    {
      if(rbAll.Checked)
      {
        rbSurname.Enabled = true;
        LoadData();
      }
    }

    private void rbBusiness_CheckedChanged(object sender, EventArgs e)
    {
      if (rbBusiness.Checked)
      {
        rbSurname.Enabled = false;
        if (rbSurname.Checked)
        {
          rbFirstName.Checked = true;
        }
        else
        {
          LoadData();
        }
        
      }
    }

    private void rbRegular_CheckedChanged(object sender, EventArgs e)
    {
      if (rbRegular.Checked)
      {
        rbSurname.Enabled = true;
        LoadData();
      }
    }
  }
}
