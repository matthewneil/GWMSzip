﻿using System;
using System.IO;
using System.Windows.Forms;

namespace workshop_orders
{
    partial class FormGeneration
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.previewButton = new System.Windows.Forms.Button();
            this.typeLabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.partCodeText = new System.Windows.Forms.TextBox();
            this.altCodeText = new System.Windows.Forms.TextBox();
            this.contactLabel = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.quantity = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.invoiceText = new System.Windows.Forms.TextBox();
            this.salesText = new System.Windows.Forms.TextBox();
            this.dateTime = new System.Windows.Forms.DateTimePicker();
            this.deliveryDateTime = new System.Windows.Forms.DateTimePicker();
            this.regoText = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.returnGroup = new System.Windows.Forms.GroupBox();
            this.cancelRadio = new System.Windows.Forms.RadioButton();
            this.errorRadio = new System.Windows.Forms.RadioButton();
            this.itemRadio = new System.Windows.Forms.RadioButton();
            this.otherRadio = new System.Windows.Forms.RadioButton();
            this.incorrectRadio = new System.Windows.Forms.RadioButton();
            this.otherText = new System.Windows.Forms.TextBox();
            this.qualityGroup = new System.Windows.Forms.GroupBox();
            this.rainRadio = new System.Windows.Forms.RadioButton();
            this.hardwareRadio = new System.Windows.Forms.RadioButton();
            this.delaminRadio = new System.Windows.Forms.RadioButton();
            this.shapeRadio = new System.Windows.Forms.RadioButton();
            this.tintRadio = new System.Windows.Forms.RadioButton();
            this.otherQRadio = new System.Windows.Forms.RadioButton();
            this.distortionRadio = new System.Windows.Forms.RadioButton();
            this.otherQText = new System.Windows.Forms.TextBox();
            this.creditRadio = new System.Windows.Forms.RadioButton();
            this.transitRadio = new System.Windows.Forms.RadioButton();
            this.qualityRadio = new System.Windows.Forms.RadioButton();
            this.damageGroup = new System.Windows.Forms.GroupBox();
            this.brokenRadio = new System.Windows.Forms.RadioButton();
            this.crackedRadio = new System.Windows.Forms.RadioButton();
            this.smashedRadio = new System.Windows.Forms.RadioButton();
            this.scratchedRadio = new System.Windows.Forms.RadioButton();
            this.otherTRadio = new System.Windows.Forms.RadioButton();
            this.shelledRadio = new System.Windows.Forms.RadioButton();
            this.otherTText = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            ((System.ComponentModel.ISupportInitialize)(this.quantity)).BeginInit();
            this.returnGroup.SuspendLayout();
            this.qualityGroup.SuspendLayout();
            this.damageGroup.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // previewButton
            // 
            this.previewButton.BackColor = System.Drawing.Color.White;
            this.previewButton.Location = new System.Drawing.Point(12, 12);
            this.previewButton.Name = "previewButton";
            this.previewButton.Size = new System.Drawing.Size(146, 41);
            this.previewButton.TabIndex = 6;
            this.previewButton.Text = "Email and Print";
            this.previewButton.UseVisualStyleBackColor = false;
            this.previewButton.Click += new System.EventHandler(this.previewButton_Click);
            // 
            // typeLabel
            // 
            this.typeLabel.AutoSize = true;
            this.typeLabel.Location = new System.Drawing.Point(8, 142);
            this.typeLabel.Name = "typeLabel";
            this.typeLabel.Size = new System.Drawing.Size(80, 20);
            this.typeLabel.TabIndex = 36;
            this.typeLabel.Text = "Part Type:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 207);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 20);
            this.label2.TabIndex = 37;
            this.label2.Text = "Euro Code:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 172);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(175, 20);
            this.label4.TabIndex = 39;
            this.label4.Text = "OBG Code: (Old Code):";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // partCodeText
            // 
            this.partCodeText.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.partCodeText.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.partCodeText.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.partCodeText.Location = new System.Drawing.Point(103, 205);
            this.partCodeText.Name = "partCodeText";
            this.partCodeText.Size = new System.Drawing.Size(247, 26);
            this.partCodeText.TabIndex = 2;
            // 
            // altCodeText
            // 
            this.altCodeText.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.altCodeText.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.altCodeText.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.altCodeText.Location = new System.Drawing.Point(186, 169);
            this.altCodeText.MaxLength = 6;
            this.altCodeText.Name = "altCodeText";
            this.altCodeText.Size = new System.Drawing.Size(164, 26);
            this.altCodeText.TabIndex = 4;
            this.altCodeText.TextChanged += new System.EventHandler(this.altCodeText_TextChanged);
            // 
            // contactLabel
            // 
            this.contactLabel.AutoSize = true;
            this.contactLabel.Location = new System.Drawing.Point(8, 243);
            this.contactLabel.Name = "contactLabel";
            this.contactLabel.Size = new System.Drawing.Size(115, 20);
            this.contactLabel.TabIndex = 62;
            this.contactLabel.Text = "Contact Name:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 102);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 20);
            this.label6.TabIndex = 63;
            this.label6.Text = "Date:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 317);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 20);
            this.label5.TabIndex = 64;
            this.label5.Text = "Quantity:";
            // 
            // quantity
            // 
            this.quantity.Location = new System.Drawing.Point(88, 315);
            this.quantity.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.quantity.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.quantity.Name = "quantity";
            this.quantity.Size = new System.Drawing.Size(120, 26);
            this.quantity.TabIndex = 65;
            this.quantity.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(8, 279);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(107, 20);
            this.label9.TabIndex = 66;
            this.label9.Text = "Delivery Date:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(8, 394);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(87, 20);
            this.label10.TabIndex = 67;
            this.label10.Text = "Invoice No:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(8, 359);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(121, 20);
            this.label11.TabIndex = 68;
            this.label11.Text = "Sales Order No:";
            // 
            // invoiceText
            // 
            this.invoiceText.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.invoiceText.Location = new System.Drawing.Point(135, 394);
            this.invoiceText.MaxLength = 6;
            this.invoiceText.Name = "invoiceText";
            this.invoiceText.Size = new System.Drawing.Size(157, 26);
            this.invoiceText.TabIndex = 2;
            // 
            // salesText
            // 
            this.salesText.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.salesText.Location = new System.Drawing.Point(135, 356);
            this.salesText.MaxLength = 6;
            this.salesText.Name = "salesText";
            this.salesText.Size = new System.Drawing.Size(157, 26);
            this.salesText.TabIndex = 1;
            // 
            // dateTime
            // 
            this.dateTime.Location = new System.Drawing.Point(62, 101);
            this.dateTime.Name = "dateTime";
            this.dateTime.Size = new System.Drawing.Size(288, 26);
            this.dateTime.TabIndex = 71;
            // 
            // deliveryDateTime
            // 
            this.deliveryDateTime.Location = new System.Drawing.Point(121, 276);
            this.deliveryDateTime.Name = "deliveryDateTime";
            this.deliveryDateTime.Size = new System.Drawing.Size(288, 26);
            this.deliveryDateTime.TabIndex = 72;
            // 
            // regoText
            // 
            this.regoText.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.regoText.Location = new System.Drawing.Point(683, 370);
            this.regoText.MaxLength = 6;
            this.regoText.Name = "regoText";
            this.regoText.Size = new System.Drawing.Size(127, 26);
            this.regoText.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(409, 373);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(268, 20);
            this.label1.TabIndex = 80;
            this.label1.Text = "Rego Number (If Sourcing Request):";
            // 
            // returnGroup
            // 
            this.returnGroup.Controls.Add(this.cancelRadio);
            this.returnGroup.Controls.Add(this.errorRadio);
            this.returnGroup.Controls.Add(this.itemRadio);
            this.returnGroup.Controls.Add(this.otherRadio);
            this.returnGroup.Controls.Add(this.incorrectRadio);
            this.returnGroup.Controls.Add(this.otherText);
            this.returnGroup.Location = new System.Drawing.Point(437, 69);
            this.returnGroup.Name = "returnGroup";
            this.returnGroup.Size = new System.Drawing.Size(373, 290);
            this.returnGroup.TabIndex = 81;
            this.returnGroup.TabStop = false;
            this.returnGroup.Text = "Return Reason";
            this.returnGroup.Visible = false;
            // 
            // cancelRadio
            // 
            this.cancelRadio.AutoSize = true;
            this.cancelRadio.Location = new System.Drawing.Point(22, 55);
            this.cancelRadio.Name = "cancelRadio";
            this.cancelRadio.Size = new System.Drawing.Size(187, 24);
            this.cancelRadio.TabIndex = 85;
            this.cancelRadio.TabStop = true;
            this.cancelRadio.Text = "Customer Cancellation";
            this.cancelRadio.UseVisualStyleBackColor = true;
            // 
            // errorRadio
            // 
            this.errorRadio.AutoSize = true;
            this.errorRadio.Location = new System.Drawing.Point(22, 85);
            this.errorRadio.Name = "errorRadio";
            this.errorRadio.Size = new System.Drawing.Size(116, 24);
            this.errorRadio.TabIndex = 84;
            this.errorRadio.TabStop = true;
            this.errorRadio.Text = "Picking Error";
            this.errorRadio.UseVisualStyleBackColor = true;
            // 
            // itemRadio
            // 
            this.itemRadio.AutoSize = true;
            this.itemRadio.Location = new System.Drawing.Point(22, 115);
            this.itemRadio.Name = "itemRadio";
            this.itemRadio.Size = new System.Drawing.Size(148, 24);
            this.itemRadio.TabIndex = 83;
            this.itemRadio.TabStop = true;
            this.itemRadio.Text = "Item not required";
            this.itemRadio.UseVisualStyleBackColor = true;
            // 
            // otherRadio
            // 
            this.otherRadio.AutoSize = true;
            this.otherRadio.Location = new System.Drawing.Point(22, 145);
            this.otherRadio.Name = "otherRadio";
            this.otherRadio.Size = new System.Drawing.Size(186, 24);
            this.otherRadio.TabIndex = 82;
            this.otherRadio.TabStop = true;
            this.otherRadio.Text = "Other (Please explain):";
            this.otherRadio.UseVisualStyleBackColor = true;
            this.otherRadio.CheckedChanged += new System.EventHandler(this.otherRadio_CheckedChanged);
            // 
            // incorrectRadio
            // 
            this.incorrectRadio.AutoSize = true;
            this.incorrectRadio.Location = new System.Drawing.Point(22, 25);
            this.incorrectRadio.Name = "incorrectRadio";
            this.incorrectRadio.Size = new System.Drawing.Size(288, 24);
            this.incorrectRadio.TabIndex = 80;
            this.incorrectRadio.TabStop = true;
            this.incorrectRadio.Text = "Incorrect ID - Ordered wrong Product";
            this.incorrectRadio.UseVisualStyleBackColor = true;
            // 
            // otherText
            // 
            this.otherText.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.otherText.Enabled = false;
            this.otherText.Location = new System.Drawing.Point(22, 179);
            this.otherText.MaxLength = 25;
            this.otherText.Name = "otherText";
            this.otherText.Size = new System.Drawing.Size(327, 26);
            this.otherText.TabIndex = 79;
            // 
            // qualityGroup
            // 
            this.qualityGroup.Controls.Add(this.rainRadio);
            this.qualityGroup.Controls.Add(this.hardwareRadio);
            this.qualityGroup.Controls.Add(this.delaminRadio);
            this.qualityGroup.Controls.Add(this.shapeRadio);
            this.qualityGroup.Controls.Add(this.tintRadio);
            this.qualityGroup.Controls.Add(this.otherQRadio);
            this.qualityGroup.Controls.Add(this.distortionRadio);
            this.qualityGroup.Controls.Add(this.otherQText);
            this.qualityGroup.Location = new System.Drawing.Point(437, 69);
            this.qualityGroup.Name = "qualityGroup";
            this.qualityGroup.Size = new System.Drawing.Size(373, 290);
            this.qualityGroup.TabIndex = 86;
            this.qualityGroup.TabStop = false;
            this.qualityGroup.Text = "Quality Issue";
            this.qualityGroup.Visible = false;
            // 
            // rainRadio
            // 
            this.rainRadio.AutoSize = true;
            this.rainRadio.Location = new System.Drawing.Point(24, 145);
            this.rainRadio.Name = "rainRadio";
            this.rainRadio.Size = new System.Drawing.Size(229, 24);
            this.rainRadio.TabIndex = 87;
            this.rainRadio.TabStop = true;
            this.rainRadio.Text = "Rain Sensor/Vin/Mirror Block";
            this.rainRadio.UseVisualStyleBackColor = true;
            // 
            // hardwareRadio
            // 
            this.hardwareRadio.AutoSize = true;
            this.hardwareRadio.Location = new System.Drawing.Point(24, 175);
            this.hardwareRadio.Name = "hardwareRadio";
            this.hardwareRadio.Size = new System.Drawing.Size(208, 24);
            this.hardwareRadio.TabIndex = 86;
            this.hardwareRadio.TabStop = true;
            this.hardwareRadio.Text = "Hardware/Retainer/Mould";
            this.hardwareRadio.UseVisualStyleBackColor = true;
            // 
            // delaminRadio
            // 
            this.delaminRadio.AutoSize = true;
            this.delaminRadio.Location = new System.Drawing.Point(24, 55);
            this.delaminRadio.Name = "delaminRadio";
            this.delaminRadio.Size = new System.Drawing.Size(120, 24);
            this.delaminRadio.TabIndex = 85;
            this.delaminRadio.TabStop = true;
            this.delaminRadio.Text = "Delamination";
            this.delaminRadio.UseVisualStyleBackColor = true;
            // 
            // shapeRadio
            // 
            this.shapeRadio.AutoSize = true;
            this.shapeRadio.Location = new System.Drawing.Point(24, 85);
            this.shapeRadio.Name = "shapeRadio";
            this.shapeRadio.Size = new System.Drawing.Size(158, 24);
            this.shapeRadio.TabIndex = 84;
            this.shapeRadio.TabStop = true;
            this.shapeRadio.Text = "Shape and/or Size";
            this.shapeRadio.UseVisualStyleBackColor = true;
            // 
            // tintRadio
            // 
            this.tintRadio.AutoSize = true;
            this.tintRadio.Location = new System.Drawing.Point(24, 115);
            this.tintRadio.Name = "tintRadio";
            this.tintRadio.Size = new System.Drawing.Size(145, 24);
            this.tintRadio.TabIndex = 83;
            this.tintRadio.TabStop = true;
            this.tintRadio.Text = "Tint Band/Colour";
            this.tintRadio.UseVisualStyleBackColor = true;
            // 
            // otherQRadio
            // 
            this.otherQRadio.AutoSize = true;
            this.otherQRadio.Location = new System.Drawing.Point(24, 205);
            this.otherQRadio.Name = "otherQRadio";
            this.otherQRadio.Size = new System.Drawing.Size(186, 24);
            this.otherQRadio.TabIndex = 82;
            this.otherQRadio.TabStop = true;
            this.otherQRadio.Text = "Other (Please explain):";
            this.otherQRadio.UseVisualStyleBackColor = true;
            this.otherQRadio.CheckedChanged += new System.EventHandler(this.otherQRadio_CheckedChanged);
            // 
            // distortionRadio
            // 
            this.distortionRadio.AutoSize = true;
            this.distortionRadio.Location = new System.Drawing.Point(24, 25);
            this.distortionRadio.Name = "distortionRadio";
            this.distortionRadio.Size = new System.Drawing.Size(95, 24);
            this.distortionRadio.TabIndex = 80;
            this.distortionRadio.TabStop = true;
            this.distortionRadio.Text = "Distortion";
            this.distortionRadio.UseVisualStyleBackColor = true;
            // 
            // otherQText
            // 
            this.otherQText.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.otherQText.Enabled = false;
            this.otherQText.Location = new System.Drawing.Point(24, 239);
            this.otherQText.MaxLength = 25;
            this.otherQText.Name = "otherQText";
            this.otherQText.Size = new System.Drawing.Size(327, 26);
            this.otherQText.TabIndex = 79;
            // 
            // creditRadio
            // 
            this.creditRadio.AutoSize = true;
            this.creditRadio.Location = new System.Drawing.Point(12, 69);
            this.creditRadio.Name = "creditRadio";
            this.creditRadio.Size = new System.Drawing.Size(130, 24);
            this.creditRadio.TabIndex = 86;
            this.creditRadio.TabStop = true;
            this.creditRadio.Text = "Credit Returns";
            this.creditRadio.UseVisualStyleBackColor = true;
            this.creditRadio.CheckedChanged += new System.EventHandler(this.creditRadio_CheckedChanged);
            // 
            // transitRadio
            // 
            this.transitRadio.AutoSize = true;
            this.transitRadio.Location = new System.Drawing.Point(158, 69);
            this.transitRadio.Name = "transitRadio";
            this.transitRadio.Size = new System.Drawing.Size(118, 24);
            this.transitRadio.TabIndex = 87;
            this.transitRadio.TabStop = true;
            this.transitRadio.Text = "Transit Claim";
            this.transitRadio.UseVisualStyleBackColor = true;
            this.transitRadio.CheckedChanged += new System.EventHandler(this.transitRadio_CheckedChanged);
            // 
            // qualityRadio
            // 
            this.qualityRadio.AutoSize = true;
            this.qualityRadio.Location = new System.Drawing.Point(291, 69);
            this.qualityRadio.Name = "qualityRadio";
            this.qualityRadio.Size = new System.Drawing.Size(118, 24);
            this.qualityRadio.TabIndex = 88;
            this.qualityRadio.TabStop = true;
            this.qualityRadio.Text = "Quality Claim";
            this.qualityRadio.UseVisualStyleBackColor = true;
            this.qualityRadio.CheckedChanged += new System.EventHandler(this.qualityRadio_CheckedChanged);
            // 
            // damageGroup
            // 
            this.damageGroup.Controls.Add(this.brokenRadio);
            this.damageGroup.Controls.Add(this.crackedRadio);
            this.damageGroup.Controls.Add(this.smashedRadio);
            this.damageGroup.Controls.Add(this.scratchedRadio);
            this.damageGroup.Controls.Add(this.otherTRadio);
            this.damageGroup.Controls.Add(this.shelledRadio);
            this.damageGroup.Controls.Add(this.otherTText);
            this.damageGroup.Location = new System.Drawing.Point(437, 69);
            this.damageGroup.Name = "damageGroup";
            this.damageGroup.Size = new System.Drawing.Size(373, 290);
            this.damageGroup.TabIndex = 88;
            this.damageGroup.TabStop = false;
            this.damageGroup.Text = "Damage Reason";
            this.damageGroup.Visible = false;
            this.damageGroup.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // brokenRadio
            // 
            this.brokenRadio.AutoSize = true;
            this.brokenRadio.Location = new System.Drawing.Point(24, 145);
            this.brokenRadio.Name = "brokenRadio";
            this.brokenRadio.Size = new System.Drawing.Size(330, 24);
            this.brokenRadio.TabIndex = 87;
            this.brokenRadio.TabStop = true;
            this.brokenRadio.Text = "Broken features (R/S, Mirror Block, Heater)";
            this.brokenRadio.UseVisualStyleBackColor = true;
            // 
            // crackedRadio
            // 
            this.crackedRadio.AutoSize = true;
            this.crackedRadio.Location = new System.Drawing.Point(24, 55);
            this.crackedRadio.Name = "crackedRadio";
            this.crackedRadio.Size = new System.Drawing.Size(86, 24);
            this.crackedRadio.TabIndex = 85;
            this.crackedRadio.TabStop = true;
            this.crackedRadio.Text = "Cracked";
            this.crackedRadio.UseVisualStyleBackColor = true;
            // 
            // smashedRadio
            // 
            this.smashedRadio.AutoSize = true;
            this.smashedRadio.Location = new System.Drawing.Point(24, 85);
            this.smashedRadio.Name = "smashedRadio";
            this.smashedRadio.Size = new System.Drawing.Size(95, 24);
            this.smashedRadio.TabIndex = 84;
            this.smashedRadio.TabStop = true;
            this.smashedRadio.Text = "Smashed";
            this.smashedRadio.UseVisualStyleBackColor = true;
            // 
            // scratchedRadio
            // 
            this.scratchedRadio.AutoSize = true;
            this.scratchedRadio.Location = new System.Drawing.Point(24, 115);
            this.scratchedRadio.Name = "scratchedRadio";
            this.scratchedRadio.Size = new System.Drawing.Size(100, 24);
            this.scratchedRadio.TabIndex = 83;
            this.scratchedRadio.TabStop = true;
            this.scratchedRadio.Text = "Scratched";
            this.scratchedRadio.UseVisualStyleBackColor = true;
            // 
            // otherTRadio
            // 
            this.otherTRadio.AutoSize = true;
            this.otherTRadio.Location = new System.Drawing.Point(24, 175);
            this.otherTRadio.Name = "otherTRadio";
            this.otherTRadio.Size = new System.Drawing.Size(186, 24);
            this.otherTRadio.TabIndex = 82;
            this.otherTRadio.TabStop = true;
            this.otherTRadio.Text = "Other (Please explain):";
            this.otherTRadio.UseVisualStyleBackColor = true;
            this.otherTRadio.CheckedChanged += new System.EventHandler(this.otherTRadio_CheckedChanged);
            // 
            // shelledRadio
            // 
            this.shelledRadio.AutoSize = true;
            this.shelledRadio.Location = new System.Drawing.Point(24, 25);
            this.shelledRadio.Name = "shelledRadio";
            this.shelledRadio.Size = new System.Drawing.Size(80, 24);
            this.shelledRadio.TabIndex = 80;
            this.shelledRadio.TabStop = true;
            this.shelledRadio.Text = "Shelled";
            this.shelledRadio.UseVisualStyleBackColor = true;
            // 
            // otherTText
            // 
            this.otherTText.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.otherTText.Enabled = false;
            this.otherTText.Location = new System.Drawing.Point(22, 203);
            this.otherTText.MaxLength = 25;
            this.otherTText.Name = "otherTText";
            this.otherTText.Size = new System.Drawing.Size(327, 26);
            this.otherTText.TabIndex = 79;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(12, 441);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(978, 408);
            this.pictureBox1.TabIndex = 89;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            this.pictureBox1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseClick);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(164, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(143, 41);
            this.button1.TabIndex = 90;
            this.button1.Text = "Clear Drawing";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox1.Location = new System.Drawing.Point(683, 406);
            this.textBox1.MaxLength = 6;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(127, 26);
            this.textBox1.TabIndex = 91;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(545, 406);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(132, 20);
            this.label3.TabIndex = 92;
            this.label3.Text = "Price (Excl. GST):";
            // 
            // printDocument1
            // 
            this.printDocument1.DocumentName = "";
            this.printDocument1.OriginAtMargins = true;
            // 
            // FormGeneration
            // 
            this.AcceptButton = this.previewButton;
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1003, 864);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.damageGroup);
            this.Controls.Add(this.qualityRadio);
            this.Controls.Add(this.transitRadio);
            this.Controls.Add(this.qualityGroup);
            this.Controls.Add(this.creditRadio);
            this.Controls.Add(this.returnGroup);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.regoText);
            this.Controls.Add(this.deliveryDateTime);
            this.Controls.Add(this.dateTime);
            this.Controls.Add(this.salesText);
            this.Controls.Add(this.invoiceText);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.quantity);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.contactLabel);
            this.Controls.Add(this.altCodeText);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.typeLabel);
            this.Controls.Add(this.partCodeText);
            this.Controls.Add(this.previewButton);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.MaximizeBox = false;
            this.Name = "FormGeneration";
            this.Text = "BMS - Credit Returns Form";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Resize += new System.EventHandler(this.ViewJobForm_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.quantity)).EndInit();
            this.returnGroup.ResumeLayout(false);
            this.returnGroup.PerformLayout();
            this.qualityGroup.ResumeLayout(false);
            this.qualityGroup.PerformLayout();
            this.damageGroup.ResumeLayout(false);
            this.damageGroup.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Button previewButton;
        private Label typeLabel;
        private Label label2;
        private Label label4;
        private TextBox partCodeText;
        private TextBox altCodeText;
        private Label contactLabel;
        private Label label6;
        private Label label5;
        private NumericUpDown quantity;
        private Label label9;
        private Label label10;
        private Label label11;
        private TextBox invoiceText;
        private TextBox salesText;
        private DateTimePicker dateTime;
        private DateTimePicker deliveryDateTime;
        private TextBox regoText;
        private Label label1;
        private GroupBox returnGroup;
        private RadioButton cancelRadio;
        private RadioButton errorRadio;
        private RadioButton itemRadio;
        private RadioButton otherRadio;
        private RadioButton incorrectRadio;
        private TextBox otherText;
        private GroupBox qualityGroup;
        private RadioButton delaminRadio;
        private RadioButton shapeRadio;
        private RadioButton tintRadio;
        private RadioButton otherQRadio;
        private RadioButton distortionRadio;
        private TextBox otherQText;
        private RadioButton rainRadio;
        private RadioButton hardwareRadio;
        private RadioButton creditRadio;
        private RadioButton transitRadio;
        private RadioButton qualityRadio;
        private GroupBox damageGroup;
        private RadioButton brokenRadio;
        private RadioButton crackedRadio;
        private RadioButton smashedRadio;
        private RadioButton scratchedRadio;
        private RadioButton otherTRadio;
        private RadioButton shelledRadio;
        private TextBox otherTText;
        private PictureBox pictureBox1;
        private Button button1;
        private TextBox textBox1;
        private Label label3;
        private System.Drawing.Printing.PrintDocument printDocument1;
    }
}

