-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: localhost    Database: gwms
-- ------------------------------------------------------
-- Server version	8.0.25

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `quotecorrespondence`
--

DROP TABLE IF EXISTS `quotecorrespondence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quotecorrespondence` (
  `QuoteCorrespondenceID` int NOT NULL AUTO_INCREMENT,
  `QuoteNo` int NOT NULL,
  `CorrespondenceTypeID` int NOT NULL,
  `qcDate` datetime NOT NULL,
  `qcNextDate` datetime NOT NULL,
  `qcDescription` varchar(300) NOT NULL,
  `qcSource` varchar(50) NOT NULL,
  `qcEmail` int NOT NULL,
  `qcCalendar` int NOT NULL,
  `StaffID` int NOT NULL,
  `qcEmailSendDate` datetime DEFAULT NULL,
  `qcEmailStaffID` int DEFAULT NULL,
  `ContactID` int DEFAULT NULL,
  PRIMARY KEY (`QuoteCorrespondenceID`),
  UNIQUE KEY `QuoteCorrespondenceID_UNIQUE` (`QuoteCorrespondenceID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotecorrespondence`
--

LOCK TABLES `quotecorrespondence` WRITE;
/*!40000 ALTER TABLE `quotecorrespondence` DISABLE KEYS */;
INSERT INTO `quotecorrespondence` VALUES (1,1000,1,'2022-01-28 14:20:29','2022-01-28 14:20:26','','',0,0,1,'2022-01-28 14:20:29',0,0),(2,1000,1,'2022-01-28 14:38:14','2022-02-09 14:37:46','Message','',0,0,1,'2022-01-28 14:38:14',0,0),(3,1000,1,'2022-01-28 14:40:11','2022-01-28 14:40:08','test','',0,0,1,'2022-01-28 14:40:11',0,0),(4,1000,1,'2022-01-28 14:52:23','2022-01-28 14:52:12','','',0,0,1,'2022-01-28 14:52:23',0,0),(5,1000,2,'2022-01-28 14:57:05','2022-01-28 14:56:45','ytr','',0,0,1,'2022-01-28 14:57:05',0,0),(6,1000,3,'2022-01-28 15:31:32','2022-02-02 15:30:55','testtt','',0,0,1,'2022-01-28 15:31:32',0,0),(7,1004,1,'2022-01-31 11:46:44','2022-02-14 11:46:15','','',0,0,1,'2022-01-31 11:46:44',0,0);
/*!40000 ALTER TABLE `quotecorrespondence` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-18 16:31:40
