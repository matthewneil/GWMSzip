﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workshop_orders
{
  public partial class JobAllocate : Form
  {
    private int JobID = -1;
    public JobAllocate(int JobID, int TimeLeft, int TravelTime, int Distance) //Adding New Job to list
    {
      InitializeComponent();
      this.JobID = JobID;
      LoadJobDetails();
      if(TimeLeft >= 0)
      {
        nudJobTime.Maximum = TimeLeft;
      }
      else
      {
        this.Close();
      }

      nudTravelTime.Value = TravelTime;
      nudDistance.Value = Distance;
    }

    public JobAllocate(int JobID, int TimeLeft, int TravelTime, int Distance, int TimeAllocated, bool Completed, string note) //For editing job that has already been added
    {
      InitializeComponent();
      this.JobID = JobID;
      LoadJobDetails();
      if (TimeLeft >= 0)
      {
        nudJobTime.Maximum = TimeAllocated + TimeLeft; //Limit on NUD is the time already allocated plus the time left to be allocated.
      }
      else
      {
        this.Close();
      }

      nudJobTime.Value = TimeAllocated;

      rbYes.Checked = Completed; //Checks Yes box if completed value is true
      rbNo.Checked = !Completed; //Checks No Box if completed value is false

      txtNote.Text = note;

      //Don't want to close out of the form if editing. Only save and close available
      tsBack.Enabled = false;
      btnCancel.Visible = false;

      btnContinue.Text = "Update";
      tsContinue.Text = "Update";

      nudTravelTime.Value = TravelTime;
      nudDistance.Value = Distance;
    }

    public void LoadJobDetails()
    {
      DataTable dt = DataAccess.ExecuteDataTable("SELECT TypeName, CustomerName, cMobilePhone, Vehicle, AreaName, JobSiteAddress, JobBookingDateBlank, Payment, JobReference, JobNote  " +
        "FROM vwJob WHERE JobID = " + JobID);


      if (dt != null && dt.Rows.Count > 0)
      {
        lblJobID.Text = "Job: " + JobID + " - " + dt.Rows[0]["TypeName"].ToString();

        txtCustomer.Text = dt.Rows[0]["CustomerName"].ToString();
        txtReference.Text = dt.Rows[0]["JobReference"].ToString();

        txtPayment.Text = dt.Rows[0]["Payment"].ToString();
        txtVehicle.Text = dt.Rows[0]["Vehicle"].ToString();

        txtArea.Text = dt.Rows[0]["AreaName"].ToString();
        txtAddress.Text = dt.Rows[0]["JobSiteAddress"].ToString();

        String bookdate = "(No Booking)";
        if(dt.Rows[0]["JobBookingDateBlank"].ToString() != "")
        {
          bookdate = DateTime.Parse(dt.Rows[0]["JobBookingDateBlank"].ToString()).ToString("dd MMM yyyy hh:mm tt");
        }
        txtBooking.Text = bookdate;

        txtJobNote.Text = dt.Rows[0]["JobNote"].ToString();

      }
    }

    private void btnContinue_Click(object sender, EventArgs e)
    {
      Continue();
    }

    public void Continue()
    {
      if (nudJobTime.Value < 1)
      {
        DataAccess.ShowMessage("Before continuing, you'll need to allocate time to this job.");
        return;
      }

      if(nudTravelTime.Value > 0 && nudDistance.Value == 0)
      {
        DataAccess.ShowMessage("You cannot allocate Travel without any Distance.");
        return;
      }

      if (nudTravelTime.Value == 0 && nudDistance.Value > 0)
      {
        DataAccess.ShowMessage("You cannot allocate Distance without any Travel.");
        return;
      }

      if (!rbYes.Checked && !rbNo.Checked)
      {
        DataAccess.ShowMessage("Please specify if the Job is completed or not.\nIf anyone else still needs to add their time to the Job, please select NO.");
        return;
      }
      Onsite.time = (int)nudJobTime.Value;
      Onsite.complete = rbYes.Checked;
      Onsite.note = txtNote.Text;
      Onsite.travel = (int)nudTravelTime.Value;
      Onsite.distance = (int)nudDistance.Value;
      this.Close();
    }

    private void btnCancel_Click(object sender, EventArgs e)
    {
      Onsite.time = -1;
      this.Close();
    }

    private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
    {

    }

    private void tsBack_Click(object sender, EventArgs e)
    {
      Onsite.time = -1;
      this.Close();
    }

    private void tsContinue_Click(object sender, EventArgs e)
    {
      Continue();
    }

    private void toolStrip1_ItemClicked_1(object sender, ToolStripItemClickedEventArgs e)
    {

    }

    private void panel2_Paint(object sender, PaintEventArgs e)
    {

    }
  }
}
