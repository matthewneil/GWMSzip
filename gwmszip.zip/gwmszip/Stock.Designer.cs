﻿namespace workshop_orders
{
  partial class Stock
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
      this.dgvItems = new System.Windows.Forms.DataGridView();
      this.toolStrip1 = new System.Windows.Forms.ToolStrip();
      this.tsClose = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
      this.tsNew = new System.Windows.Forms.ToolStripButton();
      this.tsEdit = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
      this.tsRefresh = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
      this.tsAllStock = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
      this.tsNotOrdered = new System.Windows.Forms.ToolStripButton();
      this.tsOnOrder = new System.Windows.Forms.ToolStripButton();
      this.tsReservations = new System.Windows.Forms.ToolStripButton();
      this.tsReturns = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
      this.tsLocations = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
      this.lblSection = new System.Windows.Forms.ToolStripLabel();
      this.pnlFilter = new System.Windows.Forms.Panel();
      this.Panel3 = new System.Windows.Forms.Panel();
      this.btnQuote = new System.Windows.Forms.Button();
      this.btnCode = new System.Windows.Forms.Button();
      this.txtCode = new System.Windows.Forms.TextBox();
      this.lnkFind = new System.Windows.Forms.LinkLabel();
      this.gbFilter = new System.Windows.Forms.GroupBox();
      this.chkInStock = new System.Windows.Forms.CheckBox();
      this.rbAuto = new System.Windows.Forms.RadioButton();
      this.rbGlass = new System.Windows.Forms.RadioButton();
      this.rbAll = new System.Windows.Forms.RadioButton();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.txtSearch = new System.Windows.Forms.TextBox();
      this.rbCode = new System.Windows.Forms.RadioButton();
      this.rbDescription = new System.Windows.Forms.RadioButton();
      this.chkLimit = new System.Windows.Forms.CheckBox();
      this.cmbType = new System.Windows.Forms.ComboBox();
      this.label40 = new System.Windows.Forms.Label();
      this.pnlData = new System.Windows.Forms.Panel();
      this.chItemID = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chItemMovementID = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chGroupID = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.stockID = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chJobItemID = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chJobID = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chAltCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chUOM = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chLocation = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.subgroup = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chJobBtn = new System.Windows.Forms.DataGridViewLinkColumn();
      this.chActionBtn = new System.Windows.Forms.DataGridViewLinkColumn();
      this.chRemoveBtn = new System.Windows.Forms.DataGridViewLinkColumn();
      ((System.ComponentModel.ISupportInitialize)(this.dgvItems)).BeginInit();
      this.toolStrip1.SuspendLayout();
      this.pnlFilter.SuspendLayout();
      this.Panel3.SuspendLayout();
      this.gbFilter.SuspendLayout();
      this.groupBox1.SuspendLayout();
      this.pnlData.SuspendLayout();
      this.SuspendLayout();
      // 
      // dgvItems
      // 
      this.dgvItems.AllowUserToAddRows = false;
      this.dgvItems.AllowUserToDeleteRows = false;
      dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
      this.dgvItems.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
      this.dgvItems.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
      dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
      dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
      dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
      dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
      dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
      this.dgvItems.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
      this.dgvItems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvItems.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.chItemID,
            this.chItemMovementID,
            this.chGroupID,
            this.stockID,
            this.chJobItemID,
            this.chJobID,
            this.chAltCode,
            this.chCode,
            this.chDescription,
            this.chQuantity,
            this.chCost,
            this.chPrice,
            this.chUOM,
            this.chLocation,
            this.subgroup,
            this.chJobBtn,
            this.chActionBtn,
            this.chRemoveBtn});
      dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
      dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Window;
      dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.ControlText;
      dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
      dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
      dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
      this.dgvItems.DefaultCellStyle = dataGridViewCellStyle9;
      this.dgvItems.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dgvItems.Location = new System.Drawing.Point(0, 0);
      this.dgvItems.Name = "dgvItems";
      this.dgvItems.RowHeadersWidth = 20;
      dataGridViewCellStyle10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.dgvItems.RowsDefaultCellStyle = dataGridViewCellStyle10;
      this.dgvItems.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
      this.dgvItems.Size = new System.Drawing.Size(1585, 768);
      this.dgvItems.TabIndex = 0;
      this.dgvItems.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvItems_CellContentClick);
      this.dgvItems.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvItems_CellDoubleClick);
      // 
      // toolStrip1
      // 
      this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsClose,
            this.toolStripSeparator2,
            this.tsNew,
            this.tsEdit,
            this.toolStripSeparator3,
            this.tsRefresh,
            this.toolStripSeparator4,
            this.tsAllStock,
            this.toolStripSeparator1,
            this.tsNotOrdered,
            this.tsOnOrder,
            this.tsReservations,
            this.tsReturns,
            this.toolStripSeparator5,
            this.tsLocations,
            this.toolStripSeparator6,
            this.lblSection});
      this.toolStrip1.Location = new System.Drawing.Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new System.Drawing.Size(1822, 39);
      this.toolStrip1.TabIndex = 1;
      this.toolStrip1.Text = "toolStrip1";
      // 
      // tsClose
      // 
      this.tsClose.Image = global::workshop_orders.Properties.Resources.back;
      this.tsClose.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsClose.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsClose.Name = "tsClose";
      this.tsClose.Size = new System.Drawing.Size(72, 36);
      this.tsClose.Text = "Close";
      this.tsClose.Click += new System.EventHandler(this.tbClose_Click);
      // 
      // toolStripSeparator2
      // 
      this.toolStripSeparator2.Name = "toolStripSeparator2";
      this.toolStripSeparator2.Size = new System.Drawing.Size(6, 39);
      // 
      // tsNew
      // 
      this.tsNew.Image = global::workshop_orders.Properties.Resources.addnew;
      this.tsNew.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsNew.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsNew.Name = "tsNew";
      this.tsNew.Size = new System.Drawing.Size(67, 36);
      this.tsNew.Text = "New";
      this.tsNew.Click += new System.EventHandler(this.tsNew_Click);
      // 
      // tsEdit
      // 
      this.tsEdit.Image = global::workshop_orders.Properties.Resources.edit;
      this.tsEdit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsEdit.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsEdit.Name = "tsEdit";
      this.tsEdit.Size = new System.Drawing.Size(63, 36);
      this.tsEdit.Text = "Edit";
      this.tsEdit.Click += new System.EventHandler(this.tsEdit_Click);
      // 
      // toolStripSeparator3
      // 
      this.toolStripSeparator3.Name = "toolStripSeparator3";
      this.toolStripSeparator3.Size = new System.Drawing.Size(6, 39);
      // 
      // tsRefresh
      // 
      this.tsRefresh.Image = global::workshop_orders.Properties.Resources.refresh;
      this.tsRefresh.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsRefresh.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsRefresh.Name = "tsRefresh";
      this.tsRefresh.Size = new System.Drawing.Size(82, 36);
      this.tsRefresh.Text = "Refresh";
      this.tsRefresh.Click += new System.EventHandler(this.tsRefresh_Click);
      // 
      // toolStripSeparator4
      // 
      this.toolStripSeparator4.Name = "toolStripSeparator4";
      this.toolStripSeparator4.Size = new System.Drawing.Size(6, 39);
      // 
      // tsAllStock
      // 
      this.tsAllStock.Image = global::workshop_orders.Properties.Resources.item321;
      this.tsAllStock.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsAllStock.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsAllStock.Name = "tsAllStock";
      this.tsAllStock.Size = new System.Drawing.Size(89, 36);
      this.tsAllStock.Text = "All Stock";
      this.tsAllStock.Click += new System.EventHandler(this.tsAllStock_Click);
      // 
      // toolStripSeparator1
      // 
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
      // 
      // tsNotOrdered
      // 
      this.tsNotOrdered.Image = global::workshop_orders.Properties.Resources.orders_321;
      this.tsNotOrdered.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsNotOrdered.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsNotOrdered.Name = "tsNotOrdered";
      this.tsNotOrdered.Size = new System.Drawing.Size(126, 36);
      this.tsNotOrdered.Text = "Not Ordered (0)";
      this.tsNotOrdered.Click += new System.EventHandler(this.tsReturns_Click);
      // 
      // tsOnOrder
      // 
      this.tsOnOrder.Image = global::workshop_orders.Properties.Resources.orders32;
      this.tsOnOrder.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsOnOrder.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsOnOrder.Name = "tsOnOrder";
      this.tsOnOrder.Size = new System.Drawing.Size(109, 36);
      this.tsOnOrder.Text = "On Order (0)";
      this.tsOnOrder.Click += new System.EventHandler(this.tsOnorder_Click);
      // 
      // tsReservations
      // 
      this.tsReservations.Image = global::workshop_orders.Properties.Resources.item32;
      this.tsReservations.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsReservations.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsReservations.Name = "tsReservations";
      this.tsReservations.Size = new System.Drawing.Size(126, 36);
      this.tsReservations.Text = "Reservations (0)";
      this.tsReservations.Click += new System.EventHandler(this.tsReservations_Click);
      // 
      // tsReturns
      // 
      this.tsReturns.Image = global::workshop_orders.Properties.Resources.reassign32;
      this.tsReturns.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsReturns.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsReturns.Name = "tsReturns";
      this.tsReturns.Size = new System.Drawing.Size(100, 36);
      this.tsReturns.Text = "Returns (0)";
      this.tsReturns.Click += new System.EventHandler(this.tsReturns_Click_1);
      // 
      // toolStripSeparator5
      // 
      this.toolStripSeparator5.Name = "toolStripSeparator5";
      this.toolStripSeparator5.Size = new System.Drawing.Size(6, 39);
      // 
      // tsLocations
      // 
      this.tsLocations.Image = global::workshop_orders.Properties.Resources.supplier32;
      this.tsLocations.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsLocations.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsLocations.Name = "tsLocations";
      this.tsLocations.Size = new System.Drawing.Size(94, 36);
      this.tsLocations.Text = "Locations";
      this.tsLocations.Click += new System.EventHandler(this.tsLocations_Click);
      // 
      // toolStripSeparator6
      // 
      this.toolStripSeparator6.Name = "toolStripSeparator6";
      this.toolStripSeparator6.Size = new System.Drawing.Size(6, 39);
      // 
      // lblSection
      // 
      this.lblSection.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
      this.lblSection.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblSection.Name = "lblSection";
      this.lblSection.Size = new System.Drawing.Size(70, 36);
      this.lblSection.Text = "All Stock";
      this.lblSection.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // pnlFilter
      // 
      this.pnlFilter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(210)))));
      this.pnlFilter.Controls.Add(this.Panel3);
      this.pnlFilter.Controls.Add(this.gbFilter);
      this.pnlFilter.Dock = System.Windows.Forms.DockStyle.Left;
      this.pnlFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.pnlFilter.Location = new System.Drawing.Point(0, 39);
      this.pnlFilter.Name = "pnlFilter";
      this.pnlFilter.Size = new System.Drawing.Size(237, 768);
      this.pnlFilter.TabIndex = 6;
      // 
      // Panel3
      // 
      this.Panel3.BackColor = System.Drawing.Color.White;
      this.Panel3.Controls.Add(this.btnQuote);
      this.Panel3.Controls.Add(this.btnCode);
      this.Panel3.Controls.Add(this.txtCode);
      this.Panel3.Controls.Add(this.lnkFind);
      this.Panel3.Location = new System.Drawing.Point(18, 316);
      this.Panel3.Name = "Panel3";
      this.Panel3.Size = new System.Drawing.Size(205, 58);
      this.Panel3.TabIndex = 84;
      this.Panel3.Visible = false;
      // 
      // btnQuote
      // 
      this.btnQuote.Location = new System.Drawing.Point(173, 29);
      this.btnQuote.Name = "btnQuote";
      this.btnQuote.Size = new System.Drawing.Size(10, 20);
      this.btnQuote.TabIndex = 73;
      this.btnQuote.Text = "..";
      this.btnQuote.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      this.btnQuote.UseVisualStyleBackColor = true;
      // 
      // btnCode
      // 
      this.btnCode.BackColor = System.Drawing.Color.Transparent;
      this.btnCode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
      this.btnCode.Image = global::workshop_orders.Properties.Resources.find;
      this.btnCode.Location = new System.Drawing.Point(5, 5);
      this.btnCode.Name = "btnCode";
      this.btnCode.Size = new System.Drawing.Size(48, 48);
      this.btnCode.TabIndex = 0;
      this.btnCode.UseVisualStyleBackColor = false;
      this.btnCode.Click += new System.EventHandler(this.btnCode_Click);
      // 
      // txtCode
      // 
      this.txtCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtCode.Location = new System.Drawing.Point(59, 28);
      this.txtCode.Name = "txtCode";
      this.txtCode.Size = new System.Drawing.Size(108, 23);
      this.txtCode.TabIndex = 72;
      // 
      // lnkFind
      // 
      this.lnkFind.AutoSize = true;
      this.lnkFind.DisabledLinkColor = System.Drawing.Color.White;
      this.lnkFind.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lnkFind.LinkColor = System.Drawing.Color.Black;
      this.lnkFind.Location = new System.Drawing.Point(59, 10);
      this.lnkFind.Name = "lnkFind";
      this.lnkFind.Size = new System.Drawing.Size(69, 16);
      this.lnkFind.TabIndex = 65;
      this.lnkFind.TabStop = true;
      this.lnkFind.Text = "Find Code";
      // 
      // gbFilter
      // 
      this.gbFilter.Controls.Add(this.chkInStock);
      this.gbFilter.Controls.Add(this.rbAuto);
      this.gbFilter.Controls.Add(this.rbGlass);
      this.gbFilter.Controls.Add(this.rbAll);
      this.gbFilter.Controls.Add(this.groupBox1);
      this.gbFilter.Controls.Add(this.chkLimit);
      this.gbFilter.Controls.Add(this.cmbType);
      this.gbFilter.Controls.Add(this.label40);
      this.gbFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbFilter.ForeColor = System.Drawing.Color.White;
      this.gbFilter.Location = new System.Drawing.Point(7, 10);
      this.gbFilter.Name = "gbFilter";
      this.gbFilter.Size = new System.Drawing.Size(222, 300);
      this.gbFilter.TabIndex = 0;
      this.gbFilter.TabStop = false;
      this.gbFilter.Text = "Filters";
      // 
      // chkInStock
      // 
      this.chkInStock.AutoSize = true;
      this.chkInStock.Checked = true;
      this.chkInStock.CheckState = System.Windows.Forms.CheckState.Checked;
      this.chkInStock.Location = new System.Drawing.Point(20, 246);
      this.chkInStock.Name = "chkInStock";
      this.chkInStock.Size = new System.Drawing.Size(166, 21);
      this.chkInStock.TabIndex = 19;
      this.chkInStock.Text = "Only Show In Stock";
      this.chkInStock.UseVisualStyleBackColor = true;
      this.chkInStock.CheckedChanged += new System.EventHandler(this.chkInStock_CheckedChanged);
      // 
      // rbAuto
      // 
      this.rbAuto.AutoSize = true;
      this.rbAuto.Location = new System.Drawing.Point(20, 136);
      this.rbAuto.Name = "rbAuto";
      this.rbAuto.Size = new System.Drawing.Size(59, 21);
      this.rbAuto.TabIndex = 18;
      this.rbAuto.Text = "Auto";
      this.rbAuto.UseVisualStyleBackColor = true;
      this.rbAuto.CheckedChanged += new System.EventHandler(this.rbAuto_CheckedChanged);
      // 
      // rbGlass
      // 
      this.rbGlass.AutoSize = true;
      this.rbGlass.Location = new System.Drawing.Point(20, 163);
      this.rbGlass.Name = "rbGlass";
      this.rbGlass.Size = new System.Drawing.Size(67, 21);
      this.rbGlass.TabIndex = 17;
      this.rbGlass.Text = "Glass";
      this.rbGlass.UseVisualStyleBackColor = true;
      this.rbGlass.CheckedChanged += new System.EventHandler(this.rbGlass_CheckedChanged);
      // 
      // rbAll
      // 
      this.rbAll.AutoSize = true;
      this.rbAll.Checked = true;
      this.rbAll.Location = new System.Drawing.Point(20, 109);
      this.rbAll.Name = "rbAll";
      this.rbAll.Size = new System.Drawing.Size(44, 21);
      this.rbAll.TabIndex = 14;
      this.rbAll.TabStop = true;
      this.rbAll.Text = "All";
      this.rbAll.UseVisualStyleBackColor = true;
      this.rbAll.CheckedChanged += new System.EventHandler(this.rbAll_CheckedChanged);
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.Add(this.txtSearch);
      this.groupBox1.Controls.Add(this.rbCode);
      this.groupBox1.Controls.Add(this.rbDescription);
      this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.groupBox1.ForeColor = System.Drawing.Color.White;
      this.groupBox1.Location = new System.Drawing.Point(6, 20);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(211, 83);
      this.groupBox1.TabIndex = 11;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Search";
      // 
      // txtSearch
      // 
      this.txtSearch.Location = new System.Drawing.Point(6, 22);
      this.txtSearch.Name = "txtSearch";
      this.txtSearch.Size = new System.Drawing.Size(199, 22);
      this.txtSearch.TabIndex = 7;
      this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
      // 
      // rbCode
      // 
      this.rbCode.AutoSize = true;
      this.rbCode.Checked = true;
      this.rbCode.Location = new System.Drawing.Point(14, 51);
      this.rbCode.Name = "rbCode";
      this.rbCode.Size = new System.Drawing.Size(63, 20);
      this.rbCode.TabIndex = 8;
      this.rbCode.TabStop = true;
      this.rbCode.Text = "Code";
      this.rbCode.UseVisualStyleBackColor = true;
      this.rbCode.CheckedChanged += new System.EventHandler(this.rbCode_CheckedChanged);
      // 
      // rbDescription
      // 
      this.rbDescription.AutoSize = true;
      this.rbDescription.Location = new System.Drawing.Point(86, 51);
      this.rbDescription.Name = "rbDescription";
      this.rbDescription.Size = new System.Drawing.Size(105, 20);
      this.rbDescription.TabIndex = 9;
      this.rbDescription.Text = "Description";
      this.rbDescription.UseVisualStyleBackColor = true;
      this.rbDescription.CheckedChanged += new System.EventHandler(this.rbDescription_CheckedChanged);
      // 
      // chkLimit
      // 
      this.chkLimit.AutoSize = true;
      this.chkLimit.Checked = true;
      this.chkLimit.CheckState = System.Windows.Forms.CheckState.Checked;
      this.chkLimit.Location = new System.Drawing.Point(20, 273);
      this.chkLimit.Name = "chkLimit";
      this.chkLimit.Size = new System.Drawing.Size(178, 21);
      this.chkLimit.TabIndex = 10;
      this.chkLimit.Text = "Limit Records Shown";
      this.chkLimit.UseVisualStyleBackColor = true;
      this.chkLimit.CheckedChanged += new System.EventHandler(this.chkLimit_CheckedChanged);
      // 
      // cmbType
      // 
      this.cmbType.DropDownHeight = 350;
      this.cmbType.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbType.FormattingEnabled = true;
      this.cmbType.IntegralHeight = false;
      this.cmbType.Items.AddRange(new object[] {
            "All",
            "Glass",
            "Sash",
            "Bead",
            "Handle",
            "Hinge",
            "Stay",
            "Connector",
            "Travel",
            "Labour",
            "Uncommon"});
      this.cmbType.Location = new System.Drawing.Point(11, 209);
      this.cmbType.Name = "cmbType";
      this.cmbType.Size = new System.Drawing.Size(200, 24);
      this.cmbType.TabIndex = 5;
      this.cmbType.Text = "All";
      this.cmbType.SelectedIndexChanged += new System.EventHandler(this.cmbStatus_SelectedIndexChanged);
      // 
      // label40
      // 
      this.label40.AutoSize = true;
      this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label40.ForeColor = System.Drawing.Color.White;
      this.label40.Location = new System.Drawing.Point(13, 190);
      this.label40.Name = "label40";
      this.label40.Size = new System.Drawing.Size(50, 16);
      this.label40.TabIndex = 4;
      this.label40.Text = "Group";
      // 
      // pnlData
      // 
      this.pnlData.Controls.Add(this.dgvItems);
      this.pnlData.Dock = System.Windows.Forms.DockStyle.Fill;
      this.pnlData.Location = new System.Drawing.Point(237, 39);
      this.pnlData.Name = "pnlData";
      this.pnlData.Size = new System.Drawing.Size(1585, 768);
      this.pnlData.TabIndex = 7;
      // 
      // chItemID
      // 
      this.chItemID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
      this.chItemID.DataPropertyName = "itemCostID";
      this.chItemID.HeaderText = "ID";
      this.chItemID.Name = "chItemID";
      this.chItemID.ReadOnly = true;
      this.chItemID.Visible = false;
      this.chItemID.Width = 28;
      // 
      // chItemMovementID
      // 
      this.chItemMovementID.DataPropertyName = "ItemMovementID";
      this.chItemMovementID.HeaderText = "MovementID";
      this.chItemMovementID.Name = "chItemMovementID";
      this.chItemMovementID.ReadOnly = true;
      this.chItemMovementID.Visible = false;
      // 
      // chGroupID
      // 
      this.chGroupID.DataPropertyName = "itemGroupID";
      this.chGroupID.HeaderText = "Group ID";
      this.chGroupID.Name = "chGroupID";
      this.chGroupID.ReadOnly = true;
      this.chGroupID.Visible = false;
      this.chGroupID.Width = 74;
      // 
      // stockID
      // 
      this.stockID.DataPropertyName = "ItemStockID";
      this.stockID.HeaderText = "stockid";
      this.stockID.Name = "stockID";
      this.stockID.ReadOnly = true;
      this.stockID.Visible = false;
      this.stockID.Width = 62;
      // 
      // chJobItemID
      // 
      this.chJobItemID.DataPropertyName = "JobItemID";
      this.chJobItemID.HeaderText = "JobItemID";
      this.chJobItemID.Name = "chJobItemID";
      this.chJobItemID.ReadOnly = true;
      this.chJobItemID.Visible = false;
      this.chJobItemID.Width = 81;
      // 
      // chJobID
      // 
      this.chJobID.DataPropertyName = "JobID";
      this.chJobID.HeaderText = "Job";
      this.chJobID.Name = "chJobID";
      this.chJobID.ReadOnly = true;
      this.chJobID.Width = 80;
      // 
      // chAltCode
      // 
      this.chAltCode.DataPropertyName = "Code";
      this.chAltCode.HeaderText = "Alt Code";
      this.chAltCode.Name = "chAltCode";
      this.chAltCode.ReadOnly = true;
      this.chAltCode.Width = 120;
      // 
      // chCode
      // 
      this.chCode.DataPropertyName = "icCode";
      this.chCode.HeaderText = "Code";
      this.chCode.Name = "chCode";
      this.chCode.ReadOnly = true;
      this.chCode.Width = 180;
      // 
      // chDescription
      // 
      this.chDescription.DataPropertyName = "icDescription";
      this.chDescription.HeaderText = "Description";
      this.chDescription.Name = "chDescription";
      this.chDescription.ReadOnly = true;
      this.chDescription.Width = 650;
      // 
      // chQuantity
      // 
      this.chQuantity.DataPropertyName = "Quantity";
      dataGridViewCellStyle3.Format = "N2";
      dataGridViewCellStyle3.NullValue = null;
      this.chQuantity.DefaultCellStyle = dataGridViewCellStyle3;
      this.chQuantity.HeaderText = "Qty";
      this.chQuantity.Name = "chQuantity";
      this.chQuantity.Width = 56;
      // 
      // chCost
      // 
      this.chCost.DataPropertyName = "icCost";
      dataGridViewCellStyle4.Format = "C2";
      dataGridViewCellStyle4.NullValue = null;
      this.chCost.DefaultCellStyle = dataGridViewCellStyle4;
      this.chCost.HeaderText = "Cost";
      this.chCost.Name = "chCost";
      this.chCost.ReadOnly = true;
      // 
      // chPrice
      // 
      this.chPrice.DataPropertyName = "icPrice";
      dataGridViewCellStyle5.Format = "C2";
      dataGridViewCellStyle5.NullValue = null;
      this.chPrice.DefaultCellStyle = dataGridViewCellStyle5;
      this.chPrice.HeaderText = "Price";
      this.chPrice.Name = "chPrice";
      this.chPrice.ReadOnly = true;
      // 
      // chUOM
      // 
      this.chUOM.DataPropertyName = "uom";
      this.chUOM.HeaderText = "UoM";
      this.chUOM.Name = "chUOM";
      this.chUOM.ReadOnly = true;
      this.chUOM.Visible = false;
      this.chUOM.Width = 66;
      // 
      // chLocation
      // 
      this.chLocation.DataPropertyName = "LocationCode";
      this.chLocation.HeaderText = "Location";
      this.chLocation.Name = "chLocation";
      this.chLocation.ReadOnly = true;
      this.chLocation.Visible = false;
      this.chLocation.Width = 120;
      // 
      // subgroup
      // 
      this.subgroup.DataPropertyName = "igSubGroup";
      this.subgroup.HeaderText = "subgroup";
      this.subgroup.Name = "subgroup";
      this.subgroup.ReadOnly = true;
      this.subgroup.Visible = false;
      this.subgroup.Width = 95;
      // 
      // chJobBtn
      // 
      this.chJobBtn.ActiveLinkColor = System.Drawing.Color.Blue;
      dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
      this.chJobBtn.DefaultCellStyle = dataGridViewCellStyle6;
      this.chJobBtn.HeaderText = "";
      this.chJobBtn.Name = "chJobBtn";
      this.chJobBtn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
      this.chJobBtn.Text = "View Job";
      this.chJobBtn.VisitedLinkColor = System.Drawing.Color.Blue;
      this.chJobBtn.Width = 80;
      // 
      // chActionBtn
      // 
      this.chActionBtn.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
      dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
      this.chActionBtn.DefaultCellStyle = dataGridViewCellStyle7;
      this.chActionBtn.HeaderText = "";
      this.chActionBtn.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
      this.chActionBtn.Name = "chActionBtn";
      this.chActionBtn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
      this.chActionBtn.Text = "On Order";
      this.chActionBtn.VisitedLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
      this.chActionBtn.Width = 80;
      // 
      // chRemoveBtn
      // 
      dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
      this.chRemoveBtn.DefaultCellStyle = dataGridViewCellStyle8;
      this.chRemoveBtn.HeaderText = "";
      this.chRemoveBtn.LinkColor = System.Drawing.Color.Red;
      this.chRemoveBtn.Name = "chRemoveBtn";
      this.chRemoveBtn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
      this.chRemoveBtn.Text = "Remove";
      this.chRemoveBtn.VisitedLinkColor = System.Drawing.Color.Red;
      // 
      // Stock
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.ClientSize = new System.Drawing.Size(1822, 807);
      this.ControlBox = false;
      this.Controls.Add(this.pnlData);
      this.Controls.Add(this.pnlFilter);
      this.Controls.Add(this.toolStrip1);
      this.Name = "Stock";
      this.ShowIcon = false;
      this.ShowInTaskbar = false;
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
      this.Text = "Stock";
      ((System.ComponentModel.ISupportInitialize)(this.dgvItems)).EndInit();
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.pnlFilter.ResumeLayout(false);
      this.Panel3.ResumeLayout(false);
      this.Panel3.PerformLayout();
      this.gbFilter.ResumeLayout(false);
      this.gbFilter.PerformLayout();
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.pnlData.ResumeLayout(false);
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.DataGridView dgvItems;
    private System.Windows.Forms.ToolStrip toolStrip1;
    private System.Windows.Forms.ToolStripButton tsClose;
    private System.Windows.Forms.ToolStripButton tsNew;
    private System.Windows.Forms.ToolStripButton tsRefresh;
    private System.Windows.Forms.ToolStripButton tsEdit;
    private System.Windows.Forms.Panel pnlFilter;
    internal System.Windows.Forms.Panel Panel3;
    internal System.Windows.Forms.Button btnQuote;
    internal System.Windows.Forms.Button btnCode;
    internal System.Windows.Forms.TextBox txtCode;
    internal System.Windows.Forms.LinkLabel lnkFind;
    private System.Windows.Forms.GroupBox gbFilter;
    private System.Windows.Forms.Panel pnlData;
    private System.Windows.Forms.TextBox txtSearch;
    private System.Windows.Forms.RadioButton rbDescription;
    private System.Windows.Forms.RadioButton rbCode;
    private System.Windows.Forms.CheckBox chkLimit;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.RadioButton rbAuto;
    private System.Windows.Forms.RadioButton rbGlass;
    private System.Windows.Forms.ComboBox cmbType;
    private System.Windows.Forms.Label label40;
    private System.Windows.Forms.ToolStripButton tsLocations;
    private System.Windows.Forms.ToolStripButton tsNotOrdered;
    private System.Windows.Forms.ToolStripButton tsReservations;
    private System.Windows.Forms.RadioButton rbAll;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
    private System.Windows.Forms.CheckBox chkInStock;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
    private System.Windows.Forms.ToolStripButton tsOnOrder;
    private System.Windows.Forms.ToolStripButton tsAllStock;
    private System.Windows.Forms.ToolStripButton tsReturns;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
    private System.Windows.Forms.ToolStripLabel lblSection;
    private System.Windows.Forms.DataGridViewTextBoxColumn chItemID;
    private System.Windows.Forms.DataGridViewTextBoxColumn chItemMovementID;
    private System.Windows.Forms.DataGridViewTextBoxColumn chGroupID;
    private System.Windows.Forms.DataGridViewTextBoxColumn stockID;
    private System.Windows.Forms.DataGridViewTextBoxColumn chJobItemID;
    private System.Windows.Forms.DataGridViewTextBoxColumn chJobID;
    private System.Windows.Forms.DataGridViewTextBoxColumn chAltCode;
    private System.Windows.Forms.DataGridViewTextBoxColumn chCode;
    private System.Windows.Forms.DataGridViewTextBoxColumn chDescription;
    private System.Windows.Forms.DataGridViewTextBoxColumn chQuantity;
    private System.Windows.Forms.DataGridViewTextBoxColumn chCost;
    private System.Windows.Forms.DataGridViewTextBoxColumn chPrice;
    private System.Windows.Forms.DataGridViewTextBoxColumn chUOM;
    private System.Windows.Forms.DataGridViewTextBoxColumn chLocation;
    private System.Windows.Forms.DataGridViewTextBoxColumn subgroup;
    private System.Windows.Forms.DataGridViewLinkColumn chJobBtn;
    private System.Windows.Forms.DataGridViewLinkColumn chActionBtn;
    private System.Windows.Forms.DataGridViewLinkColumn chRemoveBtn;
  }
}