﻿using System;
using System.Windows.Forms;

namespace workshop_orders
{
    partial class SearchVehicle
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SearchVehicle));
      this.txtRegistration = new System.Windows.Forms.TextBox();
      this.firstNameLabel = new System.Windows.Forms.Label();
      this.txtMake = new System.Windows.Forms.TextBox();
      this.phone1Label = new System.Windows.Forms.Label();
      this.txtModel = new System.Windows.Forms.TextBox();
      this.phone2Label = new System.Windows.Forms.Label();
      this.txtYear = new System.Windows.Forms.TextBox();
      this.label1 = new System.Windows.Forms.Label();
      this.gbMainDetails = new System.Windows.Forms.GroupBox();
      this.rbNoRecal = new System.Windows.Forms.RadioButton();
      this.rbYesRecal = new System.Windows.Forms.RadioButton();
      this.gbsearch = new System.Windows.Forms.GroupBox();
      this.lblSearchWeb = new System.Windows.Forms.Label();
      this.btnWebSearch = new System.Windows.Forms.Button();
      this.label3 = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this.cmbField = new System.Windows.Forms.ComboBox();
      this.txtSearch = new System.Windows.Forms.TextBox();
      this.dgvCustomer = new System.Windows.Forms.DataGridView();
      this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Registration = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Vehicle = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.toolStrip1 = new System.Windows.Forms.ToolStrip();
      this.tsClose = new System.Windows.Forms.ToolStripButton();
      this.tsSave = new System.Windows.Forms.ToolStripButton();
      this.tsAdd = new System.Windows.Forms.ToolStripButton();
      this.gbResult = new System.Windows.Forms.GroupBox();
      this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
      this.gbMainDetails.SuspendLayout();
      this.gbsearch.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgvCustomer)).BeginInit();
      this.toolStrip1.SuspendLayout();
      this.gbResult.SuspendLayout();
      this.SuspendLayout();
      // 
      // txtRegistration
      // 
      this.txtRegistration.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
      this.txtRegistration.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
      this.txtRegistration.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtRegistration.Location = new System.Drawing.Point(210, 30);
      this.txtRegistration.MaxLength = 50;
      this.txtRegistration.Name = "txtRegistration";
      this.txtRegistration.Size = new System.Drawing.Size(317, 31);
      this.txtRegistration.TabIndex = 1;
      // 
      // firstNameLabel
      // 
      this.firstNameLabel.AutoSize = true;
      this.firstNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.firstNameLabel.Location = new System.Drawing.Point(67, 33);
      this.firstNameLabel.Name = "firstNameLabel";
      this.firstNameLabel.Size = new System.Drawing.Size(133, 25);
      this.firstNameLabel.TabIndex = 23;
      this.firstNameLabel.Text = "Registration:";
      // 
      // txtMake
      // 
      this.txtMake.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtMake.Location = new System.Drawing.Point(210, 83);
      this.txtMake.MaxLength = 15;
      this.txtMake.Name = "txtMake";
      this.txtMake.Size = new System.Drawing.Size(317, 31);
      this.txtMake.TabIndex = 3;
      // 
      // phone1Label
      // 
      this.phone1Label.AutoSize = true;
      this.phone1Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.phone1Label.Location = new System.Drawing.Point(129, 86);
      this.phone1Label.Name = "phone1Label";
      this.phone1Label.Size = new System.Drawing.Size(71, 25);
      this.phone1Label.TabIndex = 26;
      this.phone1Label.Text = "Make:";
      // 
      // txtModel
      // 
      this.txtModel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtModel.Location = new System.Drawing.Point(210, 121);
      this.txtModel.MaxLength = 15;
      this.txtModel.Name = "txtModel";
      this.txtModel.Size = new System.Drawing.Size(317, 31);
      this.txtModel.TabIndex = 4;
      // 
      // phone2Label
      // 
      this.phone2Label.AutoSize = true;
      this.phone2Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.phone2Label.Location = new System.Drawing.Point(123, 123);
      this.phone2Label.Name = "phone2Label";
      this.phone2Label.Size = new System.Drawing.Size(77, 25);
      this.phone2Label.TabIndex = 26;
      this.phone2Label.Text = "Model:";
      // 
      // txtYear
      // 
      this.txtYear.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
      this.txtYear.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtYear.Location = new System.Drawing.Point(210, 160);
      this.txtYear.MaxLength = 50;
      this.txtYear.Name = "txtYear";
      this.txtYear.Size = new System.Drawing.Size(317, 31);
      this.txtYear.TabIndex = 88;
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label1.Location = new System.Drawing.Point(136, 160);
      this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(64, 25);
      this.label1.TabIndex = 89;
      this.label1.Text = "Year:";
      // 
      // gbMainDetails
      // 
      this.gbMainDetails.Controls.Add(this.rbNoRecal);
      this.gbMainDetails.Controls.Add(this.rbYesRecal);
      this.gbMainDetails.Controls.Add(this.firstNameLabel);
      this.gbMainDetails.Controls.Add(this.label1);
      this.gbMainDetails.Controls.Add(this.txtRegistration);
      this.gbMainDetails.Controls.Add(this.txtYear);
      this.gbMainDetails.Controls.Add(this.txtMake);
      this.gbMainDetails.Controls.Add(this.phone1Label);
      this.gbMainDetails.Controls.Add(this.txtModel);
      this.gbMainDetails.Controls.Add(this.phone2Label);
      this.gbMainDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbMainDetails.Location = new System.Drawing.Point(12, 158);
      this.gbMainDetails.Name = "gbMainDetails";
      this.gbMainDetails.Size = new System.Drawing.Size(650, 292);
      this.gbMainDetails.TabIndex = 90;
      this.gbMainDetails.TabStop = false;
      this.gbMainDetails.Text = "Main Details";
      this.gbMainDetails.Visible = false;
      // 
      // rbNoRecal
      // 
      this.rbNoRecal.AutoSize = true;
      this.rbNoRecal.Location = new System.Drawing.Point(210, 251);
      this.rbNoRecal.Name = "rbNoRecal";
      this.rbNoRecal.Size = new System.Drawing.Size(144, 24);
      this.rbNoRecal.TabIndex = 91;
      this.rbNoRecal.TabStop = true;
      this.rbNoRecal.Text = "No Recalibration";
      this.rbNoRecal.UseVisualStyleBackColor = true;
      // 
      // rbYesRecal
      // 
      this.rbYesRecal.AutoSize = true;
      this.rbYesRecal.Location = new System.Drawing.Point(210, 221);
      this.rbYesRecal.Name = "rbYesRecal";
      this.rbYesRecal.Size = new System.Drawing.Size(189, 24);
      this.rbYesRecal.TabIndex = 90;
      this.rbYesRecal.TabStop = true;
      this.rbYesRecal.Text = "Required Recalibration";
      this.rbYesRecal.UseVisualStyleBackColor = true;
      // 
      // gbsearch
      // 
      this.gbsearch.Controls.Add(this.lblSearchWeb);
      this.gbsearch.Controls.Add(this.btnWebSearch);
      this.gbsearch.Controls.Add(this.label3);
      this.gbsearch.Controls.Add(this.label2);
      this.gbsearch.Controls.Add(this.cmbField);
      this.gbsearch.Controls.Add(this.txtSearch);
      this.gbsearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbsearch.Location = new System.Drawing.Point(12, 39);
      this.gbsearch.Name = "gbsearch";
      this.gbsearch.Size = new System.Drawing.Size(650, 119);
      this.gbsearch.TabIndex = 1;
      this.gbsearch.TabStop = false;
      this.gbsearch.Text = "Search";
      // 
      // lblSearchWeb
      // 
      this.lblSearchWeb.AutoSize = true;
      this.lblSearchWeb.ForeColor = System.Drawing.Color.Green;
      this.lblSearchWeb.Location = new System.Drawing.Point(99, 89);
      this.lblSearchWeb.Name = "lblSearchWeb";
      this.lblSearchWeb.Size = new System.Drawing.Size(342, 20);
      this.lblSearchWeb.TabIndex = 99;
      this.lblSearchWeb.Text = "Searching \"thatcar.nz\", please wait a moment...";
      this.lblSearchWeb.Visible = false;
      // 
      // btnWebSearch
      // 
      this.btnWebSearch.BackColor = System.Drawing.Color.White;
      this.btnWebSearch.BackgroundImage = global::workshop_orders.Properties.Resources.find;
      this.btnWebSearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
      this.btnWebSearch.Location = new System.Drawing.Point(588, 48);
      this.btnWebSearch.Name = "btnWebSearch";
      this.btnWebSearch.Size = new System.Drawing.Size(40, 37);
      this.btnWebSearch.TabIndex = 98;
      this.btnWebSearch.UseVisualStyleBackColor = false;
      this.btnWebSearch.Visible = false;
      this.btnWebSearch.Click += new System.EventHandler(this.btnWebSearch_Click);
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Location = new System.Drawing.Point(32, 25);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(43, 20);
      this.label3.TabIndex = 97;
      this.label3.Text = "Field";
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Location = new System.Drawing.Point(15, 59);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(60, 20);
      this.label2.TabIndex = 96;
      this.label2.Text = "Search";
      // 
      // cmbField
      // 
      this.cmbField.FormattingEnabled = true;
      this.cmbField.Items.AddRange(new object[] {
            "Make",
            "Model",
            "Registration"});
      this.cmbField.Location = new System.Drawing.Point(99, 22);
      this.cmbField.Name = "cmbField";
      this.cmbField.Size = new System.Drawing.Size(149, 28);
      this.cmbField.Sorted = true;
      this.cmbField.TabIndex = 95;
      this.cmbField.Text = "Registration";
      this.cmbField.SelectedIndexChanged += new System.EventHandler(this.cmbField_SelectedIndexChanged);
      // 
      // txtSearch
      // 
      this.txtSearch.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
      this.txtSearch.Location = new System.Drawing.Point(99, 56);
      this.txtSearch.Name = "txtSearch";
      this.txtSearch.Size = new System.Drawing.Size(483, 26);
      this.txtSearch.TabIndex = 1;
      this.txtSearch.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
      // 
      // dgvCustomer
      // 
      this.dgvCustomer.AllowUserToAddRows = false;
      this.dgvCustomer.AllowUserToDeleteRows = false;
      dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
      this.dgvCustomer.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
      this.dgvCustomer.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      this.dgvCustomer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvCustomer.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.Registration,
            this.Vehicle});
      this.dgvCustomer.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dgvCustomer.GridColor = System.Drawing.SystemColors.ControlText;
      this.dgvCustomer.Location = new System.Drawing.Point(3, 20);
      this.dgvCustomer.Name = "dgvCustomer";
      this.dgvCustomer.ReadOnly = true;
      this.dgvCustomer.RowHeadersWidth = 5;
      this.dgvCustomer.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
      this.dgvCustomer.Size = new System.Drawing.Size(644, 269);
      this.dgvCustomer.TabIndex = 0;
      this.dgvCustomer.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.customerDataGrid_CellDoubleClick);
      // 
      // ID
      // 
      this.ID.HeaderText = "ID";
      this.ID.Name = "ID";
      this.ID.ReadOnly = true;
      this.ID.Visible = false;
      // 
      // Registration
      // 
      this.Registration.HeaderText = "Registration";
      this.Registration.Name = "Registration";
      this.Registration.ReadOnly = true;
      // 
      // Vehicle
      // 
      this.Vehicle.HeaderText = "Vehicle";
      this.Vehicle.Name = "Vehicle";
      this.Vehicle.ReadOnly = true;
      this.Vehicle.Width = 500;
      // 
      // toolStrip1
      // 
      this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsClose,
            this.tsSave,
            this.toolStripSeparator1,
            this.tsAdd});
      this.toolStrip1.Location = new System.Drawing.Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new System.Drawing.Size(672, 39);
      this.toolStrip1.TabIndex = 96;
      this.toolStrip1.Text = "toolStrip1";
      // 
      // tsClose
      // 
      this.tsClose.Image = ((System.Drawing.Image)(resources.GetObject("tsClose.Image")));
      this.tsClose.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsClose.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsClose.Name = "tsClose";
      this.tsClose.Size = new System.Drawing.Size(72, 36);
      this.tsClose.Text = "Close";
      this.tsClose.Click += new System.EventHandler(this.toolStripButton1_Click_1);
      // 
      // tsSave
      // 
      this.tsSave.Image = ((System.Drawing.Image)(resources.GetObject("tsSave.Image")));
      this.tsSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsSave.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsSave.Name = "tsSave";
      this.tsSave.Size = new System.Drawing.Size(67, 36);
      this.tsSave.Text = "Save";
      this.tsSave.Click += new System.EventHandler(this.saveToolStripButton2_Click);
      // 
      // tsAdd
      // 
      this.tsAdd.Image = ((System.Drawing.Image)(resources.GetObject("tsAdd.Image")));
      this.tsAdd.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsAdd.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsAdd.Name = "tsAdd";
      this.tsAdd.Size = new System.Drawing.Size(107, 36);
      this.tsAdd.Text = "New Vehicle";
      this.tsAdd.ToolTipText = "Add ";
      this.tsAdd.Click += new System.EventHandler(this.addtoolStripButton_Click);
      // 
      // gbResult
      // 
      this.gbResult.Controls.Add(this.dgvCustomer);
      this.gbResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbResult.Location = new System.Drawing.Point(12, 158);
      this.gbResult.Name = "gbResult";
      this.gbResult.Size = new System.Drawing.Size(650, 292);
      this.gbResult.TabIndex = 97;
      this.gbResult.TabStop = false;
      this.gbResult.Text = "Results";
      // 
      // toolStripSeparator1
      // 
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
      // 
      // SearchVehicle
      // 
      this.AllowDrop = true;
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.AutoScroll = true;
      this.BackColor = System.Drawing.Color.White;
      this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
      this.ClientSize = new System.Drawing.Size(672, 456);
      this.Controls.Add(this.gbResult);
      this.Controls.Add(this.toolStrip1);
      this.Controls.Add(this.gbsearch);
      this.Controls.Add(this.gbMainDetails);
      this.Cursor = System.Windows.Forms.Cursors.Default;
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
      this.MaximizeBox = false;
      this.Name = "SearchVehicle";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
      this.Text = "Vehicle Search";
      this.Load += new System.EventHandler(this.CreateJobForm_Load);
      this.gbMainDetails.ResumeLayout(false);
      this.gbMainDetails.PerformLayout();
      this.gbsearch.ResumeLayout(false);
      this.gbsearch.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgvCustomer)).EndInit();
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.gbResult.ResumeLayout(false);
      this.ResumeLayout(false);
      this.PerformLayout();

        }

        #endregion
        private TextBox txtRegistration;
        private Label firstNameLabel;
        private TextBox txtMake;
        private Label phone1Label;
        private TextBox txtModel;
        private Label phone2Label;
        private TextBox txtYear;
        private Label label1;
        private GroupBox gbMainDetails;
        private GroupBox gbsearch;
        private TextBox txtSearch;
        private ToolStrip toolStrip1;
        private ToolStripButton tsClose;
        private ToolStripButton tsSave;
        private ComboBox cmbField;
        private ToolStripButton tsAdd;
        private DataGridView dgvCustomer;
        private Label label3;
        private Label label2;
    private GroupBox gbResult;
    private RadioButton rbNoRecal;
    private RadioButton rbYesRecal;
    private DataGridViewTextBoxColumn ID;
    private DataGridViewTextBoxColumn Registration;
    private DataGridViewTextBoxColumn Vehicle;
    private Button btnWebSearch;
    private Label lblSearchWeb;
    private ToolStripSeparator toolStripSeparator1;
  }
}

