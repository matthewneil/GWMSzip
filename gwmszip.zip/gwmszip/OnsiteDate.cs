﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workshop_orders
{
  public partial class OnsiteDate : Form
  {
    public OnsiteDate(int StaffID)
    {
      InitializeComponent();
      nudStaff.Value = StaffID;
      dtpDate.Value = DateTime.Today;
      dtpDate.MinDate = DateTime.Today.AddDays(-6);
      dtpDate.MaxDate = DateTime.Today;
      Reload();
    }

    public void Reload()
    {
      lblMissingRecords.Text = "Missing Records\n";
      lnkRecord2.Visible = true;
      label2.Text = DataAccess.ExecuteScalarString("SELECT StaffFullName FROM staff WHERE staffID = " + nudStaff.Value);
      if (label2.Text == "ERROR") return;

      LoadDayRecords();

      DateTime Date = DateTime.Today;

      while (Date >= DateTime.Today.AddDays(-6))
      {
        //String date = dtpDate.Value.ToString("yyyy-MM-dd");
        DataTable dt = DataAccess.ExecuteDataTable(String.Format("SELECT StartTime FROM LABOUR WHERE StaffID = {1} AND StartTime BETWEEN '{0}' AND '{0} 23:59:59' ORDER BY StartTime",
          Date.ToString("yyyy-MM-dd"), nudStaff.Value));

        lblMissingRecords.Text += Date.ToString("ddd, dd MMM") + "\n";
        if (dt != null && dt.Rows.Count > 1)
        {
          if (DateTime.Parse(dt.Rows[0][0].ToString()) > DateTime.Parse(Date.ToString("yyyy-MM-dd ") + "08:15:00"))
          {
            lblMissingRecords.Text += "    - 8:00 am - " + DateTime.Parse(dt.Rows[0][0].ToString()).ToString("hh:mm tt") + "\n";
          }
          if (DateTime.Parse(dt.Rows[dt.Rows.Count - 1][0].ToString()) < DateTime.Parse(Date.ToString("yyyy-MM-dd ") + "16:45:00"))
          {
            lblMissingRecords.Text += "    - " + DateTime.Parse(dt.Rows[dt.Rows.Count - 1][0].ToString()).ToString("hh:mm tt") + " - 5:00 pm\n";
          }
        }
        else
        {
          lblMissingRecords.Text += "    - 8:00 am - 5:00 pm\n";
        }

        lblMissingRecords.Text += "\n";

        Date = Date.AddDays(-1);
      }
      /*
        //Find if there are any missing records at the start of the day.
        String StartTime = DataAccess.ExecuteScalarString("SELECT StartTime FROM LABOUR WHERE StaffID = " + nudStaff.Value + " AND StartTime BETWEEN '" +
          Date.ToString("yyyy-MM-dd") + "' AND '" + Date.ToString("yyyy-MM-dd") + " 23:59:59' ORDER BY StartTime");

        if (StartTime != "ERROR")
        {
          if (DateTime.Parse(StartTime) > DateTime.Parse(Date.ToString("yyyy-MM-dd ") + "08:15:00"))
          {
            
          }
        }
        else
        {
          lblMissingRecords.Text += "    - 8:00 am - 5:00 pm\n";
          if (Date == dtpDate.Value)
          {
            lnkRecord1.Text = "08:00 am - 05:00 pm\n";            
          }
        }


        //Find if there are any missing records at the end of the day.
        String EndTime = DataAccess.ExecuteScalarString("SELECT StartTime FROM LABOUR WHERE StaffID = " + nudStaff.Value + " AND StartTime BETWEEN '" +
          Date.ToString("yyyy-MM-dd") + "' AND '" + Date.ToString("yyyy-MM-dd") + " 23:59:59' ORDER BY StartTime DESC");

        if (EndTime != "ERROR")
        {
          if (DateTime.Parse(EndTime) < DateTime.Parse(Date.ToString("yyyy-MM-dd ") + "16:45:00"))
          {
            lblMissingRecords.Text += "    - " + DateTime.Parse(EndTime).ToString("hh:mm tt") + " - 5:00 pm\n";
          }
        }
        else
        {         
          if (Date == dtpDate.Value)
          {
            lnkRecord2.Visible = false;
          }
        }

        
      }
      */
    }

    private void LoadDayRecords()
    {
      lnkRecord1.Visible = true;
      lnkRecord2.Visible = true;
      lnkRecord1.Text = "";
      lnkRecord2.Text = "";

      String date = dtpDate.Value.ToString("yyyy-MM-dd");
      DataTable dt = DataAccess.ExecuteDataTable(String.Format("SELECT StartTime FROM LABOUR WHERE StaffID = {1} AND StartTime BETWEEN '{0}' AND '{0} 23:59:59' ORDER BY StartTime",
        date, nudStaff.Value));

      if(dt != null && dt.Rows.Count > 1)
      {
        if (DateTime.Parse(dt.Rows[0][0].ToString()) > DateTime.Parse(dtpDate.Value.ToString("yyyy-MM-dd ") + "08:15:00"))
        {
          lnkRecord1.Text = "08:00 am - " + DateTime.Parse(dt.Rows[0][0].ToString()).ToString("hh:mm tt");
        }
        if (DateTime.Parse(dt.Rows[dt.Rows.Count-1][0].ToString()) < DateTime.Parse(dtpDate.Value.ToString("yyyy-MM-dd ") + "16:45:00"))
        {
            lnkRecord2.Text =  DateTime.Parse(dt.Rows[dt.Rows.Count-1][0].ToString()).ToString("hh:mm tt") + " - 05:00 pm";
        }
 
      }
      else
      {
        lnkRecord1.Text = "08:00 am - 05:00 pm\n";
      }

      /*
      //Finds the first labour record entered on the day
      String StartTime = DataAccess.ExecuteScalarString(
        String.Format("SELECT StartTime FROM LABOUR WHERE StaffID = {1} AND StartTime BETWEEN '{0}' AND '{0} 23:59:59' ORDER BY StartTime",
        date, nudStaff.Value));

      //Finds the last labour record entered on the day
      String EndTime = DataAccess.ExecuteScalarString(
        String.Format("SELECT StartTime FROM LABOUR WHERE StaffID = {1} AND StartTime BETWEEN '{0}' AND '{0} 23:59:59' ORDER BY StartTime DESC",
        date, nudStaff.Value));


      //If a start time is returned, check if it is within x minutes of 8am.
      if (StartTime != "ERROR")
      {
        //If the time isn't close enough to 8am, then show a record that can be filled.
        if (DateTime.Parse(StartTime) > DateTime.Parse(dtpDate.Value.ToString("yyyy-MM-dd ") + "08:15:00"))
        {
          lnkRecord1.Text = "08:00 am - " + DateTime.Parse(StartTime).ToString("hh:mm tt");
        }
        else
        {
          lnkRecord1.Text = "";
        }
      }
      else //If no start record is found, then the whole day is blank, so show a 8am to 5pm record.
      {
         lnkRecord1.Text = "08:00 am - 05:00 pm\n";
      }

      //If a end time is returned, check if it is within x minutes of 5pm.
      if (EndTime != "ERROR")
      {
        //If the time isn't close enough to 5pm, then show a record that can be filled.
        if (DateTime.Parse(StartTime) < DateTime.Parse(dtpDate.Value.ToString("yyyy-MM-dd ") + "16:45:00"))
        {
          lnkRecord2.Text = DateTime.Parse(EndTime).ToString("hh:mm tt") + " - 05:00 pm";
        }
        else
        {
          lnkRecord2.Text = "";
        }
      }
      else //If no start record is found, then the whole day is blank, so show a 8am to 5pm record.
      {
        lnkRecord2.Text = "";
      }
      */



    }

    private void numericUpDown1_ValueChanged(object sender, EventArgs e)
    {    
      Reload();
    }

    private void dtpDate_ValueChanged(object sender, EventArgs e)
    {
      LoadDayRecords();
    }

    private void lnkRecord1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
    {
      String starttime = lnkRecord1.Text.Split('-')[0].Trim();
      String endtime = lnkRecord1.Text.Split('-')[1].Trim();

      dtpStart.Value = DateTime.Parse(dtpDate.Value.ToString("dd-MM-yyyy ") + starttime);
      dtpEnd.Value = DateTime.Parse(dtpDate.Value.ToString("dd-MM-yyyy ") + endtime);

      SetStartButtons(true);
      if (starttime == "08:00 am" && endtime == "05:00 pm") SetEndButtons(true);
      else SetEndButtons(false);

      btnContinue.Enabled = true;
      gbTimes.Enabled = true;

    }

    private void SetStartButtons(bool enabled)
    {
      dtpStart.Enabled = enabled;
      btnStartBack.Enabled = enabled;
      btnStartNext.Enabled = enabled;
    }

    private void SetEndButtons(bool enabled)
    {
      dtpEnd.Enabled = enabled;
      btnEndBack.Enabled = enabled;
      btnEndNext.Enabled = enabled;
    }

    private void lnkRecord2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
    {
      String starttime = lnkRecord2.Text.Split('-')[0].Trim();
      String endtime = lnkRecord2.Text.Split('-')[1].Trim();

      dtpStart.Value = DateTime.Parse(dtpDate.Value.ToString("dd-MM-yyyy ") + starttime);
      dtpEnd.Value = DateTime.Parse(dtpDate.Value.ToString("dd-MM-yyyy ") + endtime);

      SetStartButtons(false);
      SetEndButtons(true);

      gbTimes.Enabled = true;
      tsContinue.Enabled = true;
      btnContinue.Enabled = true;
    }

    private void btnContinue_Click(object sender, EventArgs e)
    {
      Continue();
    }

    private void Continue()
    {
      this.Close();
      FormManagement.ShowChildForm(new Onsite((int)nudStaff.Value, dtpStart.Value, dtpEnd.Value));
    }

    private void btnStartBack_Click(object sender, EventArgs e)
    {
      if (dtpStart.Value.AddMinutes(-15) >= DateTime.Parse("05:00:00")){
        dtpStart.Value = dtpStart.Value.AddMinutes(-15);
      }
      else
      {
        dtpStart.Value = DateTime.Parse("05:00:00");
      }
     
    }

    private void btnStartNext_Click(object sender, EventArgs e)
    {
      if (dtpStart.Value.AddMinutes(15) < dtpEnd.Value)
      {
        dtpStart.Value = dtpStart.Value.AddMinutes(15);
      }
    }

    private void btnEndBack_Click(object sender, EventArgs e)
    {
      if (dtpEnd.Value.AddMinutes(-15) > dtpStart.Value)
      {
        dtpEnd.Value = dtpEnd.Value.AddMinutes(-15);
      }
    }

    private void btnEndNext_Click(object sender, EventArgs e)
    {
      if (dtpEnd.Value.AddMinutes(15) <= DateTime.Parse("20:00:00"))
      {
        dtpEnd.Value = dtpEnd.Value.AddMinutes(15);
      }
      else
      {
        dtpEnd.Value = DateTime.Parse("20:00:00");
      }
    }

    private void panel1_Paint(object sender, PaintEventArgs e)
    {

    }

    private void tsBack_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private void tsContinue_Click(object sender, EventArgs e)
    {
      Continue();
    }

    private void btnCancel_Click(object sender, EventArgs e)
    {
      this.Close();
    }
  }
}
