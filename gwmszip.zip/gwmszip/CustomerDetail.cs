﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workshop_orders
{
  public partial class CustomerDetail : Form
  {
    private int CustomerID = -1;
    public CustomerDetail(int CustomerID)
    {
      InitializeComponent();
      this.CustomerID = CustomerID;

      LoadCustomerData();
      SetButtonState(DataAccess.FormState(this.AccessibilityObject.Name, tsSave));
    }

    private void SetButtonState(Boolean bState)
    {
      tsInactive.Enabled = bState;
    }


    private void LoadCustomerData()
    {
      DataTable dt = DataAccess.ExecuteDataTable("SELECT * FROM Customer WHERE CustomerID = " + CustomerID);
      if(dt.Rows.Count > 0)
      {
        txtFullName.Text = dt.Rows[0]["CustomerName"].ToString();
        txtSurname.Text = dt.Rows[0]["cSurname"].ToString();
        txtMobileNo.Text = dt.Rows[0]["cMobilePhone"].ToString();
        txtEmail.Text = dt.Rows[0]["cEmail"].ToString();
        txtPhoneNo.Text = dt.Rows[0]["cPhone2"].ToString();
         
        if (dt.Rows[0]["cBusiness"].ToString() == "1")
        {
          chkBusiness.Checked = true;
        }

        txtCity.Text = dt.Rows[0]["cCity"].ToString();
        txtAddress.Text = dt.Rows[0]["cAddress"].ToString();
        txtPostcode.Text = dt.Rows[0]["cPostcode"].ToString();
        txtSuburb.Text = dt.Rows[0]["cSuburb"].ToString();

      }

      DataTable dtQuotes = DataAccess.ExecuteDataTable("SELECT * FROM vwQuote WHERE CustomerID = " + CustomerID);
      dgvQuotes.DataSource = dtQuotes;

      DataTable dtProduction = DataAccess.ExecuteDataTable("SELECT * FROM vwJob WHERE CustomerID = " + CustomerID);
      dgvProduction.DataSource = dtProduction;
    }
    private void SetFormSecurity()
    { 
    
    
    
    }
    private void tsClose_Click(object sender, EventArgs e)
    {
      this.Close();
    }
  }
}
