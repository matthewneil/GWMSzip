﻿using DocumentFormat.OpenXml.Vml.Spreadsheet;
using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Windows.Forms;

namespace workshop_orders
{
  /*This is a form is view all the created jobs in the database*
   * This data can a queried and filter so you can only display the job you want to see*/
  public partial class Costings : Form
  {
    private int queryStart = 0;
    private int queryStart2 = 0;
    private int queryEnd = 36;

    /*A method to connect to the GoreGlassJob database*/
    public MySqlConnection connectMySql()
    {
      using (MySqlConnection conn = new MySqlConnection(GWMS.connStr))
      {
        try
        {
          Console.WriteLine("Connecting to MySQL...");

          return conn;
        }
        catch (Exception ex)
        {
          MessageBox.Show("Error connecting to server, please contact the administrator.", "Error!");
          return null;
        }

      }
    }

    /*Initializes the component and add the database varible names to the 'WHERE' box, used for querying the job database job*/
    public Costings()
    {
      InitializeComponent();
      String[] whereValues = new string[] {"JobNumber", "Customer",
                "Registration", "Part", "InsuranceProvider",  "Status", "StaffCreated", "StaffCompleted"};

      String[] databases = new String[] { "-None Selected-", "Jobs", "Customer", "Registration", "Insurer" };
      //db1Combo.Items.AddRange(databases);
      reset_all_fields();
    }

    /*Check if String entered into function is a number
     */
    public bool IsNumber(String number)
    {
      return number.All(char.IsNumber);
    }

    private void downButton_Click(object sender, EventArgs e)
    {
      queryStart += queryEnd;
      refreshOrders();
    }

    private void upButton_Click(object sender, EventArgs e)
    {
      queryStart -= queryEnd;
      refreshOrders();
    }

    private void upButton2_Click(object sender, EventArgs e)
    {
      queryStart2 -= queryEnd;
      refreshOrders();
    }

    private void downButton2_Click(object sender, EventArgs e)
    {
      queryStart2 += queryEnd;
      refreshOrders();
    }

    /*reset_all_fields method
     * Resets all the fields in the form to empty
     * Also refreshes the Today's orders' box to reflect any changes that may have happened to the database.
     */
    private void reset_all_fields()
    {

      refreshOrders();

      /*listBox1.Items.AddRange(new object[] { "Item 1, column 1",
      "Item 2, column 1",
      "Item 3, column 1",
      "Item 4, column 1",
      "Item 5, column 1",
      "Item 1, column 2",
      "Item 2, column 2",
      "Item 3, column 2"});*/
    }

    /*When this method is called, it reloads the Jobs from the MySql database*/
    private void refreshOrders()
    {
      string[] weekdays = { "MON", "TUES", "WED", "THUR", "FRI", "SAT", "SUN" };

      weekChart.Series["Actual Cost"].Points.Clear();
      weekChart.Series["Charge Out"].Points.Clear();

      monthChart.Series["Actual Cost"].Points.Clear();
      monthChart.Series["Charge Out"].Points.Clear();

      recentChart.Series["Actual Cost"].Points.Clear();
      recentChart.Series["Charge Out"].Points.Clear();

      double totalBuy = 0.0;
      double totalSell = 0.0;
      double totalCost = 0.0;
      int i = 0;
      using (MySqlConnection conn = new MySqlConnection(GWMS.connStr))
      {
        try
        {
          conn.Open();
          String sql = String.Format("SELECT jobNo, date, fixedCost,  labourCost FROM jobCost ORDER BY date DESC LIMIT 20;");
          MySqlCommand cmd = new MySqlCommand(sql, conn);
          using (MySqlDataReader rdr = cmd.ExecuteReader())
          {
            while (rdr.Read())
            {
              totalBuy = 0.0;
              totalSell = 0.0;
              totalCost = 0.0;
              using (MySqlConnection conn2 = connectMySql())
              {
                conn2.Open();
                String productCost = String.Format("SELECT buyPrice, sellPrice FROM jobPart INNER JOIN " +
                    "(SELECT objID, MAX(date) AS maxdate FROM jobPart GROUP BY objID) jP " +
                    "ON jobPart.objID = jP.objID AND date = maxdate WHERE pAllocated = {0};",
                    rdr["jobNo"].ToString());

                MySqlCommand cmd2 = new MySqlCommand(productCost, conn2);
                using (MySqlDataReader rdr2 = cmd2.ExecuteReader())
                {
                  while (rdr2.Read())
                  {
                    if (rdr2["buyPrice"] != null && rdr2["sellPrice"] != null)
                    {
                      totalBuy += Double.Parse(rdr2["buyPrice"].ToString());
                      totalSell += Double.Parse(rdr2["sellPrice"].ToString());
                    }
                  }
                }
                conn2.Close();
              }
              totalCost = totalBuy + Double.Parse(rdr["fixedCost"].ToString()) + Double.Parse(rdr["labourCost"].ToString());
              recentChart.Series["Actual Cost"].Points.AddXY(rdr["jobNo"].ToString(), totalCost);
              recentChart.Series["Charge Out"].Points.AddXY(rdr["jobNo"].ToString(), totalSell);
            }
          }
        }
        catch (Exception ex)
        {
          //MessageBox.Show("An error occured displaying costing graphs.");
          DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
        }
      }
      using (MySqlConnection conn = new MySqlConnection(GWMS.connStr))
      {
        try
        {
          conn.Open();
          string dateNow = DateTime.Now.ToString("yyyy/MM/dd" + "");
          string getOrders = String.Format("SELECT job.jobNo AS JobNo, cFirstName AS CustomerFirstName, cSurname AS Surname, cCompany AS Company, registration AS Rego, " +
              "status AS Status, " +
              "validations AS Issues, bookingDate AS BookDate, note AS Note, date AS LastUpdated FROM job " +
              "INNER JOIN customer ON customerID = cID  INNER JOIN jobStatus ON jobStatus.jobNo = job.jobNo INNER JOIN " +
              "(SELECT jobNo, MAX(date) AS maxdate FROM jobStatus GROUP BY jobNo) jS ON jobStatus.jobNo = jS.jobNo AND jobStatus.date = js.maxdate " +
              "INNER JOIN staff ON updatedBy = sUsername WHERE status != 'COMPLETE' AND status != 'INVOICED' " +
              "AND (job.jobNo LIKE '{0}%' OR cFirstName LIKE '{0}%' OR cSurname LIKE '{0}%' OR cCompany LIKE '{0}%' OR registration LIKE '{0}%') " +
              "ORDER BY status DESC, bookingDate LIMIT {1}, {2};", equalText.Text, queryStart, queryEnd);
          MySqlCommand cmd = new MySqlCommand(getOrders, conn);
          MySqlDataAdapter sqlDa = new MySqlDataAdapter(getOrders, conn);
          DataTable dtbl = new DataTable();
          sqlDa.Fill(dtbl);

          dataGridView1.DataSource = dtbl;

          foreach (DataGridViewRow row in dataGridView1.Rows)
          {
            try
            {
              if (row.Cells[5].Value != null && row.Cells[7].Value != null)
              {

                if (row.Cells[5].Value.ToString() != "COMPLETE" && DateTime.Parse(row.Cells[7].Value.ToString()) < DateTime.Today)
                {
                  //row.Cells[6].Style.BackColor = Color.Yellow;
                  row.Cells[7].Style.BackColor = Color.Yellow;
                }
              }
            }
            catch { }

            try
            {
              if (row.Cells[6].Value != null)
              {
                if (row.Cells[6].Value.ToString().Contains("NEEDS INSURANCE;") || row.Cells[6].Value.ToString().Contains("NEEDS REGO;")
                    || row.Cells[6].Value.ToString().Contains("NEEDS BOOKING;"))
                {
                  row.Cells[6].Style.BackColor = Color.Yellow;
                }
                if (row.Cells[6].Value.ToString().Contains("RECAL;"))
                {
                  row.Cells[6].Style.BackColor = Color.LightSteelBlue;
                }
                if (row.Cells[6].Value.ToString().Contains("CASH SALE;"))
                {
                  row.Cells[6].Style.BackColor = Color.LightGreen;
                }
              }
            }
            catch { }
          }
        }
        catch (Exception ex)
        {
          MessageBox.Show("Error Loading Current Jobs.");
          DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
        }
        conn.Close();
      }

      using (MySqlConnection conn = connectMySql())
      {
        try
        {
          conn.Open();
          String getOrders = String.Format("SELECT job.jobNo AS JobNo, cFirstName AS CustomerFirstName, cSurname AS Surname, cCompany AS Company, registration AS Rego, " +
              "status AS Status, " +
              "validations AS Issues, bookingDate AS BookDate, note AS Note, date AS LastUpdated FROM job " +
              "INNER JOIN customer ON customerID = cID  INNER JOIN jobStatus ON jobStatus.jobNo = job.jobNo INNER JOIN " +
              "(SELECT jobNo, MAX(date) AS maxdate FROM jobStatus GROUP BY jobNo) jS ON jobStatus.jobNo = jS.jobNo AND jobStatus.date = js.maxdate " +
              "INNER JOIN staff ON updatedBy = sUsername WHERE (status = 'COMPLETE' OR status = 'INVOICED') " +
              "AND (job.jobNo LIKE '{0}%' OR cFirstName LIKE '{0}%' OR cSurname LIKE '{0}%' OR cCompany LIKE '{0}%' OR registration LIKE '{0}%') " +
              "ORDER BY status, validations, bookingDate LIMIT {1}, {2};",
              equalText.Text, queryStart2, queryEnd);

          String jobInfo = String.Format("SELECT job.jobNo, cFirstName, cSurname, cCompany, " +
              "status AS Status, bookingDate " +
              "FROM job " +
              "INNER JOIN customer ON customerID = cID  INNER " +
              "JOIN jobStatus ON jobStatus.jobNo = job.jobNo INNER JOIN " +
              "(SELECT jobNo, MAX(date) AS maxdate FROM jobStatus GROUP BY jobNo) jS ON jobStatus.jobNo = jS.jobNo AND " +
              "jobStatus.date = js.maxdate " +
              "WHERE (job.jobNo LIKE '{0}%' OR cFirstName LIKE '{0}%' OR cSurname LIKE '{0}%' OR cCompany LIKE '{0}%' OR " +
              "registration LIKE '{0}%') " +
              "ORDER BY bookingDate;",
              equalText.Text, queryStart2, queryEnd);

          using (MySqlConnection conn2 = connectMySql())
          {
            try
            {
              String costInfo = String.Format("SELECT buyPrice, sellPrice " +
              "FROM jobPart " +
              "INNER JOIN customer ON customerID = cID  INNER " +
              "JOIN jobStatus ON jobStatus.jobNo = job.jobNo INNER JOIN " +
              "(SELECT jobNo, MAX(date) AS maxdate FROM jobStatus GROUP BY jobNo) jS ON jobStatus.jobNo = jS.jobNo AND " +
              "jobStatus.date = js.maxdate " +
              "WHERE (job.jobNo LIKE '{0}%' OR cFirstName LIKE '{0}%' OR cSurname LIKE '{0}%' OR cCompany LIKE '{0}%' OR " +
              "registration LIKE '{0}%') " +
              "ORDER BY bookingDate;", equalText.Text, queryStart2, queryEnd);
            }
            catch { }
          }


          MySqlCommand cmd = new MySqlCommand(getOrders, conn);
          MySqlDataAdapter sqlDa = new MySqlDataAdapter(getOrders, conn);
          DataTable dtbl = new DataTable();
          sqlDa.Fill(dtbl);

          dataGridView2.DataSource = dtbl;

          pageLabel.Text = "Page " + (queryStart / queryEnd + 1).ToString();
          pageLabel2.Text = "Page " + (queryStart2 / queryEnd + 1).ToString();

          foreach (DataGridViewRow row in dataGridView2.Rows)
          {
            try
            {
              if (row.Cells[6].Value != null)
              {
                if (row.Cells[6].Value.ToString() == "VALIDATION REQUIRED;")
                {
                  row.Cells[6].Style.BackColor = Color.SkyBlue;
                }
                else if (row.Cells[6].Value.ToString().Contains("CASH SALE;"))
                {
                  row.Cells[6].Style.BackColor = Color.LightGreen;
                }
                else if (row.Cells[6].Value.ToString() != "")
                {
                  row.Cells[6].Style.BackColor = Color.Yellow;
                }
              }
            }
            catch { }
          }

          if (queryStart > 0)
          {
            upButton.Enabled = true;
          }
          else
          {
            upButton.Enabled = false;
          }
          if (dataGridView1.Rows.Count < queryEnd)
          {
            downButton.Enabled = false;
          }
          else
          {
            downButton.Enabled = true;
          }

          if (queryStart2 > 0)
          {
            upButton2.Enabled = true;
          }
          else
          {
            upButton2.Enabled = false;
          }
          if (dataGridView2.Rows.Count < queryEnd)
          {
            downButton2.Enabled = false;
          }
          else
          {
            downButton2.Enabled = true;
          }
          /*
          foreach (DataGridViewRow row in dataGridView1.Rows)
          {
              if (row.Cells[8].Value != null)
              {
                  if (row.Cells[8].Value.ToString() == "COMPLETE")
                  {
                      row.Cells[8].Style.BackColor = Color.LightGreen;
                  }
                  if (row.Cells[8].Value.ToString() == "HIATUS")
                  {
                      row.Cells[8].Style.BackColor = Color.Yellow;
                  }
                  if (row.Cells[8].Value.ToString() == "FAILED")
                  {
                      row.Cells[8].Style.BackColor = Color.Red;
                  }
              }
          }*/
        }
        catch (Exception ex)
        {
          Console.WriteLine(ex.ToString());
          //MessageBox.Show("Error loading the jobs. If the problem persists, please contact the administrator.", "Error!");
          DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
        }
        conn.Close();
      }
    }

    private void refreshButton_Click(object sender, EventArgs e)
    {
      refreshOrders();
    }

    /*deleteRecordButton_Click method
     * Activated whenever the 'Delete Record' button is clicked on the form.
     * The method will delete the record from database that the user has selected.
     * Then it will refresh the top box to reflect that the record is deleted.
     */
    private void deleteRecordButton_Click(object sender, EventArgs e)
    {
      try
      {
        String jobNo = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
        if (jobNo != "")
        {
          DialogResult deletion = MessageBox.Show("Are you sure you want to delete Order #" + jobNo + "?", "Deletion", MessageBoxButtons.YesNo);
          if (deletion == DialogResult.Yes)
          {
            using (MySqlConnection conn = connectMySql())
            {
              try
              {
                conn.Open();
                string deleteStatement = "DELETE FROM jobPart WHERE " + jobNo + " = jobNo;DELETE FROM job WHERE " + jobNo + " = jobNumber;";
                MySqlCommand cmd = new MySqlCommand(deleteStatement, conn);
                MySqlDataReader rdr = cmd.ExecuteReader();
              }
              catch (Exception ex)
              {
                Console.WriteLine(ex.ToString());
                MessageBox.Show("Error deleting record. If problem persists please contact the administrator.", "Error!");
              }
              conn.Close();
            }
          }
          reset_all_fields();
        }
      }
      catch { }
    }

 

    private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      if (e.RowIndex >= 0)
      {
        DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
        BackCosting form = new BackCosting(row.Cells["JobNo"].Value.ToString());
        FormManagement.ShowDialogForm(form);
        refreshOrders();
      }
    }

    private void dataGridView2_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      if (e.RowIndex >= 0)
      {
        DataGridViewRow row = this.dataGridView2.Rows[e.RowIndex];
        BackCosting form = new BackCosting(row.Cells["JobNo"].Value.ToString());
        FormManagement.ShowDialogForm(form);
        refreshOrders();
      }
    }

    private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
    {

    }

    private void statusButton_Click(object sender, EventArgs e)
    {
      try
      {
        String jobNo = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
        if (jobNo != "")
        {

        }
      }
      catch { }
    }



    /**methods below are unused*/
    private void Form1_Load(object sender, EventArgs e)
    {
      refreshOrders();
    }

    private void ViewJobForm_Resize(object sender, EventArgs e)
    {
      //dataGridView1.Width = this.Width - dataGridView1.Location.X - 30;
      //dataGridView1.Height = this.Height - dataGridView1.Location.Y - 40;
    }



    /*Method for disabling and enabling the date boxes on the form depending on the state of the user dates check box.
     *Method is called when a check change has occured on the dates check box.
     */
    private void dateCheckBox_Select(object sender, EventArgs e)
    {
      if (dateCheckBox.Checked)
      {
        dateStart.Enabled = true;
        dateEnd.Enabled = true;
      }
      else
      {
        dateStart.Enabled = false;
        dateEnd.Enabled = false;
      }
    }

    private void equalText_TextChanged(object sender, EventArgs e)
    {
      queryStart = 0;
      queryStart2 = 0;
      refreshOrders();
      return;
      if (equalText.Text != "")
      {
        string dateNow = DateTime.Now.ToString("yyyy/MM/dd" + "");
        string getOrders = String.Format("SELECT job.jobNo AS JobNo, cFirstName AS CustomerFirstName, cSurname AS Surname, cCompany AS Company, registration AS Rego, " +
            "status AS Status, " +
            "validations AS Issues, bookingDate AS BookDate, note AS Note, date AS LastUpdated FROM job " +
            "INNER JOIN customer ON customerID = cID  INNER JOIN jobStatus ON jobStatus.jobNo = job.jobNo INNER JOIN " +
            "(SELECT jobNo, MAX(date) AS maxdate FROM jobStatus GROUP BY jobNo) jS ON jobStatus.jobNo = jS.jobNo AND jobStatus.date = js.maxdate " +
            "INNER JOIN staff ON updatedBy = sUsername " +
            "WHERE status != 'COMPLETE' AND (job.jobNo LIKE '{0}%' OR cFirstName LIKE '{0}%' OR cSurname LIKE '{0}%' OR cCompany LIKE '{0}%' OR registration LIKE '{0}%')" +
            "ORDER BY status DESC, bookingDate LIMIT {1}, {2};", equalText.Text, queryStart, queryEnd);

        MySqlConnection conn = connectMySql();
        conn.Open();
        MySqlCommand cmd = new MySqlCommand(getOrders, conn);
        MySqlDataAdapter sqlDa = new MySqlDataAdapter(getOrders, conn);
        DataTable dtbl = new DataTable();
        sqlDa.Fill(dtbl);

        dataGridView1.DataSource = dtbl;

        foreach (DataGridViewRow row in dataGridView1.Rows)
        {
          try
          {
            if (row.Cells[5].Value != null && row.Cells[8].Value != null)
            {
              if (row.Cells[5].Value.ToString() != "COMPLETE" && DateTime.Parse(row.Cells[7].Value.ToString()) < DateTime.Today)
              {
                //row.Cells[6].Style.BackColor = Color.Yellow;
                row.Cells[7].Style.BackColor = Color.Yellow;
              }
            }
          }
          catch { }
        }

        conn.Close();
        conn.Open();

        getOrders = String.Format("SELECT job.jobNo AS JobNo, cFirstName AS CustomerFirstName, cSurname AS Surname, cCompany AS Company, registration AS Rego, " +
            "status AS Status, " +
            "validations AS Issues, bookingDate AS BookDate, note AS Note, date AS LastUpdated FROM job " +
            "INNER JOIN customer ON customerID = cID  INNER JOIN jobStatus ON jobStatus.jobNo = job.jobNo INNER JOIN " +
            "(SELECT jobNo, MAX(date) AS maxdate FROM jobStatus GROUP BY jobNo) jS ON jobStatus.jobNo = jS.jobNo AND jobStatus.date = js.maxdate " +
            "INNER JOIN staff ON updatedBy = sUsername " +
            "WHERE (status = 'COMPLETE' OR status = 'INVOICED') AND (job.jobNo LIKE '{0}%' OR cFirstName LIKE '{0}%' OR cSurname LIKE '{0}%' OR cCompany LIKE '{0}%' OR registration LIKE '{0}%')" +
            "ORDER BY status, bookingDate LIMIT {0}, {1};", equalText.Text, queryStart2, queryEnd);

        cmd = new MySqlCommand(getOrders, conn);
        sqlDa = new MySqlDataAdapter(getOrders, conn);
        dtbl = new DataTable();
        sqlDa.Fill(dtbl);

        dataGridView2.DataSource = dtbl;

        pageLabel.Text = "Page " + (queryStart / queryEnd + 1).ToString();
        pageLabel2.Text = "Page " + (queryStart2 / queryEnd + 1).ToString();

        foreach (DataGridViewRow row in dataGridView2.Rows)
        {
          try
          {
            if (row.Cells[6].Value != null)
            {
              if (row.Cells[6].Value.ToString() == "VALIDATION REQUIRED;")
              {
                row.Cells[6].Style.BackColor = Color.SkyBlue;
              }
              else if (row.Cells[6].Value.ToString() != "")
              {
                row.Cells[6].Style.BackColor = Color.Yellow;
              }
            }
          }
          catch { }
        }

        if (queryStart > 0)
        {
          upButton.Enabled = true;
        }
        else
        {
          upButton.Enabled = false;
        }
        if (dataGridView1.Rows.Count < queryEnd)
        {
          downButton.Enabled = false;
        }
        else
        {
          downButton.Enabled = true;
        }

        if (queryStart2 > 0)
        {
          upButton2.Enabled = true;
        }
        else
        {
          upButton2.Enabled = false;
        }
        if (dataGridView2.Rows.Count < queryEnd)
        {
          downButton2.Enabled = false;
        }
        else
        {
          downButton2.Enabled = true;
        }
        conn.Close();

      }
      else
      {
        refreshOrders();
      }
    }

    /*When a user wants to execute a query, they will click the execute button which will load this method.
     * Depending on the input data on the form it will generate a MYSQL statement based on that and fetch
     * the information with those parameters.
     */
    private void executeButton_Click(object sender, EventArgs e)
    {
      using (MySqlConnection conn = connectMySql())
      {

        try
        {
          conn.Open();
          MySqlCommand cmd;
          MySqlDataAdapter sqlDa;
          DataTable dtbl = new DataTable();
          String sql = "";
          String where = "";

          if (dateCheckBox.Checked)
          {
            if (where != "")
            {
              where += String.Format("AND creationDate >= '{0}' AND creationDate <= '{1}' ",
                  dateStart.Value.ToString("yyyy-MM-dd"), dateEnd.Value.ToString("yyyy-MM-dd"));
            }
            else
            {
              where = String.Format("WHERE creationDate >= '{0}' AND creationDate <= '{1}' ",
                 dateStart.Value.ToString("yyyy-MM-dd"), dateEnd.Value.ToString("yyyy-MM-dd"));
            }
          }


          sql = String.Format("SELECT jobNumber AS JobNumber, creationDate AS CreationDate, bookingDate AS BookingDate, " +
              "concat(cFirstName, ' ', cSurname) AS Customer, insurer AS InsuranceProvider, claimNumber AS ClaimNo, " +
              "registration AS Registration, percentage AS Percentage, " +
              "status AS STATUS, note AS StatusInfo, concat(s1.sFirstName, ' ' , s1.sSurname) AS StaffCreated, completedBy AS StaffCompleted FROM job " +
              "INNER JOIN customer ON customerID = cID INNER JOIN staff s1 on createdBy = s1.sID WHERE status != 'COMPLETE' && status != 'INVOICED' ORDER BY " +
              "creationDate;", where);



          if (sql != "")
          {
            cmd = new MySqlCommand(sql, conn);
            sqlDa = new MySqlDataAdapter(sql, conn);
            sqlDa.Fill(dtbl);
            dataGridView1.DataSource = dtbl;
          }
          conn.Close();
          conn.Open();

          sql = String.Format("SELECT jobNumber AS JobNumber, creationDate AS CreationDate, bookingDate AS BookingDate, " +
              "concat(cFirstName, ' ', cSurname) AS Customer, insurer AS InsuranceProvider, claimNumber AS ClaimNo, " +
              "registration AS Registration, percentage AS Percentage, " +
              "status AS STATUS, note AS StatusInfo, concat(s1.sFirstName, ' ' , s1.sSurname) AS StaffCreated, completedBy AS StaffCompleted FROM job " +
              "INNER JOIN customer ON customerID = cID INNER JOIN staff s1 on createdBy = s1.sID WHERE status = 'COMPLETE' OR STATUS = 'INVOICED' ORDER BY " +
              "creationDate;", where);



          if (sql != "")
          {
            cmd = new MySqlCommand(sql, conn);
            sqlDa = new MySqlDataAdapter(sql, conn);
            sqlDa.Fill(dtbl);
            dataGridView2.DataSource = dtbl;
          }

        }
        catch (Exception ex)
        {
          Console.WriteLine(ex.ToString());
          MessageBox.Show("Error getting selected database. If problem persists please contact the administrator.");
        }
        conn.Close();
      }
    }

    private void tabPage1_Click(object sender, EventArgs e)
    {

    }

    private void tabControl1_TabIndexChanged(object sender, EventArgs e)
    {

    }

    private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
    {
      refreshOrders();
    }
  }
}
