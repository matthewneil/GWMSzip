﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workshop_orders
{
	public partial class OrderDetails : Form
	{
		int fiOrderNo = 0;
		bool fbPageLoad = false;
		bool fbDirty = false;
		DataTable dtOrderData;
		Orders OrdersForm;
		string fsSupplierName;
		public static String itemcode = "";

		public OrderDetails(Orders frm, int iOrderNo)
		{
			InitializeComponent();
			OrdersForm = frm;
			fiOrderNo = iOrderNo;
			SetButtonState(DataAccess.FormState(this.AccessibilityObject.Name, tsSave));
		}

		private void SetButtonState(Boolean bState)
		{
		}


	private void OrderDetails_Load(object sender, EventArgs e)
		{
			fbPageLoad = false;
			fbDirty = false;
			pnlHeader.Left = GWMS.HeaderPanelPosition(pnlHeader, this);
			GetSuppliers();
			GetCategory();
			GetJobs();
			if (fiOrderNo > 0) { LoadData(fiOrderNo); }
			dgvData.CurrentCell = null;
			fbPageLoad = true;
		}
		public void LoadData (int iOrderNo)
		{
			string sSQL = "SELECT * FROM vworderitem WHERE o.OrderNo = " + iOrderNo;
			dgvData.Rows.Clear();
			dtOrderData = DataAccess.ExecuteDataTable(sSQL);
			if(dtOrderData.Rows.Count > 0)
			{
				cmbSupplier.SelectedValue = int.Parse(dtOrderData.Rows[0]["SupplierID"].ToString());
				fsSupplierName = dtOrderData.Rows[0]["SupplierName"].ToString();
				lblHeader.Text = "Order No " + iOrderNo + " - " + dtOrderData.Rows[0]["SupplierName"].ToString();
				dgvData.AllowUserToAddRows = true;
				foreach (DataRow row in dtOrderData.Rows)
				{
					if(Convert.IsDBNull(row["OrderItemNo"]) == false)
					{
						DataGridViewRow drow = (DataGridViewRow) dgvData.Rows[0].Clone();
						drow.Cells[0].Value = row["OrderItemNo"];
						drow.Cells[1].Value = row["oriQuantity"];
						drow.Cells[2].Value = row["uomName"];
						drow.Cells[4].Value = row["oriCode"];
						drow.Cells[4].Value = row["oriDescription"];
						drow.Cells[5].Value = row["oriUnitPrice"];
						drow.Cells[6].Value = row["oriTotalPrice"];
						dgvData.Rows.Add(drow);
					}
				}
				dgvData.AllowUserToAddRows = false;
			}
		}
		private void GetSuppliers()
		{
			DataTable dt = DataAccess.ExecuteDataTable("SELECT SupplierID AS 'datafield', SupplierName AS 'textfield' FROM Supplier WHERE supDisabled = 0 ORDER BY SupplierName");
			DataAccess.AddSelect(dt);
			cmbSupplier.DataSource = dt;
		}
		private void GetCategory()
		{
			DataTable dt = DataAccess.ExecuteDataTable("SELECT CategoryID AS 'datafield', catName AS 'textfield' FROM Category WHERE catGroup = 'Orders' ORDER BY catSort");
			cmbOrderGroup.DataSource = dt;
			cmbOrderGroup.SelectedIndex = 0;
		}
		private void GetJobs()
		{
			string sSQL = "SELECT JobID AS 'datafield', CONCAT(CAST(JobID AS CHAR(8)),' - ', IFNULL(c.CustomerName, 'UNKNOWN')) AS 'textfield' FROM job j LEFT JOIN customer c ON c.CustomerID = j.CustomerID " +
										"WHERE DateCreated > '" + DateTime.Now.AddMonths(-7).ToString("yyyy-MM-dd") + "' ORDER BY JobID DESC";
			DataTable dt = DataAccess.ExecuteDataTable(sSQL);
			DataAccess.AddSelect(dt);
			cmbJobNo.DataSource = dt;
			cmbJobNo.SelectedIndex = 0;
		}

		private void tsClose_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		private void cmbSupplier_SelectedIndexChanged(object sender, EventArgs e)
		{

		}
		private bool ValidateData()
		{
			if (cmbSupplier.SelectedIndex == 0)
			{
				DataAccess.ShowMessage("Please select a supplier from the list", "Missing Supplier");
				return false;
			}

			if (dgvData.Rows.Count < 2)
			{
				DataAccess.ShowMessage("The purchase order requires at least one item. Please enter item details", "Missing Item");
				return false;
			}

			foreach (DataGridViewRow row in dgvData.Rows)
			{
				if (row.IsNewRow == false)
				{
					if (Convert.IsDBNull(row.Cells[0].Value) == true)
					{
						row.Cells[0].Value = "";
						row.Cells[1].Value = "";
						row.Cells[2].Value = "ea";
						row.Cells[3].Value = "";
						row.Cells[4].Value = "";
					}
					if (decimal.Parse(row.Cells[1].Value.ToString()) == 0)
					{
						// row.Cells[1].Value = 1
						DataAccess.ShowMessage("The quantity for item number " + row.Index + 1 + " needs to be a number", "Missing Item Quantity");
						return false;
					}
					if (row.Cells[2].Value.ToString().Trim(' ') == "")
						row.Cells[2].Value = "ea";

					if (row.Cells[4].Value.ToString().Trim(' ') == "")
					{
						DataAccess.ShowMessage("The description for item number " + row.Index + 1 + " is missing", "Missing Item Description");
						return false;
					}
				}
			}
			return true;
		}
		private void CheckForChanges()
		{
			if (dtOrderData.Rows.Count == 0)
				return;
			// Check for changes
			try
			{
				if (dtOrderData.Rows[0]["SupplierName"].ToString() != cmbSupplier.Text || txtAccountNo.Text != dtOrderData.Rows[0]["ordAccountNo"].ToString() || 
					cmbJobNo.Text != dtOrderData.Rows[0]["InternalID"].ToString() || txtReference.Text != dtOrderData.Rows[0]["ordReference"].ToString() || 
					DateTime.Parse(dtpRequiredDate.Text.ToString()) != DateTime.Parse(dtOrderData.Rows[0]["ordDateRequired"].ToString()) || 
					txtInstruction.Text != dtOrderData.Rows[0]["ordInstructions"].ToString())
				{
					fbDirty = true;
					return;
				}
				// Audit Order Items
				foreach (DataRow row in dtOrderData.Rows)
				{
					foreach (DataGridViewRow row1 in dgvData.Rows)
					{
						if (row1.IsNewRow == false)
						{
							if (row["OrderItemNo"] == row1.Cells[0].Value & decimal.Parse(row1.Cells[0].Value.ToString()) > 0)
							{
								if (row1.Cells[1].Value != row["oriQuantity"] || row1.Cells[2].Value != row["UOM"] || row1.Cells[4].Value != row["oriDescription"] || row1.Cells[5].Value != row["oriUnitPrice"])
								{
									fbDirty = true;
									return;
								}
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, "OrderDetails",	System.Reflection.MethodBase.GetCurrentMethod().Name, "");
				fbDirty = true;
			}
		}
		private void dgvData_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{
		}
		private void dgvData_CellClick(object sender, DataGridViewCellEventArgs e)
		{
			FindButton(e.RowIndex, e.ColumnIndex);
		}
		private void btnFind_Click(object sender, EventArgs e)
		{
			FormManagement.ShowDialogForm(new MultiSearch(3));
			if (itemcode != "")
      {
				dgvData.Rows[dgvData.SelectedCells[0].RowIndex].Cells[3].Value = itemcode;
      }
		}
		private void dgvData_CellValueChanged(object sender, DataGridViewCellEventArgs e)
		{
			if (e.RowIndex > -1) {
				if (dgvData.Rows[e.RowIndex].Cells[1].Value != null && dgvData.Rows[e.RowIndex].Cells[5].Value != null)
				dgvData.Rows[e.RowIndex].Cells[6].Value = decimal.Parse(dgvData.Rows[e.RowIndex].Cells[1].Value.ToString()) * decimal.Parse(dgvData.Rows[e.RowIndex].Cells[5].Value.ToString());
			}
		}
		private void dgvData_UserAddedRow(object sender, DataGridViewRowEventArgs e)
		{
			if (fbPageLoad == true) 
			{
				int iIndex = e.Row.Index;
				if (iIndex > 0) { iIndex -= 1; }
				dgvData.Rows[iIndex].Cells[0].Value = 0;
				dgvData.Rows[iIndex].Cells[2].Value = "ea";
				fbDirty = true;
			}
		}

		private void dgvData_CellEnter(object sender, DataGridViewCellEventArgs e)
		{
			FindButton(e.RowIndex, e.ColumnIndex);
		}
		private void FindButton(int iRowIndex, int iColumnIndex)
		{
			btnFind.Visible = false;
			if (iRowIndex == -1) { return; }
			if (iColumnIndex == 3)
			{
				btnFind.Visible = true;
				Rectangle rect = dgvData.GetCellDisplayRectangle(3, iRowIndex, true);
				btnFind.Top = rect.Top;
				btnFind.Left = rect.Left + (rect.Width - btnFind.Width);
				btnFind.Height = rect.Height;
			}
		}

		private void dgvData_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
		{
			if (e.ColumnIndex == 4 && e.RowIndex > -1 && dgvData.Rows[e.RowIndex].Cells[3].Value != null)
			{
				//'Show Long Text
				txtLongText.Text = dgvData.Rows[e.RowIndex].Cells[3].Value.ToString();
				lblRowIndex.Text = e.RowIndex.ToString();
				pnlLongText.Visible = true;
			}
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			pnlLongText.Visible = false;
		}
		private void btnSaveLongText_Click(object sender, EventArgs e)
		{
			dgvData.Rows[int.Parse(lblRowIndex.Text.ToString())].Cells[4].Value = txtLongText.Text.ToString();
			pnlLongText.Visible = false;
		}
		private void tsSave_Click(object sender, EventArgs e)
		{
			SaveData();
		}

		private bool SaveData()
		{
			txtInstruction.Focus();
			fbDirty = false;
			bool bNewOrder = false;

			if(ValidateData() == true)
			{
				if (fiOrderNo > 0) { AuditData(); }

				//Create Header Record
				int iOrderNo = DataAccess.OrderManage(fiOrderNo, int.Parse(cmbSupplier.SelectedValue.ToString()), int.Parse(cmbJobNo.SelectedValue.ToString()), "Job", 0, 1, txtReference.Text, 
																							dtpRequiredDate.Value.ToString("yyyy-MM-dd"),txtInstruction.Text, txtAccountNo.Text, "");

			//If Error
				if (iOrderNo == -1) { }




			}
			return true;
		}
		private void AuditData()
		{
			// Audit Order changes
			if (fsSupplierName != cmbSupplier.Text)
				DataAccess.Audit(fiOrderNo, "Update", "Supplier", fsSupplierName, cmbSupplier.Text, "Order");
			if (txtAccountNo.Text != dtOrderData.Rows[0]["ordAccountNo"].ToString())
				DataAccess.Audit(fiOrderNo, "Update", "AccountNo", dtOrderData.Rows[0]["ordAccountNo"].ToString(), txtAccountNo.Text, "Order");
			if (int.Parse(cmbJobNo.Text) != int.Parse(dtOrderData.Rows[0]["QuoteID"].ToString()))
				DataAccess.Audit(fiOrderNo, "Update", "QuoteID", dtOrderData.Rows[0]["QuoteID"].ToString(), cmbJobNo.Text, "Order");
			if (txtReference.Text != dtOrderData.Rows[0]["ordReference"].ToString())
				DataAccess.Audit(fiOrderNo, "Update", "Reference", dtOrderData.Rows[0]["ordReference"].ToString(), txtReference.Text, "Order");
			if (DateTime.Parse(dtpRequiredDate.Value.ToString()) != DateTime.Parse(dtOrderData.Rows[0]["ordDateRequired"].ToString()));
				DataAccess.Audit(fiOrderNo, "Update", "RequiredDate", dtOrderData.Rows[0]["ordDateRequired"].ToString(), dtpRequiredDate.Value.ToString(), "Order");
			if (txtInstruction.Text != dtOrderData.Rows[0]["ordInstructions"].ToString())
				DataAccess.Audit(fiOrderNo, "Update", "Instructions", dtOrderData.Rows[0]["ordInstructions"].ToString(), txtInstruction.Text, "Order");

			// Audit Order Items
			foreach (DataRow row in dtOrderData.Rows)
			{
				foreach (DataGridViewRow row1 in dgvData.Rows)
				{
					if (row1.IsNewRow == false)
					{
						if (row["OrderItemNo"] == row1.Cells[0].Value & decimal.Parse(row1.Cells[0].Value.ToString()) > 0)
						{
							if (row1.Cells[1].Value != row["oriQuantity"])
								DataAccess.Audit(fiOrderNo, "Update", "Quantity", row["oriQuantity"].ToString(), row1.Cells[1].Value.ToString(), "Order");
							if (row1.Cells[2].Value != row["UOM"])
								DataAccess.Audit(fiOrderNo, "Update", "UOM", row["UOM"].ToString(), row1.Cells[2].Value.ToString(), "Order");
							if (row1.Cells[3].Value != row["oriDescription"])
								DataAccess.Audit(fiOrderNo, "Update", "Description", row["oriDescription"].ToString(), row1.Cells[3].Value.ToString(), "Order");
							if (row1.Cells[4].Value != row["oriUnitPrice"])
								DataAccess.Audit(fiOrderNo, "Update", "UnitPrice", row["oriUnitPrice"].ToString(), row1.Cells[4].Value.ToString(), "Order");
						}
					}
				}
			}
		}

    private void tsSupplier_Click(object sender, EventArgs e)
    {
			FormManagement.ShowDialogForm(new SupplierSearch(0, 1));
		}
  }
}
