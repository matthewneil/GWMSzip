﻿using System;
using System.Windows.Forms;

namespace workshop_orders
{
    partial class QuoteDetail
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
      this.pnlQuote = new System.Windows.Forms.Panel();
      this.gbComments = new System.Windows.Forms.GroupBox();
      this.txtComments = new System.Windows.Forms.TextBox();
      this.gbOther = new System.Windows.Forms.GroupBox();
      this.txtAcceptedDate = new System.Windows.Forms.TextBox();
      this.txtAcceptedPrice = new System.Windows.Forms.TextBox();
      this.label7 = new System.Windows.Forms.Label();
      this.label8 = new System.Windows.Forms.Label();
      this.gbCost = new System.Windows.Forms.GroupBox();
      this.label9 = new System.Windows.Forms.Label();
      this.txtQuotePrice = new System.Windows.Forms.TextBox();
      this.label6 = new System.Windows.Forms.Label();
      this.txtDiscount = new System.Windows.Forms.TextBox();
      this.txtMarginCost = new System.Windows.Forms.TextBox();
      this.txtTotalCost = new System.Windows.Forms.TextBox();
      this.label18 = new System.Windows.Forms.Label();
      this.label17 = new System.Windows.Forms.Label();
      this.txtMarginPercent = new System.Windows.Forms.TextBox();
      this.label22 = new System.Windows.Forms.Label();
      this.gbTravel = new System.Windows.Forms.GroupBox();
      this.btnTravel = new System.Windows.Forms.Button();
      this.label15 = new System.Windows.Forms.Label();
      this.label12 = new System.Windows.Forms.Label();
      this.nudHoursPerDay = new System.Windows.Forms.NumericUpDown();
      this.nudWorkDays = new System.Windows.Forms.NumericUpDown();
      this.nudDistance = new System.Windows.Forms.NumericUpDown();
      this.nudWorkers = new System.Windows.Forms.NumericUpDown();
      this.label13 = new System.Windows.Forms.Label();
      this.label14 = new System.Windows.Forms.Label();
      this.gbDetails = new System.Windows.Forms.GroupBox();
      this.dtpQuoted = new System.Windows.Forms.DateTimePicker();
      this.label3 = new System.Windows.Forms.Label();
      this.label31 = new System.Windows.Forms.Label();
      this.cmbType = new System.Windows.Forms.ComboBox();
      this.JobNameLabel = new System.Windows.Forms.Label();
      this.txtReference = new System.Windows.Forms.TextBox();
      this.label2 = new System.Windows.Forms.Label();
      this.txtCustomer = new System.Windows.Forms.TextBox();
      this.cmbStaff = new System.Windows.Forms.ComboBox();
      this.label1 = new System.Windows.Forms.Label();
      this.DateLabel = new System.Windows.Forms.Label();
      this.dgvProduct = new System.Windows.Forms.DataGridView();
      this.tsDetails = new System.Windows.Forms.ToolStrip();
      this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
      this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
      this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
      this.tcData = new System.Windows.Forms.TabControl();
      this.tpItems = new System.Windows.Forms.TabPage();
      this.tpContact = new System.Windows.Forms.TabPage();
      this.pnlFollowupDetails = new System.Windows.Forms.Panel();
      this.cmbFollowupType = new System.Windows.Forms.ComboBox();
      this.label4 = new System.Windows.Forms.Label();
      this.cmbReminder = new System.Windows.Forms.ComboBox();
      this.label5 = new System.Windows.Forms.Label();
      this.cbReminder = new System.Windows.Forms.CheckBox();
      this.label10 = new System.Windows.Forms.Label();
      this.label16 = new System.Windows.Forms.Label();
      this.cmbFollowupPerson = new System.Windows.Forms.ComboBox();
      this.dtpNextFollowup = new System.Windows.Forms.DateTimePicker();
      this.txtDescription = new System.Windows.Forms.RichTextBox();
      this.label11 = new System.Windows.Forms.Label();
      this.pnlFollowup = new System.Windows.Forms.Panel();
      this.dgvFollowup = new System.Windows.Forms.DataGridView();
      this.Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Message = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Type = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.tsFollowup = new System.Windows.Forms.ToolStrip();
      this.tpQuoteLetter = new System.Windows.Forms.TabPage();
      this.txtQuoteLetter = new System.Windows.Forms.RichTextBox();
      this.pnlQuoteLetterTop = new System.Windows.Forms.Panel();
      this.label19 = new System.Windows.Forms.Label();
      this.pnlHeader = new System.Windows.Forms.Panel();
      this.lblHeader = new System.Windows.Forms.Label();
      this.lblStatus = new System.Windows.Forms.Label();
      this.toolStrip1 = new System.Windows.Forms.ToolStrip();
      this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
      this.tsAddItem = new System.Windows.Forms.ToolStripButton();
      this.tsAddInstallation = new System.Windows.Forms.ToolStripButton();
      this.tsEdit = new System.Windows.Forms.ToolStripButton();
      this.tsFollowupNew = new System.Windows.Forms.ToolStripButton();
      this.tsFollowupSave = new System.Windows.Forms.ToolStripButton();
      this.btnCustomer = new System.Windows.Forms.Button();
      this.PictureBox2 = new System.Windows.Forms.PictureBox();
      this.tsBack = new System.Windows.Forms.ToolStripButton();
      this.tsSave = new System.Windows.Forms.ToolStripButton();
      this.tsPrint = new System.Windows.Forms.ToolStripDropDownButton();
      this.tsItemPrint = new System.Windows.Forms.ToolStripMenuItem();
      this.tsSummaryPrint = new System.Windows.Forms.ToolStripMenuItem();
      this.tsReports = new System.Windows.Forms.ToolStripDropDownButton();
      this.tsCutlist = new System.Windows.Forms.ToolStripMenuItem();
      this.tsComponents = new System.Windows.Forms.ToolStripMenuItem();
      this.tsItemList = new System.Windows.Forms.ToolStripMenuItem();
      this.tsStatus = new System.Windows.Forms.ToolStripDropDownButton();
      this.tsAccepted = new System.Windows.Forms.ToolStripButton();
      this.tsLost = new System.Windows.Forms.ToolStripButton();
      this.tsCancelled = new System.Windows.Forms.ToolStripButton();
      this.tsClosed = new System.Windows.Forms.ToolStripButton();
      this.tsJob = new System.Windows.Forms.ToolStripButton();
      this.chID = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chName = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chFixed = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chSash = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chComponent = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chDelete = new System.Windows.Forms.DataGridViewButtonColumn();
      this.pnlQuote.SuspendLayout();
      this.gbComments.SuspendLayout();
      this.gbOther.SuspendLayout();
      this.gbCost.SuspendLayout();
      this.gbTravel.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.nudHoursPerDay)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudWorkDays)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudDistance)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudWorkers)).BeginInit();
      this.gbDetails.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgvProduct)).BeginInit();
      this.tsDetails.SuspendLayout();
      this.tcData.SuspendLayout();
      this.tpItems.SuspendLayout();
      this.tpContact.SuspendLayout();
      this.pnlFollowupDetails.SuspendLayout();
      this.pnlFollowup.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgvFollowup)).BeginInit();
      this.tsFollowup.SuspendLayout();
      this.tpQuoteLetter.SuspendLayout();
      this.pnlQuoteLetterTop.SuspendLayout();
      this.pnlHeader.SuspendLayout();
      this.toolStrip1.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.PictureBox2)).BeginInit();
      this.SuspendLayout();
      // 
      // pnlQuote
      // 
      this.pnlQuote.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.pnlQuote.Controls.Add(this.gbComments);
      this.pnlQuote.Controls.Add(this.gbOther);
      this.pnlQuote.Controls.Add(this.gbCost);
      this.pnlQuote.Controls.Add(this.gbTravel);
      this.pnlQuote.Controls.Add(this.gbDetails);
      this.pnlQuote.Controls.Add(this.DateLabel);
      this.pnlQuote.Dock = System.Windows.Forms.DockStyle.Top;
      this.pnlQuote.Location = new System.Drawing.Point(0, 39);
      this.pnlQuote.Name = "pnlQuote";
      this.pnlQuote.Size = new System.Drawing.Size(1904, 210);
      this.pnlQuote.TabIndex = 1;
      // 
      // gbComments
      // 
      this.gbComments.Controls.Add(this.txtComments);
      this.gbComments.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbComments.ForeColor = System.Drawing.Color.Blue;
      this.gbComments.Location = new System.Drawing.Point(476, 9);
      this.gbComments.Name = "gbComments";
      this.gbComments.Size = new System.Drawing.Size(364, 189);
      this.gbComments.TabIndex = 19;
      this.gbComments.TabStop = false;
      this.gbComments.Text = "Comments";
      // 
      // txtComments
      // 
      this.txtComments.AcceptsReturn = true;
      this.txtComments.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtComments.Location = new System.Drawing.Point(6, 25);
      this.txtComments.MaxLength = 1000;
      this.txtComments.Multiline = true;
      this.txtComments.Name = "txtComments";
      this.txtComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
      this.txtComments.Size = new System.Drawing.Size(352, 158);
      this.txtComments.TabIndex = 2;
      // 
      // gbOther
      // 
      this.gbOther.Controls.Add(this.txtAcceptedDate);
      this.gbOther.Controls.Add(this.txtAcceptedPrice);
      this.gbOther.Controls.Add(this.label7);
      this.gbOther.Controls.Add(this.label8);
      this.gbOther.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbOther.ForeColor = System.Drawing.Color.Blue;
      this.gbOther.Location = new System.Drawing.Point(1353, 9);
      this.gbOther.Name = "gbOther";
      this.gbOther.Size = new System.Drawing.Size(316, 189);
      this.gbOther.TabIndex = 18;
      this.gbOther.TabStop = false;
      this.gbOther.Text = "Other Details";
      this.gbOther.Visible = false;
      // 
      // txtAcceptedDate
      // 
      this.txtAcceptedDate.BackColor = System.Drawing.Color.White;
      this.txtAcceptedDate.BorderStyle = System.Windows.Forms.BorderStyle.None;
      this.txtAcceptedDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtAcceptedDate.ForeColor = System.Drawing.Color.Green;
      this.txtAcceptedDate.Location = new System.Drawing.Point(210, 28);
      this.txtAcceptedDate.MinimumSize = new System.Drawing.Size(100, 0);
      this.txtAcceptedDate.Name = "txtAcceptedDate";
      this.txtAcceptedDate.ReadOnly = true;
      this.txtAcceptedDate.Size = new System.Drawing.Size(100, 17);
      this.txtAcceptedDate.TabIndex = 18;
      this.txtAcceptedDate.Text = "Date";
      this.txtAcceptedDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
      // 
      // txtAcceptedPrice
      // 
      this.txtAcceptedPrice.BackColor = System.Drawing.Color.White;
      this.txtAcceptedPrice.BorderStyle = System.Windows.Forms.BorderStyle.None;
      this.txtAcceptedPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtAcceptedPrice.ForeColor = System.Drawing.Color.Green;
      this.txtAcceptedPrice.Location = new System.Drawing.Point(210, 62);
      this.txtAcceptedPrice.MinimumSize = new System.Drawing.Size(100, 0);
      this.txtAcceptedPrice.Name = "txtAcceptedPrice";
      this.txtAcceptedPrice.ReadOnly = true;
      this.txtAcceptedPrice.Size = new System.Drawing.Size(100, 17);
      this.txtAcceptedPrice.TabIndex = 17;
      this.txtAcceptedPrice.Text = "$0.00";
      this.txtAcceptedPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
      // 
      // label7
      // 
      this.label7.AutoSize = true;
      this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label7.ForeColor = System.Drawing.Color.Green;
      this.label7.Location = new System.Drawing.Point(8, 60);
      this.label7.Name = "label7";
      this.label7.Size = new System.Drawing.Size(121, 18);
      this.label7.TabIndex = 8;
      this.label7.Text = "Accepted Price";
      // 
      // label8
      // 
      this.label8.AutoSize = true;
      this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
      this.label8.Location = new System.Drawing.Point(8, 30);
      this.label8.Name = "label8";
      this.label8.Size = new System.Drawing.Size(117, 18);
      this.label8.TabIndex = 7;
      this.label8.Text = "Accepted Date";
      // 
      // gbCost
      // 
      this.gbCost.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.gbCost.Controls.Add(this.label9);
      this.gbCost.Controls.Add(this.txtQuotePrice);
      this.gbCost.Controls.Add(this.label6);
      this.gbCost.Controls.Add(this.txtDiscount);
      this.gbCost.Controls.Add(this.txtMarginCost);
      this.gbCost.Controls.Add(this.txtTotalCost);
      this.gbCost.Controls.Add(this.label18);
      this.gbCost.Controls.Add(this.label17);
      this.gbCost.Controls.Add(this.txtMarginPercent);
      this.gbCost.Controls.Add(this.label22);
      this.gbCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbCost.ForeColor = System.Drawing.Color.Blue;
      this.gbCost.Location = new System.Drawing.Point(1093, 9);
      this.gbCost.Name = "gbCost";
      this.gbCost.Size = new System.Drawing.Size(254, 189);
      this.gbCost.TabIndex = 18;
      this.gbCost.TabStop = false;
      this.gbCost.Text = "Financials";
      // 
      // label9
      // 
      this.label9.AutoSize = true;
      this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
      this.label9.Location = new System.Drawing.Point(40, 30);
      this.label9.Name = "label9";
      this.label9.Size = new System.Drawing.Size(67, 18);
      this.label9.TabIndex = 14;
      this.label9.Text = "Discount";
      // 
      // txtQuotePrice
      // 
      this.txtQuotePrice.BackColor = System.Drawing.Color.White;
      this.txtQuotePrice.BorderStyle = System.Windows.Forms.BorderStyle.None;
      this.txtQuotePrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtQuotePrice.ForeColor = System.Drawing.Color.Blue;
      this.txtQuotePrice.Location = new System.Drawing.Point(137, 62);
      this.txtQuotePrice.MinimumSize = new System.Drawing.Size(100, 0);
      this.txtQuotePrice.Name = "txtQuotePrice";
      this.txtQuotePrice.ReadOnly = true;
      this.txtQuotePrice.Size = new System.Drawing.Size(100, 17);
      this.txtQuotePrice.TabIndex = 14;
      this.txtQuotePrice.Text = "$0.00";
      this.txtQuotePrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
      // 
      // label6
      // 
      this.label6.AutoSize = true;
      this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label6.ForeColor = System.Drawing.Color.Blue;
      this.label6.Location = new System.Drawing.Point(9, 60);
      this.label6.Name = "label6";
      this.label6.Size = new System.Drawing.Size(98, 18);
      this.label6.TabIndex = 13;
      this.label6.Text = "Quote Price";
      // 
      // txtDiscount
      // 
      this.txtDiscount.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtDiscount.Location = new System.Drawing.Point(137, 26);
      this.txtDiscount.MinimumSize = new System.Drawing.Size(100, 0);
      this.txtDiscount.Name = "txtDiscount";
      this.txtDiscount.Size = new System.Drawing.Size(100, 24);
      this.txtDiscount.TabIndex = 13;
      this.txtDiscount.Text = "0.00";
      this.txtDiscount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
      this.txtDiscount.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtDiscount_KeyDown);
      this.txtDiscount.Leave += new System.EventHandler(this.txtDiscount_Leave);
      // 
      // txtMarginCost
      // 
      this.txtMarginCost.BackColor = System.Drawing.Color.White;
      this.txtMarginCost.BorderStyle = System.Windows.Forms.BorderStyle.None;
      this.txtMarginCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtMarginCost.Location = new System.Drawing.Point(137, 122);
      this.txtMarginCost.MinimumSize = new System.Drawing.Size(100, 0);
      this.txtMarginCost.Name = "txtMarginCost";
      this.txtMarginCost.ReadOnly = true;
      this.txtMarginCost.Size = new System.Drawing.Size(100, 17);
      this.txtMarginCost.TabIndex = 12;
      this.txtMarginCost.Text = "$0.00";
      this.txtMarginCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
      // 
      // txtTotalCost
      // 
      this.txtTotalCost.BackColor = System.Drawing.Color.White;
      this.txtTotalCost.BorderStyle = System.Windows.Forms.BorderStyle.None;
      this.txtTotalCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtTotalCost.Location = new System.Drawing.Point(137, 92);
      this.txtTotalCost.MinimumSize = new System.Drawing.Size(100, 0);
      this.txtTotalCost.Name = "txtTotalCost";
      this.txtTotalCost.ReadOnly = true;
      this.txtTotalCost.Size = new System.Drawing.Size(100, 17);
      this.txtTotalCost.TabIndex = 11;
      this.txtTotalCost.Text = "$0.00";
      this.txtTotalCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
      // 
      // label18
      // 
      this.label18.AutoSize = true;
      this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label18.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
      this.label18.Location = new System.Drawing.Point(42, 120);
      this.label18.Name = "label18";
      this.label18.Size = new System.Drawing.Size(65, 18);
      this.label18.TabIndex = 10;
      this.label18.Text = "Margin $";
      // 
      // label17
      // 
      this.label17.AutoSize = true;
      this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label17.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
      this.label17.Location = new System.Drawing.Point(30, 90);
      this.label17.Name = "label17";
      this.label17.Size = new System.Drawing.Size(77, 18);
      this.label17.TabIndex = 9;
      this.label17.Text = "Total Cost";
      // 
      // txtMarginPercent
      // 
      this.txtMarginPercent.BackColor = System.Drawing.Color.White;
      this.txtMarginPercent.BorderStyle = System.Windows.Forms.BorderStyle.None;
      this.txtMarginPercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtMarginPercent.Location = new System.Drawing.Point(136, 152);
      this.txtMarginPercent.MinimumSize = new System.Drawing.Size(100, 0);
      this.txtMarginPercent.Name = "txtMarginPercent";
      this.txtMarginPercent.ReadOnly = true;
      this.txtMarginPercent.Size = new System.Drawing.Size(100, 17);
      this.txtMarginPercent.TabIndex = 8;
      this.txtMarginPercent.Text = "0.00%";
      this.txtMarginPercent.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
      // 
      // label22
      // 
      this.label22.AutoSize = true;
      this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label22.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
      this.label22.Location = new System.Drawing.Point(37, 150);
      this.label22.Name = "label22";
      this.label22.Size = new System.Drawing.Size(70, 18);
      this.label22.TabIndex = 7;
      this.label22.Text = "Margin %";
      // 
      // gbTravel
      // 
      this.gbTravel.Controls.Add(this.btnTravel);
      this.gbTravel.Controls.Add(this.label15);
      this.gbTravel.Controls.Add(this.label12);
      this.gbTravel.Controls.Add(this.nudHoursPerDay);
      this.gbTravel.Controls.Add(this.nudWorkDays);
      this.gbTravel.Controls.Add(this.nudDistance);
      this.gbTravel.Controls.Add(this.nudWorkers);
      this.gbTravel.Controls.Add(this.label13);
      this.gbTravel.Controls.Add(this.label14);
      this.gbTravel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbTravel.ForeColor = System.Drawing.Color.Blue;
      this.gbTravel.Location = new System.Drawing.Point(846, 9);
      this.gbTravel.Name = "gbTravel";
      this.gbTravel.Size = new System.Drawing.Size(241, 189);
      this.gbTravel.TabIndex = 14;
      this.gbTravel.TabStop = false;
      this.gbTravel.Text = "Travel Details";
      // 
      // btnTravel
      // 
      this.btnTravel.Enabled = false;
      this.btnTravel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnTravel.Location = new System.Drawing.Point(54, 150);
      this.btnTravel.Name = "btnTravel";
      this.btnTravel.Size = new System.Drawing.Size(137, 32);
      this.btnTravel.TabIndex = 17;
      this.btnTravel.Text = "Add Travel";
      this.btnTravel.UseVisualStyleBackColor = true;
      this.btnTravel.Click += new System.EventHandler(this.btnTravel_Click);
      // 
      // label15
      // 
      this.label15.AutoSize = true;
      this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label15.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
      this.label15.Location = new System.Drawing.Point(18, 124);
      this.label15.Name = "label15";
      this.label15.Size = new System.Drawing.Size(110, 18);
      this.label15.TabIndex = 16;
      this.label15.Text = "Hours Per Day:";
      // 
      // label12
      // 
      this.label12.AutoSize = true;
      this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label12.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
      this.label12.Location = new System.Drawing.Point(41, 94);
      this.label12.Name = "label12";
      this.label12.Size = new System.Drawing.Size(87, 18);
      this.label12.TabIndex = 15;
      this.label12.Text = "Work Days:";
      // 
      // nudHoursPerDay
      // 
      this.nudHoursPerDay.DecimalPlaces = 1;
      this.nudHoursPerDay.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.nudHoursPerDay.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
      this.nudHoursPerDay.Location = new System.Drawing.Point(164, 122);
      this.nudHoursPerDay.Maximum = new decimal(new int[] {
            24,
            0,
            0,
            0});
      this.nudHoursPerDay.Name = "nudHoursPerDay";
      this.nudHoursPerDay.Size = new System.Drawing.Size(64, 24);
      this.nudHoursPerDay.TabIndex = 14;
      this.nudHoursPerDay.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
      this.nudHoursPerDay.Value = new decimal(new int[] {
            8,
            0,
            0,
            0});
      // 
      // nudWorkDays
      // 
      this.nudWorkDays.DecimalPlaces = 1;
      this.nudWorkDays.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.nudWorkDays.Increment = new decimal(new int[] {
            2,
            0,
            0,
            65536});
      this.nudWorkDays.Location = new System.Drawing.Point(164, 92);
      this.nudWorkDays.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
      this.nudWorkDays.Name = "nudWorkDays";
      this.nudWorkDays.Size = new System.Drawing.Size(64, 24);
      this.nudWorkDays.TabIndex = 13;
      this.nudWorkDays.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
      this.nudWorkDays.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
      // 
      // nudDistance
      // 
      this.nudDistance.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.nudDistance.Location = new System.Drawing.Point(164, 60);
      this.nudDistance.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
      this.nudDistance.Name = "nudDistance";
      this.nudDistance.Size = new System.Drawing.Size(64, 24);
      this.nudDistance.TabIndex = 10;
      this.nudDistance.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
      // 
      // nudWorkers
      // 
      this.nudWorkers.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.nudWorkers.Location = new System.Drawing.Point(164, 27);
      this.nudWorkers.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
      this.nudWorkers.Name = "nudWorkers";
      this.nudWorkers.Size = new System.Drawing.Size(64, 24);
      this.nudWorkers.TabIndex = 9;
      this.nudWorkers.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
      this.nudWorkers.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
      // 
      // label13
      // 
      this.label13.AutoSize = true;
      this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label13.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
      this.label13.Location = new System.Drawing.Point(23, 62);
      this.label13.Name = "label13";
      this.label13.Size = new System.Drawing.Size(105, 18);
      this.label13.TabIndex = 8;
      this.label13.Text = "Distance (km):";
      // 
      // label14
      // 
      this.label14.AutoSize = true;
      this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label14.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
      this.label14.Location = new System.Drawing.Point(17, 29);
      this.label14.Name = "label14";
      this.label14.Size = new System.Drawing.Size(111, 18);
      this.label14.TabIndex = 7;
      this.label14.Text = "No. of workers:";
      // 
      // gbDetails
      // 
      this.gbDetails.Controls.Add(this.dtpQuoted);
      this.gbDetails.Controls.Add(this.label3);
      this.gbDetails.Controls.Add(this.label31);
      this.gbDetails.Controls.Add(this.cmbType);
      this.gbDetails.Controls.Add(this.btnCustomer);
      this.gbDetails.Controls.Add(this.JobNameLabel);
      this.gbDetails.Controls.Add(this.txtReference);
      this.gbDetails.Controls.Add(this.label2);
      this.gbDetails.Controls.Add(this.txtCustomer);
      this.gbDetails.Controls.Add(this.cmbStaff);
      this.gbDetails.Controls.Add(this.label1);
      this.gbDetails.Dock = System.Windows.Forms.DockStyle.Fill;
      this.gbDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbDetails.ForeColor = System.Drawing.Color.Blue;
      this.gbDetails.Location = new System.Drawing.Point(0, 0);
      this.gbDetails.Name = "gbDetails";
      this.gbDetails.Size = new System.Drawing.Size(1904, 210);
      this.gbDetails.TabIndex = 8;
      this.gbDetails.TabStop = false;
      this.gbDetails.Text = "Details";
      // 
      // dtpQuoted
      // 
      this.dtpQuoted.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.dtpQuoted.Format = System.Windows.Forms.DateTimePickerFormat.Short;
      this.dtpQuoted.Location = new System.Drawing.Point(135, 147);
      this.dtpQuoted.Name = "dtpQuoted";
      this.dtpQuoted.Size = new System.Drawing.Size(161, 24);
      this.dtpQuoted.TabIndex = 12;
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
      this.label3.Location = new System.Drawing.Point(6, 151);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(88, 18);
      this.label3.TabIndex = 11;
      this.label3.Text = "Quote Date:";
      // 
      // label31
      // 
      this.label31.AutoSize = true;
      this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label31.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
      this.label31.Location = new System.Drawing.Point(25, 120);
      this.label31.Name = "label31";
      this.label31.Size = new System.Drawing.Size(73, 18);
      this.label31.TabIndex = 10;
      this.label31.Text = "Job Type:";
      // 
      // cmbType
      // 
      this.cmbType.Enabled = false;
      this.cmbType.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbType.FormattingEnabled = true;
      this.cmbType.Location = new System.Drawing.Point(135, 115);
      this.cmbType.Name = "cmbType";
      this.cmbType.Size = new System.Drawing.Size(161, 26);
      this.cmbType.TabIndex = 3;
      this.cmbType.Text = "Retrofit";
      // 
      // JobNameLabel
      // 
      this.JobNameLabel.AutoSize = true;
      this.JobNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.JobNameLabel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
      this.JobNameLabel.Location = new System.Drawing.Point(18, 58);
      this.JobNameLabel.Name = "JobNameLabel";
      this.JobNameLabel.Size = new System.Drawing.Size(80, 18);
      this.JobNameLabel.TabIndex = 2;
      this.JobNameLabel.Text = "Reference:";
      // 
      // txtReference
      // 
      this.txtReference.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtReference.Location = new System.Drawing.Point(135, 55);
      this.txtReference.Name = "txtReference";
      this.txtReference.Size = new System.Drawing.Size(285, 24);
      this.txtReference.TabIndex = 1;
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
      this.label2.Location = new System.Drawing.Point(12, 89);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(86, 18);
      this.label2.TabIndex = 6;
      this.label2.Text = "Quoted  By:";
      // 
      // txtCustomer
      // 
      this.txtCustomer.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
      this.txtCustomer.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
      this.txtCustomer.Enabled = false;
      this.txtCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtCustomer.Location = new System.Drawing.Point(135, 25);
      this.txtCustomer.Name = "txtCustomer";
      this.txtCustomer.Size = new System.Drawing.Size(285, 24);
      this.txtCustomer.TabIndex = 2;
      this.txtCustomer.TextChanged += new System.EventHandler(this.txtCustomer_TextChanged);
      // 
      // cmbStaff
      // 
      this.cmbStaff.DisplayMember = "textfield";
      this.cmbStaff.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbStaff.FormattingEnabled = true;
      this.cmbStaff.Items.AddRange(new object[] {
            "Simon Smith",
            "Peter Howes"});
      this.cmbStaff.Location = new System.Drawing.Point(135, 85);
      this.cmbStaff.Name = "cmbStaff";
      this.cmbStaff.Size = new System.Drawing.Size(161, 26);
      this.cmbStaff.TabIndex = 4;
      this.cmbStaff.ValueMember = "datafield";
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
      this.label1.Location = new System.Drawing.Point(20, 27);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(78, 18);
      this.label1.TabIndex = 4;
      this.label1.Text = "Customer:";
      // 
      // DateLabel
      // 
      this.DateLabel.AutoSize = true;
      this.DateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.DateLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
      this.DateLabel.Location = new System.Drawing.Point(12, 9);
      this.DateLabel.Name = "DateLabel";
      this.DateLabel.Size = new System.Drawing.Size(163, 16);
      this.DateLabel.TabIndex = 0;
      this.DateLabel.Text = "ERROR: No Date Loaded";
      this.DateLabel.UseWaitCursor = true;
      // 
      // dgvProduct
      // 
      this.dgvProduct.AllowUserToAddRows = false;
      this.dgvProduct.AllowUserToDeleteRows = false;
      dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
      this.dgvProduct.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
      this.dgvProduct.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      this.dgvProduct.BorderStyle = System.Windows.Forms.BorderStyle.None;
      this.dgvProduct.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
      this.dgvProduct.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvProduct.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.chID,
            this.chName,
            this.chFixed,
            this.chSash,
            this.chComponent,
            this.chDesc,
            this.chCost,
            this.chPrice,
            this.chDelete});
      this.dgvProduct.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dgvProduct.Location = new System.Drawing.Point(3, 42);
      this.dgvProduct.Name = "dgvProduct";
      dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.dgvProduct.RowsDefaultCellStyle = dataGridViewCellStyle9;
      this.dgvProduct.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
      this.dgvProduct.Size = new System.Drawing.Size(1890, 714);
      this.dgvProduct.TabIndex = 2;
      this.dgvProduct.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvProduct_CellContentClick);
      this.dgvProduct.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.CostsDataGrid_CellDoubleClick);
      // 
      // tsDetails
      // 
      this.tsDetails.BackColor = System.Drawing.SystemColors.Control;
      this.tsDetails.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsBack,
            this.tsSave,
            this.toolStripSeparator1,
            this.tsPrint,
            this.tsReports,
            this.toolStripSeparator3,
            this.tsStatus,
            this.toolStripSeparator2,
            this.tsJob});
      this.tsDetails.Location = new System.Drawing.Point(0, 0);
      this.tsDetails.Name = "tsDetails";
      this.tsDetails.Size = new System.Drawing.Size(1904, 39);
      this.tsDetails.TabIndex = 5;
      this.tsDetails.Text = "toolStrip1";
      // 
      // toolStripSeparator1
      // 
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
      // 
      // toolStripSeparator2
      // 
      this.toolStripSeparator2.Name = "toolStripSeparator2";
      this.toolStripSeparator2.Size = new System.Drawing.Size(6, 39);
      // 
      // toolStripSeparator3
      // 
      this.toolStripSeparator3.Name = "toolStripSeparator3";
      this.toolStripSeparator3.Size = new System.Drawing.Size(6, 39);
      // 
      // tcData
      // 
      this.tcData.Controls.Add(this.tpItems);
      this.tcData.Controls.Add(this.tpContact);
      this.tcData.Controls.Add(this.tpQuoteLetter);
      this.tcData.Dock = System.Windows.Forms.DockStyle.Fill;
      this.tcData.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.tcData.ItemSize = new System.Drawing.Size(150, 25);
      this.tcData.Location = new System.Drawing.Point(0, 249);
      this.tcData.Name = "tcData";
      this.tcData.SelectedIndex = 0;
      this.tcData.Size = new System.Drawing.Size(1904, 792);
      this.tcData.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
      this.tcData.TabIndex = 12;
      // 
      // tpItems
      // 
      this.tpItems.BackColor = System.Drawing.Color.White;
      this.tpItems.Controls.Add(this.dgvProduct);
      this.tpItems.Controls.Add(this.toolStrip1);
      this.tpItems.Location = new System.Drawing.Point(4, 29);
      this.tpItems.Name = "tpItems";
      this.tpItems.Padding = new System.Windows.Forms.Padding(3);
      this.tpItems.Size = new System.Drawing.Size(1896, 759);
      this.tpItems.TabIndex = 0;
      this.tpItems.Text = "Quote Items";
      // 
      // tpContact
      // 
      this.tpContact.BackColor = System.Drawing.Color.White;
      this.tpContact.Controls.Add(this.pnlFollowupDetails);
      this.tpContact.Controls.Add(this.pnlFollowup);
      this.tpContact.Controls.Add(this.tsFollowup);
      this.tpContact.Location = new System.Drawing.Point(4, 29);
      this.tpContact.Name = "tpContact";
      this.tpContact.Padding = new System.Windows.Forms.Padding(3);
      this.tpContact.Size = new System.Drawing.Size(1896, 759);
      this.tpContact.TabIndex = 1;
      this.tpContact.Text = "Followup";
      this.tpContact.Click += new System.EventHandler(this.tpContact_Click);
      // 
      // pnlFollowupDetails
      // 
      this.pnlFollowupDetails.Controls.Add(this.cmbFollowupType);
      this.pnlFollowupDetails.Controls.Add(this.label4);
      this.pnlFollowupDetails.Controls.Add(this.cmbReminder);
      this.pnlFollowupDetails.Controls.Add(this.label5);
      this.pnlFollowupDetails.Controls.Add(this.cbReminder);
      this.pnlFollowupDetails.Controls.Add(this.label10);
      this.pnlFollowupDetails.Controls.Add(this.label16);
      this.pnlFollowupDetails.Controls.Add(this.cmbFollowupPerson);
      this.pnlFollowupDetails.Controls.Add(this.dtpNextFollowup);
      this.pnlFollowupDetails.Controls.Add(this.txtDescription);
      this.pnlFollowupDetails.Controls.Add(this.label11);
      this.pnlFollowupDetails.Dock = System.Windows.Forms.DockStyle.Top;
      this.pnlFollowupDetails.Enabled = false;
      this.pnlFollowupDetails.Location = new System.Drawing.Point(3, 42);
      this.pnlFollowupDetails.Name = "pnlFollowupDetails";
      this.pnlFollowupDetails.Size = new System.Drawing.Size(1890, 381);
      this.pnlFollowupDetails.TabIndex = 17;
      // 
      // cmbFollowupType
      // 
      this.cmbFollowupType.DisplayMember = "textfield";
      this.cmbFollowupType.FormattingEnabled = true;
      this.cmbFollowupType.Items.AddRange(new object[] {
            "Phone",
            "Email",
            "Text"});
      this.cmbFollowupType.Location = new System.Drawing.Point(156, 16);
      this.cmbFollowupType.Name = "cmbFollowupType";
      this.cmbFollowupType.Size = new System.Drawing.Size(121, 28);
      this.cmbFollowupType.TabIndex = 3;
      this.cmbFollowupType.ValueMember = "datafield";
      // 
      // label4
      // 
      this.label4.AutoSize = true;
      this.label4.Location = new System.Drawing.Point(32, 19);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(114, 20);
      this.label4.TabIndex = 1;
      this.label4.Text = "Followup Type:";
      // 
      // cmbReminder
      // 
      this.cmbReminder.FormattingEnabled = true;
      this.cmbReminder.Location = new System.Drawing.Point(177, 332);
      this.cmbReminder.Name = "cmbReminder";
      this.cmbReminder.Size = new System.Drawing.Size(457, 28);
      this.cmbReminder.TabIndex = 14;
      // 
      // label5
      // 
      this.label5.AutoSize = true;
      this.label5.Location = new System.Drawing.Point(16, 51);
      this.label5.Name = "label5";
      this.label5.Size = new System.Drawing.Size(130, 20);
      this.label5.TabIndex = 4;
      this.label5.Text = "Followup Person:";
      // 
      // cbReminder
      // 
      this.cbReminder.AutoSize = true;
      this.cbReminder.Location = new System.Drawing.Point(154, 339);
      this.cbReminder.Name = "cbReminder";
      this.cbReminder.Size = new System.Drawing.Size(15, 14);
      this.cbReminder.TabIndex = 13;
      this.cbReminder.UseVisualStyleBackColor = true;
      // 
      // label10
      // 
      this.label10.AutoSize = true;
      this.label10.Location = new System.Drawing.Point(53, 82);
      this.label10.Name = "label10";
      this.label10.Size = new System.Drawing.Size(93, 20);
      this.label10.TabIndex = 5;
      this.label10.Text = "Description:";
      // 
      // label16
      // 
      this.label16.AutoSize = true;
      this.label16.Location = new System.Drawing.Point(23, 335);
      this.label16.Name = "label16";
      this.label16.Size = new System.Drawing.Size(125, 20);
      this.label16.TabIndex = 11;
      this.label16.Text = "Email Reminder:";
      // 
      // cmbFollowupPerson
      // 
      this.cmbFollowupPerson.Enabled = false;
      this.cmbFollowupPerson.FormattingEnabled = true;
      this.cmbFollowupPerson.Location = new System.Drawing.Point(156, 48);
      this.cmbFollowupPerson.Name = "cmbFollowupPerson";
      this.cmbFollowupPerson.Size = new System.Drawing.Size(385, 28);
      this.cmbFollowupPerson.TabIndex = 6;
      // 
      // dtpNextFollowup
      // 
      this.dtpNextFollowup.Format = System.Windows.Forms.DateTimePickerFormat.Short;
      this.dtpNextFollowup.Location = new System.Drawing.Point(156, 288);
      this.dtpNextFollowup.Name = "dtpNextFollowup";
      this.dtpNextFollowup.Size = new System.Drawing.Size(169, 26);
      this.dtpNextFollowup.TabIndex = 10;
      this.dtpNextFollowup.ValueChanged += new System.EventHandler(this.dtpNextFollowup_ValueChanged);
      // 
      // txtDescription
      // 
      this.txtDescription.Location = new System.Drawing.Point(156, 82);
      this.txtDescription.Name = "txtDescription";
      this.txtDescription.Size = new System.Drawing.Size(478, 190);
      this.txtDescription.TabIndex = 7;
      this.txtDescription.Text = "";
      // 
      // label11
      // 
      this.label11.AutoSize = true;
      this.label11.Location = new System.Drawing.Point(34, 293);
      this.label11.Name = "label11";
      this.label11.Size = new System.Drawing.Size(112, 20);
      this.label11.TabIndex = 9;
      this.label11.Text = "Next Followup:";
      // 
      // pnlFollowup
      // 
      this.pnlFollowup.Controls.Add(this.dgvFollowup);
      this.pnlFollowup.Dock = System.Windows.Forms.DockStyle.Bottom;
      this.pnlFollowup.Location = new System.Drawing.Point(3, 533);
      this.pnlFollowup.Name = "pnlFollowup";
      this.pnlFollowup.Size = new System.Drawing.Size(1890, 223);
      this.pnlFollowup.TabIndex = 16;
      // 
      // dgvFollowup
      // 
      this.dgvFollowup.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      this.dgvFollowup.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvFollowup.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Date,
            this.Message,
            this.Type});
      this.dgvFollowup.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dgvFollowup.Location = new System.Drawing.Point(0, 0);
      this.dgvFollowup.Name = "dgvFollowup";
      this.dgvFollowup.Size = new System.Drawing.Size(1890, 223);
      this.dgvFollowup.TabIndex = 15;
      // 
      // Date
      // 
      this.Date.DataPropertyName = "qcDate";
      this.Date.HeaderText = "Date";
      this.Date.Name = "Date";
      this.Date.ReadOnly = true;
      this.Date.Width = 170;
      // 
      // Message
      // 
      this.Message.DataPropertyName = "qcDescription";
      this.Message.HeaderText = "Message";
      this.Message.Name = "Message";
      this.Message.ReadOnly = true;
      this.Message.Width = 800;
      // 
      // Type
      // 
      this.Type.DataPropertyName = "ctName";
      this.Type.HeaderText = "Type";
      this.Type.Name = "Type";
      this.Type.ReadOnly = true;
      this.Type.Width = 150;
      // 
      // tsFollowup
      // 
      this.tsFollowup.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsFollowupNew,
            this.tsFollowupSave});
      this.tsFollowup.Location = new System.Drawing.Point(3, 3);
      this.tsFollowup.Name = "tsFollowup";
      this.tsFollowup.Size = new System.Drawing.Size(1890, 39);
      this.tsFollowup.TabIndex = 0;
      this.tsFollowup.Text = "toolStrip2";
      // 
      // tpQuoteLetter
      // 
      this.tpQuoteLetter.Controls.Add(this.txtQuoteLetter);
      this.tpQuoteLetter.Controls.Add(this.pnlQuoteLetterTop);
      this.tpQuoteLetter.Location = new System.Drawing.Point(4, 29);
      this.tpQuoteLetter.Name = "tpQuoteLetter";
      this.tpQuoteLetter.Padding = new System.Windows.Forms.Padding(3);
      this.tpQuoteLetter.Size = new System.Drawing.Size(1896, 759);
      this.tpQuoteLetter.TabIndex = 2;
      this.tpQuoteLetter.Text = "Quote Letter";
      this.tpQuoteLetter.UseVisualStyleBackColor = true;
      // 
      // txtQuoteLetter
      // 
      this.txtQuoteLetter.Dock = System.Windows.Forms.DockStyle.Fill;
      this.txtQuoteLetter.Location = new System.Drawing.Point(3, 35);
      this.txtQuoteLetter.MaxLength = 5000;
      this.txtQuoteLetter.Name = "txtQuoteLetter";
      this.txtQuoteLetter.Size = new System.Drawing.Size(1890, 721);
      this.txtQuoteLetter.TabIndex = 0;
      this.txtQuoteLetter.Text = "";
      // 
      // pnlQuoteLetterTop
      // 
      this.pnlQuoteLetterTop.Controls.Add(this.label19);
      this.pnlQuoteLetterTop.Dock = System.Windows.Forms.DockStyle.Top;
      this.pnlQuoteLetterTop.Location = new System.Drawing.Point(3, 3);
      this.pnlQuoteLetterTop.Name = "pnlQuoteLetterTop";
      this.pnlQuoteLetterTop.Size = new System.Drawing.Size(1890, 32);
      this.pnlQuoteLetterTop.TabIndex = 1;
      // 
      // label19
      // 
      this.label19.AutoSize = true;
      this.label19.Location = new System.Drawing.Point(8, 6);
      this.label19.Name = "label19";
      this.label19.Size = new System.Drawing.Size(363, 20);
      this.label19.TabIndex = 0;
      this.label19.Text = "Please enter information to appear on Quote letter";
      // 
      // pnlHeader
      // 
      this.pnlHeader.BackColor = System.Drawing.SystemColors.Control;
      this.pnlHeader.Controls.Add(this.lblHeader);
      this.pnlHeader.Controls.Add(this.PictureBox2);
      this.pnlHeader.Location = new System.Drawing.Point(1055, 2);
      this.pnlHeader.Name = "pnlHeader";
      this.pnlHeader.Size = new System.Drawing.Size(350, 32);
      this.pnlHeader.TabIndex = 79;
      // 
      // lblHeader
      // 
      this.lblHeader.AutoSize = true;
      this.lblHeader.BackColor = System.Drawing.SystemColors.Control;
      this.lblHeader.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblHeader.ForeColor = System.Drawing.Color.Black;
      this.lblHeader.Location = new System.Drawing.Point(4, 5);
      this.lblHeader.MinimumSize = new System.Drawing.Size(310, 0);
      this.lblHeader.Name = "lblHeader";
      this.lblHeader.Size = new System.Drawing.Size(310, 23);
      this.lblHeader.TabIndex = 18;
      this.lblHeader.Text = "Quote Number";
      this.lblHeader.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // lblStatus
      // 
      this.lblStatus.AutoSize = true;
      this.lblStatus.BackColor = System.Drawing.SystemColors.Control;
      this.lblStatus.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblStatus.ForeColor = System.Drawing.Color.Black;
      this.lblStatus.Location = new System.Drawing.Point(791, 7);
      this.lblStatus.MinimumSize = new System.Drawing.Size(200, 0);
      this.lblStatus.Name = "lblStatus";
      this.lblStatus.Size = new System.Drawing.Size(200, 23);
      this.lblStatus.TabIndex = 80;
      this.lblStatus.Text = "New";
      this.lblStatus.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
      // 
      // toolStrip1
      // 
      this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsAddItem,
            this.tsAddInstallation,
            this.toolStripSeparator4,
            this.tsEdit});
      this.toolStrip1.Location = new System.Drawing.Point(3, 3);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new System.Drawing.Size(1890, 39);
      this.toolStrip1.TabIndex = 3;
      this.toolStrip1.Text = "toolStrip1";
      // 
      // toolStripSeparator4
      // 
      this.toolStripSeparator4.Name = "toolStripSeparator4";
      this.toolStripSeparator4.Size = new System.Drawing.Size(6, 39);
      // 
      // tsAddItem
      // 
      this.tsAddItem.Enabled = false;
      this.tsAddItem.Image = global::workshop_orders.Properties.Resources.addnew;
      this.tsAddItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsAddItem.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsAddItem.Name = "tsAddItem";
      this.tsAddItem.Size = new System.Drawing.Size(92, 36);
      this.tsAddItem.Text = "Add Item";
      this.tsAddItem.Click += new System.EventHandler(this.tsAddItem_Click);
      // 
      // tsAddInstallation
      // 
      this.tsAddInstallation.Enabled = false;
      this.tsAddInstallation.Image = global::workshop_orders.Properties.Resources.labour_32;
      this.tsAddInstallation.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsAddInstallation.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsAddInstallation.Name = "tsAddInstallation";
      this.tsAddInstallation.Size = new System.Drawing.Size(126, 36);
      this.tsAddInstallation.Text = "Add Installation";
      this.tsAddInstallation.Click += new System.EventHandler(this.tsAddInstallation_Click);
      // 
      // tsEdit
      // 
      this.tsEdit.Enabled = false;
      this.tsEdit.Image = global::workshop_orders.Properties.Resources.edit;
      this.tsEdit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsEdit.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsEdit.Name = "tsEdit";
      this.tsEdit.Size = new System.Drawing.Size(63, 36);
      this.tsEdit.Text = "Edit";
      this.tsEdit.Click += new System.EventHandler(this.tsEdit_Click);
      // 
      // tsFollowupNew
      // 
      this.tsFollowupNew.Image = global::workshop_orders.Properties.Resources.addnew;
      this.tsFollowupNew.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsFollowupNew.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsFollowupNew.Name = "tsFollowupNew";
      this.tsFollowupNew.Size = new System.Drawing.Size(67, 36);
      this.tsFollowupNew.Text = "New";
      this.tsFollowupNew.Click += new System.EventHandler(this.tsFollowupNew_Click);
      // 
      // tsFollowupSave
      // 
      this.tsFollowupSave.Image = global::workshop_orders.Properties.Resources.save;
      this.tsFollowupSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsFollowupSave.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsFollowupSave.Name = "tsFollowupSave";
      this.tsFollowupSave.Size = new System.Drawing.Size(67, 36);
      this.tsFollowupSave.Text = "Save";
      this.tsFollowupSave.Click += new System.EventHandler(this.tsFollowupSave_Click);
      // 
      // btnCustomer
      // 
      this.btnCustomer.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnCustomer.ForeColor = System.Drawing.Color.Lime;
      this.btnCustomer.Image = global::workshop_orders.Properties.Resources.customers32;
      this.btnCustomer.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
      this.btnCustomer.Location = new System.Drawing.Point(423, 22);
      this.btnCustomer.Margin = new System.Windows.Forms.Padding(0);
      this.btnCustomer.Name = "btnCustomer";
      this.btnCustomer.Size = new System.Drawing.Size(32, 32);
      this.btnCustomer.TabIndex = 7;
      this.btnCustomer.TextAlign = System.Drawing.ContentAlignment.BottomRight;
      this.btnCustomer.UseVisualStyleBackColor = false;
      this.btnCustomer.Click += new System.EventHandler(this.AddCustomerButton_Click);
      // 
      // PictureBox2
      // 
      this.PictureBox2.Image = global::workshop_orders.Properties.Resources.product32;
      this.PictureBox2.Location = new System.Drawing.Point(318, 0);
      this.PictureBox2.Name = "PictureBox2";
      this.PictureBox2.Size = new System.Drawing.Size(32, 32);
      this.PictureBox2.TabIndex = 17;
      this.PictureBox2.TabStop = false;
      // 
      // tsBack
      // 
      this.tsBack.Image = global::workshop_orders.Properties.Resources.back;
      this.tsBack.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsBack.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsBack.Name = "tsBack";
      this.tsBack.Size = new System.Drawing.Size(72, 36);
      this.tsBack.Text = "Close";
      this.tsBack.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      this.tsBack.Click += new System.EventHandler(this.tsBack_Click);
      // 
      // tsSave
      // 
      this.tsSave.Image = global::workshop_orders.Properties.Resources.save;
      this.tsSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsSave.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsSave.Name = "tsSave";
      this.tsSave.Size = new System.Drawing.Size(67, 36);
      this.tsSave.Text = "Save";
      this.tsSave.Click += new System.EventHandler(this.tsSave_Click);
      // 
      // tsPrint
      // 
      this.tsPrint.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsItemPrint,
            this.tsSummaryPrint});
      this.tsPrint.Enabled = false;
      this.tsPrint.Image = global::workshop_orders.Properties.Resources.preview;
      this.tsPrint.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsPrint.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsPrint.Name = "tsPrint";
      this.tsPrint.Size = new System.Drawing.Size(129, 36);
      this.tsPrint.Text = "Preview Quote";
      this.tsPrint.ToolTipText = "Preview Quote";
      // 
      // tsItemPrint
      // 
      this.tsItemPrint.Image = global::workshop_orders.Properties.Resources.quote;
      this.tsItemPrint.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsItemPrint.Name = "tsItemPrint";
      this.tsItemPrint.RightToLeft = System.Windows.Forms.RightToLeft.No;
      this.tsItemPrint.Size = new System.Drawing.Size(177, 38);
      this.tsItemPrint.Text = "Itemized Quote";
      this.tsItemPrint.Click += new System.EventHandler(this.tsItemPrint_Click);
      // 
      // tsSummaryPrint
      // 
      this.tsSummaryPrint.Image = global::workshop_orders.Properties.Resources.report32;
      this.tsSummaryPrint.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsSummaryPrint.Name = "tsSummaryPrint";
      this.tsSummaryPrint.Size = new System.Drawing.Size(177, 38);
      this.tsSummaryPrint.Text = "Summary Quote";
      this.tsSummaryPrint.Click += new System.EventHandler(this.tsSummaryPrint_Click);
      // 
      // tsReports
      // 
      this.tsReports.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsCutlist,
            this.tsComponents,
            this.tsItemList});
      this.tsReports.Enabled = false;
      this.tsReports.Image = global::workshop_orders.Properties.Resources.report32;
      this.tsReports.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsReports.Name = "tsReports";
      this.tsReports.Size = new System.Drawing.Size(92, 36);
      this.tsReports.Text = "Reports";
      // 
      // tsCutlist
      // 
      this.tsCutlist.Image = global::workshop_orders.Properties.Resources.quote;
      this.tsCutlist.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsCutlist.Name = "tsCutlist";
      this.tsCutlist.Size = new System.Drawing.Size(159, 38);
      this.tsCutlist.Text = "Cut List";
      this.tsCutlist.Click += new System.EventHandler(this.tsCutlist_Click);
      // 
      // tsComponents
      // 
      this.tsComponents.Image = global::workshop_orders.Properties.Resources.labour_32;
      this.tsComponents.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsComponents.Name = "tsComponents";
      this.tsComponents.Size = new System.Drawing.Size(159, 38);
      this.tsComponents.Text = "Components";
      this.tsComponents.Click += new System.EventHandler(this.tsComponents_Click_1);
      // 
      // tsItemList
      // 
      this.tsItemList.Image = global::workshop_orders.Properties.Resources.nav_panel32;
      this.tsItemList.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsItemList.Name = "tsItemList";
      this.tsItemList.Size = new System.Drawing.Size(159, 38);
      this.tsItemList.Text = "Item List";
      this.tsItemList.Click += new System.EventHandler(this.tsItemList_Click);
      // 
      // tsStatus
      // 
      this.tsStatus.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsAccepted,
            this.tsLost,
            this.tsCancelled,
            this.tsClosed});
      this.tsStatus.Enabled = false;
      this.tsStatus.Image = global::workshop_orders.Properties.Resources.discgroup32;
      this.tsStatus.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsStatus.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsStatus.Name = "tsStatus";
      this.tsStatus.Size = new System.Drawing.Size(84, 36);
      this.tsStatus.Text = "Status";
      // 
      // tsAccepted
      // 
      this.tsAccepted.Image = global::workshop_orders.Properties.Resources.tick32;
      this.tsAccepted.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsAccepted.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsAccepted.Name = "tsAccepted";
      this.tsAccepted.Size = new System.Drawing.Size(93, 36);
      this.tsAccepted.Text = "Accepted";
      this.tsAccepted.Click += new System.EventHandler(this.tsAccepted_Click);
      // 
      // tsLost
      // 
      this.tsLost.Image = global::workshop_orders.Properties.Resources.cross32;
      this.tsLost.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsLost.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsLost.Name = "tsLost";
      this.tsLost.Size = new System.Drawing.Size(65, 36);
      this.tsLost.Text = "Lost";
      this.tsLost.Click += new System.EventHandler(this.tsLost_Click);
      // 
      // tsCancelled
      // 
      this.tsCancelled.Image = global::workshop_orders.Properties.Resources.cancel32;
      this.tsCancelled.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsCancelled.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsCancelled.Name = "tsCancelled";
      this.tsCancelled.Size = new System.Drawing.Size(95, 36);
      this.tsCancelled.Text = "Cancelled";
      this.tsCancelled.Click += new System.EventHandler(this.tsCancelled_Click);
      // 
      // tsClosed
      // 
      this.tsClosed.Image = global::workshop_orders.Properties.Resources.close_all;
      this.tsClosed.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsClosed.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsClosed.Name = "tsClosed";
      this.tsClosed.Size = new System.Drawing.Size(79, 36);
      this.tsClosed.Text = "Closed";
      this.tsClosed.Click += new System.EventHandler(this.tsClosed_Click);
      // 
      // tsJob
      // 
      this.tsJob.Enabled = false;
      this.tsJob.Image = global::workshop_orders.Properties.Resources.copy32;
      this.tsJob.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsJob.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsJob.Name = "tsJob";
      this.tsJob.Size = new System.Drawing.Size(98, 36);
      this.tsJob.Text = "Create Job";
      this.tsJob.Click += new System.EventHandler(this.tsJob_Click);
      // 
      // chID
      // 
      this.chID.DataPropertyName = "QuoteItemGroupID";
      dataGridViewCellStyle2.Format = "N0";
      this.chID.DefaultCellStyle = dataGridViewCellStyle2;
      this.chID.HeaderText = "ID";
      this.chID.Name = "chID";
      this.chID.ReadOnly = true;
      this.chID.Visible = false;
      // 
      // chName
      // 
      this.chName.DataPropertyName = "GroupName";
      this.chName.HeaderText = "Item Name";
      this.chName.Name = "chName";
      this.chName.ReadOnly = true;
      this.chName.Width = 250;
      // 
      // chFixed
      // 
      this.chFixed.DataPropertyName = "FixedGlass";
      dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
      dataGridViewCellStyle3.Format = "N0";
      dataGridViewCellStyle3.NullValue = "0";
      this.chFixed.DefaultCellStyle = dataGridViewCellStyle3;
      this.chFixed.HeaderText = "Fixed";
      this.chFixed.Name = "chFixed";
      this.chFixed.ReadOnly = true;
      // 
      // chSash
      // 
      this.chSash.DataPropertyName = "SashGlass";
      dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
      dataGridViewCellStyle4.Format = "N0";
      dataGridViewCellStyle4.NullValue = "0";
      this.chSash.DefaultCellStyle = dataGridViewCellStyle4;
      this.chSash.HeaderText = "Sash";
      this.chSash.Name = "chSash";
      this.chSash.ReadOnly = true;
      // 
      // chComponent
      // 
      this.chComponent.DataPropertyName = "Components";
      dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
      dataGridViewCellStyle5.Format = "N0";
      dataGridViewCellStyle5.NullValue = "0";
      this.chComponent.DefaultCellStyle = dataGridViewCellStyle5;
      this.chComponent.HeaderText = "Component";
      this.chComponent.Name = "chComponent";
      this.chComponent.ReadOnly = true;
      // 
      // chDesc
      // 
      this.chDesc.DataPropertyName = "description";
      this.chDesc.HeaderText = "Description";
      this.chDesc.Name = "chDesc";
      this.chDesc.ReadOnly = true;
      this.chDesc.Width = 550;
      // 
      // chCost
      // 
      this.chCost.DataPropertyName = "CostPrice";
      dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
      dataGridViewCellStyle6.Format = "C2";
      dataGridViewCellStyle6.NullValue = "0.00";
      this.chCost.DefaultCellStyle = dataGridViewCellStyle6;
      this.chCost.HeaderText = "Cost Price";
      this.chCost.Name = "chCost";
      this.chCost.ReadOnly = true;
      this.chCost.Width = 120;
      // 
      // chPrice
      // 
      this.chPrice.DataPropertyName = "QuotePrice";
      dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
      dataGridViewCellStyle7.Format = "C2";
      dataGridViewCellStyle7.NullValue = "0.00";
      this.chPrice.DefaultCellStyle = dataGridViewCellStyle7;
      this.chPrice.HeaderText = "Quote Price";
      this.chPrice.Name = "chPrice";
      this.chPrice.ReadOnly = true;
      this.chPrice.Width = 120;
      // 
      // chDelete
      // 
      dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
      dataGridViewCellStyle8.NullValue = "Delete";
      this.chDelete.DefaultCellStyle = dataGridViewCellStyle8;
      this.chDelete.HeaderText = "";
      this.chDelete.Name = "chDelete";
      // 
      // QuoteDetail
      // 
      this.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
      this.ClientSize = new System.Drawing.Size(1904, 1041);
      this.ControlBox = false;
      this.Controls.Add(this.tcData);
      this.Controls.Add(this.pnlQuote);
      this.Controls.Add(this.lblStatus);
      this.Controls.Add(this.pnlHeader);
      this.Controls.Add(this.tsDetails);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.Name = "QuoteDetail";
      this.ShowIcon = false;
      this.ShowInTaskbar = false;
      this.Text = "BMS - Quote Details";
      this.Load += new System.EventHandler(this.QuoteDetail_Load);
      this.pnlQuote.ResumeLayout(false);
      this.pnlQuote.PerformLayout();
      this.gbComments.ResumeLayout(false);
      this.gbComments.PerformLayout();
      this.gbOther.ResumeLayout(false);
      this.gbOther.PerformLayout();
      this.gbCost.ResumeLayout(false);
      this.gbCost.PerformLayout();
      this.gbTravel.ResumeLayout(false);
      this.gbTravel.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.nudHoursPerDay)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudWorkDays)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudDistance)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudWorkers)).EndInit();
      this.gbDetails.ResumeLayout(false);
      this.gbDetails.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgvProduct)).EndInit();
      this.tsDetails.ResumeLayout(false);
      this.tsDetails.PerformLayout();
      this.tcData.ResumeLayout(false);
      this.tpItems.ResumeLayout(false);
      this.tpItems.PerformLayout();
      this.tpContact.ResumeLayout(false);
      this.tpContact.PerformLayout();
      this.pnlFollowupDetails.ResumeLayout(false);
      this.pnlFollowupDetails.PerformLayout();
      this.pnlFollowup.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.dgvFollowup)).EndInit();
      this.tsFollowup.ResumeLayout(false);
      this.tsFollowup.PerformLayout();
      this.tpQuoteLetter.ResumeLayout(false);
      this.pnlQuoteLetterTop.ResumeLayout(false);
      this.pnlQuoteLetterTop.PerformLayout();
      this.pnlHeader.ResumeLayout(false);
      this.pnlHeader.PerformLayout();
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.PictureBox2)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

        }

        #endregion
        private Panel pnlQuote;
        private Label DateLabel;
        private TextBox txtReference;
        private Label label1;
        private TextBox txtCustomer;
        private Label JobNameLabel;
        private GroupBox gbDetails;
        private Label label2;
        private ComboBox cmbStaff;
        private GroupBox gbTravel;
        private Label label15;
        private Label label12;
        private NumericUpDown nudHoursPerDay;
        private NumericUpDown nudWorkDays;
        private NumericUpDown nudDistance;
        private NumericUpDown nudWorkers;
        private Label label13;
        private Label label14;
        private DataGridView dgvProduct;
        private GroupBox gbCost;
        private TextBox txtMarginCost;
        private TextBox txtTotalCost;
        private Label label18;
        private Label label17;
        private TextBox txtMarginPercent;
        private Label label22;
        private Button btnCustomer;
        private Label label31;
        private ComboBox cmbType;
        private ToolStrip tsDetails;
        private ToolStripButton tsBack;
        private ToolStripButton tsSave;
		private GroupBox gbOther;
		private Label label7;
		private Label label8;
		private DateTimePicker dtpQuoted;
		private Label label3;
		private TabControl tcData;
		private TabPage tpItems;
		private TabPage tpContact;
		internal Panel pnlHeader;
		internal Label lblHeader;
		internal PictureBox PictureBox2;
		private Label label9;
		private TextBox txtQuotePrice;
		private Label label6;
		private TextBox txtDiscount;
		internal ToolStripDropDownButton tsStatus;
		internal ToolStripButton tsAccepted;
		internal ToolStripButton tsLost;
		internal ToolStripButton tsCancelled;
		internal ToolStripButton tsClosed;
		private TextBox txtAcceptedDate;
		private TextBox txtAcceptedPrice;
		internal Label lblStatus;
		private GroupBox gbComments;
		private TextBox txtComments;
		private Button btnTravel;
		private ToolStripDropDownButton tsReports;
		private ToolStripMenuItem tsComponents;
		private ToolStripMenuItem tsItemList;
    private ToolStrip tsFollowup;
    private ToolStripButton tsFollowupNew;
    private ToolStripButton tsFollowupSave;
    private Label label11;
    private RichTextBox txtDescription;
    private ComboBox cmbFollowupPerson;
    private Label label10;
    private Label label5;
    private ComboBox cmbFollowupType;
    private Label label4;
    private Panel pnlFollowup;
    private DataGridView dgvFollowup;
    private ComboBox cmbReminder;
    private CheckBox cbReminder;
    private Label label16;
    private DateTimePicker dtpNextFollowup;
    private Panel pnlFollowupDetails;
    private DataGridViewTextBoxColumn Date;
    private DataGridViewTextBoxColumn Message;
    private DataGridViewTextBoxColumn Type;
    private TabPage tpQuoteLetter;
    private RichTextBox txtQuoteLetter;
    private Panel pnlQuoteLetterTop;
    private Label label19;
    private ToolStripMenuItem tsCutlist;
    private ToolStripDropDownButton tsPrint;
    private ToolStripMenuItem tsItemPrint;
    private ToolStripMenuItem tsSummaryPrint;
    private ToolStripSeparator toolStripSeparator1;
    private ToolStripSeparator toolStripSeparator2;
    private ToolStripSeparator toolStripSeparator3;
    private ToolStripButton tsJob;
    private ToolStrip toolStrip1;
    private ToolStripButton tsAddItem;
    private ToolStripButton tsEdit;
    private ToolStripButton tsAddInstallation;
    private ToolStripSeparator toolStripSeparator4;
    private DataGridViewTextBoxColumn chID;
    private DataGridViewTextBoxColumn chName;
    private DataGridViewTextBoxColumn chFixed;
    private DataGridViewTextBoxColumn chSash;
    private DataGridViewTextBoxColumn chComponent;
    private DataGridViewTextBoxColumn chDesc;
    private DataGridViewTextBoxColumn chCost;
    private DataGridViewTextBoxColumn chPrice;
    private DataGridViewButtonColumn chDelete;
  }
}

