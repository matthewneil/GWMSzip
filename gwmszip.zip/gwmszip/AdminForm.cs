﻿using DocumentFormat.OpenXml.Drawing;
using MySql.Data.MySqlClient;
//using MySql.Data.X.XDevAPI.Common;
using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Web.UI;
using System.Web.UI.WebControls.WebParts;
using System.Windows.Forms;
using System.IO;

namespace workshop_orders
{
  /*This is a form is view all the created jobs in the database*
   * This data can a queried and filter so you can only display the job you want to see*/
  public partial class AdminForm : Form
  {
    private bool update = false;
    private string jobNumber;
    private String code;
    private String name;

    /*A method to connect to the GoreGlassJob database*/
    public MySqlConnection connectMySql()
    {
      using (MySqlConnection conn = new MySqlConnection(GWMS.connStr))
      {
        try
        {
          Console.WriteLine("Connecting to MySQL...");
          return conn;
        }
        catch (Exception ex)
        {
          MessageBox.Show("Error connecting to server, please contact the administrator.", "Error!");
          return null;
        }
      }
    }

    private DateTime RoundUp(DateTime dt, TimeSpan d)
    {
      return new DateTime((dt.Ticks + d.Ticks - 1) / d.Ticks * d.Ticks, dt.Kind);
    }
    /*Initializes the component and add the database varible names to the 'WHERE' box, used for querying the job database job*/
    public AdminForm(string task, string code)
    {
      InitializeComponent();

      taskLabel.Text += task;

      this.code = code;
      this.name = task;
    }




    /*Check if String entered into function is a number
     */
    public bool IsNumber(String number)
    {
      return number.All(char.IsNumber);
    }

    /*reset_all_fields method
     * Resets all the fields in the form to empty
     * Also refreshes the Today's orders' box to reflect any changes that may have happened to the database.
     */
    private void reset_all_fields()
    {
    }

    private void Form1_Load(object sender, EventArgs e)
    {

    }

    private void executeSQL(string sql)
    {
      using (MySqlConnection conn = connectMySql())
      {
        try
        {
          conn.Open();
          MySqlCommand cmd = new MySqlCommand(sql, conn);
          cmd.ExecuteReader();
        }
        catch (Exception ex)
        {
          Console.WriteLine(ex.ToString());
          MessageBox.Show("Error communicating with database. If this problem persists, please contact the administrator.\n" + ex.ToString());
        }
        conn.Close();

      }
    }

    private String quote(string x)
    {
      return "'" + x + "'";
    }

    private void updateButton_Click(object sender, EventArgs e)
    {
      //INSERT comment INTO TIMESHEET
      //Come in before work on FRIDAY to add that part to db

      String addStartDayStamp = String.Format("INSERT INTO dayStamps VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}');",
                    GWMS.StaffID, DateTime.Today.ToString("yyyy-MM-dd"), DateTime.Now.ToString("HH:mm:ss"), "Admin: " + name, "START", code);

      using (MySqlConnection conn = connectMySql())
      {
        try
        {
          conn.Open();
          MySqlCommand cmd = new MySqlCommand(addStartDayStamp, conn);
          cmd.ExecuteReader();
        }
        catch (Exception ex)
        {
          DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
          System.Reflection.MethodBase.GetCurrentMethod().Name, "");
        }
      }
      this.Close();
    }


    private string quoteNull(String str)
    {
      if (str == "")
      {
        return "NULL";
      }
      else
      {
        return quote(str);
      }
    }

    private void ViewJobForm_Resize(object sender, EventArgs e)
    {

    }

    /* https://www.c-sharpcorner.com/blogs/reset-all-controls-in-groupbox1 */
    private void ResetAll(GroupBox gbox)
    {
      foreach (System.Windows.Forms.Control ctrl in gbox.Controls)
      {
        if (ctrl is TextBox)
        {
          TextBox textBox = (TextBox)ctrl;
          textBox.Text = null;
        }
        if (ctrl is ComboBox)
        {
          ComboBox comboBox = (ComboBox)ctrl;
          comboBox.SelectedIndex = -1;
        }
        if (ctrl is CheckBox)
        {
          CheckBox checkBox = (CheckBox)ctrl;
          checkBox.Checked = false;
        }
        if (ctrl is RadioButton)
        {
          RadioButton radioButton = (RadioButton)ctrl;
          radioButton.Checked = false;
        }
        if (ctrl is ListBox)
        {
          ListBox listBox = (ListBox)ctrl;
          listBox.ClearSelected();
        }
      }
    }

    private void completeRadio_CheckedChanged(object sender, EventArgs e)
    {


    }

    private void rebookRadio_CheckedChanged(object sender, EventArgs e)
    {

    }

    private void cancelRadio_CheckedChanged(object sender, EventArgs e)
    {

    }
    private void staffRadio_CheckedChanged(object sender, EventArgs e)
    {

    }

    private void customerRadio_CheckedChanged(object sender, EventArgs e)
    {

    }

    private void supplierRadio_CheckedChanged(object sender, EventArgs e)
    {

    }

    private void otherSourceRadio_CheckedChanged(object sender, EventArgs e)
    {


    }

    private void dateGroupEnabled()
    {

    }

    private void incorrectRadio_CheckedChanged(object sender, EventArgs e)
    {
      dateGroupEnabled();
    }

    private void damagedRadio_CheckedChanged(object sender, EventArgs e)
    {
      dateGroupEnabled();
    }

    private void noPartRadio_CheckedChanged(object sender, EventArgs e)
    {
      dateGroupEnabled();
    }

    private void makeItRadio_CheckedChanged(object sender, EventArgs e)
    {
      dateGroupEnabled();
    }

    private void staffnpRadio_CheckedChanged(object sender, EventArgs e)
    {
      dateGroupEnabled();
    }

    private void otherRadio_CheckedChanged(object sender, EventArgs e)
    {

    }

    private void forgotRadio_CheckedChanged(object sender, EventArgs e)
    {
      dateGroupEnabled();
    }

    private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
    {

    }

    private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
    {

    }

    private void upButton_Click(object sender, EventArgs e)
    {
    }

    private void downButton_Click(object sender, EventArgs e)
    {
    }

    private void timer1_Tick(object sender, EventArgs e)
    {

    }
  }
}
