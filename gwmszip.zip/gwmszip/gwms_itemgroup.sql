-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: localhost    Database: gwms
-- ------------------------------------------------------
-- Server version	8.0.25

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `itemgroup`
--

DROP TABLE IF EXISTS `itemgroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `itemgroup` (
  `ItemGroupID` int NOT NULL,
  `igDescription` varchar(45) NOT NULL,
  `igSubGroup` varchar(45) NOT NULL,
  `igType` varchar(45) NOT NULL,
  `igSort` int DEFAULT NULL,
  `StatusID` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`ItemGroupID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `itemgroup`
--

LOCK TABLES `itemgroup` WRITE;
/*!40000 ALTER TABLE `itemgroup` DISABLE KEYS */;
INSERT INTO `itemgroup` VALUES (0,'UNCOMMON','Uncommon','Various',0,0),(1,'CLEAR / CLEAR','GLASS','CLEAR',1,0),(2,'CLEAR / CLEAR TOUGH','GLASS','CLEAR',2,0),(3,'CLEAR TOUGH / CLEAR TOUGH','GLASS','CLEAR',3,0),(4,'TINT / CLEAR','GLASS','TINT',4,0),(5,'TINT / CLEAR TOUGH','GLASS','TINT',5,0),(6,'TINT TOUGH / CLEAR TOUGH','GLASS','TINT',6,0),(7,'CLEAR / LOW E','GLASS','LOW E',7,0),(8,'CLEAR / LOW E TOUGH','GLASS','LOW E',8,0),(9,'CLEAR TOUGH / LOW E TOUGH','GLASS','LOW E',9,0),(10,'Flat Glass','Glass','Glass',NULL,0),(11,'Retainer','Glass','Glass',NULL,0),(12,'Weathershield','Glass','Glass',NULL,0),(13,'Retainer','Glass','Glass',NULL,0),(14,'Flat Laminate','Glass','Glass',NULL,0),(15,'Consumable','Glass','Glass',NULL,0),(16,'Double Glaze','Glass','Glass',NULL,0),(17,'Reglaze','Glass','Glass',NULL,0),(50,'TRAVEL','TRAVEL','TRAVEL',1000,0),(99,'SASH','SASH','SASH',30,0),(101,'Windscreen','Auto','Auto',NULL,0),(102,'Chip','Auto','Auto',NULL,0),(103,'Rearscreen','Auto','Auto',NULL,0),(104,'Mould','Auto','Auto',NULL,0),(105,'Sideglass','Auto','Auto',NULL,0),(106,'Gelpad','Auto','Auto',NULL,0),(107,'Clips','Auto','Auto',NULL,0),(108,'Canopy Rear','Auto','Auto',NULL,0),(109,'Other','Auto','Auto',NULL,0),(110,'Refit','Auto','Auto',NULL,0),(111,'Reseal','Auto','Auto',NULL,0),(112,'Recalibration','Auto','Auto',NULL,0),(113,'Sideglass LHR','Auto','Auto',NULL,0),(114,'Sideglass RHR','Auto','Auto',NULL,0),(115,'Sideglass LHF','Auto','Auto',NULL,0),(116,'Sideglass RHF','Auto','Auto',NULL,0),(117,'Rubber','Auto','Auto',NULL,0),(118,'Canopy Front','Auto','Auto',NULL,0),(119,'R&R Stoneguard','Auto','Auto',NULL,0),(120,'Sideglass LHF 1/4','Auto','Auto',NULL,0),(121,'Sideglass LHR 1/4','Auto','Auto',NULL,0),(122,'Sideglass RHF 1/4','Auto','Auto',NULL,0),(123,'Sideglass RHR 1/4','Auto','Auto',NULL,0),(124,'Canopy Side L','Auto','Auto',NULL,0),(125,'Canopy Side R','Auto','Auto',NULL,0),(126,'Remove&Refit','Auto','Auto',NULL,0),(999,'BEAD','BEAD','BEAD',20,0),(9999,'HANDLE','HANDLE','HANDLE',40,0),(99999,'HINGE','HINGE','HINGE',41,0),(999997,'ARGON','ARGON','ARGON',44,0),(999998,'LABOUR','LABOUR','LABOUR',500,0),(999999,'STAY','STAY','STAY',42,0),(9999999,'CONNECTOR','CONNECTOR','CONNECTOR',43,0);
/*!40000 ALTER TABLE `itemgroup` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-18 16:31:40
