﻿using System;
using System.Linq;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;
using System.Data;
using System.Drawing.Printing;
using System.Diagnostics;
using Microsoft.Scripting.Interpreter;
using System.Security.Cryptography;
using System.Windows.Forms.DataVisualization.Charting;
using System.Drawing;
using System.Collections.Generic;

namespace workshop_orders
{
    public partial class Index : Form
    {

    

        public Index()
        {
            InitializeComponent();

        }

        private void productionLink_Click(object sender, EventArgs e)
        {

        }
    }
}
