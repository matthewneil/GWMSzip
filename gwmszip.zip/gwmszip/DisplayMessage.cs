﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workshop_orders
{
  public partial class DisplayMessage : Form
  {

    public DisplayMessage(String MessageText, String Title)
    {
      InitializeComponent();
      lblMessage.Text = MessageText;
      this.Text = Title;
      SetButtons(false);

    }
    public DisplayMessage(String MessageText, String Title, string Action)
    {
      InitializeComponent();
      lblMessage.Text = MessageText;
      this.Text = Title;
      SetButtons(true);

    }
    private void SetButtons(bool bButtonView)
    {
      btnYes.Visible = false;
      btnOkay.Text = "OK";
      if (bButtonView == true)
      {
        btnYes.Visible = true;
        btnOkay.Text = "No";
      }
    }


    private void btnOkay_Click(object sender, EventArgs e)
    {
      DataAccess._bMessageReturn = false;
      this.Close();
    }

    private void btnYes_Click(object sender, EventArgs e)
    {
      DataAccess._bMessageReturn = true;
        this.Close();
    }
  }
}
