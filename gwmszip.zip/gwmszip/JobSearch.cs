﻿using System;
using System.Windows.Forms;
using System.Data;

namespace workshop_orders
{
  public partial class JobSearch : Form
  {
    private bool fbPageLoad = false;
    private int fiQuoteNo = 0;
    public JobSearch()
    {
      InitializeComponent();
      fbPageLoad = false;
      dtpFromDate.Value = DateTime.Now.AddYears(-1);
      dtpToDate.Value = DateTime.Now;
      GetStaff();
      GetCustomers();
      GetTypes();
      fbPageLoad = true;
      LoadJobs();
    }
    public void GetCustomers()
    {
      DataTable dt = DataAccess.ExecuteDataTable("SELECT customerID as datafield, CustomerName as textfield FROM vwcustomer WHERE customerID IN (SELECT customerID FROM job) ORDER BY CustomerName;");
      DataAccess.AddSelect(dt);
      cmbCustomer.DataSource = dt;
    }
    public void GetStaff()
    {
      DataTable dt = DataAccess.ExecuteDataTable("SELECT staffid as datafield, StaffFullName as textfield FROM staff WHERE StaffActive = 1 ORDER BY StaffFullName;");
      DataAccess.AddSelect(dt);
      cmbStaff.DataSource = dt;
    }
    public void GetTypes()
    {
      DataTable dt = DataAccess.ExecuteDataTable("SELECT typeid as datafield, typename as textfield FROM JobType WHERE TypeGroup = 'Auto' OR TypeGroup = 'Glass' ORDER BY TypeName;");
      DataAccess.AddSelect(dt);
      cmbType.DataSource = dt;
    }
    public void LoadJobs()
    {
      string sSQL = "";
      DataTable dt;
      try
      {
        String invoice = "";
        if (cmbStaff.SelectedIndex > 0)
        {
          sSQL += " AND StaffID = '" + cmbStaff.SelectedValue + "' ";
        }
        if (cmbStatus.SelectedIndex > 0)
        {
          sSQL += GetStatus();
        }
        if (cmbCustomer.SelectedIndex > 0)
        {
          sSQL += " AND CustomerID = '" + cmbCustomer.SelectedValue + "' ";
        }
        if (cmbType.SelectedIndex > 0)
        {
          sSQL += " AND TypeID = '" + cmbType.SelectedValue + "' ";
        }
        if (chkInvoice.Checked) //unused
        {
          //invoice = " LEFT JOIN invoice i ON j.JobID = i.JobID ";
          //sSQL += " AND i.invNo IS null ";
        }
        if(txtSearch.Text != "")
        {
          sSQL += String.Format(" AND (JobID LIKE '{0}%' OR CustomerName LIKE '{0}%' OR cSurname LIKE '{0}%' OR Vehicle LIKE '{0}%') ", txtSearch.Text);
        }
        //sSQL + " AND dateCreated >= '" + dtp
        //dgvData.Rows.Clear();
        dt = DataAccess.ExecuteDataTable(
          String.Format("SELECT j.JobID, j.JobBookingDateBlank, j.CustomerName, j.JobReference, j.Vehicle, j.TypeName, j.StaffFullName, j.Payment, j.StatusName, j.AreaName, j.JobNote " +
          "FROM vwJob j  LEFT JOIN invoice i ON j.JobID = i.JobID WHERE 1=1 " + sSQL + " AND j.DateCreated BETWEEN '{0}' AND '{1} 23:59:59'  GROUP BY j.JobID ORDER BY j.JobID DESC LIMIT 500;", 
          dtpFromDate.Value.ToString("yyyy-MM-dd"), dtpToDate.Value.ToString("yyyy-MM-dd")));

        dgvData.AutoGenerateColumns = false;
        if (dt != null)
        {
          dgvData.DataSource = dt;
        }
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }
      finally 
      {
        dgvData.AllowUserToAddRows = false;
        SetSelectedRow();
      }
    }

    private void SetSelectedRow()
		{
      if (dgvData != null && dgvData.Rows.Count > 0)
      {
        dgvData.Rows[0].Selected = true;
        foreach (DataGridViewRow drow in dgvData.Rows)
        {
          if ((int)drow.Cells[0].Value == fiQuoteNo)
          {
            drow.Selected = true;
            return;
          }
        }
        dgvData.FirstDisplayedScrollingRowIndex = dgvData.SelectedRows[0].Index;
      }
       
		}
    private string GetStatus()
		{
      switch (cmbStatus.SelectedItem)
			{
        case "Current":
          return " AND StatusID = 9 ";
        case "Cancelled":
          return " AND StatusID = 10 ";
        case "Complete":
          return " AND StatusID = 11 AND i.invNo IS null ";
        case "Invoiced":
          return "AND StatusID = 11 AND i.invNo IS NOT null ";
        default:
          return "";
      }
    }


    private void searchText_TextChanged(object sender, EventArgs e)
    {
        //LoadQuotes();
    }

    private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
    {
      LoadJobs();
    }

    private void startDateTime_ValueChanged(object sender, EventArgs e)
    {
      LoadJobs();
    }

    private void endDateTime_ValueChanged(object sender, EventArgs e)
    {
      LoadJobs();
    }

      private void BackToolStripButton_Click(object sender, EventArgs e)
      {
          this.Close();
      }

      private void NewToolStripButton_Click(object sender, EventArgs e)
      {
      //Check if job sheet open
      if (FormManagement.IsFormOpen("JobEdit") == true)
      {
        DataAccess.ShowMessage("You are currently editing a job. Please save and close before creating a new job.");
        FormManagement.ShowChildForm("JobEdit");
      }
      else
      {
        JobNew frm = new JobNew(0);
        FormManagement.ShowDialogForm(frm);
      }
    }

      private void StaffCombo_SelectedIndexChanged(object sender, EventArgs e)
      {
        if (fbPageLoad == true)
		    {
        LoadJobs();
        }
      }

    private void QuoteGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      EditQuote();
    }

		private void tsRefresh_Click(object sender, EventArgs e)
		{
      LoadJobs();
		}
		private void tsDelete_Click(object sender, EventArgs e)
		{
      //Delete Quote
		}
		private void tsEdit_Click(object sender, EventArgs e)
		{
      EditJob();
    }

    public void EditJob()
    {
      if (dgvData.SelectedRows.Count == 1 && dgvData.SelectedRows[0].Index > -1)
      {
        if (FormManagement.IsFormOpen("JobEdit") == true)
        {
          DataAccess.ShowMessage("You are currently editing a job. Please save and close before creating a new job.");
          FormManagement.ShowChildForm("JobEdit");
        }
        else
        {
          try
          {
            FormManagement.ShowChildForm(new JobEdit((int)dgvData.SelectedRows[0].Cells["chJobID"].Value));
          }
          catch (Exception ex) 
          {
            DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.ToString(), this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
          }
        }
      }
    }
    private void EditQuote()
    {
      if (dgvData.SelectedRows.Count == 1 && dgvData.SelectedRows[0].Index > -1)
      {
        if (FormManagement.IsFormOpen("JobEdit") == true)
        {
          DataAccess.ShowMessage("You are currently editing a quote. Please save and close before creating/opening a new quote.");
          FormManagement.ShowChildForm("JobEdit");
        }
        else
        {
          try
          {
            fiQuoteNo = (int)dgvData.SelectedRows[0].Cells[0].Value;
            ShowQuoteDetail(fiQuoteNo);

          }
          catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
      }
      else
      {
        MessageBox.Show("Please select a quote to edit", "Missing Selection", MessageBoxButtons.OK);
      }

    }
		private void btnQuote1_Click(object sender, EventArgs e)
		{
      FindJob();
    }
		private void btnQuote_Click(object sender, EventArgs e)
		{
      FindJob();
		}
    private void FindJob()
    {
      if (txtJob.Text != "" && DataAccess.IsNumeric(txtJob.Text) && int.Parse(txtJob.Text) > 999)
      {
        DataTable dt = DataAccess.ExecuteDataTable("SELECT JobID FROM job WHERE JobID = " + txtJob.Text);
        if (dt != null && dt.Rows.Count > 0)
				{

          if (FormManagement.IsFormOpen("JobEdit") == true)
          {
            DataAccess.ShowMessage("You are currently editing a job. Please save and close before creating a new job.");
            FormManagement.ShowChildForm("JobEdit");
          }
          else
          {
            try
            {

              FormManagement.ShowChildForm(new JobEdit(int.Parse(txtJob.Text)));
            }
            catch (Exception ex) { }
          }
          return;
        }
      }
      MessageBox.Show("PLease enter a valid Job Number", "Invalid Quote", MessageBoxButtons.OK);
    }
    private void txtQuote_KeyDown(object sender, KeyEventArgs e)
		{
      if (e.KeyCode == Keys.Enter)
      {
        FindJob();
      }
    }
    private void ShowQuoteDetail(int QuoteNo)
    {
       //FormManagement.ShowChildForm(new QuoteDetail(QuoteNo, this));

    }
		private void dgvData_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
		{
      EditJob();
		}

		private void cmbCustomer_SelectedIndexChanged(object sender, EventArgs e)
		{
      if (fbPageLoad == true)
      {
        LoadJobs();
      }
    }

    private void txtSearch_TextChanged(object sender, EventArgs e)
    {
      LoadJobs();
    }

    private void cmbType_SelectedIndexChanged(object sender, EventArgs e)
    {
      LoadJobs();
    }

    private void chkInvoice_CheckedChanged(object sender, EventArgs e)
    {
      LoadJobs();
    }
  }
}
