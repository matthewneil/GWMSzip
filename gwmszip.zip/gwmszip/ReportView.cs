﻿using System;
using Microsoft.Reporting.WinForms;
using System.Xml;
using System.Net.Mail;
using System.IO;
using System.ComponentModel;
using MySql.Data.MySqlClient;
using System.Data;
using System.Windows.Forms;

namespace workshop_orders
{
  public partial class ReportView : Form
  {
    string fsDataSetName = "";
    string fsAttachmentName = "";
    private string fsType = "";
    private int fiID = 0;
    private int fiEmailCounter = 0;

    public ReportView()
    {
      InitializeComponent();
    }
    public ReportView(string CommandText, string sReportName, bool bEmail = false, string sAttachmentName = "", string sType = "", int iID = 0)
    {
      InitializeComponent();
      LoadReport(CommandText, sReportName, bEmail, sAttachmentName, sType, iID);
    }

    private void ReportView_Load(object sender, EventArgs e)
    {
      // TODO: This line of code loads data into the 'gwgjobsDataSet1.vwquoteitem' table. You can move, or remove it, as needed.
      //this.vwquoteitemTableAdapter.Fill(this.gwgjobsDataSet1.vwquoteitem);
      //this.reportViewer1.RefreshReport();
    }
    public void LoadReport(string CommandText, string sReportName, bool bEmail = false, string sAttachmentName = "", string sType = "", int iID = 0)
    {
      // Run the report in local mode, requires reading the reports .rdl file to find report and sql parameters
      // command text and dataset name. Use tis data to create the sqlcommand and return teh data to the report dataset

      System.Data.DataSet ds = new System.Data.DataSet();
      tsMenu.Visible = bEmail;
      if (bEmail == true)
      {
        fsAttachmentName = sAttachmentName;
        fsType = sType;
        fiID = iID;
        fiEmailCounter = 0;
      }
      GetEmailAddress();

      try
      {
        // Setup the SQL connection and command
        MySqlConnection conn = new MySqlConnection() { ConnectionString = GWMS.connStr };
        MySqlCommand cmdSQL = new MySqlCommand() { Connection = conn, CommandText = CommandText, CommandType = System.Data.CommandType.Text };

        // Prepare the data adapter
        MySqlDataAdapter da;
        da = new MySqlDataAdapter(cmdSQL);

        // fill the DataSet using default values for DataTable names, etc.
        da.Fill(ds);

        // setup report environment and display report
        //string[] sDir = Directory.GetCurrentDirectory().Split("\");
        //string curdir = @"C:\Jock\BinaryWizards\BusinessApps\GWG\workshop-orders\reports\" + sReportName; //
        string curdir = Directory.GetCurrentDirectory() + @"\reports\" + sReportName;
        if (GWMS._fbTesting == true) {curdir = @"C:\Users\User\Documents\GWMS\reports\" + sReportName; } //\\ajdc\BMS\BMSGWG
        ReadReportDefinition(curdir);

        ReportDataSource rds = new ReportDataSource(fsDataSetName, ds.Tables[0]);
        reportViewer1.Reset();
        reportViewer1.LocalReport.DataSources.Clear();
        reportViewer1.ProcessingMode = ProcessingMode.Local;
          
        reportViewer1.LocalReport.EnableExternalImages = true;
        reportViewer1.LocalReport.EnableHyperlinks = true;
        reportViewer1.LocalReport.ReportPath = curdir;
        // Add handler is report contains a subreport
        this.reportViewer1.LocalReport.SubreportProcessing += SubreportProcessingEventHandler;
        reportViewer1.LocalReport.DataSources.Add(rds);
        reportViewer1.RefreshReport();
      }
      catch (Exception ex)
      {
        MessageBox.Show("An error occurred while we trying to generate the report" + Environment.NewLine + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        //Errors(Information.Err.Number, ex.Message, "frmReports", "LoadReport", CommandText);
      }
    }
    public void SubreportProcessingEventHandler(object sender, SubreportProcessingEventArgs e)
    {
      // Process Sales Rep Sub Report, get the data based on the original report filters
      // Check for datasource"
      string sSQL = "";
      try
      {
        if (e != null && e.Parameters["datasource"].Values[0] != null)
        {
          DataTable dt = new DataTable();
          foreach (ReportParameterInfo p in e.Parameters)
          {
            if (p.Name != "datasource")
            {
              switch (p.DataType)
              {
                case ParameterDataType.String:
                  {
                    sSQL += "'" + p.Values[0] + "', ";
                    break;
                  }

                case ParameterDataType.DateTime:
                  {
                    sSQL += "'" + DateTime.Parse(p.Values[0]).ToString("yyyy-MM-dd hh:mm:ss") + "', ";
                    break;
                  }

                case ParameterDataType.Integer:
                  {
                    sSQL += p.Values[0] + ", ";
                    break;
                  }

                case ParameterDataType.Float:
                  {
                    sSQL += p.Values[0] + ", ";
                    break;
                  }

                case ParameterDataType.Boolean:
                  {
                    sSQL += decimal.Parse(p.Values[0]) + ", ";
                    break;
                  }
              }
            }
          }

          if (sSQL.Length == 0)
          {
            sSQL = e.Parameters["datasource"].Values[0];
          }
          else 
          { 
            sSQL = e.Parameters["datasource"].Values[0] + " " + sSQL.Substring(0, sSQL.Length - 2);
          }
          
          dt = DataAccess.ExecuteDataTable(sSQL);
          e.DataSources.Add(new ReportDataSource(e.DataSourceNames[0], dt));
        }
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
    }
    private string[,] ReadReportDefinition(string sReportPath)
    {
      // Read the XML definition and create a dataset from the field information, get sql connection and command text
      string sReport = sReportPath;
      XmlTextReader xReader = new XmlTextReader(sReport);
      string[,] sReportParams = new string[4, 11];

      // Clear the parameters array
      try
      {
        while (xReader.Read())
        {
          // Find the DataSet Name
          if (xReader.Name == "DataSet" && (int)xReader.NodeType == 1)
          {
            xReader.MoveToAttribute("Name");
            // sReportParams(2, 10) = xReader.Value
            fsDataSetName = xReader.Value;
          }
        }
        return sReportParams;
      }
      catch
      {
        return sReportParams;
      }
      finally
      {
        xReader.Close();
      }
    }
    private void GetEmailAddress()
    {
      txtEmail.Text = "";
      switch (fsType)
      {
        case "1": // Purchase Order
          {
            DataTable dt = DataAccess.ExecuteDataTable("SELECT ISNULL(supEmail, '') AS eMail, ordEmailed, ordEmailDate FROM vw_Orders WHERE OrderNo = " + fiID);
            if (dt != null && dt.Rows.Count > 0)
            {
              txtEmail.Text = dt.Rows[0]["eMail"] + ";"; // + UserEMail;
              if ((int)(dt.Rows[0]["ordEmailed"]) > 0)
              {
                fiEmailCounter = int.Parse(dt.Rows[0]["ordEmailed"].ToString());
                if (fiEmailCounter == 1)
                  MessageBox.Show("This purchase order was previously emailed on " + dt.Rows[0]["ordEmailDate"], "Email Check", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                  MessageBox.Show("This purchase order has been emailed " + decimal.Parse(dt.Rows[0]["ordEmailed"].ToString()) + " times. " + Environment.NewLine + "The last email was sent on " + dt.Rows[0]["ordEmailDate"], "Email Check", MessageBoxButtons.OK, MessageBoxIcon.Information);
              }
            }

            break;
          }
      }
    }
    private void UpdateEmailData()
    {
      fiEmailCounter += 1;
      switch (fsType)
      {
        case "1": // Purchase Order
          {
            //Dataaccess.ExecuteQuery("UPDATE Orders SET ordEmailed =" + fiEmailCounter + ", ordEmailDate = '" + Strings.Format(DateTime.Now(), "yyyy-MM-dd HH:mm") + "' WHERE OrderNo = " + fiID);
            //Audit(fiID, UserID, AuditAction.Update, "OrderEmailDate", "", Strings.Format(DateTime.Now(), "yyyy-MM-dd HH:mm"), AuditSource.Report, fiID);
            //Audit(fiID, UserID, AuditAction.Update, "OrderEmailCount", fiEmailCounter - 1, fiEmailCounter, AuditSource.Report, fiID);
            break;
          }
      }
    }
    private void ReportView_FormClosing(object sender, FormClosingEventArgs e)
    {
      reportViewer1.Reset();
      // reportViewer1 = null;
      reportViewer1.LocalReport.ReportPath = null;

    }

    private void ReportView_FormClosed(object sender, FormClosedEventArgs e)
    {
      reportViewer1.Dispose();
      this.Dispose();
    }

    private void tsEmail_Click(object sender, EventArgs e)
    {
      if (DataAccess.ValidateEmail(txtEmail.Text) == false) {
        MessageBox.Show("Please enter a valid email address", "Invalid Email", MessageBoxButtons.OK, MessageBoxIcon.Information);
        return;
      }
      Warning[] warnings = null;
      string[] streamids = null;
      string mimeType = null;
      string encoding = null;
      string extension = null;
      byte[] bytes;
      string sUserEmail = "test@test.com";
      try
      {
        this.Cursor = Cursors.WaitCursor;
        bytes = reportViewer1.LocalReport.Render("PDF", null, out mimeType, out encoding, out extension, out streamids, out warnings);

        //Create the Memory Stream
        MemoryStream s = new MemoryStream(bytes);
        s.Seek(0, SeekOrigin.Begin);

        // Create the attachment
        Attachment a = new Attachment(s, fsAttachmentName);
        string sFrom = GWMS.StaffID.ToString(); //UserEMail;
        if (sFrom == "")
        {
          sFrom = "";//BusinessEmail
        }
        DataTable dt = DataAccess.ExecuteDataTable("SELECT * FROM eMailType WHERE eMailTypeID = " + fsType);
        if (dt != null && dt.Rows.Count == 1)
        {
          string sSubject = dt.Rows[0]["eMailSubject"].ToString() + " - " + fsAttachmentName.Substring(1, fsAttachmentName.Length - 4);
          string sMessage = dt.Rows[0]["eMailMessage"].ToString();
          //Add email footer info for Purchase Order emails
          if (fsType == "1")
          {
            sMessage += Environment.NewLine + Environment.NewLine + "If you require further information please contact" + Environment.NewLine + Environment.NewLine + GWMS.StaffID + Environment.NewLine + sUserEmail + Environment.NewLine + Environment.NewLine + "Thanks ";
          }
          string sResult = DataAccess.SendEmail(sFrom, txtEmail.Text, sSubject, sMessage, a);
          if(sResult == "")
          {
            MessageBox.Show("Message Sent Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            UpdateEmailData();
            this.Close();
          }
          else
					{
            MessageBox.Show("Error sending message" + Environment.NewLine + sResult, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
          }
        }
      }
      catch(Exception ex)
      {
        MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
      }
      finally
      {
        this.Cursor = Cursors.Default;
      }
    }
	}
}
