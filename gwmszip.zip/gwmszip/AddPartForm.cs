﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace workshop_orders
{
  /*This is a form is view all the created jobjobs in the database*
   *This data can a queried and filter so you can only display the job you want to see*/
  public partial class AddPartForm : Form
  {
    private bool update = false;
    private int pID = 0;

    /*A method to connect to the GoreGlassJob database*/
    public MySqlConnection connectMySql()
    {
      string connStr = "server=10.1.1.70;user=admin;database=GWGJOBS;port=3306;password=aQuack1nce4^";
      using (MySqlConnection conn = new MySqlConnection(GWMS.connStr))
      {
        try
        {
          Console.WriteLine("Connecting to MySQL...");
          return conn;
        }
        catch (Exception ex)
        {
          MessageBox.Show("Error connecting to server, please contact the administrator.", "Error!");
          return null;
        }

      }
    }

    /*Initializes the component and add the database varible names to the 'WHERE' box, used for querying the job database job*/
    public AddPartForm()
    {
      InitializeComponent();
      partTypeCombo.Items.Add("WINDSCREEN");
      partTypeCombo.Items.Add("REARSCREEN");
      partTypeCombo.Items.Add("MOULD");
      partTypeCombo.Items.Add("CHIP");
      partTypeCombo.Items.Add("GELPAD");
      partTypeCombo.Items.Add("R&R-STONEGUARD");
      partTypeCombo.Items.Add("SIDEGLASS-LHF");
      partTypeCombo.Items.Add("SIDEGLASS-RHF");
      partTypeCombo.Items.Add("SIDEGLASS-LHR");
      partTypeCombo.Items.Add("SIDEGLASS-RHR");
      partTypeCombo.Items.Add("SIDEGLASS-LHF-1/4");
      partTypeCombo.Items.Add("SIDEGLASS-RHF-1/4");
      partTypeCombo.Items.Add("SIDEGLASS-LHR-1/4");
      partTypeCombo.Items.Add("SIDEGLASS-RHR-1/4");
      partTypeCombo.Items.Add("CANOPY-REAR");
      partTypeCombo.Items.Add("CANOPY-SIDE-L");
      partTypeCombo.Items.Add("CANOPY-SIDE-R");
      quantity.Minimum = 0;


      String sql = String.Format("SELECT pCode, pAltCode, pNagCode FROM part;");
      MySqlConnection conn = connectMySql();
      conn.Open();
      MySqlCommand cmd = new MySqlCommand(sql, conn);
      MySqlDataReader rdr = cmd.ExecuteReader();

      while (rdr.Read())
      {
        altCodeText.AutoCompleteCustomSource.Add(rdr["pAltCode"].ToString());
        partCodeText.AutoCompleteCustomSource.Add(rdr["pCode"].ToString());
        nagCodeText.AutoCompleteCustomSource.Add(rdr["pNagCode"].ToString());
      }
      conn.Close();
      reset_all_fields();
    }

    public AddPartForm(int pID, String pType, String pCode, String pAltCode, String pNagCode, String info)
    {
      InitializeComponent();

      partTypeCombo.Text = pType;
      partCodeText.Text = pCode;
      altCodeText.Text = pAltCode;
      nagCodeText.Text = pNagCode;
      quanLabel.Text = "0";
      label3.Text = "Add Amount";
      infoText.Text = info;
      quantity.Value = 0;
      quantity.Minimum = 0;
      this.pID = pID;

      partTypeCombo.Items.Add("WINDSCREEN");
      partTypeCombo.Items.Add("REARSCREEN");
      partTypeCombo.Items.Add("MOULD");
      partTypeCombo.Items.Add("CHIP");
      partTypeCombo.Items.Add("GELPAD");
      partTypeCombo.Items.Add("R&R-STONEGUARD");
      partTypeCombo.Items.Add("SIDEGLASS-LHF");
      partTypeCombo.Items.Add("SIDEGLASS-RHF");
      partTypeCombo.Items.Add("SIDEGLASS-LHR");
      partTypeCombo.Items.Add("SIDEGLASS-RHR");
      partTypeCombo.Items.Add("SIDEGLASS-LHF-1/4");
      partTypeCombo.Items.Add("SIDEGLASS-RHF-1/4");
      partTypeCombo.Items.Add("SIDEGLASS-LHR-1/4");
      partTypeCombo.Items.Add("SIDEGLASS-RHR-1/4");
      partTypeCombo.Items.Add("CANOPY-REAR");
      partTypeCombo.Items.Add("CANOPY-SIDE-L");
      partTypeCombo.Items.Add("CANOPY-SIDE-R");

      String sql = String.Format("SELECT pCode, pAltCode, pNagCode FROM part;");
      using (MySqlConnection conn = connectMySql())
      {
        try
        {
          conn.Open();
          MySqlCommand cmd = new MySqlCommand(sql, conn);
          MySqlDataReader rdr = cmd.ExecuteReader();

          while (rdr.Read())
          {
            altCodeText.AutoCompleteCustomSource.Add(rdr["pAltCode"].ToString());
            partCodeText.AutoCompleteCustomSource.Add(rdr["pCode"].ToString());
            nagCodeText.AutoCompleteCustomSource.Add(rdr["pNagCode"].ToString());
          }

          refresh_listings();
        }
        catch { }
        //partTypeCombo.Enabled = false;
        //partCodeText.Enabled = false;
        conn.Close();
      }
      update = true;
    }

    public void refresh_listings()
    {
      locationCombo.DropDownStyle = ComboBoxStyle.DropDownList;
      indexCombo.DropDownStyle = ComboBoxStyle.DropDownList;
      using (MySqlConnection conn = connectMySql())
      {
        conn.Open();
        String sql = String.Format("SELECT jobPart.objID, pAllocated AS JobNo, pState AS State, info AS note, date AS LastUpdated FROM part INNER JOIN jobPart ON part.pID = jobPart.pID INNER JOIN " +
            "(SELECT objID, max(date) AS maxdate FROM jobPart GROUP BY objID) jP ON jobPart.objID = jP.objID AND date = maxdate " +
            "WHERE part.pID = {0} AND pState != 'DELETED' AND pState != 'COMPLETE';", pID);

        MySqlDataAdapter sqlDa = new MySqlDataAdapter(sql, conn);
        DataTable dtbl = new DataTable();
        sqlDa.Fill(dtbl);

        dataGridView1.DataSource = dtbl;
        conn.Close();
      }


      using (MySqlConnection conn = connectMySql())
      {
        String sql = String.Format("SELECT * FROM locations;");
        conn.Open();
        MySqlCommand cmd = new MySqlCommand(sql, conn);
        using (MySqlDataReader rdr = cmd.ExecuteReader())
        {
          while (rdr.Read())
          {
            locationCombo.Items.Add(rdr["lCode"].ToString() + " (" + rdr["lName"].ToString() + ")");
          }
        }
        conn.Close();
      }
    }

    private void locationCombo_TextChanged(object sender, EventArgs e)
    {
      indexCombo.Items.Clear();
      using (MySqlConnection conn = connectMySql())
      {
        conn.Open();
        String sql = String.Format("SELECT * FROM locationIndex WHERE locationCode = '{0}';", locationCombo.Text.Split(' ')[0]);

        MySqlCommand cmd = new MySqlCommand(sql, conn);
        using (MySqlDataReader rdr = cmd.ExecuteReader())
        {
          while (rdr.Read())
          {
            indexCombo.Items.Add(rdr["locationIndex"].ToString() + " (" + rdr["info"].ToString() + ")");
          }
        }
        conn.Close();
      }
    }

    /*Check if String entered into function is a number
     */
    public bool IsNumber(String number)
    {
      return number.All(char.IsNumber);
    }

    /*reset_all_fields method
     * Resets all the fields in the form to empty
     * Also refreshes the Today's orders' box to reflect any changes that may have happened to the database.
     */
    private void reset_all_fields()
    {
    }

    public void updateButton_Click()
    {

    }

    /**methods below are unused*/
    private void Form1_Load(object sender, EventArgs e)
    {

    }



    private void executeSQL(string sql, bool errors)
    {
      using (MySqlConnection conn = connectMySql())
      {
        try
        {
          conn.Open();
          MySqlCommand cmd = new MySqlCommand(sql, conn);
          cmd.ExecuteReader();
        }
        catch (Exception ex)
        {
          if (errors)
          {
            MessageBox.Show("Error communicating with database. If this problem persists, please contact the administrator.\n" + ex.ToString());
            Console.WriteLine(ex.ToString());
          }
        }
        conn.Close();
      }
    }

    private String quote(string x)
    {
      return "'" + x + "'";
    }

    private void partButton_Click(object sender, EventArgs e)
    {
      /*
            String pType = quote(partTypeCombo.Text);
            String pCode = quote(partCodeText.Text);
            String pAltCode = quote(altCodeText.Text);
            String pNagCode = quote(nagCodeText.Text);
            String pQuantity = quantity.Text;
            String pInfo = quote(infoText.Text);
            String errors = "";
            int pID = this.pID;
            int objID = 0; //FIX

            if (pInfo == "''")
            {
                pInfo = "NULL";
            }

            String sql = String.Format("SELECT MAX(objID) FROM jobPart;");
            MySqlConnection conn = connectMySql();
            conn.Open();
            MySqlCommand cmd =  new MySqlCommand(sql, conn);
            MySqlDataReader rdr = cmd.ExecuteReader();
            rdr.Read();
            objID = int.Parse(rdr["MAX(objID)"].ToString()) + 1;
            conn.Close();

            if (!update)
            {
                conn.Open();
                sql = String.Format("SELECT MAX(pID) FROM part;");
                cmd = new MySqlCommand(sql, conn);
                rdr = cmd.ExecuteReader();
                rdr.Read();
                pID = int.Parse(rdr["MAX(pID)"].ToString()) + 1;
                conn.Close();
            }         

            if (pType == "''")
            {
                errors += "- Part Type must be specified.\n";
            }
            if (pCode == "''" && pAltCode == "''" && pNagCode == "''")
            {
                errors += "- At least ONE part code needs to be specified.\n";
            }
            if (pCode == "''")
            {
                pCode = "NULL";
            }
            if (pAltCode == "''")
            {
                pAltCode = "NULL";
            }
            if (pNagCode == "''")
            {
                pNagCode = "NULL";
            }

            if (int.Parse(pQuantity) < 0)
            {
                if (int.Parse(quanLabel.Text) + int.Parse(pQuantity) < 0)
                {
                    errors += "- You are deleting more stock than is is currently avaliable. If the part is allocated to a job, please deallocate it first.\n";
                }
            }

            if (!update)
            {
                int pID1 = 0;
                int pID2 = 0;
                int pID3 = 0;

                if (pCode != "NULL")
                {
                    conn.Open();
                    try
                    {
                        sql = String.Format("SELECT pID FROM part WHERE pCode = {0};", pCode);
                        cmd = new MySqlCommand(sql, conn);
                        rdr = cmd.ExecuteReader();
                        rdr.Read();
                        pID1 = int.Parse(rdr["pID"].ToString());
                    }
                    catch
                    {

                    }
                    conn.Close();
                }

                if (pAltCode != "NULL")
                {
                    conn.Open();
                    try
                    {
                        sql = String.Format("SELECT pID FROM part WHERE pAltCode = {0};", pAltCode);
                        cmd = new MySqlCommand(sql, conn);
                        rdr = cmd.ExecuteReader();
                        rdr.Read();
                        pID2 = int.Parse(rdr["pID"].ToString());
                    }
                    catch { }
                    conn.Close();
                }


                if (pNagCode != "NULL")
                {
                    conn.Open();
                    try
                    {
                        sql = String.Format("SELECT pID FROM part WHERE pNagCode = {0};", pNagCode);
                        cmd = new MySqlCommand(sql, conn);
                        rdr = cmd.ExecuteReader();
                        rdr.Read();
                        pID3 = int.Parse(rdr["pID"].ToString());
                    }
                    catch { }
                    conn.Close();
                }

                if (pID1 == 0 && pID2 == 0 && pID3 == 0)
                {
                    conn.Open();
                    sql = "SELECT MAX(pID) FROM part;";
                    cmd = new MySqlCommand(sql, conn);
                    rdr = cmd.ExecuteReader();
                    rdr.Read();
                    pID = int.Parse(rdr["MAX(pID)"].ToString()) + 1;
                    conn.Close();
                }

                else if (pID1 != 0 && pID2 != 0 && pID3 != 0)
                {
                    if (pID1 == pID2 && pID1 == pID3)
                    {
                        pID = pID1;
                    }
                    else
                    {
                        errors += "- There are different object IDs associated with these Part Codes. Please select which ID should be used.\n";
                    }
                }

                else if (pID1 != 0 && pID2 != 0 && pID3 == 0)
                {
                    if (pID1 == pID2)
                    {
                        pID = pID1;
                    }
                    else
                    {
                        errors += "- There are different IDs associated with these Part Codes. Please select which ID should be used.\n";
                    }
                }

                else if (pID1 != 0 && pID2 == 0 && pID3 != 0)
                {
                    if (pID1 == pID3)
                    {
                        pID = pID1;
                    }
                    else
                    {
                        errors += "- There are different IDs associated with these Part Codes. Please select which ID should be used.\n";
                    }
                }

                else if (pID1 == 0 && pID2 != 0 && pID3 != 0)
                {
                    if (pID2 == pID3)
                    {
                        pID = pID2;
                    }
                    else
                    {
                        errors += "- There are different IDs associated with these Part Codes. Please select which ID should be used.\n";
                    }
                }

                else if (pID1 != 0 && pID2 == 0 && pID3 == 0)
                {
                    pID = pID1;
                }

                else if (pID1 == 0 && pID2 != 0 && pID3 == 0)
                {
                    pID = pID2;
                }

                else if (pID1 == 0 && pID2 == 0 && pID3 != 0)
                {
                    pID = pID3;
                }
            }



            if (errors == "")
            {
                int quan = int.Parse(pQuantity);
                if (!update)
                {
                    sql = String.Format("INSERT INTO part VALUES ({0}, {1}, {2}, {3}, {4}, '{5}', {6}, null, null, null, false);",
                            pID, pType, pCode, pAltCode, pNagCode, GWMS.StaffID, pInfo);
                    
                    executeSQL(sql, false);
                } else
                {
                    sql = String.Format("UPDATE part SET pCode = {0}, pAltCode = {1}, pNagCode = {2}, addedBy = '{3}', " +
                        "pInfo = {4} WHERE pID = {5};", 
                        pCode, pAltCode, pNagCode, GWMS.StaffID, pInfo, pID);
                    executeSQL(sql, true);
                }

                if (allocateCheck.Checked)
                {
                    conn.Open();
                    try
                    {
                        sql = String.Format("SELECT * FROM jobPart INNER JOIN (SELECT objID, max(date) AS maxdate FROM jobPart GROUP BY objID) " +
                            "jP ON jP.objID = jobPart.objID AND date = maxdate INNER JOIN jobStatus ON jobPart.pAllocated = jobStatus.jobNo " +
                            "WHERE pID = {0} AND (pState = 'ON-ORDER' OR pState = 'NOT-ORDERED') " +
                            "ORDER BY pState DESC, bookingDate;", pID);
                        
                        cmd = new MySqlCommand(sql, conn);
                        
                        rdr = cmd.ExecuteReader();
                        conn.Close();
                        while (rdr.Read())
                        {
                            sql = String.Format("INSERT INTO jobPart VALUES({0}, '{1}', {2}, {3}, '{4}', {5}, '{6}', {7}, {8}, null, null, null, null);",
                                rdr["objID"].ToString(), DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), rdr["pID"].ToString(),
                                rdr["pAllocated"].ToString(), "IN-STOCK", "True", GWMS.StaffID, "'Auto-allocated to job from AddPart.'",
                                pInfo);
                            executeSQL(sql, true);
                            MessageBox.Show(quan.ToString());
                            quan--;
                            if (quan < 1)
                            {
                                break;
                            }
                        }
                        
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("ERROR" + ex.ToString());
                    }
                    conn.Close();
                }
                while (quan > 0)
                {
                    sql = String.Format("INSERT INTO jobPart VALUES({0}, '{1}', {2}, {3}, '{4}', {5}, '{6}', {7}, {8}, null, null, null, null);",
                        objID, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), pID, "NULL", "IN-STOCK", "True", GWMS.StaffID,
                        "'Added Part from Add Part Interface.'", pInfo);
                    executeSQL(sql, true);
                    quan--;
                    objID++;
                }
                int allocated = int.Parse(pQuantity) - quan;

                this.Close();
            }
            else
            {
                MessageBox.Show(errors);
            }
      */
    }

    private void ViewJobForm_Resize(object sender, EventArgs e)
    {

    }

    private void label4_Click(object sender, EventArgs e)
    {

    }

    private void quanLabel_Click(object sender, EventArgs e)
    {

    }

    private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      if (e.RowIndex >= 0)
      {
        DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
        if (row.Cells["JobNo"].Value.ToString() != "")
        {
          ChangeJobPart form = new ChangeJobPart(int.Parse(row.Cells["ObjID"].Value.ToString()));
          FormManagement.ShowDialogForm(form);
        }
        else
        {
          AllocatePart form = new AllocatePart(int.Parse(row.Cells["ObjID"].Value.ToString()));
          FormManagement.ShowDialogForm(form);
        }
      }
    }
  }
}