-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: localhost    Database: gwms
-- ------------------------------------------------------
-- Server version	8.0.25

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `insurance`
--

DROP TABLE IF EXISTS `insurance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `insurance` (
  `InsuranceID` int NOT NULL AUTO_INCREMENT,
  `InsuranceName` varchar(45) NOT NULL,
  `active` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`InsuranceID`),
  UNIQUE KEY `InsuranceID_UNIQUE` (`InsuranceID`),
  UNIQUE KEY `InsuranceName_UNIQUE` (`InsuranceName`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insurance`
--

LOCK TABLES `insurance` WRITE;
/*!40000 ALTER TABLE `insurance` DISABLE KEYS */;
INSERT INTO `insurance` VALUES (1,'FMG',1),(2,'AA',1),(3,'NZI',1),(4,'Lumley',1),(5,'IAG State',1),(6,'AMI',1),(7,'Vero',1),(8,'Customfleet',1),(9,'State',1),(10,'Tower',1),(11,'Hollard',1),(12,'Westpac',1),(13,'Bnz Premicare',1),(14,'Amp',1),(15,'Fleetpartners',1),(16,'Nz Autoglass',1),(17,'Lantern',1),(18,'Hyundai',1),(19,'Lumley Auto Direct',1),(20,'Capricorn',1),(21,'Qbe',1),(22,'Star',1),(23,'Iag Datarich',1),(24,'Instant',1),(25,'Toyota',1),(26,'Medical',1),(27,'Ando',1),(28,'Instant Windscreens',1),(29,'Star Insurance',1),(30,'Aa Insurance',1),(31,'Provident',1),(32,'Coop',1),(33,'Nac',1),(34,'Monument',1),(35,'Orix',1),(36,'Medical Assurance',1),(37,'Kim Mcdowall Painting',1),(38,'Farmlands',1),(39,'Zurich',1),(40,'Fleetline',1),(41,'Kiwibank',1),(42,'Aon',1),(43,'Bnz',1),(44,'Capricorn Mutual',1),(45,'Wells Instrumental',1),(46,'Covi',1),(47,'Verp',1),(48,'Lumleu',1),(49,'Mitsisomo',1),(50,'Fleetparnters',1),(51,'Ultrasure',1),(52,'Rothburys',1),(53,'Uaa',1),(54,'Cove',1),(55,'Sureplan',1),(56,'Smartpack',1),(57,'Providen',1),(58,'Alan Waddell',1),(59,'Asb',1),(60,'Carrfields 22637',1),(61,'Nzi Swan',1),(62,'Carrfields',1),(63,'Lanter',1),(64,'Datarich',1),(65,'Protecta Insruance',1),(66,'Custom Fleet',1),(67,'Bnz Premier Care',1),(68,'Sg Fleet',1),(69,'Alliance',1),(70,'Anz',1),(71,'Qbe Smartpak',1),(72,'Iag Fi Datarich',1),(73,'Pulse',1),(74,'Carfieilds Livestock',1),(75,'Iag Bnz',1),(76,'Southsure',1),(77,'Trade Me',1),(78,'Fleetpartner',1),(79,'Pgg',1),(80,'Leaseplan',1),(81,'Camper Care',1),(82,'Iag',1),(83,'Vero Style Cover',1),(84,'Tlc',1),(85,'Iba',1),(86,'Iua',1),(87,'Electrix',1),(88,'Inspire Properties',1),(89,'Nzautoglass',1),(90,'Hrt',1),(91,'Aon Dunedin',1),(92,'Stuart Quertier',1),(93,'Ver',1),(94,'Target',1),(95,'Classic Cover',1),(96,'Fleetwise',1),(97,'Nzie',1),(98,'Emergency Glass',1),(99,'Fleet Plus',1),(100,'Inspire',1);
/*!40000 ALTER TABLE `insurance` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-18 16:31:39
