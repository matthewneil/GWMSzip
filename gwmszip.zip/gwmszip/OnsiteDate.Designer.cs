﻿
namespace workshop_orders
{
  partial class OnsiteDate
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.label16 = new System.Windows.Forms.Label();
      this.label17 = new System.Windows.Forms.Label();
      this.dtpEnd = new System.Windows.Forms.DateTimePicker();
      this.dtpStart = new System.Windows.Forms.DateTimePicker();
      this.dtpDate = new System.Windows.Forms.DateTimePicker();
      this.lblMissingRecords = new System.Windows.Forms.Label();
      this.nudStaff = new System.Windows.Forms.NumericUpDown();
      this.label2 = new System.Windows.Forms.Label();
      this.lnkRecord1 = new System.Windows.Forms.LinkLabel();
      this.lnkRecord2 = new System.Windows.Forms.LinkLabel();
      this.btnContinue = new System.Windows.Forms.Button();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.groupBox2 = new System.Windows.Forms.GroupBox();
      this.gbTimes = new System.Windows.Forms.GroupBox();
      this.btnEndBack = new System.Windows.Forms.Button();
      this.btnEndNext = new System.Windows.Forms.Button();
      this.btnStartNext = new System.Windows.Forms.Button();
      this.btnStartBack = new System.Windows.Forms.Button();
      this.panel1 = new System.Windows.Forms.Panel();
      this.toolStrip1 = new System.Windows.Forms.ToolStrip();
      this.tsBack = new System.Windows.Forms.ToolStripButton();
      this.tsContinue = new System.Windows.Forms.ToolStripButton();
      this.panel2 = new System.Windows.Forms.Panel();
      this.btnCancel = new System.Windows.Forms.Button();
      ((System.ComponentModel.ISupportInitialize)(this.nudStaff)).BeginInit();
      this.groupBox1.SuspendLayout();
      this.groupBox2.SuspendLayout();
      this.gbTimes.SuspendLayout();
      this.panel1.SuspendLayout();
      this.toolStrip1.SuspendLayout();
      this.panel2.SuspendLayout();
      this.SuspendLayout();
      // 
      // label16
      // 
      this.label16.AutoSize = true;
      this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label16.Location = new System.Drawing.Point(224, 30);
      this.label16.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
      this.label16.Name = "label16";
      this.label16.Size = new System.Drawing.Size(38, 20);
      this.label16.TabIndex = 40;
      this.label16.Text = "End";
      // 
      // label17
      // 
      this.label17.AutoSize = true;
      this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label17.Location = new System.Drawing.Point(20, 30);
      this.label17.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
      this.label17.Name = "label17";
      this.label17.Size = new System.Drawing.Size(44, 20);
      this.label17.TabIndex = 41;
      this.label17.Text = "Start";
      // 
      // dtpEnd
      // 
      this.dtpEnd.CustomFormat = "hh:mm tt";
      this.dtpEnd.Enabled = false;
      this.dtpEnd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.dtpEnd.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
      this.dtpEnd.Location = new System.Drawing.Point(226, 53);
      this.dtpEnd.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
      this.dtpEnd.Name = "dtpEnd";
      this.dtpEnd.ShowUpDown = true;
      this.dtpEnd.Size = new System.Drawing.Size(92, 26);
      this.dtpEnd.TabIndex = 44;
      this.dtpEnd.Value = new System.DateTime(2022, 6, 2, 17, 0, 0, 0);
      // 
      // dtpStart
      // 
      this.dtpStart.CustomFormat = "hh:mm tt";
      this.dtpStart.Enabled = false;
      this.dtpStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.dtpStart.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
      this.dtpStart.Location = new System.Drawing.Point(42, 53);
      this.dtpStart.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
      this.dtpStart.Name = "dtpStart";
      this.dtpStart.ShowUpDown = true;
      this.dtpStart.Size = new System.Drawing.Size(90, 26);
      this.dtpStart.TabIndex = 43;
      this.dtpStart.Value = new System.DateTime(2022, 6, 2, 8, 0, 0, 0);
      // 
      // dtpDate
      // 
      this.dtpDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.dtpDate.Location = new System.Drawing.Point(20, 29);
      this.dtpDate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
      this.dtpDate.Name = "dtpDate";
      this.dtpDate.Size = new System.Drawing.Size(280, 26);
      this.dtpDate.TabIndex = 42;
      this.dtpDate.Value = new System.DateTime(2022, 6, 2, 0, 0, 0, 0);
      this.dtpDate.ValueChanged += new System.EventHandler(this.dtpDate_ValueChanged);
      // 
      // lblMissingRecords
      // 
      this.lblMissingRecords.AutoSize = true;
      this.lblMissingRecords.Location = new System.Drawing.Point(23, 29);
      this.lblMissingRecords.Name = "lblMissingRecords";
      this.lblMissingRecords.Size = new System.Drawing.Size(212, 20);
      this.lblMissingRecords.TabIndex = 45;
      this.lblMissingRecords.Text = "You have no missing records";
      // 
      // nudStaff
      // 
      this.nudStaff.Location = new System.Drawing.Point(307, 12);
      this.nudStaff.Name = "nudStaff";
      this.nudStaff.Size = new System.Drawing.Size(120, 26);
      this.nudStaff.TabIndex = 46;
      this.nudStaff.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Location = new System.Drawing.Point(305, 41);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(138, 20);
      this.label2.TabIndex = 48;
      this.label2.Text = "staff name label";
      // 
      // lnkRecord1
      // 
      this.lnkRecord1.AutoSize = true;
      this.lnkRecord1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lnkRecord1.Location = new System.Drawing.Point(38, 32);
      this.lnkRecord1.Name = "lnkRecord1";
      this.lnkRecord1.Size = new System.Drawing.Size(154, 20);
      this.lnkRecord1.TabIndex = 50;
      this.lnkRecord1.TabStop = true;
      this.lnkRecord1.Text = "08:00 am - 05:00 pm";
      this.lnkRecord1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkRecord1_LinkClicked);
      // 
      // lnkRecord2
      // 
      this.lnkRecord2.AutoSize = true;
      this.lnkRecord2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lnkRecord2.Location = new System.Drawing.Point(234, 32);
      this.lnkRecord2.Name = "lnkRecord2";
      this.lnkRecord2.Size = new System.Drawing.Size(154, 20);
      this.lnkRecord2.TabIndex = 51;
      this.lnkRecord2.TabStop = true;
      this.lnkRecord2.Text = "08:00 am - 05:00 pm";
      this.lnkRecord2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkRecord2_LinkClicked);
      // 
      // btnContinue
      // 
      this.btnContinue.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnContinue.Enabled = false;
      this.btnContinue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnContinue.Location = new System.Drawing.Point(353, 3);
      this.btnContinue.Name = "btnContinue";
      this.btnContinue.Size = new System.Drawing.Size(84, 39);
      this.btnContinue.TabIndex = 52;
      this.btnContinue.Text = "Continue";
      this.btnContinue.UseVisualStyleBackColor = false;
      this.btnContinue.Click += new System.EventHandler(this.btnContinue_Click);
      // 
      // groupBox1
      // 
      this.groupBox1.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.groupBox1.Controls.Add(this.dtpDate);
      this.groupBox1.Controls.Add(this.nudStaff);
      this.groupBox1.Controls.Add(this.label2);
      this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
      this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.groupBox1.Location = new System.Drawing.Point(0, 39);
      this.groupBox1.Margin = new System.Windows.Forms.Padding(10);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(446, 72);
      this.groupBox1.TabIndex = 53;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Select Date";
      // 
      // groupBox2
      // 
      this.groupBox2.Controls.Add(this.lnkRecord1);
      this.groupBox2.Controls.Add(this.lnkRecord2);
      this.groupBox2.Dock = System.Windows.Forms.DockStyle.Top;
      this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.groupBox2.Location = new System.Drawing.Point(0, 111);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new System.Drawing.Size(446, 76);
      this.groupBox2.TabIndex = 54;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Select Record to fill";
      // 
      // gbTimes
      // 
      this.gbTimes.Controls.Add(this.btnEndBack);
      this.gbTimes.Controls.Add(this.btnEndNext);
      this.gbTimes.Controls.Add(this.btnStartNext);
      this.gbTimes.Controls.Add(this.btnStartBack);
      this.gbTimes.Controls.Add(this.dtpStart);
      this.gbTimes.Controls.Add(this.label17);
      this.gbTimes.Controls.Add(this.dtpEnd);
      this.gbTimes.Controls.Add(this.label16);
      this.gbTimes.Dock = System.Windows.Forms.DockStyle.Fill;
      this.gbTimes.Enabled = false;
      this.gbTimes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbTimes.Location = new System.Drawing.Point(0, 187);
      this.gbTimes.Name = "gbTimes";
      this.gbTimes.Size = new System.Drawing.Size(446, 294);
      this.gbTimes.TabIndex = 55;
      this.gbTimes.TabStop = false;
      this.gbTimes.Text = "Change Times";
      // 
      // btnEndBack
      // 
      this.btnEndBack.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnEndBack.BackgroundImage = global::workshop_orders.Properties.Resources.arrow_back32;
      this.btnEndBack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
      this.btnEndBack.Location = new System.Drawing.Point(199, 53);
      this.btnEndBack.Name = "btnEndBack";
      this.btnEndBack.Size = new System.Drawing.Size(26, 26);
      this.btnEndBack.TabIndex = 56;
      this.btnEndBack.UseVisualStyleBackColor = false;
      this.btnEndBack.Click += new System.EventHandler(this.btnEndBack_Click);
      // 
      // btnEndNext
      // 
      this.btnEndNext.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnEndNext.BackgroundImage = global::workshop_orders.Properties.Resources.arrow_next32;
      this.btnEndNext.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
      this.btnEndNext.Location = new System.Drawing.Point(319, 53);
      this.btnEndNext.Name = "btnEndNext";
      this.btnEndNext.Size = new System.Drawing.Size(26, 26);
      this.btnEndNext.TabIndex = 55;
      this.btnEndNext.UseVisualStyleBackColor = false;
      this.btnEndNext.Click += new System.EventHandler(this.btnEndNext_Click);
      // 
      // btnStartNext
      // 
      this.btnStartNext.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnStartNext.BackgroundImage = global::workshop_orders.Properties.Resources.arrow_next32;
      this.btnStartNext.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
      this.btnStartNext.Location = new System.Drawing.Point(133, 53);
      this.btnStartNext.Name = "btnStartNext";
      this.btnStartNext.Size = new System.Drawing.Size(26, 26);
      this.btnStartNext.TabIndex = 54;
      this.btnStartNext.UseVisualStyleBackColor = false;
      this.btnStartNext.Click += new System.EventHandler(this.btnStartNext_Click);
      // 
      // btnStartBack
      // 
      this.btnStartBack.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnStartBack.BackgroundImage = global::workshop_orders.Properties.Resources.arrow_back32;
      this.btnStartBack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
      this.btnStartBack.Location = new System.Drawing.Point(15, 53);
      this.btnStartBack.Name = "btnStartBack";
      this.btnStartBack.Size = new System.Drawing.Size(26, 26);
      this.btnStartBack.TabIndex = 53;
      this.btnStartBack.UseVisualStyleBackColor = false;
      this.btnStartBack.Click += new System.EventHandler(this.btnStartBack_Click);
      // 
      // panel1
      // 
      this.panel1.BackColor = System.Drawing.SystemColors.ControlLight;
      this.panel1.Controls.Add(this.lblMissingRecords);
      this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
      this.panel1.Location = new System.Drawing.Point(446, 39);
      this.panel1.Name = "panel1";
      this.panel1.Size = new System.Drawing.Size(304, 442);
      this.panel1.TabIndex = 56;
      this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
      // 
      // toolStrip1
      // 
      this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsBack,
            this.tsContinue});
      this.toolStrip1.Location = new System.Drawing.Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new System.Drawing.Size(750, 39);
      this.toolStrip1.TabIndex = 49;
      this.toolStrip1.Text = "toolStrip1";
      // 
      // tsBack
      // 
      this.tsBack.Image = global::workshop_orders.Properties.Resources.back;
      this.tsBack.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsBack.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsBack.Name = "tsBack";
      this.tsBack.Size = new System.Drawing.Size(68, 36);
      this.tsBack.Text = "Back";
      this.tsBack.Click += new System.EventHandler(this.tsBack_Click);
      // 
      // tsContinue
      // 
      this.tsContinue.Enabled = false;
      this.tsContinue.Image = global::workshop_orders.Properties.Resources.tick32;
      this.tsContinue.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsContinue.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsContinue.Name = "tsContinue";
      this.tsContinue.Size = new System.Drawing.Size(92, 36);
      this.tsContinue.Text = "Continue";
      this.tsContinue.Click += new System.EventHandler(this.tsContinue_Click);
      // 
      // panel2
      // 
      this.panel2.BackColor = System.Drawing.SystemColors.ControlLight;
      this.panel2.Controls.Add(this.btnCancel);
      this.panel2.Controls.Add(this.btnContinue);
      this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
      this.panel2.Location = new System.Drawing.Point(0, 435);
      this.panel2.Name = "panel2";
      this.panel2.Size = new System.Drawing.Size(446, 46);
      this.panel2.TabIndex = 57;
      // 
      // btnCancel
      // 
      this.btnCancel.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnCancel.Location = new System.Drawing.Point(263, 3);
      this.btnCancel.Name = "btnCancel";
      this.btnCancel.Size = new System.Drawing.Size(84, 39);
      this.btnCancel.TabIndex = 53;
      this.btnCancel.Text = "Cancel";
      this.btnCancel.UseVisualStyleBackColor = false;
      this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
      // 
      // OnsiteDate
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.ClientSize = new System.Drawing.Size(750, 481);
      this.Controls.Add(this.panel2);
      this.Controls.Add(this.gbTimes);
      this.Controls.Add(this.groupBox2);
      this.Controls.Add(this.groupBox1);
      this.Controls.Add(this.panel1);
      this.Controls.Add(this.toolStrip1);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
      this.Name = "OnsiteDate";
      this.Text = "OnsiteDate";
      ((System.ComponentModel.ISupportInitialize)(this.nudStaff)).EndInit();
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.groupBox2.ResumeLayout(false);
      this.groupBox2.PerformLayout();
      this.gbTimes.ResumeLayout(false);
      this.gbTimes.PerformLayout();
      this.panel1.ResumeLayout(false);
      this.panel1.PerformLayout();
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.panel2.ResumeLayout(false);
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Label label16;
    private System.Windows.Forms.Label label17;
    private System.Windows.Forms.DateTimePicker dtpEnd;
    private System.Windows.Forms.DateTimePicker dtpStart;
    private System.Windows.Forms.DateTimePicker dtpDate;
    private System.Windows.Forms.Label lblMissingRecords;
    private System.Windows.Forms.NumericUpDown nudStaff;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.LinkLabel lnkRecord1;
    private System.Windows.Forms.LinkLabel lnkRecord2;
    private System.Windows.Forms.Button btnContinue;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.GroupBox groupBox2;
    private System.Windows.Forms.GroupBox gbTimes;
    private System.Windows.Forms.Button btnEndBack;
    private System.Windows.Forms.Button btnEndNext;
    private System.Windows.Forms.Button btnStartNext;
    private System.Windows.Forms.Button btnStartBack;
    private System.Windows.Forms.Panel panel1;
    private System.Windows.Forms.ToolStrip toolStrip1;
    private System.Windows.Forms.ToolStripButton tsBack;
    private System.Windows.Forms.ToolStripButton tsContinue;
    private System.Windows.Forms.Panel panel2;
    private System.Windows.Forms.Button btnCancel;
  }
}