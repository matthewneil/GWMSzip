﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workshop_orders
{
  public partial class WorkshopLabour : Form
  {
    private int StaffID = -1;
    private int JobTaskID = -1;
    private int MinimumPercent = 0;
    private bool load = true;

    public static Workshop frm;
    public WorkshopLabour(int JobTaskID, int StaffID)
    {
      InitializeComponent();
      this.JobTaskID = JobTaskID;
      this.StaffID = StaffID;

      tsUser.Text = DataAccess.ExecuteScalarString("SELECT StaffFullName FROM staff WHERE StaffID = " + StaffID);

      MinimumPercent = DataAccess.ExecuteScalarInt("SELECT SUM(percent) FROM labour WHERE JobTaskID = " + JobTaskID + " GROUP BY JobTaskID");
      tbrPercentage.Value = MinimumPercent;

      if(MinimumPercent == 100)
      {
        tsTime.Enabled = false;
        btnTime.Enabled = false;
      }

      dtpTextTime.Value = RoundUp(DateTime.Now, TimeSpan.FromMinutes(15));
      
      DateTime.Now.AddMinutes(30);
      dtpTextDay.Value = DateTime.Today.AddDays(1);

      load = false;
      SetButtonState(DataAccess.FormState(this.AccessibilityObject.Name, tsTime));
    }

    DateTime RoundUp(DateTime dt, TimeSpan d)
    {
      return new DateTime((dt.Ticks + d.Ticks - 1) / d.Ticks * d.Ticks, dt.Kind);
    }

    private void SetButtonState(Boolean bState)
    {
      btnTime.Enabled = false;
    }


    private void lblPercent_TextChanged(object sender, EventArgs e)
    {
      lblPercent2.Text = lblPercent.Text;
    }

    private void tsBack_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private void btnTime_Click(object sender, EventArgs e)
    {
      AddTime();
    }

    private void tsTime_Click(object sender, EventArgs e)
    {
      AddTime();
    }

    private void AddTime()
    {
      String errors = "Unable to save time due to the following issues:\n\n";

      if(tbrPercentage.Value < 1)
      {
        errors += " - You need to add a percent value to this job.\n";
      }
      if(!rbTextYes.Checked && !rbTextNo.Checked)
      {
        errors += " - You need to select if a text should be sent or not.\n";
      }
      if(nudMilage.Value == 0)
      {
        //errors += " - With this Job you need to specify the milage.\n";
      }

      DataTable dt = DataAccess.ExecuteDataTable("SELECT * FROM jobitem WHERE JobID = " + JobTaskID);
      if (dt != null && dt.Rows.Count > 0)
      {
        foreach (DataRow row in dt.Rows)
        {
          MessageBox.Show(row["ItemStockID"].ToString());
        }
      }

      if (errors != "Unable to save time due to the following issues:\n\n")
      {
        DataAccess.ShowMessage(errors);
        return;
      }
      DataAccess.LabourManage(StaffID, JobTaskID, tbrPercentage.Value - MinimumPercent, txtNote.Text);
      if(tbrPercentage.Value == 100)
      {
        DataTable dt2 = DataAccess.ExecuteDataTable("SELECT * FROM jobitem WHERE JobID = " + JobTaskID);
        if(dt != null && dt.Rows.Count > 0)
        {
          foreach(DataRow row in dt.Rows)
          {
            DataAccess.ItemMovementManage(int.Parse(row["ItemStockID"].ToString()), 2, JobTaskID, DataAccess.InternalIDType.Job, -1, decimal.Parse(row["Cost"].ToString()), "Job Completed", 0);
          }
        }

        DataAccess.ExecuteNonQuery("UPDATE job SET statusID = 11 WHERE JobID = " + JobTaskID); //StatusID 11 is 'Complete'
        DataAccess.ExecuteNonQuery("UPDATE jobitem SET statusID = 11 WHERE JobID = " + JobTaskID);

        if(nudMilage.Value > 0) //only update milage if the milage value is above 0
        {
          DataAccess.ExecuteNonQuery("UPDATE job SET JobMilage = " + nudMilage.Value + " WHERE JobID = " + JobTaskID); //Update milage on job
        }

        DataAccess.ItemMovementManage(1, 2, JobTaskID, DataAccess.InternalIDType.Job, 1, 0, "Job Completed", 0);
        if (rbTextYes.Checked)
        {
          DataAccess.ExecuteNonQuery("INSERT INTO sms(`smsDate`, `smsSent`, `smsJobID`) VALUES ('" + dtpTextDay.Value.ToString("yyyy-MM-dd ") + dtpTextTime.Value.ToString("HH:mm:ss") + "', 0, " + JobTaskID + ");");
        }
      }    
      DataAccess.ShowMessage("Time successfully added.");
      if(frm != null)
      {
        frm.LoadUsers();
      }
      
      this.Close();
    }

   

    private void chkTextToday_CheckedChanged(object sender, EventArgs e)
    {
      dtpTextDay.Visible = !chkTextToday.Checked;
    }

    private void tbrPercentage_ValueChanged(object sender, EventArgs e)
    {
      if (tbrPercentage.Value < MinimumPercent)
      {
        tbrPercentage.Value = MinimumPercent;
      }
      
      if(tbrPercentage.Value - (tbrPercentage.Value % 5) >= MinimumPercent)
      {
        tbrPercentage.Value = tbrPercentage.Value - (tbrPercentage.Value % 5);
      }

      if(tbrPercentage.Value > MinimumPercent)
      {
        tsTime.Enabled = true;
        btnTime.Enabled = true;
      }
      else
      {
        tsTime.Enabled = false;
        btnTime.Enabled = false;
      }
      lblPercent.Text = tbrPercentage.Value + "%";
    }

    private void btnPercentUp_Click(object sender, EventArgs e)
    {
      if (tbrPercentage.Value + 5 > tbrPercentage.Maximum)
      {
        tbrPercentage.Value = 100;
      }
      else
      {
        tbrPercentage.Value += 5;
      }
    }

    private void btnPercentDown_Click(object sender, EventArgs e)
    {
      if (tbrPercentage.Value - 5 < tbrPercentage.Minimum)
      {
        tbrPercentage.Value = 0;
      }
      else
      {
        tbrPercentage.Value -= 5;
      }
    }

    private void btnTextDown_Click(object sender, EventArgs e)
    {
      dtpTextTime.Value = dtpTextTime.Value.AddMinutes(-15);
      if(dtpTextTime.Value < DateTime.Parse("08:00:00"))
      {
        dtpTextTime.Value = DateTime.Parse("08:00:00");
      }
    }

    private void btnTextUp_Click(object sender, EventArgs e)
    {
      dtpTextTime.Value = dtpTextTime.Value.AddMinutes(15);
      if (dtpTextTime.Value > DateTime.Parse("16:45:00"))
      {
        dtpTextTime.Value = DateTime.Parse("16:45:00");
      }
    }

    private void rbTextYes_CheckedChanged(object sender, EventArgs e)
    {

      btnTextDown.Visible = rbTextYes.Checked;
      btnTextUp.Visible = rbTextYes.Checked;
      dtpTextTime.Visible = rbTextYes.Checked;
      //chkTextToday.Visible = rbTextYes.Checked;
      chkTextToday.Checked = true;

    }

    private void chkMilage_CheckedChanged(object sender, EventArgs e)
    {
    }
  }
}
