﻿namespace workshop_orders
{
  partial class Quantity
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.label1 = new System.Windows.Forms.Label();
      this.nudQuantity = new System.Windows.Forms.NumericUpDown();
      this.btnContinue = new System.Windows.Forms.Button();
      ((System.ComponentModel.ISupportInitialize)(this.nudQuantity)).BeginInit();
      this.SuspendLayout();
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label1.Location = new System.Drawing.Point(23, 14);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(72, 20);
      this.label1.TabIndex = 0;
      this.label1.Text = "Quantity:";
      // 
      // nudQuantity
      // 
      this.nudQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.nudQuantity.Location = new System.Drawing.Point(106, 12);
      this.nudQuantity.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
      this.nudQuantity.Name = "nudQuantity";
      this.nudQuantity.Size = new System.Drawing.Size(120, 26);
      this.nudQuantity.TabIndex = 1;
      this.nudQuantity.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
      // 
      // btnContinue
      // 
      this.btnContinue.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnContinue.Location = new System.Drawing.Point(79, 45);
      this.btnContinue.Name = "btnContinue";
      this.btnContinue.Size = new System.Drawing.Size(82, 35);
      this.btnContinue.TabIndex = 2;
      this.btnContinue.Text = "Continue";
      this.btnContinue.UseVisualStyleBackColor = true;
      this.btnContinue.Click += new System.EventHandler(this.btnContinue_Click);
      // 
      // Quantity
      // 
      this.AcceptButton = this.btnContinue;
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(257, 137);
      this.ControlBox = false;
      this.Controls.Add(this.btnContinue);
      this.Controls.Add(this.nudQuantity);
      this.Controls.Add(this.label1);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
      this.Name = "Quantity";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
      this.Text = "Quantity";
      ((System.ComponentModel.ISupportInitialize)(this.nudQuantity)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.NumericUpDown nudQuantity;
    private System.Windows.Forms.Button btnContinue;
  }
}