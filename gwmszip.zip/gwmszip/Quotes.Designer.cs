﻿using System;
using System.Windows.Forms;

namespace workshop_orders
{
    partial class Quotes
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Quotes));
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
      this.pnlFilter = new System.Windows.Forms.Panel();
      this.Panel3 = new System.Windows.Forms.Panel();
      this.btnQuote = new System.Windows.Forms.Button();
      this.btnQuote1 = new System.Windows.Forms.Button();
      this.txtQuote = new System.Windows.Forms.TextBox();
      this.lnkFind = new System.Windows.Forms.LinkLabel();
      this.gbFilter = new System.Windows.Forms.GroupBox();
      this.btnReset = new System.Windows.Forms.Button();
      this.Label3 = new System.Windows.Forms.Label();
      this.chkOverdue = new System.Windows.Forms.CheckBox();
      this.cmbCustomer = new System.Windows.Forms.ComboBox();
      this.label2 = new System.Windows.Forms.Label();
      this.cmbStaff = new System.Windows.Forms.ComboBox();
      this.label1 = new System.Windows.Forms.Label();
      this.cmbStatus = new System.Windows.Forms.ComboBox();
      this.label40 = new System.Windows.Forms.Label();
      this.dtpToDate = new System.Windows.Forms.DateTimePicker();
      this.label39 = new System.Windows.Forms.Label();
      this.dtpFromDate = new System.Windows.Forms.DateTimePicker();
      this.label38 = new System.Windows.Forms.Label();
      this.ts = new System.Windows.Forms.ToolStrip();
      this.tbBack = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
      this.tbNew = new System.Windows.Forms.ToolStripButton();
      this.tsEdit = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
      this.tsDelete = new System.Windows.Forms.ToolStripButton();
      this.tsRefresh = new System.Windows.Forms.ToolStripButton();
      this.pnlBody = new System.Windows.Forms.Panel();
      this.dgvData = new System.Windows.Forms.DataGridView();
      this.chQuoteID1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chDate1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chCustomer1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chReference = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chQuoteType = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chStaffID = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chJobPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.DataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chLabour = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chCreateBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chLast1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chNext1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.DataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.pnlFilter.SuspendLayout();
      this.Panel3.SuspendLayout();
      this.gbFilter.SuspendLayout();
      this.ts.SuspendLayout();
      this.pnlBody.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgvData)).BeginInit();
      this.SuspendLayout();
      // 
      // pnlFilter
      // 
      this.pnlFilter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(210)))));
      this.pnlFilter.Controls.Add(this.Panel3);
      this.pnlFilter.Controls.Add(this.gbFilter);
      this.pnlFilter.Dock = System.Windows.Forms.DockStyle.Left;
      this.pnlFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.pnlFilter.Location = new System.Drawing.Point(0, 39);
      this.pnlFilter.Name = "pnlFilter";
      this.pnlFilter.Size = new System.Drawing.Size(237, 1002);
      this.pnlFilter.TabIndex = 5;
      // 
      // Panel3
      // 
      this.Panel3.BackColor = System.Drawing.Color.White;
      this.Panel3.Controls.Add(this.btnQuote);
      this.Panel3.Controls.Add(this.btnQuote1);
      this.Panel3.Controls.Add(this.txtQuote);
      this.Panel3.Controls.Add(this.lnkFind);
      this.Panel3.Location = new System.Drawing.Point(19, 449);
      this.Panel3.Name = "Panel3";
      this.Panel3.Size = new System.Drawing.Size(205, 58);
      this.Panel3.TabIndex = 84;
      // 
      // btnQuote
      // 
      this.btnQuote.Location = new System.Drawing.Point(173, 29);
      this.btnQuote.Name = "btnQuote";
      this.btnQuote.Size = new System.Drawing.Size(13, 20);
      this.btnQuote.TabIndex = 73;
      this.btnQuote.Text = "..";
      this.btnQuote.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      this.btnQuote.UseVisualStyleBackColor = true;
      this.btnQuote.Click += new System.EventHandler(this.btnQuote_Click);
      // 
      // btnQuote1
      // 
      this.btnQuote1.BackColor = System.Drawing.Color.Transparent;
      this.btnQuote1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
      this.btnQuote1.Image = global::workshop_orders.Properties.Resources.find;
      this.btnQuote1.Location = new System.Drawing.Point(5, 5);
      this.btnQuote1.Name = "btnQuote1";
      this.btnQuote1.Size = new System.Drawing.Size(48, 48);
      this.btnQuote1.TabIndex = 0;
      this.btnQuote1.UseVisualStyleBackColor = false;
      this.btnQuote1.Click += new System.EventHandler(this.btnQuote1_Click);
      // 
      // txtQuote
      // 
      this.txtQuote.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtQuote.Location = new System.Drawing.Point(59, 28);
      this.txtQuote.Name = "txtQuote";
      this.txtQuote.Size = new System.Drawing.Size(108, 23);
      this.txtQuote.TabIndex = 72;
      this.txtQuote.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtQuote_KeyDown);
      // 
      // lnkFind
      // 
      this.lnkFind.AutoSize = true;
      this.lnkFind.DisabledLinkColor = System.Drawing.Color.White;
      this.lnkFind.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lnkFind.LinkColor = System.Drawing.Color.Black;
      this.lnkFind.Location = new System.Drawing.Point(59, 10);
      this.lnkFind.Name = "lnkFind";
      this.lnkFind.Size = new System.Drawing.Size(76, 16);
      this.lnkFind.TabIndex = 65;
      this.lnkFind.TabStop = true;
      this.lnkFind.Text = "Find Quote";
      // 
      // gbFilter
      // 
      this.gbFilter.Controls.Add(this.btnReset);
      this.gbFilter.Controls.Add(this.Label3);
      this.gbFilter.Controls.Add(this.chkOverdue);
      this.gbFilter.Controls.Add(this.cmbCustomer);
      this.gbFilter.Controls.Add(this.label2);
      this.gbFilter.Controls.Add(this.cmbStaff);
      this.gbFilter.Controls.Add(this.label1);
      this.gbFilter.Controls.Add(this.cmbStatus);
      this.gbFilter.Controls.Add(this.label40);
      this.gbFilter.Controls.Add(this.dtpToDate);
      this.gbFilter.Controls.Add(this.label39);
      this.gbFilter.Controls.Add(this.dtpFromDate);
      this.gbFilter.Controls.Add(this.label38);
      this.gbFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbFilter.ForeColor = System.Drawing.Color.White;
      this.gbFilter.Location = new System.Drawing.Point(7, 10);
      this.gbFilter.Name = "gbFilter";
      this.gbFilter.Size = new System.Drawing.Size(222, 358);
      this.gbFilter.TabIndex = 0;
      this.gbFilter.TabStop = false;
      this.gbFilter.Text = "Filters";
      // 
      // btnReset
      // 
      this.btnReset.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnReset.ForeColor = System.Drawing.Color.Black;
      this.btnReset.Image = global::workshop_orders.Properties.Resources.reset;
      this.btnReset.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
      this.btnReset.Location = new System.Drawing.Point(47, 315);
      this.btnReset.Name = "btnReset";
      this.btnReset.Padding = new System.Windows.Forms.Padding(5, 0, 5, 0);
      this.btnReset.Size = new System.Drawing.Size(118, 36);
      this.btnReset.TabIndex = 85;
      this.btnReset.Text = "Reset";
      this.btnReset.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      this.btnReset.UseVisualStyleBackColor = true;
      // 
      // Label3
      // 
      this.Label3.AutoSize = true;
      this.Label3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.Label3.ForeColor = System.Drawing.Color.Red;
      this.Label3.Location = new System.Drawing.Point(12, 279);
      this.Label3.Name = "Label3";
      this.Label3.Size = new System.Drawing.Size(129, 16);
      this.Label3.TabIndex = 101;
      this.Label3.Text = "Overdue Followups";
      // 
      // chkOverdue
      // 
      this.chkOverdue.AutoSize = true;
      this.chkOverdue.Location = new System.Drawing.Point(150, 278);
      this.chkOverdue.Name = "chkOverdue";
      this.chkOverdue.Size = new System.Drawing.Size(32, 21);
      this.chkOverdue.TabIndex = 100;
      this.chkOverdue.Text = " ";
      this.chkOverdue.UseVisualStyleBackColor = true;
      // 
      // cmbCustomer
      // 
      this.cmbCustomer.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
      this.cmbCustomer.DisplayMember = "textfield";
      this.cmbCustomer.DropDownHeight = 300;
      this.cmbCustomer.DropDownWidth = 250;
      this.cmbCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbCustomer.FormattingEnabled = true;
      this.cmbCustomer.IntegralHeight = false;
      this.cmbCustomer.Location = new System.Drawing.Point(12, 186);
      this.cmbCustomer.Name = "cmbCustomer";
      this.cmbCustomer.Size = new System.Drawing.Size(200, 24);
      this.cmbCustomer.TabIndex = 9;
      this.cmbCustomer.ValueMember = "datafield";
      this.cmbCustomer.SelectedIndexChanged += new System.EventHandler(this.cmbCustomer_SelectedIndexChanged);
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label2.ForeColor = System.Drawing.Color.White;
      this.label2.Location = new System.Drawing.Point(12, 168);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(73, 16);
      this.label2.TabIndex = 8;
      this.label2.Text = "Customer";
      // 
      // cmbStaff
      // 
      this.cmbStaff.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
      this.cmbStaff.DisplayMember = "textfield";
      this.cmbStaff.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbStaff.FormattingEnabled = true;
      this.cmbStaff.Location = new System.Drawing.Point(12, 236);
      this.cmbStaff.Name = "cmbStaff";
      this.cmbStaff.Size = new System.Drawing.Size(200, 24);
      this.cmbStaff.TabIndex = 7;
      this.cmbStaff.ValueMember = "datafield";
      this.cmbStaff.SelectedIndexChanged += new System.EventHandler(this.StaffCombo_SelectedIndexChanged);
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label1.ForeColor = System.Drawing.Color.White;
      this.label1.Location = new System.Drawing.Point(12, 218);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(39, 16);
      this.label1.TabIndex = 6;
      this.label1.Text = "Staff";
      // 
      // cmbStatus
      // 
      this.cmbStatus.DropDownHeight = 350;
      this.cmbStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbStatus.FormattingEnabled = true;
      this.cmbStatus.IntegralHeight = false;
      this.cmbStatus.Items.AddRange(new object[] {
            "All",
            "Accepted",
            "Lost",
            "Cancelled",
            "Closed",
            "New/Pending"});
      this.cmbStatus.Location = new System.Drawing.Point(12, 138);
      this.cmbStatus.Name = "cmbStatus";
      this.cmbStatus.Size = new System.Drawing.Size(200, 24);
      this.cmbStatus.TabIndex = 5;
      this.cmbStatus.Text = "All";
      this.cmbStatus.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
      // 
      // label40
      // 
      this.label40.AutoSize = true;
      this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label40.ForeColor = System.Drawing.Color.White;
      this.label40.Location = new System.Drawing.Point(12, 122);
      this.label40.Name = "label40";
      this.label40.Size = new System.Drawing.Size(51, 16);
      this.label40.TabIndex = 4;
      this.label40.Text = "Status";
      // 
      // dtpToDate
      // 
      this.dtpToDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.dtpToDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
      this.dtpToDate.Location = new System.Drawing.Point(12, 94);
      this.dtpToDate.Name = "dtpToDate";
      this.dtpToDate.Size = new System.Drawing.Size(102, 22);
      this.dtpToDate.TabIndex = 3;
      this.dtpToDate.Value = new System.DateTime(2021, 12, 9, 12, 50, 7, 0);
      this.dtpToDate.CloseUp += new System.EventHandler(this.endDateTime_ValueChanged);
      // 
      // label39
      // 
      this.label39.AutoSize = true;
      this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label39.ForeColor = System.Drawing.Color.White;
      this.label39.Location = new System.Drawing.Point(12, 75);
      this.label39.Name = "label39";
      this.label39.Size = new System.Drawing.Size(60, 16);
      this.label39.TabIndex = 2;
      this.label39.Text = "ToDate";
      // 
      // dtpFromDate
      // 
      this.dtpFromDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.dtpFromDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
      this.dtpFromDate.Location = new System.Drawing.Point(12, 46);
      this.dtpFromDate.Name = "dtpFromDate";
      this.dtpFromDate.Size = new System.Drawing.Size(102, 22);
      this.dtpFromDate.TabIndex = 1;
      this.dtpFromDate.Value = new System.DateTime(2021, 12, 9, 12, 50, 7, 0);
      this.dtpFromDate.CloseUp += new System.EventHandler(this.startDateTime_ValueChanged);
      // 
      // label38
      // 
      this.label38.AutoSize = true;
      this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label38.ForeColor = System.Drawing.Color.White;
      this.label38.Location = new System.Drawing.Point(12, 27);
      this.label38.Name = "label38";
      this.label38.Size = new System.Drawing.Size(80, 16);
      this.label38.TabIndex = 0;
      this.label38.Text = "From Date";
      // 
      // ts
      // 
      this.ts.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tbBack,
            this.toolStripSeparator1,
            this.tbNew,
            this.tsEdit,
            this.toolStripSeparator2,
            this.tsDelete,
            this.tsRefresh});
      this.ts.Location = new System.Drawing.Point(0, 0);
      this.ts.Name = "ts";
      this.ts.Size = new System.Drawing.Size(1904, 39);
      this.ts.TabIndex = 6;
      this.ts.Text = "toolStrip1";
      // 
      // tbBack
      // 
      this.tbBack.Image = ((System.Drawing.Image)(resources.GetObject("tbBack.Image")));
      this.tbBack.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tbBack.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tbBack.Name = "tbBack";
      this.tbBack.Size = new System.Drawing.Size(68, 36);
      this.tbBack.Text = "Back";
      this.tbBack.Click += new System.EventHandler(this.BackToolStripButton_Click);
      // 
      // toolStripSeparator1
      // 
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
      // 
      // tbNew
      // 
      this.tbNew.Image = ((System.Drawing.Image)(resources.GetObject("tbNew.Image")));
      this.tbNew.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tbNew.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tbNew.Name = "tbNew";
      this.tbNew.Size = new System.Drawing.Size(67, 36);
      this.tbNew.Text = "New";
      this.tbNew.Click += new System.EventHandler(this.NewToolStripButton_Click);
      // 
      // tsEdit
      // 
      this.tsEdit.Image = global::workshop_orders.Properties.Resources.edit;
      this.tsEdit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsEdit.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsEdit.Name = "tsEdit";
      this.tsEdit.Size = new System.Drawing.Size(63, 36);
      this.tsEdit.Text = "Edit";
      this.tsEdit.ToolTipText = "Edit";
      this.tsEdit.Click += new System.EventHandler(this.tsEdit_Click);
      // 
      // toolStripSeparator2
      // 
      this.toolStripSeparator2.Name = "toolStripSeparator2";
      this.toolStripSeparator2.Size = new System.Drawing.Size(6, 39);
      // 
      // tsDelete
      // 
      this.tsDelete.ForeColor = System.Drawing.Color.Red;
      this.tsDelete.Image = global::workshop_orders.Properties.Resources.delete;
      this.tsDelete.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsDelete.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsDelete.Name = "tsDelete";
      this.tsDelete.Size = new System.Drawing.Size(76, 36);
      this.tsDelete.Text = "Delete";
      this.tsDelete.Visible = false;
      this.tsDelete.Click += new System.EventHandler(this.tsDelete_Click);
      // 
      // tsRefresh
      // 
      this.tsRefresh.Image = global::workshop_orders.Properties.Resources.refresh;
      this.tsRefresh.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsRefresh.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsRefresh.Name = "tsRefresh";
      this.tsRefresh.Size = new System.Drawing.Size(82, 36);
      this.tsRefresh.Text = "Refresh";
      this.tsRefresh.Click += new System.EventHandler(this.tsRefresh_Click);
      // 
      // pnlBody
      // 
      this.pnlBody.Controls.Add(this.dgvData);
      this.pnlBody.Dock = System.Windows.Forms.DockStyle.Fill;
      this.pnlBody.Location = new System.Drawing.Point(237, 39);
      this.pnlBody.Name = "pnlBody";
      this.pnlBody.Size = new System.Drawing.Size(1667, 1002);
      this.pnlBody.TabIndex = 7;
      // 
      // dgvData
      // 
      this.dgvData.AllowUserToAddRows = false;
      this.dgvData.AllowUserToDeleteRows = false;
      this.dgvData.AllowUserToResizeRows = false;
      dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
      this.dgvData.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle15;
      this.dgvData.BackgroundColor = System.Drawing.Color.White;
      this.dgvData.BorderStyle = System.Windows.Forms.BorderStyle.None;
      this.dgvData.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
      dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
      dataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Control;
      dataGridViewCellStyle16.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      dataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.WindowText;
      dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight;
      dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
      dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
      this.dgvData.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle16;
      this.dgvData.ColumnHeadersHeight = 28;
      this.dgvData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
      this.dgvData.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.chQuoteID1,
            this.chDate1,
            this.chCustomer1,
            this.chReference,
            this.chQuoteType,
            this.chStaffID,
            this.chJobPrice,
            this.DataGridViewTextBoxColumn3,
            this.chLabour,
            this.chCreateBy,
            this.chLast1,
            this.chNext1,
            this.DataGridViewTextBoxColumn4});
      this.dgvData.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dgvData.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
      this.dgvData.Location = new System.Drawing.Point(0, 0);
      this.dgvData.MultiSelect = false;
      this.dgvData.Name = "dgvData";
      dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
      dataGridViewCellStyle27.BackColor = System.Drawing.SystemColors.Control;
      dataGridViewCellStyle27.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      dataGridViewCellStyle27.ForeColor = System.Drawing.SystemColors.WindowText;
      dataGridViewCellStyle27.SelectionBackColor = System.Drawing.SystemColors.Highlight;
      dataGridViewCellStyle27.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
      dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
      this.dgvData.RowHeadersDefaultCellStyle = dataGridViewCellStyle27;
      this.dgvData.RowHeadersVisible = false;
      dataGridViewCellStyle28.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.dgvData.RowsDefaultCellStyle = dataGridViewCellStyle28;
      this.dgvData.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
      this.dgvData.ShowEditingIcon = false;
      this.dgvData.Size = new System.Drawing.Size(1667, 1002);
      this.dgvData.TabIndex = 74;
      this.dgvData.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvData_CellDoubleClick);
      // 
      // chQuoteID1
      // 
      dataGridViewCellStyle17.NullValue = null;
      this.chQuoteID1.DefaultCellStyle = dataGridViewCellStyle17;
      this.chQuoteID1.HeaderText = "Quote";
      this.chQuoteID1.Name = "chQuoteID1";
      this.chQuoteID1.ReadOnly = true;
      this.chQuoteID1.Width = 90;
      // 
      // chDate1
      // 
      dataGridViewCellStyle18.Format = "d";
      dataGridViewCellStyle18.NullValue = null;
      this.chDate1.DefaultCellStyle = dataGridViewCellStyle18;
      this.chDate1.HeaderText = "Quote Date";
      this.chDate1.Name = "chDate1";
      this.chDate1.ReadOnly = true;
      // 
      // chCustomer1
      // 
      this.chCustomer1.HeaderText = "Customer";
      this.chCustomer1.Name = "chCustomer1";
      this.chCustomer1.ReadOnly = true;
      this.chCustomer1.Width = 250;
      // 
      // chReference
      // 
      this.chReference.HeaderText = "Reference";
      this.chReference.Name = "chReference";
      this.chReference.ReadOnly = true;
      this.chReference.Width = 200;
      // 
      // chQuoteType
      // 
      dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
      this.chQuoteType.DefaultCellStyle = dataGridViewCellStyle19;
      this.chQuoteType.HeaderText = "Quote Type";
      this.chQuoteType.Name = "chQuoteType";
      this.chQuoteType.ReadOnly = true;
      this.chQuoteType.Width = 120;
      // 
      // chStaffID
      // 
      dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
      this.chStaffID.DefaultCellStyle = dataGridViewCellStyle20;
      this.chStaffID.HeaderText = "Status";
      this.chStaffID.Name = "chStaffID";
      this.chStaffID.ReadOnly = true;
      this.chStaffID.Width = 110;
      // 
      // chJobPrice
      // 
      dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
      dataGridViewCellStyle21.Format = "C2";
      this.chJobPrice.DefaultCellStyle = dataGridViewCellStyle21;
      this.chJobPrice.HeaderText = "Quote Price";
      this.chJobPrice.Name = "chJobPrice";
      this.chJobPrice.ReadOnly = true;
      this.chJobPrice.Width = 120;
      // 
      // DataGridViewTextBoxColumn3
      // 
      dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
      dataGridViewCellStyle22.Format = "C2";
      this.DataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle22;
      this.DataGridViewTextBoxColumn3.HeaderText = "Cost Price";
      this.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3";
      this.DataGridViewTextBoxColumn3.ReadOnly = true;
      this.DataGridViewTextBoxColumn3.Width = 120;
      // 
      // chLabour
      // 
      dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
      dataGridViewCellStyle23.Format = "P2";
      this.chLabour.DefaultCellStyle = dataGridViewCellStyle23;
      this.chLabour.HeaderText = "Margin";
      this.chLabour.Name = "chLabour";
      this.chLabour.ReadOnly = true;
      // 
      // chCreateBy
      // 
      this.chCreateBy.DataPropertyName = "StaffName";
      dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
      this.chCreateBy.DefaultCellStyle = dataGridViewCellStyle24;
      this.chCreateBy.HeaderText = "Quoted By";
      this.chCreateBy.Name = "chCreateBy";
      this.chCreateBy.ReadOnly = true;
      this.chCreateBy.Width = 150;
      // 
      // chLast1
      // 
      dataGridViewCellStyle25.Format = "dd/MM/yyyy";
      this.chLast1.DefaultCellStyle = dataGridViewCellStyle25;
      this.chLast1.HeaderText = "Last Contact";
      this.chLast1.Name = "chLast1";
      this.chLast1.ReadOnly = true;
      this.chLast1.Width = 139;
      // 
      // chNext1
      // 
      dataGridViewCellStyle26.Format = "dd/MM/yyyy";
      this.chNext1.DefaultCellStyle = dataGridViewCellStyle26;
      this.chNext1.HeaderText = "Next Contact";
      this.chNext1.Name = "chNext1";
      this.chNext1.ReadOnly = true;
      this.chNext1.Visible = false;
      this.chNext1.Width = 90;
      // 
      // DataGridViewTextBoxColumn4
      // 
      this.DataGridViewTextBoxColumn4.DataPropertyName = "Comments";
      this.DataGridViewTextBoxColumn4.HeaderText = "Comments";
      this.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4";
      this.DataGridViewTextBoxColumn4.ReadOnly = true;
      this.DataGridViewTextBoxColumn4.Width = 350;
      // 
      // Quotes
      // 
      this.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
      this.ClientSize = new System.Drawing.Size(1904, 1041);
      this.ControlBox = false;
      this.Controls.Add(this.pnlBody);
      this.Controls.Add(this.pnlFilter);
      this.Controls.Add(this.ts);
      this.Name = "Quotes";
      this.ShowIcon = false;
      this.ShowInTaskbar = false;
      this.Text = "Quotes";
      this.pnlFilter.ResumeLayout(false);
      this.Panel3.ResumeLayout(false);
      this.Panel3.PerformLayout();
      this.gbFilter.ResumeLayout(false);
      this.gbFilter.PerformLayout();
      this.ts.ResumeLayout(false);
      this.ts.PerformLayout();
      this.pnlBody.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.dgvData)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

        }

        #endregion
        private Panel pnlFilter;
        private GroupBox gbFilter;
        private ComboBox cmbStatus;
        private Label label40;
        private ToolStrip ts;
        private ToolStripButton tbBack;
        private ToolStripButton tbNew;
		internal Panel Panel3;
		internal Button btnQuote;
		internal Button btnQuote1;
		internal TextBox txtQuote;
		internal LinkLabel lnkFind;
		private Panel pnlBody;
		internal ToolStripButton tsEdit;
		internal ToolStripButton tsDelete;
		internal ToolStripButton tsRefresh;
		private ToolStripSeparator toolStripSeparator1;
		private ToolStripSeparator toolStripSeparator2;
		internal DataGridView dgvData;
		private DataGridViewTextBoxColumn chQuoteID1;
		private DataGridViewTextBoxColumn chDate1;
		private DataGridViewTextBoxColumn chCustomer1;
		private DataGridViewTextBoxColumn chReference;
		private DataGridViewTextBoxColumn chQuoteType;
		private DataGridViewTextBoxColumn chStaffID;
		private DataGridViewTextBoxColumn chJobPrice;
		private DataGridViewTextBoxColumn DataGridViewTextBoxColumn3;
		private DataGridViewTextBoxColumn chLabour;
		private DataGridViewTextBoxColumn chCreateBy;
		private DataGridViewTextBoxColumn chLast1;
		private DataGridViewTextBoxColumn chNext1;
		private DataGridViewTextBoxColumn DataGridViewTextBoxColumn4;
    internal Button btnReset;
    internal Label Label3;
    internal CheckBox chkOverdue;
    private ComboBox cmbCustomer;
    private Label label2;
    private ComboBox cmbStaff;
    private Label label1;
    private DateTimePicker dtpToDate;
    private Label label39;
    private DateTimePicker dtpFromDate;
    private Label label38;
  }
}

