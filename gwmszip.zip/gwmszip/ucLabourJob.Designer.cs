﻿namespace workshop_orders
{
  partial class ucLabourJob
  {
    /// <summary> 
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary> 
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Component Designer generated code

    /// <summary> 
    /// Required method for Designer support - do not modify 
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.lblJobID = new System.Windows.Forms.Label();
      this.lblBooking = new System.Windows.Forms.Label();
      this.lblTime = new System.Windows.Forms.Label();
      this.lblType = new System.Windows.Forms.Label();
      this.lblCustomer = new System.Windows.Forms.Label();
      this.lblVehicle = new System.Windows.Forms.Label();
      this.lblArea = new System.Windows.Forms.Label();
      this.lblReference = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // lblJobID
      // 
      this.lblJobID.AutoSize = true;
      this.lblJobID.BackColor = System.Drawing.Color.Transparent;
      this.lblJobID.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblJobID.Location = new System.Drawing.Point(13, 36);
      this.lblJobID.Name = "lblJobID";
      this.lblJobID.Size = new System.Drawing.Size(58, 24);
      this.lblJobID.TabIndex = 1;
      this.lblJobID.Text = "JobID";
      this.lblJobID.Click += new System.EventHandler(this.lblJobID_Click);
      // 
      // lblBooking
      // 
      this.lblBooking.BackColor = System.Drawing.Color.Transparent;
      this.lblBooking.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblBooking.Location = new System.Drawing.Point(77, 10);
      this.lblBooking.Name = "lblBooking";
      this.lblBooking.Size = new System.Drawing.Size(279, 24);
      this.lblBooking.TabIndex = 2;
      this.lblBooking.Text = "Booking Date";
      this.lblBooking.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      this.lblBooking.Click += new System.EventHandler(this.lblBooking_Click);
      // 
      // lblTime
      // 
      this.lblTime.BackColor = System.Drawing.Color.Transparent;
      this.lblTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblTime.Location = new System.Drawing.Point(103, 36);
      this.lblTime.Name = "lblTime";
      this.lblTime.Size = new System.Drawing.Size(253, 24);
      this.lblTime.TabIndex = 3;
      this.lblTime.Text = "Time";
      this.lblTime.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      this.lblTime.Click += new System.EventHandler(this.lblTime_Click);
      // 
      // lblType
      // 
      this.lblType.AutoSize = true;
      this.lblType.BackColor = System.Drawing.Color.Transparent;
      this.lblType.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblType.Location = new System.Drawing.Point(13, 10);
      this.lblType.Name = "lblType";
      this.lblType.Size = new System.Drawing.Size(84, 24);
      this.lblType.TabIndex = 4;
      this.lblType.Text = "JobType";
      this.lblType.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      this.lblType.Click += new System.EventHandler(this.lblType_Click);
      // 
      // lblCustomer
      // 
      this.lblCustomer.BackColor = System.Drawing.Color.Transparent;
      this.lblCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblCustomer.Location = new System.Drawing.Point(13, 120);
      this.lblCustomer.Name = "lblCustomer";
      this.lblCustomer.Size = new System.Drawing.Size(343, 24);
      this.lblCustomer.TabIndex = 5;
      this.lblCustomer.Text = "Customer Name";
      this.lblCustomer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      this.lblCustomer.Click += new System.EventHandler(this.lblCustomer_Click);
      // 
      // lblVehicle
      // 
      this.lblVehicle.BackColor = System.Drawing.Color.Transparent;
      this.lblVehicle.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblVehicle.Location = new System.Drawing.Point(13, 86);
      this.lblVehicle.Name = "lblVehicle";
      this.lblVehicle.Size = new System.Drawing.Size(343, 24);
      this.lblVehicle.TabIndex = 6;
      this.lblVehicle.Text = "Vehicle";
      this.lblVehicle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      this.lblVehicle.Click += new System.EventHandler(this.lblVehicle_Click);
      // 
      // lblArea
      // 
      this.lblArea.BackColor = System.Drawing.Color.Transparent;
      this.lblArea.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblArea.Location = new System.Drawing.Point(13, 151);
      this.lblArea.Name = "lblArea";
      this.lblArea.Size = new System.Drawing.Size(343, 24);
      this.lblArea.TabIndex = 7;
      this.lblArea.Text = "Area";
      this.lblArea.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      this.lblArea.Click += new System.EventHandler(this.lblArea_Click);
      // 
      // lblReference
      // 
      this.lblReference.BackColor = System.Drawing.Color.Transparent;
      this.lblReference.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblReference.Location = new System.Drawing.Point(13, 183);
      this.lblReference.Name = "lblReference";
      this.lblReference.Size = new System.Drawing.Size(343, 24);
      this.lblReference.TabIndex = 8;
      this.lblReference.Text = "Reference";
      this.lblReference.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      this.lblReference.Click += new System.EventHandler(this.lblReference_Click);
      // 
      // ucLabourJob
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackColor = System.Drawing.Color.LightSteelBlue;
      this.Controls.Add(this.lblReference);
      this.Controls.Add(this.lblArea);
      this.Controls.Add(this.lblVehicle);
      this.Controls.Add(this.lblCustomer);
      this.Controls.Add(this.lblType);
      this.Controls.Add(this.lblTime);
      this.Controls.Add(this.lblBooking);
      this.Controls.Add(this.lblJobID);
      this.Margin = new System.Windows.Forms.Padding(5);
      this.Name = "ucLabourJob";
      this.Padding = new System.Windows.Forms.Padding(10);
      this.Size = new System.Drawing.Size(369, 226);
      this.Click += new System.EventHandler(this.ucLabourJob_Click);
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion
    private System.Windows.Forms.Label lblJobID;
    private System.Windows.Forms.Label lblBooking;
    private System.Windows.Forms.Label lblTime;
    private System.Windows.Forms.Label lblType;
    private System.Windows.Forms.Label lblCustomer;
    private System.Windows.Forms.Label lblVehicle;
    private System.Windows.Forms.Label lblArea;
    private System.Windows.Forms.Label lblReference;
  }
}
