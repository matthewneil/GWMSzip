﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workshop_orders
{
  public partial class Home : Form
  {
    public Home()
    {
      InitializeComponent();

      pnlProduction.Visible = true;
      LoadJobCount();
    }

    private void imgProduction_Click(object sender, EventArgs e)
    {
      ShowPanel(pnlProduction);
    }

    private void imgSales_Click(object sender, EventArgs e)
    {
      ShowPanel(pnlSales);
    }

    private void ShowPanel(Panel pnl)
    {
      pnlProduction.Visible = false;
      pnlSales.Visible = false;

      pnl.Visible = true;

      LoadJobCount();
    }

    private void LoadJobCount()
    {
      chAutoCount.ChartAreas[0].AxisX.Interval = 1;
      chAutoCount.Series.Clear();
      DateTime date = DateTime.Today;
      DateTime firstdayofmonth = new DateTime(date.Year, date.Month, 1);

      
      if (pnlSales.Visible)
      {
        chAutoCount.Series.Add("Quote");
        DataTable dt = DataAccess.ExecuteDataTable(
        "SELECT MONTHNAME(dateCreated) AS month,  YEAR(dateCreated) AS year, COUNT(*) as count " +
        "FROM vwQuote " +
        "WHERE dateCreated > '" + firstdayofmonth.AddMonths(-12).ToString("yyyy-MM-dd") + "' " +
        "GROUP BY MONTH(dateCreated), YEAR(dateCreated) " +
        "ORDER BY YEAR(dateCreated), MONTH(dateCreated);");

        if (dt != null && dt.Rows.Count > 0)
        {
          foreach (DataRow row in dt.Rows)
          {
            chAutoCount.Series["Quote"].Points.AddXY(row["month"].ToString().Substring(0, 3) + " " + row["year"].ToString().Remove(0, 2), row["count"].ToString());
          }

        }
      }
      else
      {
        chAutoCount.Series.Add("Auto");
        chAutoCount.Series.Add("Glass");

        DataTable dt = DataAccess.ExecuteDataTable(
        "SELECT MONTHNAME(JobBookingDate) AS month,  YEAR(JobBookingDate) AS year, COUNT(*) as count, TypeGroup " +
        "FROM vwJob " +
        "WHERE JobBookingDate > '" + firstdayofmonth.AddMonths(-12).ToString("yyyy-MM-dd") + "' " +
        "AND (TypeGroup = 'Auto' OR TypeGroup = 'Glass') " +
        "GROUP BY TypeGroup, MONTH(JobBookingDate), YEAR(JobBookingDate) " +
        "ORDER BY YEAR(JobBookingDate), MONTH(JobBookingDate);");

        if (dt != null && dt.Rows.Count > 0)
        {
          foreach (DataRow row in dt.Rows)
          {
            chAutoCount.Series[row["TypeGroup"].ToString()].Points.AddXY(row["month"].ToString().Substring(0, 3) + " " + row["year"].ToString().Remove(0, 2), row["count"].ToString());
          }

        }
      }
    }

    private void btnProduction_Click(object sender, EventArgs e)
    {
      FormManagement.ShowChildForm("JobView");
    }

    private void btnNewJob_Click(object sender, EventArgs e)
    {
      if (FormManagement.IsFormOpen("JobEdit") == true)
      {
        DataAccess.ShowMessage("You are currently editing a job. Please save and close before creating a new job.");
        FormManagement.ShowChildForm("JobEdit");
      }
      else
      {
        FormManagement.ShowDialogForm(new JobNew(0));
      }
    }

    private void btnSearchJob_Click(object sender, EventArgs e)
    {
      FormManagement.ShowChildForm("JobSearch");
    }

    private void btnFindJob_Click(object sender, EventArgs e)
    {
      if (txtFindJob.Text != "" && DataAccess.IsNumeric(txtFindJob.Text) && int.Parse(txtFindJob.Text) > 999)
      {
        DataTable dt = DataAccess.ExecuteDataTable("SELECT JobID FROM job WHERE JobID = " + txtFindJob.Text);
        if (dt != null && dt.Rows.Count > 0)
        {

          if (FormManagement.IsFormOpen("JobEdit") == true)
          {
            DataAccess.ShowMessage("You are currently editing a job. Please save and close before creating a new job.");
            FormManagement.ShowChildForm("JobEdit");
          }
          else
          {
            try
            {
              FormManagement.ShowChildForm(new JobEdit(int.Parse(txtFindJob.Text)));
              txtFindJob.Text = "";
            }
            catch (Exception ex) { }
          }
          return;
        }
      }
      MessageBox.Show("Please enter a valid Job Number", "Invalid Job", MessageBoxButtons.OK);
    }

    private void btnSearchQuote_Click(object sender, EventArgs e)
    {
      FormManagement.ShowChildForm("Quotes");
    }

    private void btnNewQuote_Click(object sender, EventArgs e)
    {
      if (FormManagement.IsFormOpen("QuoteDetail") == true)
      {
        DataAccess.ShowMessage("You are currently editing a quote. Please save and close before creating a new quote.");
        FormManagement.ShowChildForm("QuoteDetail");
      }
      else
      {
        try
        {
          FormManagement.ShowDialogForm("QuoteNew");
        }
        catch (Exception ex)
        {
          DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
            System.Reflection.MethodBase.GetCurrentMethod().Name, "");
        }
      }
    }

    private void btnFindQuote_Click(object sender, EventArgs e)
    {
      if (txtFindQuote.Text != "" && DataAccess.IsNumeric(txtFindQuote.Text) && int.Parse(txtFindQuote.Text) > 999)
      {
        DataTable dt = DataAccess.ExecuteDataTable("SELECT * FROM quote WHERE QuoteNo = " + txtFindQuote.Text);
        if (dt != null && dt.Rows.Count > 0)
        {
          if (FormManagement.IsFormOpen("QuoteDetail") == true)
          {
            DataAccess.ShowMessage("You are currently editing a quote. Please save and close before creating a new quote.");
            FormManagement.ShowChildForm("QuoteDetail");
            return;
          }
          else
          {
            FormManagement.ShowChildForm(new QuoteDetail(int.Parse(txtFindQuote.Text), null));
            txtFindQuote.Text = "";
            return;
          }
        }
      }
      MessageBox.Show("Please enter a valid Quote Number", "Invalid Quote", MessageBoxButtons.OK);
    }
  }
}
