﻿namespace workshop_orders
{
  partial class SupplierView
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
      this.dgvCustomer = new System.Windows.Forms.DataGridView();
      this.toolStrip1 = new System.Windows.Forms.ToolStrip();
      this.tsClose = new System.Windows.Forms.ToolStripButton();
      this.tsNew = new System.Windows.Forms.ToolStripButton();
      this.tsEdit = new System.Windows.Forms.ToolStripButton();
      this.tsRefresh = new System.Windows.Forms.ToolStripButton();
      this.pnlFilter = new System.Windows.Forms.Panel();
      this.gbFilter = new System.Windows.Forms.GroupBox();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.txtSearch = new System.Windows.Forms.TextBox();
      this.rbSurname = new System.Windows.Forms.RadioButton();
      this.rbFirstName = new System.Windows.Forms.RadioButton();
      this.rbRegular = new System.Windows.Forms.RadioButton();
      this.rbAll = new System.Windows.Forms.RadioButton();
      this.rbBusiness = new System.Windows.Forms.RadioButton();
      this.pnlData = new System.Windows.Forms.Panel();
      ((System.ComponentModel.ISupportInitialize)(this.dgvCustomer)).BeginInit();
      this.toolStrip1.SuspendLayout();
      this.pnlFilter.SuspendLayout();
      this.gbFilter.SuspendLayout();
      this.groupBox1.SuspendLayout();
      this.pnlData.SuspendLayout();
      this.SuspendLayout();
      // 
      // dgvCustomer
      // 
      this.dgvCustomer.AllowUserToAddRows = false;
      this.dgvCustomer.AllowUserToDeleteRows = false;
      dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
      this.dgvCustomer.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
      this.dgvCustomer.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
      dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
      dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
      dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
      dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
      dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
      this.dgvCustomer.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
      this.dgvCustomer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
      dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
      dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
      dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
      dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
      dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
      this.dgvCustomer.DefaultCellStyle = dataGridViewCellStyle3;
      this.dgvCustomer.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dgvCustomer.Location = new System.Drawing.Point(0, 0);
      this.dgvCustomer.Name = "dgvCustomer";
      dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
      dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
      dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
      dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
      dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
      dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
      this.dgvCustomer.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
      this.dgvCustomer.RowHeadersWidth = 20;
      dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.dgvCustomer.RowsDefaultCellStyle = dataGridViewCellStyle5;
      this.dgvCustomer.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
      this.dgvCustomer.Size = new System.Drawing.Size(1572, 791);
      this.dgvCustomer.TabIndex = 0;
      this.dgvCustomer.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvItems_CellDoubleClick);
      // 
      // toolStrip1
      // 
      this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsClose,
            this.tsNew,
            this.tsEdit,
            this.tsRefresh});
      this.toolStrip1.Location = new System.Drawing.Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new System.Drawing.Size(1809, 39);
      this.toolStrip1.TabIndex = 1;
      this.toolStrip1.Text = "toolStrip1";
      // 
      // tsClose
      // 
      this.tsClose.Image = global::workshop_orders.Properties.Resources.back;
      this.tsClose.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsClose.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsClose.Name = "tsClose";
      this.tsClose.Size = new System.Drawing.Size(72, 36);
      this.tsClose.Text = "Close";
      this.tsClose.Click += new System.EventHandler(this.tbClose_Click);
      // 
      // tsNew
      // 
      this.tsNew.Image = global::workshop_orders.Properties.Resources.addnew;
      this.tsNew.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsNew.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsNew.Name = "tsNew";
      this.tsNew.Size = new System.Drawing.Size(67, 36);
      this.tsNew.Text = "New";
      this.tsNew.Click += new System.EventHandler(this.tsNew_Click);
      // 
      // tsEdit
      // 
      this.tsEdit.Image = global::workshop_orders.Properties.Resources.edit;
      this.tsEdit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsEdit.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsEdit.Name = "tsEdit";
      this.tsEdit.Size = new System.Drawing.Size(63, 36);
      this.tsEdit.Text = "Edit";
      this.tsEdit.Click += new System.EventHandler(this.tsEdit_Click);
      // 
      // tsRefresh
      // 
      this.tsRefresh.Image = global::workshop_orders.Properties.Resources.refresh;
      this.tsRefresh.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsRefresh.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsRefresh.Name = "tsRefresh";
      this.tsRefresh.Size = new System.Drawing.Size(82, 36);
      this.tsRefresh.Text = "Refresh";
      this.tsRefresh.Click += new System.EventHandler(this.tsRefresh_Click);
      // 
      // pnlFilter
      // 
      this.pnlFilter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(210)))));
      this.pnlFilter.Controls.Add(this.gbFilter);
      this.pnlFilter.Dock = System.Windows.Forms.DockStyle.Left;
      this.pnlFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.pnlFilter.Location = new System.Drawing.Point(0, 39);
      this.pnlFilter.Name = "pnlFilter";
      this.pnlFilter.Size = new System.Drawing.Size(237, 791);
      this.pnlFilter.TabIndex = 6;
      // 
      // gbFilter
      // 
      this.gbFilter.Controls.Add(this.groupBox1);
      this.gbFilter.Controls.Add(this.rbRegular);
      this.gbFilter.Controls.Add(this.rbAll);
      this.gbFilter.Controls.Add(this.rbBusiness);
      this.gbFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbFilter.ForeColor = System.Drawing.Color.White;
      this.gbFilter.Location = new System.Drawing.Point(7, 10);
      this.gbFilter.Name = "gbFilter";
      this.gbFilter.Size = new System.Drawing.Size(222, 206);
      this.gbFilter.TabIndex = 0;
      this.gbFilter.TabStop = false;
      this.gbFilter.Text = "Filters";
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.Add(this.txtSearch);
      this.groupBox1.Controls.Add(this.rbSurname);
      this.groupBox1.Controls.Add(this.rbFirstName);
      this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.groupBox1.ForeColor = System.Drawing.Color.White;
      this.groupBox1.Location = new System.Drawing.Point(5, 18);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(211, 79);
      this.groupBox1.TabIndex = 13;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Search Bar";
      // 
      // txtSearch
      // 
      this.txtSearch.Location = new System.Drawing.Point(6, 22);
      this.txtSearch.Name = "txtSearch";
      this.txtSearch.Size = new System.Drawing.Size(199, 22);
      this.txtSearch.TabIndex = 7;
      this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
      // 
      // rbSurname
      // 
      this.rbSurname.AutoSize = true;
      this.rbSurname.Location = new System.Drawing.Point(116, 51);
      this.rbSurname.Name = "rbSurname";
      this.rbSurname.Size = new System.Drawing.Size(87, 20);
      this.rbSurname.TabIndex = 8;
      this.rbSurname.Text = "Surname";
      this.rbSurname.UseVisualStyleBackColor = true;
      this.rbSurname.CheckedChanged += new System.EventHandler(this.rbSurname_CheckedChanged);
      // 
      // rbFirstName
      // 
      this.rbFirstName.AutoSize = true;
      this.rbFirstName.Checked = true;
      this.rbFirstName.Location = new System.Drawing.Point(8, 51);
      this.rbFirstName.Name = "rbFirstName";
      this.rbFirstName.Size = new System.Drawing.Size(96, 20);
      this.rbFirstName.TabIndex = 9;
      this.rbFirstName.TabStop = true;
      this.rbFirstName.Text = "Full Name";
      this.rbFirstName.UseVisualStyleBackColor = true;
      this.rbFirstName.CheckedChanged += new System.EventHandler(this.rbFirstName_CheckedChanged);
      // 
      // rbRegular
      // 
      this.rbRegular.AutoSize = true;
      this.rbRegular.Location = new System.Drawing.Point(17, 168);
      this.rbRegular.Name = "rbRegular";
      this.rbRegular.Size = new System.Drawing.Size(125, 21);
      this.rbRegular.TabIndex = 12;
      this.rbRegular.Text = "Non Business";
      this.rbRegular.UseVisualStyleBackColor = true;
      this.rbRegular.CheckedChanged += new System.EventHandler(this.rbRegular_CheckedChanged);
      // 
      // rbAll
      // 
      this.rbAll.AutoSize = true;
      this.rbAll.Checked = true;
      this.rbAll.Location = new System.Drawing.Point(17, 112);
      this.rbAll.Name = "rbAll";
      this.rbAll.Size = new System.Drawing.Size(44, 21);
      this.rbAll.TabIndex = 11;
      this.rbAll.TabStop = true;
      this.rbAll.Text = "All";
      this.rbAll.UseVisualStyleBackColor = true;
      this.rbAll.CheckedChanged += new System.EventHandler(this.rbAll_CheckedChanged);
      // 
      // rbBusiness
      // 
      this.rbBusiness.AutoSize = true;
      this.rbBusiness.Location = new System.Drawing.Point(17, 141);
      this.rbBusiness.Name = "rbBusiness";
      this.rbBusiness.Size = new System.Drawing.Size(91, 21);
      this.rbBusiness.TabIndex = 10;
      this.rbBusiness.Text = "Business";
      this.rbBusiness.UseVisualStyleBackColor = true;
      this.rbBusiness.CheckedChanged += new System.EventHandler(this.rbBusiness_CheckedChanged);
      // 
      // pnlData
      // 
      this.pnlData.Controls.Add(this.dgvCustomer);
      this.pnlData.Dock = System.Windows.Forms.DockStyle.Fill;
      this.pnlData.Location = new System.Drawing.Point(237, 39);
      this.pnlData.Name = "pnlData";
      this.pnlData.Size = new System.Drawing.Size(1572, 791);
      this.pnlData.TabIndex = 7;
      // 
      // SupplierView
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.ClientSize = new System.Drawing.Size(1809, 830);
      this.ControlBox = false;
      this.Controls.Add(this.pnlData);
      this.Controls.Add(this.pnlFilter);
      this.Controls.Add(this.toolStrip1);
      this.Name = "SupplierView";
      this.ShowIcon = false;
      this.ShowInTaskbar = false;
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
      this.Text = "Supplier List";
      ((System.ComponentModel.ISupportInitialize)(this.dgvCustomer)).EndInit();
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.pnlFilter.ResumeLayout(false);
      this.gbFilter.ResumeLayout(false);
      this.gbFilter.PerformLayout();
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.pnlData.ResumeLayout(false);
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.DataGridView dgvCustomer;
    private System.Windows.Forms.ToolStrip toolStrip1;
    private System.Windows.Forms.ToolStripButton tsClose;
    private System.Windows.Forms.ToolStripButton tsNew;
    private System.Windows.Forms.ToolStripButton tsRefresh;
    private System.Windows.Forms.ToolStripButton tsEdit;
    private System.Windows.Forms.Panel pnlFilter;
    private System.Windows.Forms.GroupBox gbFilter;
    private System.Windows.Forms.Panel pnlData;
    private System.Windows.Forms.TextBox txtSearch;
    private System.Windows.Forms.RadioButton rbFirstName;
    private System.Windows.Forms.RadioButton rbSurname;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.RadioButton rbRegular;
    private System.Windows.Forms.RadioButton rbAll;
    private System.Windows.Forms.RadioButton rbBusiness;
  }
}