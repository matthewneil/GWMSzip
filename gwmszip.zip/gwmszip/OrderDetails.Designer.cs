﻿
namespace workshop_orders
{
	partial class OrderDetails
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
      this.lblDefaultPrinter = new System.Windows.Forms.Label();
      this.DataGridViewImageColumn2 = new System.Windows.Forms.DataGridViewImageColumn();
      this.DataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.DataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.DataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.DataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.DataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.DataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.DataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.DataGridViewImageColumn1 = new System.Windows.Forms.DataGridViewImageColumn();
      this.pnlHeader = new System.Windows.Forms.Panel();
      this.lblHeader = new System.Windows.Forms.Label();
      this.PictureBox2 = new System.Windows.Forms.PictureBox();
      this.ToolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
      this.ToolStrip1 = new System.Windows.Forms.ToolStrip();
      this.tsClose = new System.Windows.Forms.ToolStripButton();
      this.tsSave = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
      this.tsPrint = new System.Windows.Forms.ToolStripButton();
      this.tsPreview = new System.Windows.Forms.ToolStripButton();
      this.tsEmail = new System.Windows.Forms.ToolStripButton();
      this.tsSupplier = new System.Windows.Forms.ToolStripButton();
      this.GroupBox3 = new System.Windows.Forms.GroupBox();
      this.cmbOrderGroup = new System.Windows.Forms.ComboBox();
      this.Label9 = new System.Windows.Forms.Label();
      this.cmbJobNo = new System.Windows.Forms.ComboBox();
      this.lblQuotes = new System.Windows.Forms.Label();
      this.Label4 = new System.Windows.Forms.Label();
      this.Label1 = new System.Windows.Forms.Label();
      this.txtAccountNo = new System.Windows.Forms.TextBox();
      this.dtpRequiredDate = new System.Windows.Forms.DateTimePicker();
      this.Label11 = new System.Windows.Forms.Label();
      this.Label3 = new System.Windows.Forms.Label();
      this.txtReference = new System.Windows.Forms.TextBox();
      this.cmbSupplier = new System.Windows.Forms.ComboBox();
      this.pnlMain = new System.Windows.Forms.Panel();
      this.pnlMainDataGrid = new System.Windows.Forms.Panel();
      this.btnFind = new System.Windows.Forms.Button();
      this.pnlLongText = new System.Windows.Forms.Panel();
      this.lblRowIndex = new System.Windows.Forms.Label();
      this.btnSaveLongText = new System.Windows.Forms.Button();
      this.btnCancel = new System.Windows.Forms.Button();
      this.txtLongText = new System.Windows.Forms.TextBox();
      this.dgvData = new System.Windows.Forms.DataGridView();
      this.chID = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chUOM = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chPartCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chTotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chAttach = new System.Windows.Forms.DataGridViewLinkColumn();
      this.chImageName = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.pnlMainBottom = new System.Windows.Forms.Panel();
      this.Label8 = new System.Windows.Forms.Label();
      this.lblStaffName = new System.Windows.Forms.Label();
      this.GroupBox1 = new System.Windows.Forms.GroupBox();
      this.txtInstruction = new System.Windows.Forms.TextBox();
      this.lblDate = new System.Windows.Forms.Label();
      this.pnlTop = new System.Windows.Forms.Panel();
      this.pnlHeader.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.PictureBox2)).BeginInit();
      this.ToolStrip1.SuspendLayout();
      this.GroupBox3.SuspendLayout();
      this.pnlMain.SuspendLayout();
      this.pnlMainDataGrid.SuspendLayout();
      this.pnlLongText.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgvData)).BeginInit();
      this.pnlMainBottom.SuspendLayout();
      this.GroupBox1.SuspendLayout();
      this.pnlTop.SuspendLayout();
      this.SuspendLayout();
      // 
      // lblDefaultPrinter
      // 
      this.lblDefaultPrinter.AutoSize = true;
      this.lblDefaultPrinter.BackColor = System.Drawing.SystemColors.Control;
      this.lblDefaultPrinter.ForeColor = System.Drawing.Color.Blue;
      this.lblDefaultPrinter.Location = new System.Drawing.Point(641, 9);
      this.lblDefaultPrinter.Name = "lblDefaultPrinter";
      this.lblDefaultPrinter.Size = new System.Drawing.Size(77, 13);
      this.lblDefaultPrinter.TabIndex = 84;
      this.lblDefaultPrinter.Text = "Default Printer:";
      // 
      // DataGridViewImageColumn2
      // 
      this.DataGridViewImageColumn2.FillWeight = 16F;
      this.DataGridViewImageColumn2.HeaderText = "";
      this.DataGridViewImageColumn2.Name = "DataGridViewImageColumn2";
      this.DataGridViewImageColumn2.ReadOnly = true;
      // 
      // DataGridViewTextBoxColumn7
      // 
      this.DataGridViewTextBoxColumn7.HeaderText = "Image";
      this.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7";
      this.DataGridViewTextBoxColumn7.ReadOnly = true;
      this.DataGridViewTextBoxColumn7.Visible = false;
      // 
      // DataGridViewTextBoxColumn6
      // 
      dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
      dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Blue;
      dataGridViewCellStyle1.Format = "C2";
      dataGridViewCellStyle1.NullValue = "0.00";
      dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.White;
      dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Blue;
      this.DataGridViewTextBoxColumn6.DefaultCellStyle = dataGridViewCellStyle1;
      this.DataGridViewTextBoxColumn6.HeaderText = "Total";
      this.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6";
      this.DataGridViewTextBoxColumn6.ReadOnly = true;
      // 
      // DataGridViewTextBoxColumn5
      // 
      dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
      dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Blue;
      dataGridViewCellStyle2.Format = "C2";
      dataGridViewCellStyle2.NullValue = "0.00";
      dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.White;
      dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Blue;
      this.DataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle2;
      this.DataGridViewTextBoxColumn5.HeaderText = "Rate";
      this.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5";
      this.DataGridViewTextBoxColumn5.Width = 75;
      // 
      // DataGridViewTextBoxColumn4
      // 
      this.DataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
      dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
      dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
      this.DataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle3;
      this.DataGridViewTextBoxColumn4.HeaderText = "Description";
      this.DataGridViewTextBoxColumn4.MaxInputLength = 250;
      this.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4";
      this.DataGridViewTextBoxColumn4.ToolTipText = "Double Click the description cell to enter Mutiple lines of text";
      // 
      // DataGridViewTextBoxColumn3
      // 
      dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
      this.DataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle4;
      this.DataGridViewTextBoxColumn3.HeaderText = "UOM";
      this.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3";
      this.DataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
      this.DataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
      this.DataGridViewTextBoxColumn3.Width = 70;
      // 
      // DataGridViewTextBoxColumn2
      // 
      dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
      this.DataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle5;
      this.DataGridViewTextBoxColumn2.HeaderText = "Quantity";
      this.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2";
      this.DataGridViewTextBoxColumn2.Width = 60;
      // 
      // DataGridViewTextBoxColumn1
      // 
      dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
      dataGridViewCellStyle6.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.DataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle6;
      this.DataGridViewTextBoxColumn1.Frozen = true;
      this.DataGridViewTextBoxColumn1.HeaderText = "";
      this.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1";
      this.DataGridViewTextBoxColumn1.ReadOnly = true;
      this.DataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
      this.DataGridViewTextBoxColumn1.Width = 40;
      // 
      // DataGridViewImageColumn1
      // 
      this.DataGridViewImageColumn1.Frozen = true;
      this.DataGridViewImageColumn1.HeaderText = "";
      this.DataGridViewImageColumn1.MinimumWidth = 24;
      this.DataGridViewImageColumn1.Name = "DataGridViewImageColumn1";
      this.DataGridViewImageColumn1.ReadOnly = true;
      this.DataGridViewImageColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
      this.DataGridViewImageColumn1.Width = 24;
      // 
      // pnlHeader
      // 
      this.pnlHeader.BackColor = System.Drawing.SystemColors.Control;
      this.pnlHeader.Controls.Add(this.lblHeader);
      this.pnlHeader.Controls.Add(this.PictureBox2);
      this.pnlHeader.Location = new System.Drawing.Point(751, 1);
      this.pnlHeader.Name = "pnlHeader";
      this.pnlHeader.Size = new System.Drawing.Size(533, 32);
      this.pnlHeader.TabIndex = 82;
      // 
      // lblHeader
      // 
      this.lblHeader.BackColor = System.Drawing.SystemColors.Control;
      this.lblHeader.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblHeader.ForeColor = System.Drawing.Color.Black;
      this.lblHeader.Location = new System.Drawing.Point(85, 6);
      this.lblHeader.MinimumSize = new System.Drawing.Size(400, 0);
      this.lblHeader.Name = "lblHeader";
      this.lblHeader.Size = new System.Drawing.Size(400, 23);
      this.lblHeader.TabIndex = 18;
      this.lblHeader.Text = "Orders";
      this.lblHeader.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // PictureBox2
      // 
      this.PictureBox2.Dock = System.Windows.Forms.DockStyle.Right;
      this.PictureBox2.Image = global::workshop_orders.Properties.Resources.orders32;
      this.PictureBox2.Location = new System.Drawing.Point(485, 0);
      this.PictureBox2.Name = "PictureBox2";
      this.PictureBox2.Size = new System.Drawing.Size(48, 32);
      this.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
      this.PictureBox2.TabIndex = 17;
      this.PictureBox2.TabStop = false;
      // 
      // ToolStripSeparator1
      // 
      this.ToolStripSeparator1.Name = "ToolStripSeparator1";
      this.ToolStripSeparator1.Size = new System.Drawing.Size(6, 39);
      // 
      // ToolStrip1
      // 
      this.ToolStrip1.BackColor = System.Drawing.SystemColors.Control;
      this.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
      this.ToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsClose,
            this.tsSave,
            this.toolStripSeparator2,
            this.tsPrint,
            this.tsPreview,
            this.tsEmail,
            this.ToolStripSeparator1,
            this.tsSupplier});
      this.ToolStrip1.Location = new System.Drawing.Point(0, 0);
      this.ToolStrip1.Name = "ToolStrip1";
      this.ToolStrip1.Size = new System.Drawing.Size(1288, 39);
      this.ToolStrip1.TabIndex = 50;
      this.ToolStrip1.Text = "ToolStrip1";
      // 
      // tsClose
      // 
      this.tsClose.Image = global::workshop_orders.Properties.Resources.back;
      this.tsClose.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsClose.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsClose.Name = "tsClose";
      this.tsClose.Size = new System.Drawing.Size(72, 36);
      this.tsClose.Text = "Close";
      this.tsClose.Click += new System.EventHandler(this.tsClose_Click);
      // 
      // tsSave
      // 
      this.tsSave.Image = global::workshop_orders.Properties.Resources.save;
      this.tsSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsSave.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsSave.Name = "tsSave";
      this.tsSave.Size = new System.Drawing.Size(67, 36);
      this.tsSave.Text = "Save";
      this.tsSave.ToolTipText = "Edit";
      this.tsSave.Click += new System.EventHandler(this.tsSave_Click);
      // 
      // toolStripSeparator2
      // 
      this.toolStripSeparator2.Name = "toolStripSeparator2";
      this.toolStripSeparator2.Size = new System.Drawing.Size(6, 39);
      // 
      // tsPrint
      // 
      this.tsPrint.Image = global::workshop_orders.Properties.Resources.print;
      this.tsPrint.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsPrint.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsPrint.Name = "tsPrint";
      this.tsPrint.Size = new System.Drawing.Size(68, 36);
      this.tsPrint.Text = "Print";
      // 
      // tsPreview
      // 
      this.tsPreview.Image = global::workshop_orders.Properties.Resources.preview;
      this.tsPreview.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsPreview.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsPreview.Name = "tsPreview";
      this.tsPreview.Size = new System.Drawing.Size(84, 36);
      this.tsPreview.Text = "Preview";
      // 
      // tsEmail
      // 
      this.tsEmail.Image = global::workshop_orders.Properties.Resources.email32_2;
      this.tsEmail.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsEmail.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsEmail.Name = "tsEmail";
      this.tsEmail.Size = new System.Drawing.Size(72, 36);
      this.tsEmail.Text = "eMail";
      // 
      // tsSupplier
      // 
      this.tsSupplier.Image = global::workshop_orders.Properties.Resources.suppliers32;
      this.tsSupplier.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsSupplier.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsSupplier.Name = "tsSupplier";
      this.tsSupplier.Size = new System.Drawing.Size(86, 36);
      this.tsSupplier.Text = "Supplier";
      this.tsSupplier.Click += new System.EventHandler(this.tsSupplier_Click);
      // 
      // GroupBox3
      // 
      this.GroupBox3.Controls.Add(this.cmbOrderGroup);
      this.GroupBox3.Controls.Add(this.Label9);
      this.GroupBox3.Controls.Add(this.cmbJobNo);
      this.GroupBox3.Controls.Add(this.lblQuotes);
      this.GroupBox3.Controls.Add(this.Label4);
      this.GroupBox3.Controls.Add(this.Label1);
      this.GroupBox3.Controls.Add(this.txtAccountNo);
      this.GroupBox3.Controls.Add(this.dtpRequiredDate);
      this.GroupBox3.Controls.Add(this.Label11);
      this.GroupBox3.Controls.Add(this.Label3);
      this.GroupBox3.Controls.Add(this.txtReference);
      this.GroupBox3.Controls.Add(this.cmbSupplier);
      this.GroupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.GroupBox3.ForeColor = System.Drawing.Color.Blue;
      this.GroupBox3.Location = new System.Drawing.Point(3, 3);
      this.GroupBox3.Name = "GroupBox3";
      this.GroupBox3.Size = new System.Drawing.Size(342, 188);
      this.GroupBox3.TabIndex = 85;
      this.GroupBox3.TabStop = false;
      this.GroupBox3.Text = "Order Details";
      // 
      // cmbOrderGroup
      // 
      this.cmbOrderGroup.DisplayMember = "textfield";
      this.cmbOrderGroup.DropDownHeight = 500;
      this.cmbOrderGroup.DropDownWidth = 110;
      this.cmbOrderGroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbOrderGroup.FormattingEnabled = true;
      this.cmbOrderGroup.IntegralHeight = false;
      this.cmbOrderGroup.Location = new System.Drawing.Point(102, 129);
      this.cmbOrderGroup.Name = "cmbOrderGroup";
      this.cmbOrderGroup.Size = new System.Drawing.Size(100, 26);
      this.cmbOrderGroup.TabIndex = 5;
      this.cmbOrderGroup.ValueMember = "datafield";
      this.cmbOrderGroup.Visible = false;
      // 
      // Label9
      // 
      this.Label9.AutoSize = true;
      this.Label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.Label9.ForeColor = System.Drawing.Color.Black;
      this.Label9.Location = new System.Drawing.Point(3, 132);
      this.Label9.Name = "Label9";
      this.Label9.Size = new System.Drawing.Size(96, 18);
      this.Label9.TabIndex = 36;
      this.Label9.Text = "Order Group:";
      this.Label9.Visible = false;
      // 
      // cmbJobNo
      // 
      this.cmbJobNo.DisplayMember = "textfield";
      this.cmbJobNo.DropDownHeight = 500;
      this.cmbJobNo.DropDownWidth = 250;
      this.cmbJobNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbJobNo.FormattingEnabled = true;
      this.cmbJobNo.IntegralHeight = false;
      this.cmbJobNo.Location = new System.Drawing.Point(102, 101);
      this.cmbJobNo.Name = "cmbJobNo";
      this.cmbJobNo.Size = new System.Drawing.Size(234, 26);
      this.cmbJobNo.TabIndex = 4;
      this.cmbJobNo.ValueMember = "datafield";
      // 
      // lblQuotes
      // 
      this.lblQuotes.AutoSize = true;
      this.lblQuotes.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblQuotes.ForeColor = System.Drawing.Color.Black;
      this.lblQuotes.Location = new System.Drawing.Point(5, 104);
      this.lblQuotes.Name = "lblQuotes";
      this.lblQuotes.Size = new System.Drawing.Size(94, 18);
      this.lblQuotes.TabIndex = 33;
      this.lblQuotes.Text = "Job Number:";
      // 
      // Label4
      // 
      this.Label4.AutoSize = true;
      this.Label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.Label4.ForeColor = System.Drawing.Color.Black;
      this.Label4.Location = new System.Drawing.Point(28, 79);
      this.Label4.Name = "Label4";
      this.Label4.Size = new System.Drawing.Size(71, 18);
      this.Label4.TabIndex = 31;
      this.Label4.Text = "Required:";
      // 
      // Label1
      // 
      this.Label1.AutoSize = true;
      this.Label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.Label1.ForeColor = System.Drawing.Color.Black;
      this.Label1.Location = new System.Drawing.Point(39, 161);
      this.Label1.Name = "Label1";
      this.Label1.Size = new System.Drawing.Size(60, 18);
      this.Label1.TabIndex = 29;
      this.Label1.Text = "A/C No:";
      this.Label1.Visible = false;
      // 
      // txtAccountNo
      // 
      this.txtAccountNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtAccountNo.Location = new System.Drawing.Point(102, 158);
      this.txtAccountNo.Name = "txtAccountNo";
      this.txtAccountNo.Size = new System.Drawing.Size(100, 24);
      this.txtAccountNo.TabIndex = 6;
      this.txtAccountNo.Visible = false;
      // 
      // dtpRequiredDate
      // 
      this.dtpRequiredDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.dtpRequiredDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
      this.dtpRequiredDate.Location = new System.Drawing.Point(102, 76);
      this.dtpRequiredDate.Name = "dtpRequiredDate";
      this.dtpRequiredDate.Size = new System.Drawing.Size(101, 24);
      this.dtpRequiredDate.TabIndex = 3;
      // 
      // Label11
      // 
      this.Label11.AutoSize = true;
      this.Label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.Label11.ForeColor = System.Drawing.Color.Black;
      this.Label11.Location = new System.Drawing.Point(19, 54);
      this.Label11.Name = "Label11";
      this.Label11.Size = new System.Drawing.Size(80, 18);
      this.Label11.TabIndex = 27;
      this.Label11.Text = "Reference:";
      // 
      // Label3
      // 
      this.Label3.AutoSize = true;
      this.Label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.Label3.ForeColor = System.Drawing.Color.Black;
      this.Label3.Location = new System.Drawing.Point(34, 24);
      this.Label3.Name = "Label3";
      this.Label3.Size = new System.Drawing.Size(65, 18);
      this.Label3.TabIndex = 18;
      this.Label3.Text = "Supplier:";
      // 
      // txtReference
      // 
      this.txtReference.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtReference.Location = new System.Drawing.Point(102, 49);
      this.txtReference.Name = "txtReference";
      this.txtReference.Size = new System.Drawing.Size(234, 24);
      this.txtReference.TabIndex = 2;
      // 
      // cmbSupplier
      // 
      this.cmbSupplier.DisplayMember = "textfield";
      this.cmbSupplier.DropDownHeight = 500;
      this.cmbSupplier.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.cmbSupplier.DropDownWidth = 300;
      this.cmbSupplier.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbSupplier.FormattingEnabled = true;
      this.cmbSupplier.IntegralHeight = false;
      this.cmbSupplier.Location = new System.Drawing.Point(102, 19);
      this.cmbSupplier.Name = "cmbSupplier";
      this.cmbSupplier.Size = new System.Drawing.Size(234, 26);
      this.cmbSupplier.TabIndex = 1;
      this.cmbSupplier.ValueMember = "datafield";
      this.cmbSupplier.SelectedIndexChanged += new System.EventHandler(this.cmbSupplier_SelectedIndexChanged);
      // 
      // pnlMain
      // 
      this.pnlMain.BackColor = System.Drawing.Color.White;
      this.pnlMain.Controls.Add(this.pnlMainDataGrid);
      this.pnlMain.Controls.Add(this.pnlMainBottom);
      this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
      this.pnlMain.Location = new System.Drawing.Point(0, 243);
      this.pnlMain.Name = "pnlMain";
      this.pnlMain.Padding = new System.Windows.Forms.Padding(5);
      this.pnlMain.Size = new System.Drawing.Size(1288, 689);
      this.pnlMain.TabIndex = 87;
      // 
      // pnlMainDataGrid
      // 
      this.pnlMainDataGrid.Controls.Add(this.btnFind);
      this.pnlMainDataGrid.Controls.Add(this.pnlLongText);
      this.pnlMainDataGrid.Controls.Add(this.dgvData);
      this.pnlMainDataGrid.Dock = System.Windows.Forms.DockStyle.Left;
      this.pnlMainDataGrid.Location = new System.Drawing.Point(5, 5);
      this.pnlMainDataGrid.Name = "pnlMainDataGrid";
      this.pnlMainDataGrid.Size = new System.Drawing.Size(1000, 639);
      this.pnlMainDataGrid.TabIndex = 34;
      // 
      // btnFind
      // 
      this.btnFind.BackColor = System.Drawing.SystemColors.Control;
      this.btnFind.BackgroundImage = global::workshop_orders.Properties.Resources.find;
      this.btnFind.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
      this.btnFind.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
      this.btnFind.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
      this.btnFind.Location = new System.Drawing.Point(286, 25);
      this.btnFind.Name = "btnFind";
      this.btnFind.Size = new System.Drawing.Size(24, 24);
      this.btnFind.TabIndex = 33;
      this.btnFind.UseVisualStyleBackColor = false;
      this.btnFind.Visible = false;
      this.btnFind.Click += new System.EventHandler(this.btnFind_Click);
      // 
      // pnlLongText
      // 
      this.pnlLongText.BackColor = System.Drawing.SystemColors.Control;
      this.pnlLongText.Controls.Add(this.lblRowIndex);
      this.pnlLongText.Controls.Add(this.btnSaveLongText);
      this.pnlLongText.Controls.Add(this.btnCancel);
      this.pnlLongText.Controls.Add(this.txtLongText);
      this.pnlLongText.Location = new System.Drawing.Point(371, 85);
      this.pnlLongText.Name = "pnlLongText";
      this.pnlLongText.Size = new System.Drawing.Size(494, 315);
      this.pnlLongText.TabIndex = 32;
      this.pnlLongText.Visible = false;
      // 
      // lblRowIndex
      // 
      this.lblRowIndex.AutoSize = true;
      this.lblRowIndex.Location = new System.Drawing.Point(333, 280);
      this.lblRowIndex.Name = "lblRowIndex";
      this.lblRowIndex.Size = new System.Drawing.Size(0, 13);
      this.lblRowIndex.TabIndex = 73;
      // 
      // btnSaveLongText
      // 
      this.btnSaveLongText.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold);
      this.btnSaveLongText.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
      this.btnSaveLongText.Location = new System.Drawing.Point(143, 272);
      this.btnSaveLongText.Name = "btnSaveLongText";
      this.btnSaveLongText.Size = new System.Drawing.Size(85, 30);
      this.btnSaveLongText.TabIndex = 72;
      this.btnSaveLongText.Text = "Save";
      this.btnSaveLongText.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      this.btnSaveLongText.UseVisualStyleBackColor = true;
      this.btnSaveLongText.Click += new System.EventHandler(this.btnSaveLongText_Click);
      // 
      // btnCancel
      // 
      this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold);
      this.btnCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
      this.btnCancel.Location = new System.Drawing.Point(243, 272);
      this.btnCancel.Name = "btnCancel";
      this.btnCancel.Size = new System.Drawing.Size(85, 30);
      this.btnCancel.TabIndex = 71;
      this.btnCancel.Text = "Cancel";
      this.btnCancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      this.btnCancel.UseVisualStyleBackColor = true;
      this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
      // 
      // txtLongText
      // 
      this.txtLongText.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
      this.txtLongText.Location = new System.Drawing.Point(6, 5);
      this.txtLongText.Multiline = true;
      this.txtLongText.Name = "txtLongText";
      this.txtLongText.Size = new System.Drawing.Size(481, 261);
      this.txtLongText.TabIndex = 0;
      // 
      // dgvData
      // 
      this.dgvData.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
      this.dgvData.BackgroundColor = System.Drawing.Color.White;
      this.dgvData.BorderStyle = System.Windows.Forms.BorderStyle.None;
      this.dgvData.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
      dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
      dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
      dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
      dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
      dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
      dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
      dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
      this.dgvData.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
      this.dgvData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvData.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.chID,
            this.chQuantity,
            this.chUOM,
            this.chPartCode,
            this.chDesc,
            this.chRate,
            this.chTotal,
            this.chAttach,
            this.chImageName});
      dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
      dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window;
      dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
      dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText;
      dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
      dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
      dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
      this.dgvData.DefaultCellStyle = dataGridViewCellStyle14;
      this.dgvData.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dgvData.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
      this.dgvData.Location = new System.Drawing.Point(0, 0);
      this.dgvData.Name = "dgvData";
      dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
      dataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control;
      dataGridViewCellStyle15.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
      dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText;
      dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight;
      dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
      dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
      this.dgvData.RowHeadersDefaultCellStyle = dataGridViewCellStyle15;
      this.dgvData.RowHeadersWidth = 20;
      this.dgvData.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
      this.dgvData.ShowEditingIcon = false;
      this.dgvData.Size = new System.Drawing.Size(1000, 639);
      this.dgvData.TabIndex = 8;
      this.dgvData.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvData_CellClick);
      this.dgvData.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvData_CellContentClick);
      this.dgvData.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvData_CellDoubleClick);
      this.dgvData.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvData_CellEnter);
      this.dgvData.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvData_CellValueChanged);
      this.dgvData.UserAddedRow += new System.Windows.Forms.DataGridViewRowEventHandler(this.dgvData_UserAddedRow);
      // 
      // chID
      // 
      dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
      dataGridViewCellStyle8.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.chID.DefaultCellStyle = dataGridViewCellStyle8;
      this.chID.Frozen = true;
      this.chID.HeaderText = "";
      this.chID.Name = "chID";
      this.chID.ReadOnly = true;
      this.chID.Resizable = System.Windows.Forms.DataGridViewTriState.False;
      this.chID.Width = 40;
      // 
      // chQuantity
      // 
      dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
      this.chQuantity.DefaultCellStyle = dataGridViewCellStyle9;
      this.chQuantity.HeaderText = "Qty";
      this.chQuantity.Name = "chQuantity";
      this.chQuantity.Width = 60;
      // 
      // chUOM
      // 
      dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
      this.chUOM.DefaultCellStyle = dataGridViewCellStyle10;
      this.chUOM.HeaderText = "UOM";
      this.chUOM.Name = "chUOM";
      this.chUOM.Resizable = System.Windows.Forms.DataGridViewTriState.True;
      this.chUOM.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
      this.chUOM.Width = 70;
      // 
      // chPartCode
      // 
      this.chPartCode.HeaderText = "Part No";
      this.chPartCode.Name = "chPartCode";
      this.chPartCode.Width = 120;
      // 
      // chDesc
      // 
      this.chDesc.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
      dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
      dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
      this.chDesc.DefaultCellStyle = dataGridViewCellStyle11;
      this.chDesc.HeaderText = "Description";
      this.chDesc.MaxInputLength = 250;
      this.chDesc.Name = "chDesc";
      this.chDesc.ToolTipText = "Double Click the description cell to enter Mutiple lines of text";
      // 
      // chRate
      // 
      dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
      dataGridViewCellStyle12.ForeColor = System.Drawing.Color.Blue;
      dataGridViewCellStyle12.Format = "C2";
      dataGridViewCellStyle12.NullValue = "0.00";
      dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.White;
      dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.Blue;
      this.chRate.DefaultCellStyle = dataGridViewCellStyle12;
      this.chRate.HeaderText = "Rate";
      this.chRate.Name = "chRate";
      this.chRate.Width = 75;
      // 
      // chTotal
      // 
      dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
      dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
      dataGridViewCellStyle13.ForeColor = System.Drawing.Color.Blue;
      dataGridViewCellStyle13.Format = "C2";
      dataGridViewCellStyle13.NullValue = "0.00";
      dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.White;
      dataGridViewCellStyle13.SelectionForeColor = System.Drawing.Color.Blue;
      this.chTotal.DefaultCellStyle = dataGridViewCellStyle13;
      this.chTotal.HeaderText = "Total";
      this.chTotal.Name = "chTotal";
      this.chTotal.ReadOnly = true;
      // 
      // chAttach
      // 
      this.chAttach.HeaderText = "Image";
      this.chAttach.Name = "chAttach";
      this.chAttach.Resizable = System.Windows.Forms.DataGridViewTriState.True;
      this.chAttach.Text = "Attach";
      this.chAttach.TrackVisitedState = false;
      this.chAttach.Visible = false;
      this.chAttach.Width = 60;
      // 
      // chImageName
      // 
      this.chImageName.HeaderText = "Image";
      this.chImageName.Name = "chImageName";
      this.chImageName.ReadOnly = true;
      this.chImageName.Visible = false;
      // 
      // pnlMainBottom
      // 
      this.pnlMainBottom.BackColor = System.Drawing.Color.White;
      this.pnlMainBottom.Controls.Add(this.Label8);
      this.pnlMainBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
      this.pnlMainBottom.Location = new System.Drawing.Point(5, 644);
      this.pnlMainBottom.Name = "pnlMainBottom";
      this.pnlMainBottom.Size = new System.Drawing.Size(1278, 40);
      this.pnlMainBottom.TabIndex = 33;
      // 
      // Label8
      // 
      this.Label8.AutoSize = true;
      this.Label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
      this.Label8.Location = new System.Drawing.Point(254, 13);
      this.Label8.Name = "Label8";
      this.Label8.Size = new System.Drawing.Size(401, 18);
      this.Label8.TabIndex = 79;
      this.Label8.Text = "Double Click the description cell to enter Mutiple lines of text";
      // 
      // lblStaffName
      // 
      this.lblStaffName.AutoSize = true;
      this.lblStaffName.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
      this.lblStaffName.Location = new System.Drawing.Point(716, 36);
      this.lblStaffName.MinimumSize = new System.Drawing.Size(200, 0);
      this.lblStaffName.Name = "lblStaffName";
      this.lblStaffName.Size = new System.Drawing.Size(200, 18);
      this.lblStaffName.TabIndex = 88;
      this.lblStaffName.Text = "StaffID";
      this.lblStaffName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // GroupBox1
      // 
      this.GroupBox1.Controls.Add(this.txtInstruction);
      this.GroupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
      this.GroupBox1.ForeColor = System.Drawing.Color.Blue;
      this.GroupBox1.Location = new System.Drawing.Point(358, 3);
      this.GroupBox1.Name = "GroupBox1";
      this.GroupBox1.Size = new System.Drawing.Size(342, 188);
      this.GroupBox1.TabIndex = 86;
      this.GroupBox1.TabStop = false;
      this.GroupBox1.Text = "Instructions";
      // 
      // txtInstruction
      // 
      this.txtInstruction.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
      this.txtInstruction.Location = new System.Drawing.Point(5, 20);
      this.txtInstruction.Multiline = true;
      this.txtInstruction.Name = "txtInstruction";
      this.txtInstruction.Size = new System.Drawing.Size(331, 160);
      this.txtInstruction.TabIndex = 7;
      // 
      // lblDate
      // 
      this.lblDate.AutoSize = true;
      this.lblDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
      this.lblDate.Location = new System.Drawing.Point(716, 13);
      this.lblDate.MinimumSize = new System.Drawing.Size(200, 0);
      this.lblDate.Name = "lblDate";
      this.lblDate.Size = new System.Drawing.Size(200, 18);
      this.lblDate.TabIndex = 89;
      this.lblDate.Text = "Date";
      this.lblDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // pnlTop
      // 
      this.pnlTop.Controls.Add(this.GroupBox3);
      this.pnlTop.Controls.Add(this.GroupBox1);
      this.pnlTop.Controls.Add(this.lblDate);
      this.pnlTop.Controls.Add(this.lblStaffName);
      this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
      this.pnlTop.Location = new System.Drawing.Point(0, 39);
      this.pnlTop.Name = "pnlTop";
      this.pnlTop.Size = new System.Drawing.Size(1288, 204);
      this.pnlTop.TabIndex = 91;
      // 
      // OrderDetails
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
      this.BackColor = System.Drawing.Color.White;
      this.ClientSize = new System.Drawing.Size(1288, 932);
      this.Controls.Add(this.pnlMain);
      this.Controls.Add(this.pnlTop);
      this.Controls.Add(this.lblDefaultPrinter);
      this.Controls.Add(this.pnlHeader);
      this.Controls.Add(this.ToolStrip1);
      this.Name = "OrderDetails";
      this.Text = "OrderDetails";
      this.Load += new System.EventHandler(this.OrderDetails_Load);
      this.pnlHeader.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.PictureBox2)).EndInit();
      this.ToolStrip1.ResumeLayout(false);
      this.ToolStrip1.PerformLayout();
      this.GroupBox3.ResumeLayout(false);
      this.GroupBox3.PerformLayout();
      this.pnlMain.ResumeLayout(false);
      this.pnlMainDataGrid.ResumeLayout(false);
      this.pnlLongText.ResumeLayout(false);
      this.pnlLongText.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgvData)).EndInit();
      this.pnlMainBottom.ResumeLayout(false);
      this.pnlMainBottom.PerformLayout();
      this.GroupBox1.ResumeLayout(false);
      this.GroupBox1.PerformLayout();
      this.pnlTop.ResumeLayout(false);
      this.pnlTop.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

		}

		#endregion
		internal System.Windows.Forms.Label lblDefaultPrinter;
		internal System.Windows.Forms.DataGridViewImageColumn DataGridViewImageColumn2;
		internal System.Windows.Forms.DataGridViewTextBoxColumn DataGridViewTextBoxColumn7;
		internal System.Windows.Forms.DataGridViewTextBoxColumn DataGridViewTextBoxColumn6;
		internal System.Windows.Forms.DataGridViewTextBoxColumn DataGridViewTextBoxColumn5;
		internal System.Windows.Forms.DataGridViewTextBoxColumn DataGridViewTextBoxColumn4;
		internal System.Windows.Forms.DataGridViewTextBoxColumn DataGridViewTextBoxColumn3;
		internal System.Windows.Forms.DataGridViewTextBoxColumn DataGridViewTextBoxColumn2;
		internal System.Windows.Forms.DataGridViewTextBoxColumn DataGridViewTextBoxColumn1;
		internal System.Windows.Forms.DataGridViewImageColumn DataGridViewImageColumn1;
		internal System.Windows.Forms.Panel pnlHeader;
		internal System.Windows.Forms.Label lblHeader;
		internal System.Windows.Forms.PictureBox PictureBox2;
		internal System.Windows.Forms.ToolStripButton tsSupplier;
		internal System.Windows.Forms.ToolStripSeparator ToolStripSeparator1;
		internal System.Windows.Forms.ToolStripButton tsEmail;
		internal System.Windows.Forms.ToolStripButton tsPreview;
		internal System.Windows.Forms.ToolStripButton tsPrint;
		internal System.Windows.Forms.ToolStripButton tsSave;
		internal System.Windows.Forms.ToolStripButton tsClose;
		internal System.Windows.Forms.ToolStrip ToolStrip1;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
		internal System.Windows.Forms.GroupBox GroupBox3;
		internal System.Windows.Forms.ComboBox cmbOrderGroup;
		internal System.Windows.Forms.Label Label9;
		internal System.Windows.Forms.Label lblQuotes;
		internal System.Windows.Forms.Label Label4;
		internal System.Windows.Forms.Label Label1;
		internal System.Windows.Forms.TextBox txtAccountNo;
		internal System.Windows.Forms.DateTimePicker dtpRequiredDate;
		internal System.Windows.Forms.Label Label11;
		internal System.Windows.Forms.Label Label3;
		internal System.Windows.Forms.TextBox txtReference;
		internal System.Windows.Forms.ComboBox cmbSupplier;
		internal System.Windows.Forms.Panel pnlMain;
		internal System.Windows.Forms.Panel pnlMainDataGrid;
		internal System.Windows.Forms.Panel pnlLongText;
		internal System.Windows.Forms.Label lblRowIndex;
		internal System.Windows.Forms.Button btnSaveLongText;
		internal System.Windows.Forms.Button btnCancel;
		internal System.Windows.Forms.TextBox txtLongText;
		internal System.Windows.Forms.DataGridView dgvData;
		internal System.Windows.Forms.Panel pnlMainBottom;
		internal System.Windows.Forms.Label Label8;
		internal System.Windows.Forms.Label lblStaffName;
		internal System.Windows.Forms.GroupBox GroupBox1;
		internal System.Windows.Forms.TextBox txtInstruction;
		internal System.Windows.Forms.Label lblDate;
		private System.Windows.Forms.Panel pnlTop;
		internal System.Windows.Forms.ComboBox cmbJobNo;
		private System.Windows.Forms.Button btnFind;
		private System.Windows.Forms.DataGridViewTextBoxColumn chID;
		private System.Windows.Forms.DataGridViewTextBoxColumn chQuantity;
		private System.Windows.Forms.DataGridViewTextBoxColumn chUOM;
		private System.Windows.Forms.DataGridViewTextBoxColumn chPartCode;
		private System.Windows.Forms.DataGridViewTextBoxColumn chDesc;
		private System.Windows.Forms.DataGridViewTextBoxColumn chRate;
		private System.Windows.Forms.DataGridViewTextBoxColumn chTotal;
		private System.Windows.Forms.DataGridViewLinkColumn chAttach;
		private System.Windows.Forms.DataGridViewTextBoxColumn chImageName;
	}
}