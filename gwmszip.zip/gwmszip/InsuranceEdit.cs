﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workshop_orders
{
  public partial class InsuranceEdit : Form
  {
    private int InsuranceID;
    private bool active = true;
    public InsuranceEdit(int InsuranceID)
    {
      InitializeComponent();
      this.InsuranceID = InsuranceID;

      Text = "New Insurance Provider";
      if (InsuranceID > 0)
      {
        Text = "Edit Insurance Provider";
        LoadData();
      }
      SetButtonState(DataAccess.FormState(this.AccessibilityObject.Name, tsSave));
    }

    
    private void SetButtonState(Boolean bState)
    {
      tsActive.Enabled = bState;

    }

    public void LoadData()
    {
      DataTable dt = DataAccess.ExecuteDataTable("SELECT * FROM insurance WHERE InsuranceID = " + InsuranceID);
      try
      {
        if (dt != null && dt.Rows.Count > 0)
        {
          txtInsuranceName.Text = dt.Rows[0]["InsuranceName"].ToString();

          if (dt.Rows[0]["active"].ToString() == "0")
          {
            tsActive.Text = "Set to Active";
            active = false;
          }
        }
      }
      catch (Exception ex)
      {
        MessageBox.Show("There was an error loading Item Data");
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name, 
          System.Reflection.MethodBase.GetCurrentMethod().Name, "SELECT * FROM insurance WHERE InsuranceID = " + InsuranceID);
      }
    }



    private void tsClose_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private void tsSave_Click(object sender, EventArgs e)
    {
      //ERROR CHECK
      String errors = "";

      if(txtInsuranceName.Text.Trim() == "")
      {
        errors += "The Insurance Provider name cannot be blank!\n";
      }


      if (errors == "")
      {
        //manage procedure
        DataAccess.InsuranceManage(InsuranceID, txtInsuranceName.Text);

        this.Close();
      }
      else
      {
        DataAccess.ShowMessage(errors);
      }
    }



    private void tsActive_Click(object sender, EventArgs e)
    {
      if (active)
      {
        bool res = DataAccess.ShowMessage("Set Insurance Provider to Inactive?", "Inactive", false);
        if (res)
        {
          DataAccess.ExecuteNonQuery("UPDATE insurance SET active = 0 WHERE InsuranceID = " + InsuranceID);
          tsActive.Text = "Set to Active";

          active = false;
        }
      }
      else
      {
        bool res = DataAccess.ShowMessage("Set Insurance Provider to Active?", "Active", false);
        if (res)
        {
          DataAccess.ExecuteNonQuery("UPDATE insurance SET active = 1 WHERE InsuranceID = " + InsuranceID);
          tsActive.Text = "Set to Inactive";
          active = true;
        }
      }
    }
  }
}
