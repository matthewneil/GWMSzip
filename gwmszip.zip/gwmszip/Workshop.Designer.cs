﻿
namespace workshop_orders
{
  partial class Workshop
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      this.flpMenu = new System.Windows.Forms.FlowLayoutPanel();
      this.toolStrip1 = new System.Windows.Forms.ToolStrip();
      this.tsBack = new System.Windows.Forms.ToolStripButton();
      this.tsStart = new System.Windows.Forms.ToolStripButton();
      this.tsRefresh = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
      this.tslblSearch = new System.Windows.Forms.ToolStripLabel();
      this.tsSearchBar = new System.Windows.Forms.ToolStripTextBox();
      this.tsUser = new System.Windows.Forms.ToolStripLabel();
      this.tsReport = new System.Windows.Forms.ToolStripButton();
      this.tsPrev = new System.Windows.Forms.ToolStripButton();
      this.tsNext = new System.Windows.Forms.ToolStripButton();
      this.pnlJobDetails = new System.Windows.Forms.Panel();
      this.dtpSearchDate = new System.Windows.Forms.DateTimePicker();
      this.timer1 = new System.Windows.Forms.Timer(this.components);
      this.toolStrip1.SuspendLayout();
      this.SuspendLayout();
      // 
      // flpMenu
      // 
      this.flpMenu.AutoScroll = true;
      this.flpMenu.Dock = System.Windows.Forms.DockStyle.Fill;
      this.flpMenu.Location = new System.Drawing.Point(0, 39);
      this.flpMenu.Name = "flpMenu";
      this.flpMenu.Size = new System.Drawing.Size(1878, 891);
      this.flpMenu.TabIndex = 0;
      // 
      // toolStrip1
      // 
      this.toolStrip1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsBack,
            this.tsStart,
            this.tsRefresh,
            this.toolStripSeparator1,
            this.tslblSearch,
            this.tsSearchBar,
            this.tsUser,
            this.tsReport,
            this.tsPrev,
            this.tsNext});
      this.toolStrip1.Location = new System.Drawing.Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new System.Drawing.Size(1878, 39);
      this.toolStrip1.TabIndex = 0;
      this.toolStrip1.Text = "toolStrip1";
      // 
      // tsBack
      // 
      this.tsBack.Image = global::workshop_orders.Properties.Resources.back;
      this.tsBack.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsBack.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsBack.Name = "tsBack";
      this.tsBack.Size = new System.Drawing.Size(78, 36);
      this.tsBack.Text = "Back";
      this.tsBack.Click += new System.EventHandler(this.tsBack_Click);
      // 
      // tsStart
      // 
      this.tsStart.Image = global::workshop_orders.Properties.Resources.reset;
      this.tsStart.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsStart.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsStart.Name = "tsStart";
      this.tsStart.Size = new System.Drawing.Size(132, 36);
      this.tsStart.Text = "Back to Start";
      this.tsStart.Click += new System.EventHandler(this.tsStart_Click);
      // 
      // tsRefresh
      // 
      this.tsRefresh.Image = global::workshop_orders.Properties.Resources.refresh;
      this.tsRefresh.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsRefresh.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsRefresh.Name = "tsRefresh";
      this.tsRefresh.Size = new System.Drawing.Size(99, 36);
      this.tsRefresh.Text = "Refresh";
      this.tsRefresh.Click += new System.EventHandler(this.tsRefresh_Click);
      // 
      // toolStripSeparator1
      // 
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
      // 
      // tslblSearch
      // 
      this.tslblSearch.Name = "tslblSearch";
      this.tslblSearch.Size = new System.Drawing.Size(57, 36);
      this.tslblSearch.Text = "Search";
      this.tslblSearch.Visible = false;
      // 
      // tsSearchBar
      // 
      this.tsSearchBar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.tsSearchBar.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.tsSearchBar.Name = "tsSearchBar";
      this.tsSearchBar.Size = new System.Drawing.Size(500, 39);
      this.tsSearchBar.Visible = false;
      this.tsSearchBar.TextChanged += new System.EventHandler(this.tsSearchBar_TextChanged);
      // 
      // tsUser
      // 
      this.tsUser.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
      this.tsUser.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.tsUser.Name = "tsUser";
      this.tsUser.Size = new System.Drawing.Size(66, 36);
      this.tsUser.Text = "No User";
      // 
      // tsReport
      // 
      this.tsReport.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
      this.tsReport.Image = global::workshop_orders.Properties.Resources.report32;
      this.tsReport.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsReport.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsReport.Name = "tsReport";
      this.tsReport.Size = new System.Drawing.Size(124, 36);
      this.tsReport.Text = "Day Report";
      this.tsReport.Visible = false;
      this.tsReport.Click += new System.EventHandler(this.tsReport_Click);
      // 
      // tsPrev
      // 
      this.tsPrev.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.tsPrev.Image = global::workshop_orders.Properties.Resources.arrow_back32;
      this.tsPrev.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsPrev.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsPrev.Name = "tsPrev";
      this.tsPrev.Size = new System.Drawing.Size(36, 36);
      this.tsPrev.Text = "toolStripButton1";
      this.tsPrev.Visible = false;
      this.tsPrev.Click += new System.EventHandler(this.tsPrev_Click);
      // 
      // tsNext
      // 
      this.tsNext.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.tsNext.Image = global::workshop_orders.Properties.Resources.arrow_next32;
      this.tsNext.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsNext.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsNext.Name = "tsNext";
      this.tsNext.Size = new System.Drawing.Size(36, 36);
      this.tsNext.Text = "toolStripButton2";
      this.tsNext.Visible = false;
      this.tsNext.Click += new System.EventHandler(this.tsNext_Click);
      // 
      // pnlJobDetails
      // 
      this.pnlJobDetails.Dock = System.Windows.Forms.DockStyle.Fill;
      this.pnlJobDetails.Location = new System.Drawing.Point(0, 39);
      this.pnlJobDetails.Name = "pnlJobDetails";
      this.pnlJobDetails.Size = new System.Drawing.Size(1878, 891);
      this.pnlJobDetails.TabIndex = 0;
      this.pnlJobDetails.Visible = false;
      // 
      // dtpSearchDate
      // 
      this.dtpSearchDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.dtpSearchDate.Location = new System.Drawing.Point(954, 4);
      this.dtpSearchDate.Name = "dtpSearchDate";
      this.dtpSearchDate.Size = new System.Drawing.Size(328, 29);
      this.dtpSearchDate.TabIndex = 1;
      this.dtpSearchDate.ValueChanged += new System.EventHandler(this.dtpSearchDate_ValueChanged);
      // 
      // timer1
      // 
      this.timer1.Enabled = true;
      this.timer1.Interval = 60000;
      this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
      // 
      // Workshop
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.ClientSize = new System.Drawing.Size(1878, 930);
      this.Controls.Add(this.dtpSearchDate);
      this.Controls.Add(this.pnlJobDetails);
      this.Controls.Add(this.flpMenu);
      this.Controls.Add(this.toolStrip1);
      this.Name = "Workshop";
      this.Text = "Workshop";
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

    }


    #endregion

    private System.Windows.Forms.FlowLayoutPanel flpMenu;
    private System.Windows.Forms.ToolStrip toolStrip1;
    private System.Windows.Forms.ToolStripButton tsBack;
    private System.Windows.Forms.ToolStripButton tsStart;
    private System.Windows.Forms.ToolStripButton tsRefresh;
    private System.Windows.Forms.ToolStripLabel tslblSearch;
    private System.Windows.Forms.ToolStripTextBox tsSearchBar;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
    private System.Windows.Forms.ToolStripLabel tsUser;
    private System.Windows.Forms.Panel pnlJobDetails;
    private System.Windows.Forms.DateTimePicker dtpSearchDate;
    private System.Windows.Forms.Timer timer1;
    private System.Windows.Forms.ToolStripButton tsReport;
    private System.Windows.Forms.ToolStripButton tsPrev;
    private System.Windows.Forms.ToolStripButton tsNext;
  }
}