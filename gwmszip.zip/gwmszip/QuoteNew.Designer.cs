﻿namespace workshop_orders
{
  partial class QuoteNew
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.gbCustomer = new System.Windows.Forms.GroupBox();
      this.groupBox5 = new System.Windows.Forms.GroupBox();
      this.txtCustomer = new System.Windows.Forms.TextBox();
      this.gbType = new System.Windows.Forms.GroupBox();
      this.cmbType = new System.Windows.Forms.ComboBox();
      this.label31 = new System.Windows.Forms.Label();
      this.gbReference = new System.Windows.Forms.GroupBox();
      this.groupBox4 = new System.Windows.Forms.GroupBox();
      this.txtNote = new System.Windows.Forms.TextBox();
      this.groupBox3 = new System.Windows.Forms.GroupBox();
      this.txtReference = new System.Windows.Forms.TextBox();
      this.JobNameLabel = new System.Windows.Forms.Label();
      this.panel1 = new System.Windows.Forms.Panel();
      this.rbReference = new System.Windows.Forms.RadioButton();
      this.rbCustomer = new System.Windows.Forms.RadioButton();
      this.rbType = new System.Windows.Forms.RadioButton();
      this.toolStrip2 = new System.Windows.Forms.ToolStrip();
      this.panel2 = new System.Windows.Forms.Panel();
      this.txtBasicDescription = new System.Windows.Forms.TextBox();
      this.gbBasic = new System.Windows.Forms.GroupBox();
      this.nudCost = new System.Windows.Forms.NumericUpDown();
      this.nudPrice = new System.Windows.Forms.NumericUpDown();
      this.label1 = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this.label3 = new System.Windows.Forms.Label();
      this.btnCustomer = new System.Windows.Forms.Button();
      this.tsPrevious = new System.Windows.Forms.ToolStripButton();
      this.tsNext = new System.Windows.Forms.ToolStripButton();
      this.tsSave = new System.Windows.Forms.ToolStripButton();
      this.btnSave = new System.Windows.Forms.Button();
      this.btnCancel = new System.Windows.Forms.Button();
      this.gbCustomer.SuspendLayout();
      this.groupBox5.SuspendLayout();
      this.gbType.SuspendLayout();
      this.gbReference.SuspendLayout();
      this.groupBox4.SuspendLayout();
      this.groupBox3.SuspendLayout();
      this.panel1.SuspendLayout();
      this.toolStrip2.SuspendLayout();
      this.panel2.SuspendLayout();
      this.gbBasic.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.nudCost)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudPrice)).BeginInit();
      this.SuspendLayout();
      // 
      // gbCustomer
      // 
      this.gbCustomer.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.gbCustomer.Controls.Add(this.groupBox5);
      this.gbCustomer.Dock = System.Windows.Forms.DockStyle.Fill;
      this.gbCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbCustomer.Location = new System.Drawing.Point(230, 39);
      this.gbCustomer.Name = "gbCustomer";
      this.gbCustomer.Size = new System.Drawing.Size(599, 391);
      this.gbCustomer.TabIndex = 1;
      this.gbCustomer.TabStop = false;
      this.gbCustomer.Text = "Customer";
      // 
      // groupBox5
      // 
      this.groupBox5.Controls.Add(this.txtCustomer);
      this.groupBox5.Controls.Add(this.btnCustomer);
      this.groupBox5.Dock = System.Windows.Forms.DockStyle.Top;
      this.groupBox5.Location = new System.Drawing.Point(3, 20);
      this.groupBox5.Name = "groupBox5";
      this.groupBox5.Size = new System.Drawing.Size(593, 69);
      this.groupBox5.TabIndex = 10;
      this.groupBox5.TabStop = false;
      // 
      // txtCustomer
      // 
      this.txtCustomer.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
      this.txtCustomer.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
      this.txtCustomer.Cursor = System.Windows.Forms.Cursors.Default;
      this.txtCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtCustomer.Location = new System.Drawing.Point(169, 25);
      this.txtCustomer.Name = "txtCustomer";
      this.txtCustomer.ReadOnly = true;
      this.txtCustomer.Size = new System.Drawing.Size(412, 26);
      this.txtCustomer.TabIndex = 8;
      // 
      // gbType
      // 
      this.gbType.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.gbType.Controls.Add(this.gbBasic);
      this.gbType.Controls.Add(this.cmbType);
      this.gbType.Controls.Add(this.label31);
      this.gbType.Dock = System.Windows.Forms.DockStyle.Fill;
      this.gbType.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbType.Location = new System.Drawing.Point(230, 39);
      this.gbType.Name = "gbType";
      this.gbType.Size = new System.Drawing.Size(599, 391);
      this.gbType.TabIndex = 45;
      this.gbType.TabStop = false;
      this.gbType.Text = "Quote Type";
      // 
      // cmbType
      // 
      this.cmbType.DisplayMember = "textfield";
      this.cmbType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.cmbType.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbType.FormattingEnabled = true;
      this.cmbType.Items.AddRange(new object[] {
            "Retrofit",
            "Basic Quote"});
      this.cmbType.Location = new System.Drawing.Point(127, 40);
      this.cmbType.Name = "cmbType";
      this.cmbType.Size = new System.Drawing.Size(171, 28);
      this.cmbType.TabIndex = 207;
      this.cmbType.ValueMember = "datafield";
      this.cmbType.SelectedIndexChanged += new System.EventHandler(this.cmbType_SelectedIndexChanged);
      // 
      // label31
      // 
      this.label31.AutoSize = true;
      this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label31.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
      this.label31.Location = new System.Drawing.Point(24, 43);
      this.label31.Name = "label31";
      this.label31.Size = new System.Drawing.Size(95, 20);
      this.label31.TabIndex = 46;
      this.label31.Text = "Quote Type:";
      // 
      // gbReference
      // 
      this.gbReference.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.gbReference.Controls.Add(this.groupBox4);
      this.gbReference.Controls.Add(this.groupBox3);
      this.gbReference.Dock = System.Windows.Forms.DockStyle.Fill;
      this.gbReference.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbReference.Location = new System.Drawing.Point(230, 39);
      this.gbReference.Name = "gbReference";
      this.gbReference.Size = new System.Drawing.Size(599, 391);
      this.gbReference.TabIndex = 223;
      this.gbReference.TabStop = false;
      this.gbReference.Text = "Reference and Note";
      // 
      // groupBox4
      // 
      this.groupBox4.Controls.Add(this.txtNote);
      this.groupBox4.Dock = System.Windows.Forms.DockStyle.Fill;
      this.groupBox4.Location = new System.Drawing.Point(3, 75);
      this.groupBox4.Name = "groupBox4";
      this.groupBox4.Size = new System.Drawing.Size(593, 313);
      this.groupBox4.TabIndex = 5;
      this.groupBox4.TabStop = false;
      this.groupBox4.Text = "Note";
      // 
      // txtNote
      // 
      this.txtNote.Dock = System.Windows.Forms.DockStyle.Fill;
      this.txtNote.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtNote.Location = new System.Drawing.Point(3, 20);
      this.txtNote.MaxLength = 5000;
      this.txtNote.Multiline = true;
      this.txtNote.Name = "txtNote";
      this.txtNote.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
      this.txtNote.Size = new System.Drawing.Size(587, 290);
      this.txtNote.TabIndex = 211;
      this.txtNote.TextChanged += new System.EventHandler(this.txtNote_TextChanged);
      // 
      // groupBox3
      // 
      this.groupBox3.Controls.Add(this.txtReference);
      this.groupBox3.Controls.Add(this.JobNameLabel);
      this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
      this.groupBox3.Location = new System.Drawing.Point(3, 20);
      this.groupBox3.Name = "groupBox3";
      this.groupBox3.Size = new System.Drawing.Size(593, 55);
      this.groupBox3.TabIndex = 212;
      this.groupBox3.TabStop = false;
      // 
      // txtReference
      // 
      this.txtReference.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtReference.Location = new System.Drawing.Point(105, 17);
      this.txtReference.MaxLength = 100;
      this.txtReference.Name = "txtReference";
      this.txtReference.Size = new System.Drawing.Size(476, 26);
      this.txtReference.TabIndex = 3;
      this.txtReference.TextChanged += new System.EventHandler(this.txtReference_TextChanged);
      // 
      // JobNameLabel
      // 
      this.JobNameLabel.AutoSize = true;
      this.JobNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.JobNameLabel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
      this.JobNameLabel.Location = new System.Drawing.Point(9, 18);
      this.JobNameLabel.Name = "JobNameLabel";
      this.JobNameLabel.Size = new System.Drawing.Size(88, 20);
      this.JobNameLabel.TabIndex = 4;
      this.JobNameLabel.Text = "Reference:";
      // 
      // panel1
      // 
      this.panel1.BackColor = System.Drawing.Color.Gray;
      this.panel1.Controls.Add(this.rbReference);
      this.panel1.Controls.Add(this.rbCustomer);
      this.panel1.Controls.Add(this.rbType);
      this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
      this.panel1.Location = new System.Drawing.Point(0, 0);
      this.panel1.Name = "panel1";
      this.panel1.Size = new System.Drawing.Size(230, 480);
      this.panel1.TabIndex = 225;
      // 
      // rbReference
      // 
      this.rbReference.AutoSize = true;
      this.rbReference.Enabled = false;
      this.rbReference.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.rbReference.ForeColor = System.Drawing.Color.White;
      this.rbReference.Location = new System.Drawing.Point(39, 86);
      this.rbReference.Name = "rbReference";
      this.rbReference.Size = new System.Drawing.Size(158, 22);
      this.rbReference.TabIndex = 232;
      this.rbReference.Text = "Reference and Note";
      this.rbReference.UseVisualStyleBackColor = true;
      this.rbReference.CheckedChanged += new System.EventHandler(this.rbReference_CheckedChanged);
      // 
      // rbCustomer
      // 
      this.rbCustomer.AutoSize = true;
      this.rbCustomer.Checked = true;
      this.rbCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.rbCustomer.ForeColor = System.Drawing.Color.White;
      this.rbCustomer.Location = new System.Drawing.Point(39, 30);
      this.rbCustomer.Name = "rbCustomer";
      this.rbCustomer.Size = new System.Drawing.Size(92, 22);
      this.rbCustomer.TabIndex = 227;
      this.rbCustomer.TabStop = true;
      this.rbCustomer.Text = "Customer";
      this.rbCustomer.UseVisualStyleBackColor = true;
      this.rbCustomer.CheckedChanged += new System.EventHandler(this.rbCustomer_CheckedChanged);
      // 
      // rbType
      // 
      this.rbType.AutoSize = true;
      this.rbType.Enabled = false;
      this.rbType.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.rbType.ForeColor = System.Drawing.Color.White;
      this.rbType.Location = new System.Drawing.Point(39, 58);
      this.rbType.Name = "rbType";
      this.rbType.Size = new System.Drawing.Size(58, 22);
      this.rbType.TabIndex = 226;
      this.rbType.Text = "Type";
      this.rbType.UseVisualStyleBackColor = true;
      this.rbType.CheckedChanged += new System.EventHandler(this.rbType_CheckedChanged);
      // 
      // toolStrip2
      // 
      this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsPrevious,
            this.tsNext,
            this.tsSave});
      this.toolStrip2.Location = new System.Drawing.Point(230, 0);
      this.toolStrip2.Name = "toolStrip2";
      this.toolStrip2.Size = new System.Drawing.Size(599, 39);
      this.toolStrip2.TabIndex = 226;
      this.toolStrip2.Text = "toolStrip2";
      // 
      // panel2
      // 
      this.panel2.Controls.Add(this.btnSave);
      this.panel2.Controls.Add(this.btnCancel);
      this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
      this.panel2.Location = new System.Drawing.Point(230, 430);
      this.panel2.Name = "panel2";
      this.panel2.Size = new System.Drawing.Size(599, 50);
      this.panel2.TabIndex = 11;
      // 
      // txtBasicDescription
      // 
      this.txtBasicDescription.AcceptsReturn = true;
      this.txtBasicDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtBasicDescription.Location = new System.Drawing.Point(124, 23);
      this.txtBasicDescription.MaxLength = 1000;
      this.txtBasicDescription.Multiline = true;
      this.txtBasicDescription.Name = "txtBasicDescription";
      this.txtBasicDescription.Size = new System.Drawing.Size(463, 106);
      this.txtBasicDescription.TabIndex = 227;
      // 
      // gbBasic
      // 
      this.gbBasic.Controls.Add(this.label3);
      this.gbBasic.Controls.Add(this.label2);
      this.gbBasic.Controls.Add(this.label1);
      this.gbBasic.Controls.Add(this.nudPrice);
      this.gbBasic.Controls.Add(this.nudCost);
      this.gbBasic.Controls.Add(this.txtBasicDescription);
      this.gbBasic.Dock = System.Windows.Forms.DockStyle.Bottom;
      this.gbBasic.Location = new System.Drawing.Point(3, 81);
      this.gbBasic.Name = "gbBasic";
      this.gbBasic.Size = new System.Drawing.Size(593, 307);
      this.gbBasic.TabIndex = 228;
      this.gbBasic.TabStop = false;
      this.gbBasic.Text = "Basic Quote Details";
      this.gbBasic.Visible = false;
      // 
      // nudCost
      // 
      this.nudCost.DecimalPlaces = 2;
      this.nudCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.nudCost.Location = new System.Drawing.Point(124, 148);
      this.nudCost.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
      this.nudCost.Name = "nudCost";
      this.nudCost.Size = new System.Drawing.Size(120, 24);
      this.nudCost.TabIndex = 228;
      // 
      // nudPrice
      // 
      this.nudPrice.DecimalPlaces = 2;
      this.nudPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.nudPrice.Location = new System.Drawing.Point(124, 178);
      this.nudPrice.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
      this.nudPrice.Name = "nudPrice";
      this.nudPrice.Size = new System.Drawing.Size(120, 24);
      this.nudPrice.TabIndex = 229;
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
      this.label1.Location = new System.Drawing.Point(23, 34);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(93, 20);
      this.label1.TabIndex = 208;
      this.label1.Text = "Description:";
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
      this.label2.Location = new System.Drawing.Point(70, 150);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(46, 20);
      this.label2.TabIndex = 230;
      this.label2.Text = "Cost:";
      this.label2.Click += new System.EventHandler(this.label2_Click);
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
      this.label3.Location = new System.Drawing.Point(70, 180);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(48, 20);
      this.label3.TabIndex = 231;
      this.label3.Text = "Price:";
      // 
      // btnCustomer
      // 
      this.btnCustomer.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnCustomer.BackgroundImage = global::workshop_orders.Properties.Resources.customers32;
      this.btnCustomer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
      this.btnCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnCustomer.ForeColor = System.Drawing.Color.Black;
      this.btnCustomer.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
      this.btnCustomer.Location = new System.Drawing.Point(3, 20);
      this.btnCustomer.Margin = new System.Windows.Forms.Padding(0);
      this.btnCustomer.Name = "btnCustomer";
      this.btnCustomer.Size = new System.Drawing.Size(158, 36);
      this.btnCustomer.TabIndex = 9;
      this.btnCustomer.Text = "Find Customer";
      this.btnCustomer.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      this.btnCustomer.UseVisualStyleBackColor = false;
      this.btnCustomer.Click += new System.EventHandler(this.btnCustomer_Click);
      // 
      // tsPrevious
      // 
      this.tsPrevious.Image = global::workshop_orders.Properties.Resources.arrow_back32;
      this.tsPrevious.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsPrevious.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsPrevious.Name = "tsPrevious";
      this.tsPrevious.Size = new System.Drawing.Size(69, 36);
      this.tsPrevious.Text = "Prev.";
      this.tsPrevious.Click += new System.EventHandler(this.tsPrevious_Click);
      // 
      // tsNext
      // 
      this.tsNext.Image = global::workshop_orders.Properties.Resources.arrow_next32;
      this.tsNext.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsNext.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsNext.Name = "tsNext";
      this.tsNext.Size = new System.Drawing.Size(68, 36);
      this.tsNext.Text = "Next";
      this.tsNext.Click += new System.EventHandler(this.tsNext_Click);
      // 
      // tsSave
      // 
      this.tsSave.Image = global::workshop_orders.Properties.Resources.save;
      this.tsSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsSave.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsSave.Name = "tsSave";
      this.tsSave.Size = new System.Drawing.Size(67, 36);
      this.tsSave.Text = "Save";
      this.tsSave.Visible = false;
      this.tsSave.Click += new System.EventHandler(this.tsSave_Click_1);
      // 
      // btnSave
      // 
      this.btnSave.Enabled = false;
      this.btnSave.Image = global::workshop_orders.Properties.Resources.save;
      this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
      this.btnSave.Location = new System.Drawing.Point(509, 5);
      this.btnSave.Name = "btnSave";
      this.btnSave.Size = new System.Drawing.Size(75, 39);
      this.btnSave.TabIndex = 1;
      this.btnSave.Text = "Save";
      this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      this.btnSave.UseVisualStyleBackColor = true;
      this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
      // 
      // btnCancel
      // 
      this.btnCancel.Image = global::workshop_orders.Properties.Resources.cancel32;
      this.btnCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
      this.btnCancel.Location = new System.Drawing.Point(422, 6);
      this.btnCancel.Name = "btnCancel";
      this.btnCancel.Size = new System.Drawing.Size(82, 38);
      this.btnCancel.TabIndex = 0;
      this.btnCancel.Text = "Cancel";
      this.btnCancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      this.btnCancel.UseVisualStyleBackColor = true;
      this.btnCancel.Click += new System.EventHandler(this.button2_Click);
      // 
      // QuoteNew
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.ClientSize = new System.Drawing.Size(829, 480);
      this.Controls.Add(this.gbType);
      this.Controls.Add(this.gbCustomer);
      this.Controls.Add(this.gbReference);
      this.Controls.Add(this.toolStrip2);
      this.Controls.Add(this.panel2);
      this.Controls.Add(this.panel1);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
      this.Name = "QuoteNew";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
      this.Text = "New Quote";
      this.gbCustomer.ResumeLayout(false);
      this.groupBox5.ResumeLayout(false);
      this.groupBox5.PerformLayout();
      this.gbType.ResumeLayout(false);
      this.gbType.PerformLayout();
      this.gbReference.ResumeLayout(false);
      this.groupBox4.ResumeLayout(false);
      this.groupBox4.PerformLayout();
      this.groupBox3.ResumeLayout(false);
      this.groupBox3.PerformLayout();
      this.panel1.ResumeLayout(false);
      this.panel1.PerformLayout();
      this.toolStrip2.ResumeLayout(false);
      this.toolStrip2.PerformLayout();
      this.panel2.ResumeLayout(false);
      this.gbBasic.ResumeLayout(false);
      this.gbBasic.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.nudCost)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudPrice)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion
    private System.Windows.Forms.GroupBox gbCustomer;
    private System.Windows.Forms.Button btnCustomer;
    private System.Windows.Forms.TextBox txtCustomer;
    private System.Windows.Forms.GroupBox gbType;
    private System.Windows.Forms.Label label31;
    private System.Windows.Forms.GroupBox gbReference;
    private System.Windows.Forms.Label JobNameLabel;
    private System.Windows.Forms.TextBox txtReference;
    private System.Windows.Forms.TextBox txtNote;
    private System.Windows.Forms.Panel panel1;
    private System.Windows.Forms.RadioButton rbCustomer;
    private System.Windows.Forms.RadioButton rbType;
    private System.Windows.Forms.RadioButton rbReference;
    private System.Windows.Forms.ToolStrip toolStrip2;
    private System.Windows.Forms.ToolStripButton tsPrevious;
    private System.Windows.Forms.ToolStripButton tsNext;
    private System.Windows.Forms.ComboBox cmbType;
    private System.Windows.Forms.GroupBox groupBox3;
    private System.Windows.Forms.GroupBox groupBox5;
    private System.Windows.Forms.Panel panel2;
    private System.Windows.Forms.Button btnSave;
    private System.Windows.Forms.Button btnCancel;
    private System.Windows.Forms.ToolStripButton tsSave;
    private System.Windows.Forms.GroupBox groupBox4;
    private System.Windows.Forms.GroupBox gbBasic;
    private System.Windows.Forms.TextBox txtBasicDescription;
    private System.Windows.Forms.NumericUpDown nudPrice;
    private System.Windows.Forms.NumericUpDown nudCost;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label label3;
  }
}