﻿
namespace workshop_orders
{
  partial class AdminTask
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.gbAdmin = new System.Windows.Forms.GroupBox();
      this.txtNote = new System.Windows.Forms.TextBox();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.toolStrip1 = new System.Windows.Forms.ToolStrip();
      this.tsBack = new System.Windows.Forms.ToolStripButton();
      this.tsAddTime = new System.Windows.Forms.ToolStripButton();
      this.tsUser = new System.Windows.Forms.ToolStripLabel();
      this.gbAdmin.SuspendLayout();
      this.groupBox1.SuspendLayout();
      this.toolStrip1.SuspendLayout();
      this.SuspendLayout();
      // 
      // gbAdmin
      // 
      this.gbAdmin.Controls.Add(this.groupBox1);
      this.gbAdmin.Dock = System.Windows.Forms.DockStyle.Fill;
      this.gbAdmin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbAdmin.Location = new System.Drawing.Point(0, 39);
      this.gbAdmin.Name = "gbAdmin";
      this.gbAdmin.Size = new System.Drawing.Size(800, 411);
      this.gbAdmin.TabIndex = 0;
      this.gbAdmin.TabStop = false;
      this.gbAdmin.Text = "Admin Task: ";
      // 
      // txtNote
      // 
      this.txtNote.Dock = System.Windows.Forms.DockStyle.Fill;
      this.txtNote.Location = new System.Drawing.Point(3, 22);
      this.txtNote.Multiline = true;
      this.txtNote.Name = "txtNote";
      this.txtNote.Size = new System.Drawing.Size(788, 361);
      this.txtNote.TabIndex = 0;
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.Add(this.txtNote);
      this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.groupBox1.Location = new System.Drawing.Point(3, 22);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(794, 386);
      this.groupBox1.TabIndex = 1;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Comment";
      // 
      // toolStrip1
      // 
      this.toolStrip1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsBack,
            this.tsAddTime,
            this.tsUser});
      this.toolStrip1.Location = new System.Drawing.Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new System.Drawing.Size(800, 39);
      this.toolStrip1.TabIndex = 2;
      this.toolStrip1.Text = "toolStrip1";
      // 
      // tsBack
      // 
      this.tsBack.Image = global::workshop_orders.Properties.Resources.back;
      this.tsBack.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsBack.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsBack.Name = "tsBack";
      this.tsBack.Size = new System.Drawing.Size(78, 36);
      this.tsBack.Text = "Back";
      this.tsBack.Click += new System.EventHandler(this.tsBack_Click);
      // 
      // tsAddTime
      // 
      this.tsAddTime.Image = global::workshop_orders.Properties.Resources.hourglass32;
      this.tsAddTime.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsAddTime.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsAddTime.Name = "tsAddTime";
      this.tsAddTime.Size = new System.Drawing.Size(124, 36);
      this.tsAddTime.Text = "Add Admin";
      this.tsAddTime.Click += new System.EventHandler(this.tsAddTime_Click);
      // 
      // tsUser
      // 
      this.tsUser.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
      this.tsUser.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.tsUser.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
      this.tsUser.Name = "tsUser";
      this.tsUser.Size = new System.Drawing.Size(71, 36);
      this.tsUser.Text = "No User";
      // 
      // AdminTask
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(800, 450);
      this.Controls.Add(this.gbAdmin);
      this.Controls.Add(this.toolStrip1);
      this.Name = "AdminTask";
      this.Text = "Admin";
      this.gbAdmin.ResumeLayout(false);
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.GroupBox gbAdmin;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.TextBox txtNote;
    private System.Windows.Forms.ToolStrip toolStrip1;
    private System.Windows.Forms.ToolStripButton tsBack;
    private System.Windows.Forms.ToolStripButton tsAddTime;
    private System.Windows.Forms.ToolStripLabel tsUser;
  }
}