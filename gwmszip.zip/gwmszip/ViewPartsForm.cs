﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Remoting;
using System.Windows.Forms;

namespace workshop_orders
{
  /*This is a form is view all the created jobs in the database*
   * This data can a queried and filter so you can only display the job you want to see*/
  public partial class ViewPartsForm : Form
  {

    /*A method to connect to the GoreGlassJob database*/
    public MySqlConnection connectMySql()
    {
      using (MySqlConnection conn = new MySqlConnection(GWMS.connStr))
      {
        try
        {
          Console.WriteLine("Connecting to MySQL...");

          return conn;
        }
        catch (Exception ex)
        {
          MessageBox.Show("Error connecting to server, please contact the administrator.", "Error!");
          DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
          System.Reflection.MethodBase.GetCurrentMethod().Name, "");
          return null;
        }

      }
    }

    /*Initializes the component and add the database varible names to the 'WHERE' box, used for querying the job database job*/
    public ViewPartsForm()
    {
      InitializeComponent();
      reset_all_fields();
    }

    /*Check if String entered into function is a number
     */
    public bool IsNumber(String number)
    {
      return number.All(char.IsNumber);
    }

    /*reset_all_fields method
     * Resets all the fields in the form to empty
     * Also refreshes the Today's orders' box to reflect any changes that may have happened to the database.
     */
    private void reset_all_fields()
    {
      refreshOrders();
    }

    /*When this method is called, it reloads the Jobs from the MySql database*/
    private void refreshOrders()
    {
      using (MySqlConnection conn = connectMySql())
      {
        try
        {
          conn.Open();
          string sql = String.Format("SELECT orderNo AS OrderNo, jobNo AS Job, dateRequired AS DateRequired " +
              "FROM orders WHERE status = 'NOT-ORDERED' ORDER BY dateRequired;");

          MySqlDataAdapter sqlDa = new MySqlDataAdapter(sql, conn);
          DataTable dtbl = new DataTable();
          sqlDa.Fill(dtbl);

          notDataGrid.DataSource = dtbl;
          foreach (DataGridViewRow row in notDataGrid.Rows)
          {
            try
            {
              if (row.Cells[2].Value != null)
              {
                if (DateTime.Parse(row.Cells[2].Value.ToString()) >= DateTime.Today)
                {
                  row.Cells[2].Style.BackColor = Color.OrangeRed;
                }
                else if (DateTime.Parse(row.Cells[2].Value.ToString()) >= DateTime.Today.AddDays(1))
                {
                  row.Cells[2].Style.BackColor = Color.Yellow;
                }
              }
            }
            catch (Exception ex)
            {

            }
          }
          conn.Close();
        }
        catch (Exception ex)
        {
          DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
        }
      }
      using (MySqlConnection conn = connectMySql())
      {
        try
        {
          conn.Open();
          string sql = String.Format("SELECT orderNo AS OrderNo, jobNo AS Job, " +
              "dateRequired AS DateRequired, dateSent AS DateSent " +
              "FROM orders WHERE status = 'ON-ORDER' ORDER BY dateRequired;");

          MySqlDataAdapter sqlDa = new MySqlDataAdapter(sql, conn);
          DataTable dtbl = new DataTable();
          sqlDa.Fill(dtbl);

          onDataGrid.DataSource = dtbl;
          foreach (DataGridViewRow row in onDataGrid.Rows)
          {
            try
            {
              if (row.Cells[2].Value != null)
              {
                if (DateTime.Parse(row.Cells[2].Value.ToString()) >= DateTime.Today)
                {
                  row.Cells[2].Style.BackColor = Color.OrangeRed;
                }
                else if (DateTime.Parse(row.Cells[2].Value.ToString()) >= DateTime.Today.AddDays(1))
                {
                  row.Cells[2].Style.BackColor = Color.Yellow;
                }
              }
            }
            catch (Exception ex)
            {

            }
          }
          conn.Close();
        }
        catch (Exception ex)
        {
          DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
        }
      }
      using (MySqlConnection conn = connectMySql())
      {
        try
        {
          conn.Open();
          string sql = String.Format("SELECT orderNo AS OrderNo, jobNo AS Job, " +
              "dateArrived AS DateArrived, dateRequired AS DateRequired, dateSent AS DateSent " +
              "FROM orders WHERE status = 'ARRIVED' ORDER BY dateRequired;");

          MySqlDataAdapter sqlDa = new MySqlDataAdapter(sql, conn);
          DataTable dtbl = new DataTable();
          sqlDa.Fill(dtbl);

          recentDataGrid.DataSource = dtbl;
          foreach (DataGridViewRow row in recentDataGrid.Rows)
          {
            try
            {
              if (row.Cells[2].Value != null)
              {
                if (DateTime.Parse(row.Cells[2].Value.ToString()) >= DateTime.Today)
                {
                  row.Cells[2].Style.BackColor = Color.OrangeRed;
                }
                else if (DateTime.Parse(row.Cells[2].Value.ToString()) >= DateTime.Today.AddDays(1))
                {
                  row.Cells[2].Style.BackColor = Color.Yellow;
                }
              }
            }
            catch (Exception ex)
            {

            }
          }
          conn.Close();
        }
        catch (Exception ex)
        {
          DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
        }
      }
      using (MySqlConnection conn = connectMySql())
      {
        try
        {
          conn.Open();
          string dateNow = DateTime.Now.ToString("yyyy/MM/dd" + "");
          string sql;
          MySqlCommand cmd;
          MySqlDataAdapter sqlDa;
          DataTable dtbl;
          if (stockSearchText.Text.Length >= 3 || stockSearchText.Text.Length == 0)
          {
            /*string getOrders = "SELECT jobNo AS JobNumber, jobPart.pType AS PartType, jobPart.pCode AS PartCode, pAltCode AS AltCode, bookingDate AS BookingDate, " +
                "state AS State FROM jobPart INNER JOIN part ON part.pType = jobPart.pType AND part.pCode = jobPart.pCode " +
                "INNER JOIN job ON jobNo = jobNumber " +
                "ORDER BY jobNo DESC;";*/

            sql = String.Format("SELECT job.jobNo AS JobNo, part.pID AS PartID, part.pType AS PartType, part.pCode AS PartCode, pAltCode AS AltCode, " +
            "pNagCode AS NagsCode, pState AS State, status AS JobStatus, note AS JobNote, cFirstName AS CustomerFirstName, cSurname AS Surname, bookingDate AS BookDate, " +
            "bookingTime AS BookTime FROM job INNER JOIN jobPart ON job.jobNo = jobPart.pAllocated INNER JOIN part ON " +
            "part.pID = jobPart.pID INNER JOIN " +
            "(SELECT MAX(date) AS maxdate FROM jobStatus WHERE jobNo = job.jobNo) jS ON jS.maxdate = job.jobNo INNER JOIN customer ON customerID = cID WHERE jobPart.pAllocated != null;");

            sql = String.Format("SELECT job.jobNo AS JobNo, pType AS PartType, pCode AS EuroCode, pAltCode AS OBCODE, pNagCode AS NagCode, " +
                "pState AS State, status AS JobStatus, registration AS Rego, bookingDate AS BookDate, cSurname AS Surname, cFirstName AS CustomerFirstName, cCompany AS Company, note AS JobNote, " +
                "jobPart.date AS PartUpdated, jobPart.updatedBy AS UpdatedBy, jobPart.objID AS OID FROM jobPart INNER JOIN (SELECT objID, MAX(date) AS maxdate FROM jobPart GROUP BY objID) jP " +
                "ON jP.maxdate = jobPart.date AND jP.objID = jobPart.objID INNER JOIN job ON jobPart.pAllocated = job.jobNo INNER JOIN jobStatus ON jobStatus.jobNo = job.jobNo " +
                "INNER JOIN (SELECT jobNo, MAX(date) AS maxdate FROM jobStatus GROUP BY jobNo) jS ON jobStatus.date = jS.maxdate AND jS.jobNo = jobStatus.jobNo INNER JOIN part ON " +
                "part.pID = jobPart.pID INNER JOIN customer ON cID = customerID WHERE pState != 'COMPLETE' ORDER BY pState DESC;");

            cmd = new MySqlCommand(sql, conn);
            sqlDa = new MySqlDataAdapter(sql, conn);
            dtbl = new DataTable();
            sqlDa.Fill(dtbl);

            dataGridView1.DataSource = dtbl;

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
              try
              {
                if (row.Cells[5].Value != null && row.Cells[8].Value != null)
                {
                  if (row.Cells[5].Value.ToString() != "IN-STOCK" &&
                      row.Cells[5].Value.ToString() != "COMPLETE" &&
                      DateTime.Parse(row.Cells[8].Value.ToString().Split(' ')[0]) <= DateTime.Today)
                  {
                    row.Cells[5].Style.BackColor = Color.OrangeRed;

                  }
                  else if (row.Cells[5].Value.ToString() != "IN-STOCK" &&
                      row.Cells[5].Value.ToString() != "COMPLETE" &&
                      row.Cells[8].Value.ToString().Split(' ')[0] == DateTime.Now.AddDays(1).ToString("dd/MM/yyyy"))
                  {
                    row.Cells[5].Style.BackColor = Color.Yellow;

                  }
                }
                if (row.Cells[8].Value != null && row.Cells[5].Value.ToString() != "COMPLETE")
                {
                  if (DateTime.Parse(row.Cells[8].Value.ToString().Split(' ')[0]) < DateTime.Today)
                  {
                    row.Cells[8].Style.BackColor = Color.Yellow;
                  }
                }
              }
              catch (Exception ex)
              {
              }
            }
          }

          if (stockSearchText.Text.Length >= 3)
          {
            sql = String.Format("SELECT job.jobNo AS JobNo, part.pID AS PartID, part.pType AS PartType, " +
                "part.pCode AS PartCode, pAltCode AS AltCode, " +
                "pNagCode AS NagsCode, pState AS State, status AS JobStatus, note AS JobNote, " +
                "cFirstName AS CustomerFirstName, cSurname AS Surname, bookingDate AS BookDate, " +
                "bookingTime AS BookTime FROM job INNER JOIN jobPart ON job.jobNo = jobPart.pAllocated " +
                "INNER JOIN part ON " +
                "part.pID = jobPart.pID INNER JOIN " +
                "(SELECT *, MAX(date) FROM jobStatus GROUP BY jobNo) jS ON jS.jobNo = job.jobNo " +
                "INNER JOIN customer ON customerID = cID WHERE jobPart.pAllocated = null;");

            sql = String.Format("SELECT pType AS PartType, pCode AS EuroCode, pAltCode AS OBCODE, " +
                "pNagCode AS NagCode, " +
                "pState AS State, " +
                "jobPart.date AS PartUpdated, jobPart.updatedBy AS UpdatedBy, jobPart.objID AS OID " +
                "FROM jobPart INNER JOIN (SELECT objID, MAX(date) AS maxdate FROM jobPart GROUP BY objID) jP " +
                "ON jP.maxdate = jobPart.date AND jP.objID = jobPart.objID INNER JOIN part ON " +
                "part.pID = jobPart.pID WHERE pAllocated IS NULL LIMIT 100;");

            cmd = new MySqlCommand(sql, conn);
            sqlDa = new MySqlDataAdapter(sql, conn);
            dtbl = new DataTable();
            sqlDa.Fill(dtbl);

            dataGridView2.DataSource = dtbl;

            sql = String.Format("SELECT part.pID AS PartID, pType AS PartType, pCode AS PartCode, " +
                "pAltCode AS AltCode, " +
                "pNagCode AS NagsCode, quan AS Quan, allo AS Allo, pInfo AS Info FROM part " +
                "LEFT JOIN (SELECT pID, COUNT(*) AS quan FROM jobPart INNER JOIN " +
                "(SELECT jobPart.objID, MAX(date) AS maxdate FROM jobPart " +
                "INNER JOIN (SELECT objID, MAX(date) AS maxdate FROM jobPart GROUP BY objID) jP ON jP.objID = jobPart.objID " +
                "AND maxdate = date WHERE pAllocated IS null AND pState = 'IN-STOCK' " +
                "GROUP BY jobPart.objID) jP ON jobPart.date = jP.maxdate AND jobPart.objID = jP.objID " +
                "GROUP BY pID) jP ON jP.pID = part.pID " +
                "LEFT JOIN(SELECT pID, COUNT(*) AS allo FROM jobPart INNER JOIN " +
                "(SELECT jobPart.objID, MAX(date) AS maxdate FROM jobPart " +
                "INNER JOIN (SELECT objID, MAX(date) AS maxdate FROM jobPart GROUP BY objID) jP " +
                "ON jP.objID = jobPart.objID " +
                "AND maxdate = date WHERE pAllocated IS NOT null AND pState = 'IN-STOCK' " +
                "GROUP BY jobPart.objID) jP ON jobPart.date = jP.maxdate AND jobPart.objID = jP.objID " +
                "GROUP BY pID) jP2 ON jP2.pID = part.pID " +
                "WHERE part.pID > 0 ORDER BY part.pID DESC LIMIT 100;");

            cmd = new MySqlCommand(sql, conn);
            sqlDa = new MySqlDataAdapter(sql, conn);
            dtbl = new DataTable();
            sqlDa.Fill(dtbl);

            dataGridView3.DataSource = dtbl;
          }
          if (stockSearchText.Text.Length >= 3 || stockSearchText.Text.Length == 0)
          {
            sql = String.Format("SELECT job.jobNo AS JobNo, part.pID AS PartID, part.pType AS PartType, " +
                "part.pCode AS PartCode, pAltCode AS AltCode, " +
           "pNagCode AS NagsCode, pState AS State, registration AS Rego, status AS JobStatus, " +
           "note AS JobNote, cFirstName AS CustomerFirstName, cSurname AS Surname, bookingDate AS BookDate, " +
           "bookingTime AS BookTime FROM part LEFT JOIN jobPart ON part.pID = jobPart.pID " +
           "LEFT JOIN job ON " +
           "job.jobNo = jobPart.pAllocated LEFT JOIN " +
           "(SELECT *, MAX(date) FROM jobStatus GROUP BY jobNo) jS ON jS.jobNo = job.jobNo " +
           "LEFT JOIN customer ON customerID = cID;");

            //cmd = new MySqlCommand(sql, conn);
            //sqlDa = new MySqlDataAdapter(sql, conn);

            sql = String.Format("SELECT job.jobNo AS JobNo, part.pType AS PartType, part.pCode AS PartCode, " +
                "pAltCode AS AltCode, " +
                "pNagCode AS NagsCode, bookingDate AS BookDate, registration AS Rego, " +
                "concat(COALESCE(cFirstName, ''), ' ', COALESCE(cSurname, ''), ' || ', " +
                "COALESCE(cCompany, '')) AS Customer, note AS JobNote, objID AS OID " +
                "FROM part LEFT JOIN jobPart ON part.pID = jobPart.pID LEFT JOIN job ON " +
                "job.jobNo = jobPart.pAllocated LEFT JOIN " +
                "(SELECT *, MAX(date) FROM jobStatus GROUP BY jobNo) jS ON jS.jobNo = job.jobNo " +
                "LEFT JOIN customer ON customerID = cID " +
                "WHERE pState = 'NOT-ORDERED' AND bookingDate IS NOT NULL ORDER BY bookingDate;");


            cmd = new MySqlCommand(sql, conn);
            sqlDa = new MySqlDataAdapter(sql, conn);
            dtbl = new DataTable();
            sqlDa.Fill(dtbl);

            dataGridView4.DataSource = dtbl;

            sql = String.Format("SELECT jobPart.objID AS ID, part.pType AS PartType, " +
                "part.pCode AS PartCode, pAltCode AS AltCode, " +
                "pNagCode AS NagsCode, pState AS State, date AS DateArrived " +
                "FROM part INNER JOIN jobPart ON part.pID = jobPart.pID " +
                "INNER JOIN (SELECT objID, MAX(date) AS maxdate FROM jobPart GROUP BY objID) jP " +
                "ON jP.objID = jobPart.objID AND " +
                "date = maxdate " +
                "WHERE pState = 'ON-CREDIT' OR pState = 'CREDIT' ORDER BY jobPart.date;");

            cmd = new MySqlCommand(sql, conn);
            sqlDa = new MySqlDataAdapter(sql, conn);
            dtbl = new DataTable();
            sqlDa.Fill(dtbl);

            dataGridView5.DataSource = dtbl;

            MySqlDataReader rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
              creditNotify.Visible = true;
              break;
            }

            conn.Close();
            conn.Open();
            sql = String.Format("SELECT jobPart.objID AS ID, part.pType AS PartType, " +
                "part.pCode AS PartCode, pAltCode AS AltCode, " +
                "pNagCode AS NagsCode, pState AS State, date AS DateArrived " +
                "FROM part INNER JOIN jobPart ON part.pID = jobPart.pID " +
                "INNER JOIN (SELECT objID, MAX(date) AS maxdate FROM jobPart GROUP BY objID) jP " +
                "ON jP.objID = jobPart.objID AND " +
                "date = maxdate " +
                "WHERE pState = 'AUTO-STOCK' ORDER BY jobPart.date;");

            cmd = new MySqlCommand(sql, conn);
            sqlDa = new MySqlDataAdapter(sql, conn);
            dtbl = new DataTable();
            sqlDa.Fill(dtbl);

            autoDataGrid.DataSource = dtbl;

            rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
              autoNotify.Visible = true;
              break;
            }
          }
          try
          {
            foreach (DataGridViewRow row in dataGridView4.Rows)
            {
              if (row.Cells[5].Value != null)
              {

                if (DateTime.Parse(row.Cells[5].Value.ToString()) <= DateTime.Today.AddDays(3))
                {
                  row.Cells[5].Style.BackColor = Color.LightGreen;
                }
              }
            }
          }
          catch { }


          foreach (DataGridViewRow row in dataGridView2.Rows)
          {
            /*
            if (row.Cells[4].Value != null)
            {

                if (row.Cells[4].Value.ToString() == "NOT-ORDERED")
                {
                    row.Cells[4].Style.BackColor = Color.Yellow;
                }

                if (row.Cells[4].Value.ToString() == "INCORRECT")
                {
                    row.Cells[4].Style.BackColor = Color.OrangeRed;
                }

                if (row.Cells[4].Value.ToString() == "DAMAGED")
                {
                    row.Cells[4].Style.BackColor = Color.OrangeRed;
                }

                if (row.Cells[7].Value.ToString().Split(' ')[0] == DateTime.Now.ToString("dd/MM/yyyy" + ""))
                {
                    row.Cells[7].Style.BackColor = Color.Red;
                }

                if (row.Cells[7].Value.ToString().Split(' ')[0] == DateTime.Now.AddDays(-1).ToString("dd/MM/yyyy" + ""))
                {
                    row.Cells[7].Style.BackColor = Color.OrangeRed;
                }

                if (row.Cells[4].Value.ToString() == "IN-STOCK")
                {
                    row.Cells[4].Style.BackColor = Color.LightGreen;
                }
            }*/
          }

        }

        catch (Exception ex)
        {
          MessageBox.Show("Error loading part database. If the problem persists, " +
              "please contact the administrator.", "Error!");
          DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
        }
        conn.Close();
      }
    }

    private void refreshButton_Click(object sender, EventArgs e)
    {
      refreshOrders();
    }

    private void setPart(object sender, EventArgs e)
    {
      try
      {
        int length = sender.ToString().Split(' ').Length;
        String state = sender.ToString().Split(' ')[length - 1];
        String jobNo = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
        if (jobNo != "")
        {
          using (MySqlConnection conn = connectMySql())
          {
            try
            {
              conn.Open();
              String sql = String.Format("UPDATE jobPart SET pState = '{0}' WHERE pAllocated = '{1}';",
                  state, jobNo);
              MySqlCommand cmd = new MySqlCommand(sql, conn);
              MySqlDataReader rdr = cmd.ExecuteReader();
              refreshOrders();
            }
            catch (Exception ex)
            {
              Console.WriteLine(ex.ToString());
              MessageBox.Show("Error updating part status. If this problem persists, " +
                  "please contact the administrator.\n");
              DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
            }
            conn.Close();
          }
        }
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }
    }

    public void updateButton_Click()
    {

    }

    private void addPartButton_Click(object sender, EventArgs e)
    {
      AddPartForm form = new AddPartForm();
      form.ShowDialog();
      refreshOrders();
    }


    /*A method which runs when the user closes the form.
     * It just asks the user to confirm if they want to quit the program or not.
     */
    protected override void OnFormClosing(FormClosingEventArgs e)
    {
      base.OnFormClosing(e);

      if (e.CloseReason == CloseReason.WindowsShutDown) return;

      // Confirm user wants to close
      switch (MessageBox.Show(this, "Are you sure you want to close?", "Closing", MessageBoxButtons.YesNo))
      {
        case DialogResult.No:
          e.Cancel = true;
          break;
        default:
          break;
      }
    }

    /**methods below are unused*/
    private void Form1_Load(object sender, EventArgs e)
    {
      refreshOrders();
    }

    private void ViewJobForm_Resize(object sender, EventArgs e)
    {
      //dataGridView1.Width = this.Width - dataGridView1.Location.X - 30;
      //dataGridView1.Height = this.Height - dataGridView1.Location.Y - 40;
    }
    // // /--// // /--// // /--// / / // // /// //

    private void dataGridView3_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
    {

    }

    private void dataGridView2_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
    {

    }

    private void stockSearchText_TextChanged(object sender, EventArgs e)
    {

      if (stockSearchText.Text != "")
      {
        stockSearchText.Text.Trim();
        String code = stockSearchText.Text.Split(' ').First();
        using (MySqlConnection conn = connectMySql())
        {
          try
          {
            MySqlDataAdapter sqlDa;
            DataTable dtbl;
            conn.Open();
            String sql = String.Format("SELECT part.pID AS PartID, pType AS PartType, pCode AS PartCode, pAltCode AS AltCode, " +
                "pNagCode AS NagsCode, quan AS Quan, allo AS Allo, pInfo AS Info FROM part LEFT JOIN (SELECT pID, COUNT(*) AS quan FROM jobPart INNER JOIN " +
                "(SELECT jobPart.objID, MAX(date) AS maxdate FROM jobPart INNER JOIN (SELECT objID, MAX(date) AS maxdate FROM jobPart GROUP BY objID) jP ON jP.objID = jobPart.objID " +
                "AND maxdate = date WHERE pAllocated IS null AND pState = 'IN-STOCK' GROUP BY jobPart.objID) jP ON jobPart.date = jP.maxdate AND jobPart.objID = jP.objID " +
                "GROUP BY pID) jP ON jP.pID = part.pID " +
                "LEFT JOIN(SELECT pID, COUNT(*) AS allo FROM jobPart INNER JOIN " +
                "(SELECT jobPart.objID, MAX(date) AS maxdate FROM jobPart INNER JOIN (SELECT objID, MAX(date) AS maxdate FROM jobPart GROUP BY objID) jP ON jP.objID = jobPart.objID " +
                "AND maxdate = date WHERE pAllocated IS NOT null AND pState = 'IN-STOCK' GROUP BY jobPart.objID) jP ON jobPart.date = jP.maxdate AND jobPart.objID = jP.objID " +
                "GROUP BY pID) jP2 ON jP2.pID = part.pID " +
                "WHERE pCode LIKE '{0}%' OR pAltCode LIKE " +
                "'{0}%' OR pNagCode LIKE '{0}%' OR pType LIKE '{0}%' ORDER BY part.pID DESC LIMIT 1000;",
                code);

            if (stockSearchText.Text.Length >= 3 || stockSearchText.Text.Length == 0)
            {
              /*string sql = String.Format("SELECT pID AS PartID, pType AS PartType, pCode AS PartCode, pAltCode AS AltCode, " +
                  "pNagCode AS NagsCode, pQuantity AS Quan, pAllocated AS Allo, pInfo AS Info FROM part WHERE pCode LIKE '{0}%' OR pAltCode LIKE " +
                  "'{0}%' OR pNagCode LIKE '{0}%' " +
                  "AND pID > 0;",
                  code);*/
              sqlDa = new MySqlDataAdapter(sql, conn);
              dtbl = new DataTable();
              sqlDa.Fill(dtbl);

              dataGridView3.DataSource = dtbl;
            }
            sql = String.Format("SELECT job.jobNo AS JobNo, part.pType AS PartType, part.pCode AS PartCode, pAltCode AS AltCode, " +
            "pNagCode AS NagsCode, bookingDate AS BookDate, registration AS Rego, " +
            "concat(COALESCE(cFirstName, ''), ' ', COALESCE(cSurname, ''), ' || ', COALESCE(cCompany, '')) AS Customer, note AS JobNote, objID AS OID " +
            "FROM part LEFT JOIN jobPart ON part.pID = jobPart.pID LEFT JOIN job ON " +
            "job.jobNo = jobPart.pAllocated LEFT JOIN " +
            "(SELECT *, MAX(date) FROM jobStatus GROUP BY jobNo) jS ON jS.jobNo = job.jobNo LEFT JOIN customer ON customerID = cID " +
            "WHERE pState = 'NOT-ORDERED' AND bookingDate IS NOT NULL AND (pCode LIKE '{0}%' OR pAltCode LIKE " +
                "'{0}%' OR pNagCode LIKE '{0}%' OR pType LIKE '{0}%') ORDER BY part.pID DESC LIMIT 1000;", code);

            sqlDa = new MySqlDataAdapter(sql, conn);
            dtbl = new DataTable();
            sqlDa.Fill(dtbl);

            dataGridView4.DataSource = dtbl;

            if (stockSearchText.Text.Length >= 3 || stockSearchText.Text.Length == 0)
            {
              sql = String.Format("SELECT pType AS PartType, pCode AS EuroCode, pAltCode AS OBCODE, pNagCode AS NagCode, " +
              "pState AS State, " +
              "jobPart.date AS PartUpdated, jobPart.updatedBy AS UpdatedBy, jobPart.objID AS OID FROM jobPart " +
              "INNER JOIN (SELECT objID, MAX(date) AS maxdate FROM jobPart GROUP BY objID) jP " +
              "ON jP.maxdate = jobPart.date AND jP.objID = jobPart.objID INNER JOIN part ON " +
              "part.pID = jobPart.pID WHERE pAllocated IS NULL AND (pCode LIKE '{0}%' OR pAltCode LIKE " +
              "'{0}%' OR pNagCode LIKE '{0}%' OR pType LIKE '{0}%');", code);

              sqlDa = new MySqlDataAdapter(sql, conn);
              dtbl = new DataTable();
              sqlDa.Fill(dtbl);

              dataGridView2.DataSource = dtbl;
            }

            sql = String.Format("SELECT job.jobNo AS JobNo, pType AS PartType, pCode AS EuroCode, pAltCode AS OBCODE, pNagCode AS NagCode, " +
                "pState AS State, status AS JobStatus, registration AS Rego, bookingDate AS BookDate, cSurname AS Surname, cFirstName AS cFirstName, cCompany AS Company, note AS JobNote, " +
                "jobPart.date AS PartUpdated, jobPart.updatedBy AS UpdatedBy, jobPart.objID AS OID FROM jobPart INNER JOIN (SELECT objID, MAX(date) AS maxdate FROM jobPart GROUP BY objID) jP " +
                "ON jP.maxdate = jobPart.date AND jP.objID = jobPart.objID INNER JOIN job ON jobPart.pAllocated = job.jobNo INNER JOIN jobStatus ON jobStatus.jobNo = job.jobNo " +
                "INNER JOIN (SELECT jobNo, MAX(date) AS maxdate FROM jobStatus GROUP BY jobNo) jS ON jobStatus.date = jS.maxdate AND jS.jobNo = jobStatus.jobNo INNER JOIN part ON " +
                "part.pID = jobPart.pID INNER JOIN customer ON cID = customerID WHERE pState != 'COMPLETE' AND (pCode LIKE '{0}%' OR pAltCode LIKE " +
                "'{0}%' OR pNagCode LIKE '{0}%' OR cFirstName LIKE '{0}%' OR cSurname LIKE '{0}%' OR job.jobNo LIKE '{0}%' OR pType LIKE '{0}%' OR registration LIKE '{0}%' OR cCompany LIKE '{0}%') ORDER BY pState DESC;", code);

            sqlDa = new MySqlDataAdapter(sql, conn);
            dtbl = new DataTable();
            sqlDa.Fill(dtbl);

            dataGridView1.DataSource = dtbl;
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
              try
              {
                if (row.Cells[5].Value != null)
                {
                  if (row.Cells[5].Value.ToString() != "IN-STOCK" && row.Cells[5].Value.ToString() != "COMPLETE" && DateTime.Parse(row.Cells[8].Value.ToString().Split(' ')[0]) <= DateTime.Today)
                  {
                    row.Cells[5].Style.BackColor = Color.OrangeRed;
                  }
                  else if (row.Cells[5].Value.ToString() != "IN-STOCK" && row.Cells[5].Value.ToString() != "COMPLETE" && row.Cells[8].Value.ToString().Split(' ')[0] == DateTime.Now.AddDays(1).ToString("dd/MM/yyyy"))
                  {
                    row.Cells[5].Style.BackColor = Color.Yellow;

                  }
                }

                if (row.Cells[8].Value != null && row.Cells[5].Value.ToString() != "COMPLETE")
                {
                  if (DateTime.Parse(row.Cells[8].Value.ToString().Split(' ')[0]) < DateTime.Today)
                  {
                    row.Cells[8].Style.BackColor = Color.Yellow;
                  }
                }
              }
              catch { }
            }
          }
          catch (Exception ex)
          {
            MessageBox.Show("Issue getting Customer Information. Please Contact Administrator.\nError Information:\n");
            DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
          }
          conn.Close();
        }
      }
      else if (stockSearchText.Text == "")
      {
        using (MySqlConnection conn = connectMySql())
        {
          conn.Open();
          String sql = String.Format("SELECT part.pID AS PartID, pType AS PartType, pCode AS PartCode, " +
              "pAltCode AS AltCode, " +
                 "pNagCode AS NagsCode, quan AS Quan, allo AS Allo, pInfo AS Info FROM part " +
                 "LEFT JOIN (SELECT pID, COUNT(*) AS quan FROM jobPart INNER JOIN " +
                 "(SELECT jobPart.objID, MAX(date) AS maxdate FROM jobPart " +
                 "INNER JOIN (SELECT objID, MAX(date) AS maxdate FROM jobPart GROUP BY objID) jP " +
                 "ON jP.objID = jobPart.objID " +
                 "AND maxdate = date WHERE pAllocated IS null AND pState = 'IN-STOCK' " +
                 "GROUP BY jobPart.objID) jP ON jobPart.date = jP.maxdate AND jobPart.objID = jP.objID " +
                 "GROUP BY pID) jP ON jP.pID = part.pID " +
                 "LEFT JOIN(SELECT pID, COUNT(*) AS allo FROM jobPart INNER JOIN " +
                 "(SELECT jobPart.objID, MAX(date) AS maxdate FROM jobPart " +
                 "INNER JOIN (SELECT objID, MAX(date) AS maxdate FROM jobPart GROUP BY objID) jP " +
                 "ON jP.objID = jobPart.objID " +
                 "AND maxdate = date WHERE pAllocated IS NOT null AND pState = 'IN-STOCK' " +
                 "GROUP BY jobPart.objID) jP ON jobPart.date = jP.maxdate AND jobPart.objID = jP.objID " +
                 "GROUP BY pID) jP2 ON jP2.pID = part.pID " +
                 "WHERE part.pID > 0 ORDER BY part.pID DESC LIMIT 1000;");
          /*String sql = String.Format("SELECT pID AS PartID, pType AS PartType, pCode AS PartCode, pAltCode AS AltCode, " +
                  "pNagCode AS NagsCode, pQuantity AS Quan, pAllocated AS Allo FROM part WHERE pID > 0;");*/

          MySqlCommand cmd = new MySqlCommand(sql, conn);
          MySqlDataAdapter sqlDa = new MySqlDataAdapter(sql, conn);
          DataTable dtbl = new DataTable();
          sqlDa.Fill(dtbl);

          dataGridView3.DataSource = dtbl;

          sql = String.Format("SELECT pType AS PartType, pCode AS EuroCode, pAltCode AS OBCODE, " +
              "pNagCode AS NagCode, " +
                  "pState AS State, " +
                  "jobPart.date AS PartUpdated, jobPart.updatedBy AS UpdatedBy, jobPart.objID AS OID " +
                  "FROM jobPart " +
                  "INNER JOIN (SELECT objID, MAX(date) AS maxdate FROM jobPart GROUP BY objID) jP " +
                  "ON jP.maxdate = jobPart.date AND jP.objID = jobPart.objID INNER JOIN part ON " +
                  "part.pID = jobPart.pID WHERE pAllocated IS NULL LIMIT 1000;");

          sqlDa = new MySqlDataAdapter(sql, conn);
          dtbl = new DataTable();
          sqlDa.Fill(dtbl);

          dataGridView2.DataSource = dtbl;

          sql = String.Format("SELECT job.jobNo AS JobNo, part.pType AS PartType, part.pCode AS PartCode, " +
              "pAltCode AS AltCode, " +
              "pNagCode AS NagsCode, bookingDate AS BookDate, registration AS Rego, " +
              "concat(COALESCE(cFirstName, ''), ' ', COALESCE(cSurname, ''), ' || ', " +
              "COALESCE(cCompany, '')) AS Customer, note AS JobNote, objID AS OID " +
              "FROM part LEFT JOIN jobPart ON part.pID = jobPart.pID LEFT JOIN job ON " +
              "job.jobNo = jobPart.pAllocated LEFT JOIN " +
              "(SELECT *, MAX(date) FROM jobStatus GROUP BY jobNo) jS ON jS.jobNo = job.jobNo " +
              "LEFT JOIN customer ON customerID = cID " +
              "WHERE pState = 'NOT-ORDERED' AND bookingDate IS NOT NULL ORDER BY bookingDate;");

          sqlDa = new MySqlDataAdapter(sql, conn);
          dtbl = new DataTable();
          sqlDa.Fill(dtbl);

          dataGridView4.DataSource = dtbl;

          sql = String.Format("SELECT job.jobNo AS JobNo, pType AS PartType, pCode AS EuroCode, " +
              "pAltCode AS OBCODE, pNagCode AS NagCode, " +
                  "pState AS State, status AS JobStatus, registration AS Rego, bookingDate AS BookDate, " +
                  "cSurname AS Surname, cFirstName AS cFirstName, cCompany AS Company, note AS JobNote," +
                  "jobPart.date AS PartUpdated, jobPart.updatedBy AS UpdatedBy, jobPart.objID AS OID " +
                  "FROM jobPart INNER JOIN (SELECT objID, MAX(date) AS maxdate FROM jobPart GROUP BY objID) jP " +
                  "ON jP.maxdate = jobPart.date AND jP.objID = jobPart.objID " +
                  "INNER JOIN job ON jobPart.pAllocated = job.jobNo " +
                  "INNER JOIN jobStatus ON jobStatus.jobNo = job.jobNo " +
                  "INNER JOIN (SELECT jobNo, MAX(date) AS maxdate FROM jobStatus GROUP BY jobNo) jS " +
                  "ON jobStatus.date = jS.maxdate AND jS.jobNo = jobStatus.jobNo INNER JOIN part ON " +
                  "part.pID = jobPart.pID INNER JOIN customer ON cID = customerID " +
                  "WHERE pState != 'COMPLETE' ORDER BY pState DESC;");

          sqlDa = new MySqlDataAdapter(sql, conn);
          dtbl = new DataTable();
          sqlDa.Fill(dtbl);

          dataGridView1.DataSource = dtbl;
          foreach (DataGridViewRow row in dataGridView1.Rows)
          {
            try
            {
              if (row.Cells[5].Value != null)
              {
                if (row.Cells[5].Value.ToString() != "IN-STOCK" && row.Cells[5].Value.ToString() != "COMPLETE" && DateTime.Parse(row.Cells[8].Value.ToString().Split(' ')[0]) <= DateTime.Today)
                {
                  row.Cells[5].Style.BackColor = Color.OrangeRed;

                }
                else if (row.Cells[5].Value.ToString() != "IN-STOCK" && row.Cells[5].Value.ToString() != "COMPLETE" && row.Cells[8].Value.ToString().Split(' ')[0] == DateTime.Now.AddDays(1).ToString("dd/MM/yyyy"))
                {
                  row.Cells[5].Style.BackColor = Color.Yellow;
                }
              }

              if (row.Cells[8].Value != null && row.Cells[5].Value.ToString() != "COMPLETE")
              {
                if (DateTime.Parse(row.Cells[8].Value.ToString().Split(' ')[0]) < DateTime.Today)
                {
                  row.Cells[8].Style.BackColor = Color.Yellow;
                }
              }
            }
            catch (Exception ex) { }
          }
          conn.Close();
        }
      }
      else
      {
        dataGridView3.DataSource = null;
        dataGridView2.DataSource = null;
        dataGridView1.DataSource = null;
      }
    }

    private void dataGridView1_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
    {

    }

    private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      if (e.RowIndex >= 0)
      {
        DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
        ChangeJobPart form = new ChangeJobPart(int.Parse(row.Cells["OID"].Value.ToString()));
        form.ShowDialog();
        refreshOrders();
      }
    }

    private void dataGridView3_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      if (e.RowIndex >= 0)
      {
        DataGridViewRow row = this.dataGridView3.Rows[e.RowIndex];
        AddPartForm form = new AddPartForm(int.Parse(row.Cells["PartID"].Value.ToString()), row.Cells["PartType"].Value.ToString(),
            row.Cells["PartCode"].Value.ToString(), row.Cells["AltCode"].Value.ToString(), row.Cells["NagsCode"].Value.ToString(),
            row.Cells["Info"].Value.ToString());
        form.ShowDialog();
        refreshOrders();
      }
    }

    private void dataGridView2_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      if (e.RowIndex >= 0)
      {
        DataGridViewRow row = this.dataGridView2.Rows[e.RowIndex];
        AllocatePart form = new AllocatePart(int.Parse(row.Cells["OID"].Value.ToString()));
        form.ShowDialog();
        refreshOrders();
      }
    }

    /*TODO: Reinstate this refresh once pages are made on this form.
     * This currently makes the tab switching too slow
     */
    private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
    {
      //refreshOrders();
    }

    private void dataGridView5_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      DataGridViewRow row = this.dataGridView5.Rows[e.RowIndex];
      DialogResult dr = MessageBox.Show("Do you want to credit the product to Smith & Smith?", "Credit?", MessageBoxButtons.YesNoCancel);
      if (dr == DialogResult.Yes)
      {
        FormGeneration form = new FormGeneration(int.Parse(row.Cells["ID"].Value.ToString()));
        form.ShowDialog();

        dr = MessageBox.Show("Sign off as CREDITED?", "Confirm", MessageBoxButtons.YesNo);
        if (dr == DialogResult.Yes)
        {
          String update = String.Format("UPDATE jobPart SET pState = 'CREDITED' WHERE objID = {0};", row.Cells["ID"].Value.ToString());
          using (MySqlConnection conn = connectMySql())
          {
            try
            {
              conn.Open();
              MySqlCommand cmd = new MySqlCommand(update, conn);
              cmd.ExecuteReader();
              conn.Close();
            }
            catch (Exception ex)
            {
              MessageBox.Show("An Error occured setting this product to creditor. Please contact the administrator!\n\nERROR DETAILS:\n\n" + ex.ToString(), "ERROR!"); ;

            }
          }
        }
      }
      else if (dr == DialogResult.No)
      {
        ChangeJobPart form = new ChangeJobPart(int.Parse(row.Cells["ID"].Value.ToString()));
        form.ShowDialog();
      }
      refreshOrders();
    }

    private void dataGridView4_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      if (e.RowIndex >= 0)
      {
        DataGridViewRow row = this.dataGridView4.Rows[e.RowIndex];
        ChangeJobPart form = new ChangeJobPart(int.Parse(row.Cells["OID"].Value.ToString()));
        form.ShowDialog();
        refreshOrders();
      }
    }

    private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    private void autoDataGrid_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      if (e.RowIndex >= 0)
      {
        DataGridViewRow row = this.autoDataGrid.Rows[e.RowIndex];
        ChangeJobPart form = new ChangeJobPart(int.Parse(row.Cells["ID"].Value.ToString()));
        form.ShowDialog();
        refreshOrders();
      }
    }

    private void refreshNotify_Tick(object sender, EventArgs e)
    {
      using (MySqlConnection conn = connectMySql())
      {
        try
        {
          conn.Open();
          string sql = String.Format("SELECT jobPart.objID AS ID, part.pType AS PartType, part.pCode AS PartCode, pAltCode AS AltCode, " +
                 "pNagCode AS NagsCode, pState AS State, date AS DateArrived " +
                 "FROM part INNER JOIN jobPart ON part.pID = jobPart.pID INNER JOIN (SELECT objID, MAX(date) AS maxdate FROM jobPart GROUP BY objID) jP ON jP.objID = jobPart.objID AND " +
                 "date = maxdate " +
                 "WHERE pState = 'ON-CREDIT' OR pState = 'CREDIT' ORDER BY jobPart.date LIMIT 2;");

          MySqlCommand cmd = new MySqlCommand(sql, conn);
          MySqlDataReader rdr = cmd.ExecuteReader();
          while (rdr.Read())
          {
            creditNotify.Visible = true;
            break;
          }

          conn.Close();
          conn.Open();
          sql = String.Format("SELECT jobPart.objID AS ID, part.pType AS PartType, part.pCode AS PartCode, pAltCode AS AltCode, " +
                 "pNagCode AS NagsCode, pState AS State, date AS DateArrived " +
                 "FROM part INNER JOIN jobPart ON part.pID = jobPart.pID INNER JOIN (SELECT objID, MAX(date) AS maxdate FROM jobPart GROUP BY objID) jP ON jP.objID = jobPart.objID AND " +
                 "date = maxdate " +
                 "WHERE pState = 'AUTO-STOCK' ORDER BY jobPart.date LIMIT 2;");

          cmd = new MySqlCommand(sql, conn);
          rdr = cmd.ExecuteReader();
          while (rdr.Read())
          {
            autoNotify.Visible = true;
            break;
          }
        }
        catch (Exception ex)
        {
          DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
        }
      }

    }


    private void dataGridView5_CellClick(object sender, DataGridViewCellEventArgs e)
    {

    }
    /*
        private void notDataGrid_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.notDataGrid.Rows[e.RowIndex];
                Order form = new Order(row.Cells["OrderNo"].Value.ToString(), "NOT");
                form.ShowDialog();
                refreshOrders();
            }
        }
    */
  }
}