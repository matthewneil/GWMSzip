using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using MySql.Data;
using System.Management;
using MySql.Data.MySqlClient;
using System.Diagnostics;
using System.IO;

namespace workshop_orders
{
  static class Program
  {
    /// <summary>
    ///  The main entry point for the application.
    ///  The program loads the login form for the user to enter in their username and password. It checks the details against the 
    ///  SQL database and if the user and password are correct, it will load GWMS, giving it the username and password and GWMS
    ///  can figure out what permissions it should be giving to that user.
    /// </summary>
    [STAThread]
    static void Main()
    {
      String xmlString = File.ReadAllText("GWG.xml");
      StringReader stringReader = new StringReader(xmlString);
      DataSet ds = new DataSet();
      ds.ReadXml(stringReader);

      DataRow dr = ds.Tables[0].Rows[0];

      GWMS.connStr = String.Format("server={0};user={1};database={2};password={3}",
        dr["host"].ToString(), dr["user"].ToString(), dr["name"].ToString(), dr["pass"].ToString());

      Application.EnableVisualStyles();
      Application.SetCompatibleTextRenderingDefault(false);
      FormManagement.mdi = new GWMS();
      Application.Run(FormManagement.mdi);



    }
  }
}
