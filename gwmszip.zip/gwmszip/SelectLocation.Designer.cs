﻿
namespace workshop_orders
{
  partial class SelectLocation
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
      this.dgvLocations = new System.Windows.Forms.DataGridView();
      this.chItemStockID = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chGroup = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chSubGroup = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.toolStrip1 = new System.Windows.Forms.ToolStrip();
      this.tsBack = new System.Windows.Forms.ToolStripButton();
      this.tsSelect = new System.Windows.Forms.ToolStripButton();
      this.label1 = new System.Windows.Forms.Label();
      this.tsNew = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
      ((System.ComponentModel.ISupportInitialize)(this.dgvLocations)).BeginInit();
      this.toolStrip1.SuspendLayout();
      this.SuspendLayout();
      // 
      // dgvLocations
      // 
      this.dgvLocations.AllowUserToAddRows = false;
      this.dgvLocations.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
      dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
      dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
      dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
      dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
      dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
      this.dgvLocations.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
      this.dgvLocations.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvLocations.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.chItemStockID,
            this.chGroup,
            this.chSubGroup,
            this.chCode,
            this.chDescription,
            this.chQuantity});
      dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
      dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
      dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
      dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
      dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
      dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
      this.dgvLocations.DefaultCellStyle = dataGridViewCellStyle4;
      this.dgvLocations.Location = new System.Drawing.Point(12, 67);
      this.dgvLocations.Name = "dgvLocations";
      this.dgvLocations.RowHeadersWidth = 5;
      this.dgvLocations.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
      this.dgvLocations.Size = new System.Drawing.Size(781, 341);
      this.dgvLocations.TabIndex = 0;
      this.dgvLocations.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvLocations_CellDoubleClick);
      // 
      // chItemStockID
      // 
      this.chItemStockID.DataPropertyName = "ItemStockID";
      this.chItemStockID.HeaderText = "itemstockid";
      this.chItemStockID.Name = "chItemStockID";
      this.chItemStockID.ReadOnly = true;
      this.chItemStockID.Visible = false;
      // 
      // chGroup
      // 
      this.chGroup.DataPropertyName = "LocationGroup";
      this.chGroup.HeaderText = "Group";
      this.chGroup.Name = "chGroup";
      this.chGroup.ReadOnly = true;
      this.chGroup.Width = 120;
      // 
      // chSubGroup
      // 
      this.chSubGroup.DataPropertyName = "LocationSubGroup";
      this.chSubGroup.HeaderText = "Sub Group";
      this.chSubGroup.Name = "chSubGroup";
      this.chSubGroup.ReadOnly = true;
      this.chSubGroup.Width = 120;
      // 
      // chCode
      // 
      this.chCode.DataPropertyName = "LocationCode";
      this.chCode.HeaderText = "Code";
      this.chCode.Name = "chCode";
      this.chCode.ReadOnly = true;
      this.chCode.Width = 150;
      // 
      // chDescription
      // 
      this.chDescription.DataPropertyName = "LocationDescription";
      this.chDescription.HeaderText = "Description";
      this.chDescription.Name = "chDescription";
      this.chDescription.ReadOnly = true;
      this.chDescription.Width = 300;
      // 
      // chQuantity
      // 
      this.chQuantity.DataPropertyName = "Quantity";
      this.chQuantity.HeaderText = "Qty.";
      this.chQuantity.Name = "chQuantity";
      this.chQuantity.ReadOnly = true;
      this.chQuantity.Width = 80;
      // 
      // toolStrip1
      // 
      this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsBack,
            this.tsSelect,
            this.toolStripSeparator1,
            this.tsNew});
      this.toolStrip1.Location = new System.Drawing.Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new System.Drawing.Size(803, 39);
      this.toolStrip1.TabIndex = 1;
      this.toolStrip1.Text = "toolStrip1";
      // 
      // tsBack
      // 
      this.tsBack.Image = global::workshop_orders.Properties.Resources.back;
      this.tsBack.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsBack.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsBack.Name = "tsBack";
      this.tsBack.Size = new System.Drawing.Size(68, 36);
      this.tsBack.Text = "Back";
      this.tsBack.Click += new System.EventHandler(this.tsBack_Click);
      // 
      // tsSelect
      // 
      this.tsSelect.Image = global::workshop_orders.Properties.Resources.tick32;
      this.tsSelect.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsSelect.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsSelect.Name = "tsSelect";
      this.tsSelect.Size = new System.Drawing.Size(74, 36);
      this.tsSelect.Text = "Select";
      this.tsSelect.Click += new System.EventHandler(this.tsSelect_Click);
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label1.Location = new System.Drawing.Point(9, 46);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(467, 18);
      this.label1.TabIndex = 2;
      this.label1.Text = "Please select a location where you want to Reserve the item:";
      // 
      // tsNew
      // 
      this.tsNew.Image = global::workshop_orders.Properties.Resources.addnew;
      this.tsNew.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsNew.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsNew.Name = "tsNew";
      this.tsNew.Size = new System.Drawing.Size(138, 36);
      this.tsNew.Text = "Order New Screen";
      this.tsNew.Click += new System.EventHandler(this.tsNew_Click);
      // 
      // toolStripSeparator1
      // 
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
      // 
      // SelectLocation
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.ClientSize = new System.Drawing.Size(803, 424);
      this.Controls.Add(this.label1);
      this.Controls.Add(this.toolStrip1);
      this.Controls.Add(this.dgvLocations);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
      this.Name = "SelectLocation";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
      this.Text = "Select Location";
      ((System.ComponentModel.ISupportInitialize)(this.dgvLocations)).EndInit();
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.DataGridView dgvLocations;
    private System.Windows.Forms.ToolStrip toolStrip1;
    private System.Windows.Forms.ToolStripButton tsBack;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.DataGridViewTextBoxColumn chItemStockID;
    private System.Windows.Forms.DataGridViewTextBoxColumn chGroup;
    private System.Windows.Forms.DataGridViewTextBoxColumn chSubGroup;
    private System.Windows.Forms.DataGridViewTextBoxColumn chCode;
    private System.Windows.Forms.DataGridViewTextBoxColumn chDescription;
    private System.Windows.Forms.DataGridViewTextBoxColumn chQuantity;
    private System.Windows.Forms.ToolStripButton tsSelect;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
    private System.Windows.Forms.ToolStripButton tsNew;
  }
}