﻿
namespace workshop_orders
{
  partial class Onsite
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
      this.dgvJob = new System.Windows.Forms.DataGridView();
      this.chJobID = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chType = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chCustomer = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chVehicle = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chBooking = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.label1 = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this.nudDistance = new System.Windows.Forms.NumericUpDown();
      this.dgvJobAdded = new System.Windows.Forms.DataGridView();
      this.chJobIDAdded = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chTravel = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chDistance = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chNote = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chComplete = new System.Windows.Forms.DataGridViewCheckBoxColumn();
      this.chTypeAdded = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chCustomerAdded = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.label3 = new System.Windows.Forms.Label();
      this.txtSearch = new System.Windows.Forms.TextBox();
      this.nudTravelTime = new System.Windows.Forms.NumericUpDown();
      this.toolStrip1 = new System.Windows.Forms.ToolStrip();
      this.tsBack = new System.Windows.Forms.ToolStripButton();
      this.tsSave = new System.Windows.Forms.ToolStripButton();
      this.tsUser = new System.Windows.Forms.ToolStripLabel();
      this.lblTime = new System.Windows.Forms.Label();
      this.label4 = new System.Windows.Forms.Label();
      this.label5 = new System.Windows.Forms.Label();
      this.nudUnproductiveTime = new System.Windows.Forms.NumericUpDown();
      this.label6 = new System.Windows.Forms.Label();
      this.label7 = new System.Windows.Forms.Label();
      this.label8 = new System.Windows.Forms.Label();
      this.label9 = new System.Windows.Forms.Label();
      this.label10 = new System.Windows.Forms.Label();
      this.label11 = new System.Windows.Forms.Label();
      this.label12 = new System.Windows.Forms.Label();
      this.label13 = new System.Windows.Forms.Label();
      this.label14 = new System.Windows.Forms.Label();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.txtJobTime = new System.Windows.Forms.TextBox();
      this.groupBox3 = new System.Windows.Forms.GroupBox();
      this.txtTimeLeft = new System.Windows.Forms.TextBox();
      this.txtTimeAllocated = new System.Windows.Forms.TextBox();
      this.txtTimeToAllo = new System.Windows.Forms.TextBox();
      this.chkCompleted = new System.Windows.Forms.CheckBox();
      this.panel1 = new System.Windows.Forms.Panel();
      this.label15 = new System.Windows.Forms.Label();
      this.txtUnproductiveNote = new System.Windows.Forms.TextBox();
      this.txtTravelNote = new System.Windows.Forms.TextBox();
      this.groupBox4 = new System.Windows.Forms.GroupBox();
      this.btnRemove = new System.Windows.Forms.Button();
      this.btnAdd = new System.Windows.Forms.Button();
      ((System.ComponentModel.ISupportInitialize)(this.dgvJob)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudDistance)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dgvJobAdded)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudTravelTime)).BeginInit();
      this.toolStrip1.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.nudUnproductiveTime)).BeginInit();
      this.groupBox1.SuspendLayout();
      this.groupBox3.SuspendLayout();
      this.panel1.SuspendLayout();
      this.groupBox4.SuspendLayout();
      this.SuspendLayout();
      // 
      // dgvJob
      // 
      this.dgvJob.AllowUserToAddRows = false;
      this.dgvJob.AllowUserToDeleteRows = false;
      this.dgvJob.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      this.dgvJob.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvJob.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.chJobID,
            this.chType,
            this.chCustomer,
            this.chVehicle,
            this.chBooking,
            this.chStatus});
      this.dgvJob.Location = new System.Drawing.Point(8, 291);
      this.dgvJob.Margin = new System.Windows.Forms.Padding(4);
      this.dgvJob.Name = "dgvJob";
      this.dgvJob.RowHeadersWidth = 5;
      this.dgvJob.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
      this.dgvJob.Size = new System.Drawing.Size(829, 462);
      this.dgvJob.TabIndex = 1;
      this.dgvJob.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvJob_CellDoubleClick);
      // 
      // chJobID
      // 
      this.chJobID.DataPropertyName = "JobID";
      this.chJobID.HeaderText = "Job";
      this.chJobID.Name = "chJobID";
      this.chJobID.ReadOnly = true;
      this.chJobID.Width = 75;
      // 
      // chType
      // 
      this.chType.DataPropertyName = "TypeName";
      this.chType.HeaderText = "Type";
      this.chType.Name = "chType";
      this.chType.ReadOnly = true;
      // 
      // chCustomer
      // 
      this.chCustomer.DataPropertyName = "CustomerName";
      this.chCustomer.HeaderText = "Customer";
      this.chCustomer.Name = "chCustomer";
      this.chCustomer.ReadOnly = true;
      this.chCustomer.Width = 200;
      // 
      // chVehicle
      // 
      this.chVehicle.DataPropertyName = "Vehicle";
      this.chVehicle.HeaderText = "Vehicle";
      this.chVehicle.Name = "chVehicle";
      this.chVehicle.ReadOnly = true;
      this.chVehicle.Width = 170;
      // 
      // chBooking
      // 
      this.chBooking.DataPropertyName = "JobBookingDateBlank";
      dataGridViewCellStyle2.Format = "g";
      dataGridViewCellStyle2.NullValue = null;
      this.chBooking.DefaultCellStyle = dataGridViewCellStyle2;
      this.chBooking.HeaderText = "Booking";
      this.chBooking.Name = "chBooking";
      this.chBooking.ReadOnly = true;
      this.chBooking.Width = 150;
      // 
      // chStatus
      // 
      this.chStatus.DataPropertyName = "StatusName";
      this.chStatus.HeaderText = "Status";
      this.chStatus.Name = "chStatus";
      this.chStatus.ReadOnly = true;
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(64, 31);
      this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(93, 20);
      this.label1.TabIndex = 2;
      this.label1.Text = "Travel Time:";
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Location = new System.Drawing.Point(81, 70);
      this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(76, 20);
      this.label2.TabIndex = 3;
      this.label2.Text = "Distance:";
      // 
      // nudDistance
      // 
      this.nudDistance.Location = new System.Drawing.Point(165, 68);
      this.nudDistance.Margin = new System.Windows.Forms.Padding(4);
      this.nudDistance.Name = "nudDistance";
      this.nudDistance.Size = new System.Drawing.Size(75, 26);
      this.nudDistance.TabIndex = 4;
      // 
      // dgvJobAdded
      // 
      this.dgvJobAdded.AllowUserToAddRows = false;
      this.dgvJobAdded.AllowUserToDeleteRows = false;
      this.dgvJobAdded.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      this.dgvJobAdded.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvJobAdded.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.chJobIDAdded,
            this.chTime,
            this.chTravel,
            this.chDistance,
            this.chNote,
            this.chComplete,
            this.chTypeAdded,
            this.chCustomerAdded});
      this.dgvJobAdded.Location = new System.Drawing.Point(915, 291);
      this.dgvJobAdded.Margin = new System.Windows.Forms.Padding(4);
      this.dgvJobAdded.Name = "dgvJobAdded";
      this.dgvJobAdded.RowHeadersWidth = 5;
      this.dgvJobAdded.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
      this.dgvJobAdded.Size = new System.Drawing.Size(836, 462);
      this.dgvJobAdded.TabIndex = 7;
      this.dgvJobAdded.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvJobAdded_CellDoubleClick);
      // 
      // chJobIDAdded
      // 
      this.chJobIDAdded.HeaderText = "Job";
      this.chJobIDAdded.Name = "chJobIDAdded";
      this.chJobIDAdded.ReadOnly = true;
      // 
      // chTime
      // 
      this.chTime.HeaderText = "Job Time";
      this.chTime.Name = "chTime";
      this.chTime.ReadOnly = true;
      // 
      // chTravel
      // 
      this.chTravel.HeaderText = "Travel";
      this.chTravel.Name = "chTravel";
      this.chTravel.ReadOnly = true;
      // 
      // chDistance
      // 
      this.chDistance.HeaderText = "Distance";
      this.chDistance.Name = "chDistance";
      this.chDistance.ReadOnly = true;
      // 
      // chNote
      // 
      this.chNote.HeaderText = "Note";
      this.chNote.Name = "chNote";
      this.chNote.ReadOnly = true;
      this.chNote.Width = 200;
      // 
      // chComplete
      // 
      this.chComplete.HeaderText = "Com";
      this.chComplete.Name = "chComplete";
      this.chComplete.ReadOnly = true;
      this.chComplete.Width = 50;
      // 
      // chTypeAdded
      // 
      this.chTypeAdded.HeaderText = "Type";
      this.chTypeAdded.Name = "chTypeAdded";
      this.chTypeAdded.ReadOnly = true;
      // 
      // chCustomerAdded
      // 
      this.chCustomerAdded.HeaderText = "Customer";
      this.chCustomerAdded.Name = "chCustomerAdded";
      this.chCustomerAdded.ReadOnly = true;
      this.chCustomerAdded.Width = 300;
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Location = new System.Drawing.Point(18, 37);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(90, 20);
      this.label3.TabIndex = 8;
      this.label3.Text = "Search Job";
      // 
      // txtSearch
      // 
      this.txtSearch.Location = new System.Drawing.Point(121, 37);
      this.txtSearch.Name = "txtSearch";
      this.txtSearch.Size = new System.Drawing.Size(443, 26);
      this.txtSearch.TabIndex = 9;
      this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
      // 
      // nudTravelTime
      // 
      this.nudTravelTime.Location = new System.Drawing.Point(165, 29);
      this.nudTravelTime.Margin = new System.Windows.Forms.Padding(4);
      this.nudTravelTime.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
      this.nudTravelTime.Name = "nudTravelTime";
      this.nudTravelTime.Size = new System.Drawing.Size(75, 26);
      this.nudTravelTime.TabIndex = 12;
      this.nudTravelTime.ValueChanged += new System.EventHandler(this.nudTravelTime_ValueChanged);
      // 
      // toolStrip1
      // 
      this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsBack,
            this.tsSave,
            this.tsUser});
      this.toolStrip1.Location = new System.Drawing.Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new System.Drawing.Size(1766, 39);
      this.toolStrip1.TabIndex = 13;
      this.toolStrip1.Text = "toolStrip1";
      // 
      // tsBack
      // 
      this.tsBack.Image = global::workshop_orders.Properties.Resources.back;
      this.tsBack.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsBack.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsBack.Name = "tsBack";
      this.tsBack.Size = new System.Drawing.Size(68, 36);
      this.tsBack.Text = "Back";
      this.tsBack.Click += new System.EventHandler(this.tsBack_Click);
      // 
      // tsSave
      // 
      this.tsSave.Image = global::workshop_orders.Properties.Resources.save;
      this.tsSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsSave.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsSave.Name = "tsSave";
      this.tsSave.Size = new System.Drawing.Size(67, 36);
      this.tsSave.Text = "Save";
      this.tsSave.Click += new System.EventHandler(this.tsSave_Click);
      // 
      // tsUser
      // 
      this.tsUser.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
      this.tsUser.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.tsUser.Name = "tsUser";
      this.tsUser.Size = new System.Drawing.Size(66, 36);
      this.tsUser.Text = "No User";
      // 
      // lblTime
      // 
      this.lblTime.AutoSize = true;
      this.lblTime.Location = new System.Drawing.Point(48, 34);
      this.lblTime.Name = "lblTime";
      this.lblTime.Size = new System.Drawing.Size(130, 20);
      this.lblTime.TabIndex = 14;
      this.lblTime.Text = "Time to Allocate: ";
      // 
      // label4
      // 
      this.label4.AutoSize = true;
      this.label4.Location = new System.Drawing.Point(58, 73);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(117, 20);
      this.label4.TabIndex = 15;
      this.label4.Text = "Time Allocated:";
      // 
      // label5
      // 
      this.label5.AutoSize = true;
      this.label5.Location = new System.Drawing.Point(343, 77);
      this.label5.Name = "label5";
      this.label5.Size = new System.Drawing.Size(88, 20);
      this.label5.TabIndex = 16;
      this.label5.Text = "Extra Time:";
      // 
      // nudUnproductiveTime
      // 
      this.nudUnproductiveTime.Location = new System.Drawing.Point(347, 106);
      this.nudUnproductiveTime.Margin = new System.Windows.Forms.Padding(4);
      this.nudUnproductiveTime.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
      this.nudUnproductiveTime.Name = "nudUnproductiveTime";
      this.nudUnproductiveTime.Size = new System.Drawing.Size(76, 26);
      this.nudUnproductiveTime.TabIndex = 17;
      this.nudUnproductiveTime.ValueChanged += new System.EventHandler(this.nudUnproductive_ValueChanged);
      // 
      // label6
      // 
      this.label6.AutoSize = true;
      this.label6.Location = new System.Drawing.Point(17, 112);
      this.label6.Name = "label6";
      this.label6.Size = new System.Drawing.Size(158, 20);
      this.label6.TabIndex = 18;
      this.label6.Text = "Time Left to Allocate:";
      // 
      // label7
      // 
      this.label7.AutoSize = true;
      this.label7.Location = new System.Drawing.Point(82, 112);
      this.label7.Name = "label7";
      this.label7.Size = new System.Drawing.Size(77, 20);
      this.label7.TabIndex = 22;
      this.label7.Text = "Job Time:";
      // 
      // label8
      // 
      this.label8.AutoSize = true;
      this.label8.Location = new System.Drawing.Point(248, 32);
      this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label8.Name = "label8";
      this.label8.Size = new System.Drawing.Size(34, 20);
      this.label8.TabIndex = 24;
      this.label8.Text = "min";
      // 
      // label9
      // 
      this.label9.AutoSize = true;
      this.label9.Location = new System.Drawing.Point(251, 112);
      this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label9.Name = "label9";
      this.label9.Size = new System.Drawing.Size(34, 20);
      this.label9.TabIndex = 25;
      this.label9.Text = "min";
      // 
      // label10
      // 
      this.label10.AutoSize = true;
      this.label10.Location = new System.Drawing.Point(440, 109);
      this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label10.Name = "label10";
      this.label10.Size = new System.Drawing.Size(34, 20);
      this.label10.TabIndex = 26;
      this.label10.Text = "min";
      // 
      // label11
      // 
      this.label11.AutoSize = true;
      this.label11.Location = new System.Drawing.Point(255, 35);
      this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label11.Name = "label11";
      this.label11.Size = new System.Drawing.Size(34, 20);
      this.label11.TabIndex = 27;
      this.label11.Text = "min";
      // 
      // label12
      // 
      this.label12.AutoSize = true;
      this.label12.Location = new System.Drawing.Point(255, 115);
      this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label12.Name = "label12";
      this.label12.Size = new System.Drawing.Size(34, 20);
      this.label12.TabIndex = 28;
      this.label12.Text = "min";
      // 
      // label13
      // 
      this.label13.AutoSize = true;
      this.label13.Location = new System.Drawing.Point(255, 74);
      this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label13.Name = "label13";
      this.label13.Size = new System.Drawing.Size(34, 20);
      this.label13.TabIndex = 29;
      this.label13.Text = "min";
      // 
      // label14
      // 
      this.label14.AutoSize = true;
      this.label14.Location = new System.Drawing.Point(252, 70);
      this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label14.Name = "label14";
      this.label14.Size = new System.Drawing.Size(30, 20);
      this.label14.TabIndex = 30;
      this.label14.Text = "km";
      // 
      // groupBox1
      // 
      this.groupBox1.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.groupBox1.Controls.Add(this.nudDistance);
      this.groupBox1.Controls.Add(this.txtJobTime);
      this.groupBox1.Controls.Add(this.label2);
      this.groupBox1.Controls.Add(this.label1);
      this.groupBox1.Controls.Add(this.label14);
      this.groupBox1.Controls.Add(this.label9);
      this.groupBox1.Controls.Add(this.nudTravelTime);
      this.groupBox1.Controls.Add(this.label8);
      this.groupBox1.Controls.Add(this.label7);
      this.groupBox1.Location = new System.Drawing.Point(10, 3);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(294, 146);
      this.groupBox1.TabIndex = 31;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Time Breakdown";
      // 
      // txtJobTime
      // 
      this.txtJobTime.Location = new System.Drawing.Point(165, 109);
      this.txtJobTime.Name = "txtJobTime";
      this.txtJobTime.ReadOnly = true;
      this.txtJobTime.Size = new System.Drawing.Size(76, 26);
      this.txtJobTime.TabIndex = 31;
      this.txtJobTime.Text = "0";
      this.txtJobTime.TextChanged += new System.EventHandler(this.txtJobTime_TextChanged);
      // 
      // groupBox3
      // 
      this.groupBox3.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.groupBox3.Controls.Add(this.label5);
      this.groupBox3.Controls.Add(this.txtTimeLeft);
      this.groupBox3.Controls.Add(this.label10);
      this.groupBox3.Controls.Add(this.txtTimeAllocated);
      this.groupBox3.Controls.Add(this.txtTimeToAllo);
      this.groupBox3.Controls.Add(this.nudUnproductiveTime);
      this.groupBox3.Controls.Add(this.lblTime);
      this.groupBox3.Controls.Add(this.label4);
      this.groupBox3.Controls.Add(this.label6);
      this.groupBox3.Controls.Add(this.label13);
      this.groupBox3.Controls.Add(this.label12);
      this.groupBox3.Controls.Add(this.label11);
      this.groupBox3.Location = new System.Drawing.Point(310, 3);
      this.groupBox3.Name = "groupBox3";
      this.groupBox3.Size = new System.Drawing.Size(605, 146);
      this.groupBox3.TabIndex = 33;
      this.groupBox3.TabStop = false;
      this.groupBox3.Text = "Time Allocation";
      this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
      // 
      // txtTimeLeft
      // 
      this.txtTimeLeft.Location = new System.Drawing.Point(178, 109);
      this.txtTimeLeft.Name = "txtTimeLeft";
      this.txtTimeLeft.ReadOnly = true;
      this.txtTimeLeft.Size = new System.Drawing.Size(70, 26);
      this.txtTimeLeft.TabIndex = 30;
      this.txtTimeLeft.Text = "0";
      // 
      // txtTimeAllocated
      // 
      this.txtTimeAllocated.Location = new System.Drawing.Point(178, 71);
      this.txtTimeAllocated.Name = "txtTimeAllocated";
      this.txtTimeAllocated.ReadOnly = true;
      this.txtTimeAllocated.Size = new System.Drawing.Size(70, 26);
      this.txtTimeAllocated.TabIndex = 0;
      this.txtTimeAllocated.Text = "0";
      this.txtTimeAllocated.TextChanged += new System.EventHandler(this.txtTimeAllocated_TextChanged);
      // 
      // txtTimeToAllo
      // 
      this.txtTimeToAllo.Location = new System.Drawing.Point(178, 33);
      this.txtTimeToAllo.Name = "txtTimeToAllo";
      this.txtTimeToAllo.ReadOnly = true;
      this.txtTimeToAllo.Size = new System.Drawing.Size(70, 26);
      this.txtTimeToAllo.TabIndex = 0;
      this.txtTimeToAllo.Text = "0";
      // 
      // chkCompleted
      // 
      this.chkCompleted.AutoSize = true;
      this.chkCompleted.Location = new System.Drawing.Point(582, 39);
      this.chkCompleted.Name = "chkCompleted";
      this.chkCompleted.Size = new System.Drawing.Size(149, 24);
      this.chkCompleted.TabIndex = 34;
      this.chkCompleted.Text = "Show Completed";
      this.chkCompleted.UseVisualStyleBackColor = true;
      this.chkCompleted.CheckedChanged += new System.EventHandler(this.chkCompleted_CheckedChanged);
      // 
      // panel1
      // 
      this.panel1.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.panel1.Controls.Add(this.label15);
      this.panel1.Controls.Add(this.txtUnproductiveNote);
      this.panel1.Controls.Add(this.groupBox1);
      this.panel1.Controls.Add(this.txtTravelNote);
      this.panel1.Controls.Add(this.groupBox3);
      this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
      this.panel1.Location = new System.Drawing.Point(0, 39);
      this.panel1.Name = "panel1";
      this.panel1.Size = new System.Drawing.Size(1766, 158);
      this.panel1.TabIndex = 35;
      // 
      // label15
      // 
      this.label15.AutoSize = true;
      this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label15.Location = new System.Drawing.Point(1391, 24);
      this.label15.Name = "label15";
      this.label15.Size = new System.Drawing.Size(49, 16);
      this.label15.TabIndex = 29;
      this.label15.Text = "Notes";
      // 
      // txtUnproductiveNote
      // 
      this.txtUnproductiveNote.Location = new System.Drawing.Point(1394, 80);
      this.txtUnproductiveNote.MaxLength = 1000;
      this.txtUnproductiveNote.Name = "txtUnproductiveNote";
      this.txtUnproductiveNote.Size = new System.Drawing.Size(357, 26);
      this.txtUnproductiveNote.TabIndex = 28;
      // 
      // txtTravelNote
      // 
      this.txtTravelNote.Location = new System.Drawing.Point(1394, 43);
      this.txtTravelNote.MaxLength = 1000;
      this.txtTravelNote.Name = "txtTravelNote";
      this.txtTravelNote.Size = new System.Drawing.Size(357, 26);
      this.txtTravelNote.TabIndex = 27;
      // 
      // groupBox4
      // 
      this.groupBox4.Controls.Add(this.label3);
      this.groupBox4.Controls.Add(this.txtSearch);
      this.groupBox4.Controls.Add(this.chkCompleted);
      this.groupBox4.Location = new System.Drawing.Point(10, 203);
      this.groupBox4.Name = "groupBox4";
      this.groupBox4.Size = new System.Drawing.Size(827, 79);
      this.groupBox4.TabIndex = 36;
      this.groupBox4.TabStop = false;
      this.groupBox4.Text = "Search";
      // 
      // btnRemove
      // 
      this.btnRemove.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnRemove.Image = global::workshop_orders.Properties.Resources.arrow_back32;
      this.btnRemove.Location = new System.Drawing.Point(844, 357);
      this.btnRemove.Name = "btnRemove";
      this.btnRemove.Size = new System.Drawing.Size(64, 60);
      this.btnRemove.TabIndex = 11;
      this.btnRemove.UseVisualStyleBackColor = false;
      this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
      // 
      // btnAdd
      // 
      this.btnAdd.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnAdd.Image = global::workshop_orders.Properties.Resources.arrow_next32;
      this.btnAdd.Location = new System.Drawing.Point(844, 291);
      this.btnAdd.Name = "btnAdd";
      this.btnAdd.Size = new System.Drawing.Size(64, 60);
      this.btnAdd.TabIndex = 10;
      this.btnAdd.UseVisualStyleBackColor = false;
      this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
      // 
      // Onsite
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.ClientSize = new System.Drawing.Size(1766, 793);
      this.Controls.Add(this.groupBox4);
      this.Controls.Add(this.panel1);
      this.Controls.Add(this.toolStrip1);
      this.Controls.Add(this.btnRemove);
      this.Controls.Add(this.btnAdd);
      this.Controls.Add(this.dgvJobAdded);
      this.Controls.Add(this.dgvJob);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.Margin = new System.Windows.Forms.Padding(4);
      this.Name = "Onsite";
      this.Text = "Onsite";
      ((System.ComponentModel.ISupportInitialize)(this.dgvJob)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudDistance)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dgvJobAdded)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudTravelTime)).EndInit();
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.nudUnproductiveTime)).EndInit();
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.groupBox3.ResumeLayout(false);
      this.groupBox3.PerformLayout();
      this.panel1.ResumeLayout(false);
      this.panel1.PerformLayout();
      this.groupBox4.ResumeLayout(false);
      this.groupBox4.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion
    private System.Windows.Forms.DataGridView dgvJob;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.NumericUpDown nudDistance;
    private System.Windows.Forms.DataGridView dgvJobAdded;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.TextBox txtSearch;
    private System.Windows.Forms.Button btnAdd;
    private System.Windows.Forms.Button btnRemove;
    private System.Windows.Forms.NumericUpDown nudTravelTime;
    private System.Windows.Forms.ToolStrip toolStrip1;
    private System.Windows.Forms.ToolStripButton tsBack;
    private System.Windows.Forms.ToolStripButton tsSave;
    private System.Windows.Forms.Label lblTime;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.Label label5;
    private System.Windows.Forms.NumericUpDown nudUnproductiveTime;
    private System.Windows.Forms.Label label6;
    private System.Windows.Forms.Label label7;
    private System.Windows.Forms.Label label8;
    private System.Windows.Forms.Label label9;
    private System.Windows.Forms.Label label10;
    private System.Windows.Forms.Label label11;
    private System.Windows.Forms.Label label12;
    private System.Windows.Forms.Label label13;
    private System.Windows.Forms.Label label14;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.GroupBox groupBox3;
    private System.Windows.Forms.ToolStripLabel tsUser;
    private System.Windows.Forms.DataGridViewTextBoxColumn chJobID;
    private System.Windows.Forms.DataGridViewTextBoxColumn chType;
    private System.Windows.Forms.DataGridViewTextBoxColumn chCustomer;
    private System.Windows.Forms.DataGridViewTextBoxColumn chVehicle;
    private System.Windows.Forms.DataGridViewTextBoxColumn chBooking;
    private System.Windows.Forms.DataGridViewTextBoxColumn chStatus;
    private System.Windows.Forms.CheckBox chkCompleted;
    private System.Windows.Forms.Panel panel1;
    private System.Windows.Forms.GroupBox groupBox4;
    private System.Windows.Forms.Label label15;
    private System.Windows.Forms.TextBox txtUnproductiveNote;
    private System.Windows.Forms.TextBox txtTravelNote;
    private System.Windows.Forms.TextBox txtJobTime;
    private System.Windows.Forms.TextBox txtTimeToAllo;
    private System.Windows.Forms.TextBox txtTimeAllocated;
    private System.Windows.Forms.TextBox txtTimeLeft;
    private System.Windows.Forms.DataGridViewTextBoxColumn chJobIDAdded;
    private System.Windows.Forms.DataGridViewTextBoxColumn chTime;
    private System.Windows.Forms.DataGridViewTextBoxColumn chTravel;
    private System.Windows.Forms.DataGridViewTextBoxColumn chDistance;
    private System.Windows.Forms.DataGridViewTextBoxColumn chNote;
    private System.Windows.Forms.DataGridViewCheckBoxColumn chComplete;
    private System.Windows.Forms.DataGridViewTextBoxColumn chTypeAdded;
    private System.Windows.Forms.DataGridViewTextBoxColumn chCustomerAdded;
  }
}