﻿
namespace workshop_orders
{
  partial class BasicQuote
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.toolStrip1 = new System.Windows.Forms.ToolStrip();
      this.tsBack = new System.Windows.Forms.ToolStripButton();
      this.tsSave = new System.Windows.Forms.ToolStripButton();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.txtDescription = new System.Windows.Forms.TextBox();
      this.lblQuotePrice = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this.lblCostPrice = new System.Windows.Forms.Label();
      this.nudCost = new System.Windows.Forms.NumericUpDown();
      this.nudQuote = new System.Windows.Forms.NumericUpDown();
      this.tsItem = new System.Windows.Forms.ToolStripButton();
      this.toolStrip1.SuspendLayout();
      this.groupBox1.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.nudCost)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudQuote)).BeginInit();
      this.SuspendLayout();
      // 
      // toolStrip1
      // 
      this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsBack,
            this.tsSave,
            this.tsItem});
      this.toolStrip1.Location = new System.Drawing.Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new System.Drawing.Size(627, 39);
      this.toolStrip1.TabIndex = 0;
      this.toolStrip1.Text = "toolStrip1";
      this.toolStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.toolStrip1_ItemClicked);
      // 
      // tsBack
      // 
      this.tsBack.Image = global::workshop_orders.Properties.Resources.back;
      this.tsBack.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsBack.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsBack.Name = "tsBack";
      this.tsBack.Size = new System.Drawing.Size(68, 36);
      this.tsBack.Text = "Back";
      this.tsBack.Click += new System.EventHandler(this.tsBack_Click);
      // 
      // tsSave
      // 
      this.tsSave.Image = global::workshop_orders.Properties.Resources.save;
      this.tsSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsSave.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsSave.Name = "tsSave";
      this.tsSave.Size = new System.Drawing.Size(67, 36);
      this.tsSave.Text = "Save";
      this.tsSave.Click += new System.EventHandler(this.tsSave_Click);
      // 
      // groupBox1
      // 
      this.groupBox1.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.groupBox1.Controls.Add(this.nudQuote);
      this.groupBox1.Controls.Add(this.nudCost);
      this.groupBox1.Controls.Add(this.lblCostPrice);
      this.groupBox1.Controls.Add(this.label2);
      this.groupBox1.Controls.Add(this.lblQuotePrice);
      this.groupBox1.Controls.Add(this.txtDescription);
      this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.groupBox1.Location = new System.Drawing.Point(0, 39);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(627, 301);
      this.groupBox1.TabIndex = 1;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Quote Item Details";
      // 
      // txtDescription
      // 
      this.txtDescription.AcceptsReturn = true;
      this.txtDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtDescription.Location = new System.Drawing.Point(117, 23);
      this.txtDescription.Multiline = true;
      this.txtDescription.Name = "txtDescription";
      this.txtDescription.Size = new System.Drawing.Size(502, 180);
      this.txtDescription.TabIndex = 0;
      // 
      // lblQuotePrice
      // 
      this.lblQuotePrice.AutoSize = true;
      this.lblQuotePrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblQuotePrice.Location = new System.Drawing.Point(13, 261);
      this.lblQuotePrice.Name = "lblQuotePrice";
      this.lblQuotePrice.Size = new System.Drawing.Size(96, 20);
      this.lblQuotePrice.TabIndex = 1;
      this.lblQuotePrice.Text = "Quote Price:";
      this.lblQuotePrice.Click += new System.EventHandler(this.lblQuotePrice_Click);
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label2.Location = new System.Drawing.Point(12, 26);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(93, 20);
      this.label2.TabIndex = 2;
      this.label2.Text = "Description:";
      // 
      // lblCostPrice
      // 
      this.lblCostPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblCostPrice.Location = new System.Drawing.Point(5, 228);
      this.lblCostPrice.Name = "lblCostPrice";
      this.lblCostPrice.Size = new System.Drawing.Size(104, 18);
      this.lblCostPrice.TabIndex = 3;
      this.lblCostPrice.Text = "Cost Price:";
      this.lblCostPrice.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      this.lblCostPrice.Click += new System.EventHandler(this.lblCostPrice_Click);
      // 
      // nudCost
      // 
      this.nudCost.DecimalPlaces = 2;
      this.nudCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.nudCost.Location = new System.Drawing.Point(117, 224);
      this.nudCost.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
      this.nudCost.Name = "nudCost";
      this.nudCost.Size = new System.Drawing.Size(120, 24);
      this.nudCost.TabIndex = 4;
      this.nudCost.ValueChanged += new System.EventHandler(this.nudCost_ValueChanged);
      // 
      // nudQuote
      // 
      this.nudQuote.DecimalPlaces = 2;
      this.nudQuote.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.nudQuote.Location = new System.Drawing.Point(117, 257);
      this.nudQuote.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
      this.nudQuote.Name = "nudQuote";
      this.nudQuote.Size = new System.Drawing.Size(120, 24);
      this.nudQuote.TabIndex = 5;
      // 
      // tsItem
      // 
      this.tsItem.Image = global::workshop_orders.Properties.Resources.detail32;
      this.tsItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsItem.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsItem.Name = "tsItem";
      this.tsItem.Size = new System.Drawing.Size(93, 36);
      this.tsItem.Text = "Find Item";
      this.tsItem.Click += new System.EventHandler(this.tsItem_Click);
      // 
      // BasicQuote
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(627, 340);
      this.Controls.Add(this.groupBox1);
      this.Controls.Add(this.toolStrip1);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
      this.Name = "BasicQuote";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
      this.Text = "Basic Quote - Edit";
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.nudCost)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudQuote)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.ToolStrip toolStrip1;
    private System.Windows.Forms.ToolStripButton tsBack;
    private System.Windows.Forms.ToolStripButton tsSave;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.Label lblQuotePrice;
    private System.Windows.Forms.TextBox txtDescription;
    private System.Windows.Forms.Label lblCostPrice;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.NumericUpDown nudQuote;
    private System.Windows.Forms.NumericUpDown nudCost;
    private System.Windows.Forms.ToolStripButton tsItem;
  }
}