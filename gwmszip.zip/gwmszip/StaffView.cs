﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workshop_orders
{
  public partial class StaffView : Form
  {

    public StaffView()
    {
      InitializeComponent();

      LoadData();
    }

    private string IsDev()
    {
      if (GWMS.Dev != 1) return "AND StaffID != 0 AND StaffID != 15"; //StaffID 0 is Admin, StaffID 15 is Workshop, these should not edited. Unless if you are labelled as DEV
      return "";
    }

    private void LoadData()
    {
      String filter = "";
      switch (cmbStatus.Text)
      {
        case "Admin":
          filter = "AND StaffAdmin = 1 AND StaffActive = 1 ";
          break;

        case "Regular User":
          filter = "AND StaffAdmin = 0 AND StaffActive = 1 ";
          break;

        case "Active":
          filter = "AND StaffActive = 1 ";
          break;

        case "Inactive":
          filter = "AND StaffActive = 0 ";
          break;

        case "Workshop":
          filter = "AND StaffWorkshop = 1 AND StaffActive = 1 ";
          break;
      }
      try
      {

        DataTable dt = DataAccess.ExecuteDataTable(
          "SELECT StaffID, StaffFullName, StaffUsername, StaffAdmin, StaffWorkshop, StaffEmail " +
          "FROM staff " +
          "WHERE 1=1 " + 
          IsDev() + " " + 
          filter +
          "ORDER BY StaffFullName;");


        dgvStaff.DataSource = dt;

        foreach (DataGridViewRow row in dgvStaff.Rows)
        {
          try
          {
            if (row.Cells[3].Value.ToString() == "1") //Admin
            {
              row.Cells[3].Style.BackColor = Color.CornflowerBlue;
            }
            if (row.Cells[4].Value.ToString() == "1") //Workshop
            {
              row.Cells[4].Style.BackColor = Color.Orange;
            }
          }
          catch (Exception ex)
          {
            DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
              System.Reflection.MethodBase.GetCurrentMethod().Name, "");
          }
        }
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
          System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }
    }

    private void cmbStatus_SelectedIndexChanged(object sender, EventArgs e)
    {
      LoadData();
    }


    private void tbClose_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private void dgvItems_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      EditUser();
    }

    private void EditUser()
    {
      if (dgvStaff.SelectedRows.Count > 0 && dgvStaff.SelectedRows[0].Index > -1)
      {
        StaffEdit frm = new StaffEdit((int)dgvStaff.SelectedRows[0].Cells[0].Value);
        FormManagement.ShowDialogForm(frm);
        LoadData();
      }
    }

    private void tsNew_Click(object sender, EventArgs e)
    {
      StaffEdit frm = new StaffEdit(0);
      FormManagement.ShowDialogForm(frm);
      LoadData();
    }

    private void tsRefresh_Click(object sender, EventArgs e)
    {
      LoadData();
    }

    private void tsEdit_Click(object sender, EventArgs e)
    {
      EditUser();
    }

  }
}
