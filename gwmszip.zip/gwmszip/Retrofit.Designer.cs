﻿
namespace workshop_orders
{
	partial class Retrofit
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.components = new System.ComponentModel.Container();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Retrofit));
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
      this.dgvData = new System.Windows.Forms.DataGridView();
      this.cmbGlassType = new System.Windows.Forms.ComboBox();
      this.cmbGlassCode = new System.Windows.Forms.ComboBox();
      this.cmbOption = new System.Windows.Forms.ComboBox();
      this.label1 = new System.Windows.Forms.Label();
      this.label3 = new System.Windows.Forms.Label();
      this.lblOption = new System.Windows.Forms.Label();
      this.nudThickness = new System.Windows.Forms.NumericUpDown();
      this.label2 = new System.Windows.Forms.Label();
      this.btnFixed = new System.Windows.Forms.Button();
      this.btnSash = new System.Windows.Forms.Button();
      this.cmbCostItem = new System.Windows.Forms.ComboBox();
      this.cmbType = new System.Windows.Forms.ComboBox();
      this.dgvComponent = new System.Windows.Forms.DataGridView();
      this.gbComponents = new System.Windows.Forms.GroupBox();
      this.label4 = new System.Windows.Forms.Label();
      this.label5 = new System.Windows.Forms.Label();
      this.nudWidth = new System.Windows.Forms.NumericUpDown();
      this.label6 = new System.Windows.Forms.Label();
      this.nudHeight = new System.Windows.Forms.NumericUpDown();
      this.btnAdd = new System.Windows.Forms.Button();
      this.btnEdit = new System.Windows.Forms.Button();
      this.btnComponents = new System.Windows.Forms.Button();
      this.gbGlassDetails = new System.Windows.Forms.GroupBox();
      this.lblM2 = new System.Windows.Forms.Label();
      this.label9 = new System.Windows.Forms.Label();
      this.label8 = new System.Windows.Forms.Label();
      this.label7 = new System.Windows.Forms.Label();
      this.nudLength = new System.Windows.Forms.NumericUpDown();
      this.lvData = new System.Windows.Forms.ListView();
      this.iglProduct = new System.Windows.Forms.ImageList(this.components);
      this.toolStrip1 = new System.Windows.Forms.ToolStrip();
      this.tbBack = new System.Windows.Forms.ToolStripButton();
      this.tbSave = new System.Windows.Forms.ToolStripButton();
      this.tbDelete = new System.Windows.Forms.ToolStripButton();
      this.tslName = new System.Windows.Forms.ToolStripLabel();
      this.btnClear = new System.Windows.Forms.Button();
      this.btnDelete = new System.Windows.Forms.Button();
      this.label10 = new System.Windows.Forms.Label();
      this.label11 = new System.Windows.Forms.Label();
      this.label12 = new System.Windows.Forms.Label();
      this.label13 = new System.Windows.Forms.Label();
      this.label14 = new System.Windows.Forms.Label();
      this.lblGlassCost = new System.Windows.Forms.Label();
      this.lblBeadCost = new System.Windows.Forms.Label();
      this.lblSashCost = new System.Windows.Forms.Label();
      this.lblComponentCost = new System.Windows.Forms.Label();
      this.lblTotalCost = new System.Windows.Forms.Label();
      this.label20 = new System.Windows.Forms.Label();
      this.lblTravel = new System.Windows.Forms.Label();
      this.label16 = new System.Windows.Forms.Label();
      this.lblTravelPrice = new System.Windows.Forms.Label();
      this.lblTotalPrice = new System.Windows.Forms.Label();
      this.lblCompPrice = new System.Windows.Forms.Label();
      this.lblSashPrice = new System.Windows.Forms.Label();
      this.lblBeadPrice = new System.Windows.Forms.Label();
      this.lblGlassPrice = new System.Windows.Forms.Label();
      this.label23 = new System.Windows.Forms.Label();
      this.chID = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chItem = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.ItemGroupID = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.ItemCostID = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.RowID = new System.Windows.Forms.DataGridViewTextBoxColumn();
      ((System.ComponentModel.ISupportInitialize)(this.dgvData)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudThickness)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dgvComponent)).BeginInit();
      this.gbComponents.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.nudWidth)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudHeight)).BeginInit();
      this.gbGlassDetails.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.nudLength)).BeginInit();
      this.toolStrip1.SuspendLayout();
      this.SuspendLayout();
      // 
      // dgvData
      // 
      this.dgvData.AllowUserToResizeColumns = false;
      this.dgvData.AllowUserToResizeRows = false;
      this.dgvData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvData.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
      this.dgvData.Location = new System.Drawing.Point(10, 613);
      this.dgvData.Margin = new System.Windows.Forms.Padding(4);
      this.dgvData.MultiSelect = false;
      this.dgvData.Name = "dgvData";
      this.dgvData.Size = new System.Drawing.Size(1005, 189);
      this.dgvData.TabIndex = 1;
      this.dgvData.Visible = false;
      // 
      // cmbGlassType
      // 
      this.cmbGlassType.DisplayMember = "textfield";
      this.cmbGlassType.DropDownHeight = 250;
      this.cmbGlassType.DropDownWidth = 300;
      this.cmbGlassType.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbGlassType.FormattingEnabled = true;
      this.cmbGlassType.IntegralHeight = false;
      this.cmbGlassType.Location = new System.Drawing.Point(165, 90);
      this.cmbGlassType.Margin = new System.Windows.Forms.Padding(4);
      this.cmbGlassType.Name = "cmbGlassType";
      this.cmbGlassType.Size = new System.Drawing.Size(280, 26);
      this.cmbGlassType.TabIndex = 13;
      this.cmbGlassType.ValueMember = "datafield";
      this.cmbGlassType.SelectedIndexChanged += new System.EventHandler(this.cmbGlassType_SelectedIndexChanged);
      // 
      // cmbGlassCode
      // 
      this.cmbGlassCode.DisplayMember = "textfield";
      this.cmbGlassCode.DropDownHeight = 250;
      this.cmbGlassCode.DropDownWidth = 300;
      this.cmbGlassCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbGlassCode.FormattingEnabled = true;
      this.cmbGlassCode.IntegralHeight = false;
      this.cmbGlassCode.Location = new System.Drawing.Point(165, 148);
      this.cmbGlassCode.Margin = new System.Windows.Forms.Padding(4);
      this.cmbGlassCode.Name = "cmbGlassCode";
      this.cmbGlassCode.Size = new System.Drawing.Size(280, 26);
      this.cmbGlassCode.TabIndex = 15;
      this.cmbGlassCode.ValueMember = "datafield";
      // 
      // cmbOption
      // 
      this.cmbOption.DisplayMember = "textfield";
      this.cmbOption.DropDownHeight = 250;
      this.cmbOption.DropDownWidth = 300;
      this.cmbOption.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbOption.FormattingEnabled = true;
      this.cmbOption.IntegralHeight = false;
      this.cmbOption.Location = new System.Drawing.Point(165, 179);
      this.cmbOption.Margin = new System.Windows.Forms.Padding(4);
      this.cmbOption.Name = "cmbOption";
      this.cmbOption.Size = new System.Drawing.Size(280, 26);
      this.cmbOption.TabIndex = 16;
      this.cmbOption.ValueMember = "datafield";
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label1.Location = new System.Drawing.Point(44, 93);
      this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(83, 18);
      this.label1.TabIndex = 6;
      this.label1.Text = "Glass Type";
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label3.Location = new System.Drawing.Point(15, 154);
      this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(112, 18);
      this.label3.TabIndex = 8;
      this.label3.Text = "Glass Selection";
      // 
      // lblOption
      // 
      this.lblOption.AutoSize = true;
      this.lblOption.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblOption.Location = new System.Drawing.Point(85, 186);
      this.lblOption.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.lblOption.Name = "lblOption";
      this.lblOption.Size = new System.Drawing.Size(42, 18);
      this.lblOption.TabIndex = 9;
      this.lblOption.Text = "Bead";
      // 
      // nudThickness
      // 
      this.nudThickness.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.nudThickness.Location = new System.Drawing.Point(165, 120);
      this.nudThickness.Margin = new System.Windows.Forms.Padding(4);
      this.nudThickness.Maximum = new decimal(new int[] {
            8,
            0,
            0,
            0});
      this.nudThickness.Minimum = new decimal(new int[] {
            4,
            0,
            0,
            0});
      this.nudThickness.Name = "nudThickness";
      this.nudThickness.Size = new System.Drawing.Size(54, 24);
      this.nudThickness.TabIndex = 14;
      this.nudThickness.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
      this.nudThickness.ValueChanged += new System.EventHandler(this.nudThickness_ValueChanged);
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label2.Location = new System.Drawing.Point(8, 121);
      this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(119, 18);
      this.label2.TabIndex = 12;
      this.label2.Text = "Glass Thickness";
      // 
      // btnFixed
      // 
      this.btnFixed.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnFixed.Location = new System.Drawing.Point(13, 50);
      this.btnFixed.Margin = new System.Windows.Forms.Padding(4);
      this.btnFixed.Name = "btnFixed";
      this.btnFixed.Size = new System.Drawing.Size(112, 62);
      this.btnFixed.TabIndex = 1;
      this.btnFixed.Text = "Fixed Glass";
      this.btnFixed.UseVisualStyleBackColor = false;
      this.btnFixed.Click += new System.EventHandler(this.btnFixed_Click);
      // 
      // btnSash
      // 
      this.btnSash.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnSash.Location = new System.Drawing.Point(136, 49);
      this.btnSash.Margin = new System.Windows.Forms.Padding(4);
      this.btnSash.Name = "btnSash";
      this.btnSash.Size = new System.Drawing.Size(112, 62);
      this.btnSash.TabIndex = 2;
      this.btnSash.Text = "Sash Glass";
      this.btnSash.UseVisualStyleBackColor = false;
      this.btnSash.Click += new System.EventHandler(this.btnSash_Click);
      // 
      // cmbCostItem
      // 
      this.cmbCostItem.BackColor = System.Drawing.Color.White;
      this.cmbCostItem.DisplayMember = "textfield";
      this.cmbCostItem.DropDownHeight = 350;
      this.cmbCostItem.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.cmbCostItem.DropDownWidth = 230;
      this.cmbCostItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
      this.cmbCostItem.FormattingEnabled = true;
      this.cmbCostItem.IntegralHeight = false;
      this.cmbCostItem.Location = new System.Drawing.Point(145, 80);
      this.cmbCostItem.Margin = new System.Windows.Forms.Padding(4);
      this.cmbCostItem.Name = "cmbCostItem";
      this.cmbCostItem.Size = new System.Drawing.Size(244, 24);
      this.cmbCostItem.TabIndex = 23;
      this.cmbCostItem.ValueMember = "datafield";
      this.cmbCostItem.Visible = false;
      this.cmbCostItem.SelectedIndexChanged += new System.EventHandler(this.cmbCostItem_SelectedIndexChanged);
      // 
      // cmbType
      // 
      this.cmbType.DisplayMember = "textfield";
      this.cmbType.DropDownHeight = 350;
      this.cmbType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.cmbType.DropDownWidth = 230;
      this.cmbType.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
      this.cmbType.FormattingEnabled = true;
      this.cmbType.IntegralHeight = false;
      this.cmbType.Location = new System.Drawing.Point(50, 80);
      this.cmbType.Margin = new System.Windows.Forms.Padding(4);
      this.cmbType.Name = "cmbType";
      this.cmbType.Size = new System.Drawing.Size(87, 24);
      this.cmbType.TabIndex = 22;
      this.cmbType.ValueMember = "datafield";
      this.cmbType.Visible = false;
      this.cmbType.SelectedIndexChanged += new System.EventHandler(this.cmbType_SelectedIndexChanged);
      // 
      // dgvComponent
      // 
      this.dgvComponent.BackgroundColor = System.Drawing.SystemColors.ControlLight;
      this.dgvComponent.BorderStyle = System.Windows.Forms.BorderStyle.None;
      this.dgvComponent.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvComponent.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.chID,
            this.chItem,
            this.chDesc,
            this.chQuantity,
            this.ItemGroupID,
            this.ItemCostID,
            this.RowID});
      this.dgvComponent.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
      this.dgvComponent.Location = new System.Drawing.Point(5, 25);
      this.dgvComponent.Margin = new System.Windows.Forms.Padding(4);
      this.dgvComponent.Name = "dgvComponent";
      dataGridViewCellStyle2.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.dgvComponent.RowsDefaultCellStyle = dataGridViewCellStyle2;
      this.dgvComponent.ShowEditingIcon = false;
      this.dgvComponent.Size = new System.Drawing.Size(475, 202);
      this.dgvComponent.TabIndex = 18;
      this.dgvComponent.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvComponent_CellClick);
      this.dgvComponent.UserDeletingRow += new System.Windows.Forms.DataGridViewRowCancelEventHandler(this.dgvComponent_UserDeletingRow);
      // 
      // gbComponents
      // 
      this.gbComponents.Controls.Add(this.cmbCostItem);
      this.gbComponents.Controls.Add(this.cmbType);
      this.gbComponents.Controls.Add(this.dgvComponent);
      this.gbComponents.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbComponents.Location = new System.Drawing.Point(10, 370);
      this.gbComponents.Margin = new System.Windows.Forms.Padding(4);
      this.gbComponents.Name = "gbComponents";
      this.gbComponents.Padding = new System.Windows.Forms.Padding(4);
      this.gbComponents.Size = new System.Drawing.Size(485, 235);
      this.gbComponents.TabIndex = 17;
      this.gbComponents.TabStop = false;
      this.gbComponents.Text = "Components";
      this.gbComponents.Visible = false;
      // 
      // label4
      // 
      this.label4.AutoSize = true;
      this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label4.Location = new System.Drawing.Point(75, 212);
      this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(52, 18);
      this.label4.TabIndex = 20;
      this.label4.Text = "Length";
      // 
      // label5
      // 
      this.label5.AutoSize = true;
      this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label5.Location = new System.Drawing.Point(21, 62);
      this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label5.Name = "label5";
      this.label5.Size = new System.Drawing.Size(106, 18);
      this.label5.TabIndex = 23;
      this.label5.Text = "Platform Width";
      // 
      // nudWidth
      // 
      this.nudWidth.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.nudWidth.Location = new System.Drawing.Point(165, 60);
      this.nudWidth.Margin = new System.Windows.Forms.Padding(4);
      this.nudWidth.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
      this.nudWidth.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
      this.nudWidth.Name = "nudWidth";
      this.nudWidth.Size = new System.Drawing.Size(106, 24);
      this.nudWidth.TabIndex = 12;
      this.nudWidth.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
      this.nudWidth.ValueChanged += new System.EventHandler(this.nudWidth_ValueChanged);
      // 
      // label6
      // 
      this.label6.AutoSize = true;
      this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label6.Location = new System.Drawing.Point(17, 30);
      this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label6.Name = "label6";
      this.label6.Size = new System.Drawing.Size(110, 18);
      this.label6.TabIndex = 25;
      this.label6.Text = "Platform Height";
      // 
      // nudHeight
      // 
      this.nudHeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.nudHeight.Location = new System.Drawing.Point(165, 28);
      this.nudHeight.Margin = new System.Windows.Forms.Padding(4);
      this.nudHeight.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
      this.nudHeight.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
      this.nudHeight.Name = "nudHeight";
      this.nudHeight.Size = new System.Drawing.Size(106, 24);
      this.nudHeight.TabIndex = 11;
      this.nudHeight.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
      this.nudHeight.ValueChanged += new System.EventHandler(this.nudHeight_ValueChanged);
      // 
      // btnAdd
      // 
      this.btnAdd.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnAdd.Location = new System.Drawing.Point(542, 182);
      this.btnAdd.Name = "btnAdd";
      this.btnAdd.Size = new System.Drawing.Size(111, 47);
      this.btnAdd.TabIndex = 20;
      this.btnAdd.Text = "Add >>";
      this.btnAdd.UseVisualStyleBackColor = false;
      this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
      // 
      // btnEdit
      // 
      this.btnEdit.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnEdit.Location = new System.Drawing.Point(542, 231);
      this.btnEdit.Name = "btnEdit";
      this.btnEdit.Size = new System.Drawing.Size(111, 47);
      this.btnEdit.TabIndex = 21;
      this.btnEdit.Text = "<< Edit ";
      this.btnEdit.UseVisualStyleBackColor = false;
      this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
      // 
      // btnComponents
      // 
      this.btnComponents.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnComponents.Location = new System.Drawing.Point(259, 49);
      this.btnComponents.Margin = new System.Windows.Forms.Padding(4);
      this.btnComponents.Name = "btnComponents";
      this.btnComponents.Size = new System.Drawing.Size(140, 62);
      this.btnComponents.TabIndex = 3;
      this.btnComponents.Text = "Components";
      this.btnComponents.UseVisualStyleBackColor = false;
      this.btnComponents.Click += new System.EventHandler(this.btnComponents_Click);
      // 
      // gbGlassDetails
      // 
      this.gbGlassDetails.Controls.Add(this.lblM2);
      this.gbGlassDetails.Controls.Add(this.label9);
      this.gbGlassDetails.Controls.Add(this.label8);
      this.gbGlassDetails.Controls.Add(this.label7);
      this.gbGlassDetails.Controls.Add(this.nudLength);
      this.gbGlassDetails.Controls.Add(this.nudHeight);
      this.gbGlassDetails.Controls.Add(this.cmbGlassType);
      this.gbGlassDetails.Controls.Add(this.cmbGlassCode);
      this.gbGlassDetails.Controls.Add(this.cmbOption);
      this.gbGlassDetails.Controls.Add(this.label6);
      this.gbGlassDetails.Controls.Add(this.label1);
      this.gbGlassDetails.Controls.Add(this.label3);
      this.gbGlassDetails.Controls.Add(this.label5);
      this.gbGlassDetails.Controls.Add(this.lblOption);
      this.gbGlassDetails.Controls.Add(this.nudWidth);
      this.gbGlassDetails.Controls.Add(this.nudThickness);
      this.gbGlassDetails.Controls.Add(this.label2);
      this.gbGlassDetails.Controls.Add(this.label4);
      this.gbGlassDetails.Location = new System.Drawing.Point(10, 118);
      this.gbGlassDetails.Name = "gbGlassDetails";
      this.gbGlassDetails.Size = new System.Drawing.Size(526, 250);
      this.gbGlassDetails.TabIndex = 29;
      this.gbGlassDetails.TabStop = false;
      this.gbGlassDetails.Text = "Glass Details";
      // 
      // lblM2
      // 
      this.lblM2.AutoSize = true;
      this.lblM2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblM2.Location = new System.Drawing.Point(449, 153);
      this.lblM2.Name = "lblM2";
      this.lblM2.Size = new System.Drawing.Size(25, 15);
      this.lblM2.TabIndex = 30;
      this.lblM2.Text = "m2";
      // 
      // label9
      // 
      this.label9.AutoSize = true;
      this.label9.Location = new System.Drawing.Point(278, 214);
      this.label9.Name = "label9";
      this.label9.Size = new System.Drawing.Size(34, 18);
      this.label9.TabIndex = 29;
      this.label9.Text = "mm";
      // 
      // label8
      // 
      this.label8.AutoSize = true;
      this.label8.Location = new System.Drawing.Point(279, 62);
      this.label8.Name = "label8";
      this.label8.Size = new System.Drawing.Size(34, 18);
      this.label8.TabIndex = 28;
      this.label8.Text = "mm";
      // 
      // label7
      // 
      this.label7.AutoSize = true;
      this.label7.Location = new System.Drawing.Point(279, 34);
      this.label7.Name = "label7";
      this.label7.Size = new System.Drawing.Size(34, 18);
      this.label7.TabIndex = 27;
      this.label7.Text = "mm";
      // 
      // nudLength
      // 
      this.nudLength.BackColor = System.Drawing.Color.White;
      this.nudLength.Enabled = false;
      this.nudLength.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.nudLength.Location = new System.Drawing.Point(165, 210);
      this.nudLength.Margin = new System.Windows.Forms.Padding(4);
      this.nudLength.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
      this.nudLength.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
      this.nudLength.Name = "nudLength";
      this.nudLength.ReadOnly = true;
      this.nudLength.Size = new System.Drawing.Size(106, 24);
      this.nudLength.TabIndex = 26;
      this.nudLength.TabStop = false;
      this.nudLength.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
      // 
      // lvData
      // 
      this.lvData.Activation = System.Windows.Forms.ItemActivation.OneClick;
      this.lvData.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
      this.lvData.HideSelection = false;
      this.lvData.LargeImageList = this.iglProduct;
      this.lvData.Location = new System.Drawing.Point(659, 117);
      this.lvData.Name = "lvData";
      this.lvData.Size = new System.Drawing.Size(454, 250);
      this.lvData.TabIndex = 30;
      this.lvData.TabStop = false;
      this.lvData.UseCompatibleStateImageBehavior = false;
      this.lvData.Click += new System.EventHandler(this.lvData_Click);
      this.lvData.DoubleClick += new System.EventHandler(this.lvData_DoubleClick);
      // 
      // iglProduct
      // 
      this.iglProduct.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("iglProduct.ImageStream")));
      this.iglProduct.TransparentColor = System.Drawing.Color.Transparent;
      this.iglProduct.Images.SetKeyName(0, "edit.png");
      this.iglProduct.Images.SetKeyName(1, "fixed.png");
      this.iglProduct.Images.SetKeyName(2, "sash.png");
      this.iglProduct.Images.SetKeyName(3, "component.png");
      this.iglProduct.Images.SetKeyName(4, "travel.png");
      // 
      // toolStrip1
      // 
      this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tbBack,
            this.tbSave,
            this.tbDelete,
            this.tslName});
      this.toolStrip1.Location = new System.Drawing.Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new System.Drawing.Size(1125, 39);
      this.toolStrip1.TabIndex = 40;
      this.toolStrip1.Text = "toolStrip1";
      // 
      // tbBack
      // 
      this.tbBack.Image = ((System.Drawing.Image)(resources.GetObject("tbBack.Image")));
      this.tbBack.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tbBack.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tbBack.Name = "tbBack";
      this.tbBack.Size = new System.Drawing.Size(72, 36);
      this.tbBack.Text = "Close";
      this.tbBack.Click += new System.EventHandler(this.tbBack_Click);
      // 
      // tbSave
      // 
      this.tbSave.Image = ((System.Drawing.Image)(resources.GetObject("tbSave.Image")));
      this.tbSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tbSave.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tbSave.Name = "tbSave";
      this.tbSave.Size = new System.Drawing.Size(67, 36);
      this.tbSave.Text = "Save";
      this.tbSave.Click += new System.EventHandler(this.tbSave_Click);
      // 
      // tbDelete
      // 
      this.tbDelete.Image = ((System.Drawing.Image)(resources.GetObject("tbDelete.Image")));
      this.tbDelete.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tbDelete.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tbDelete.Name = "tbDelete";
      this.tbDelete.Size = new System.Drawing.Size(76, 36);
      this.tbDelete.Text = "Delete";
      this.tbDelete.Click += new System.EventHandler(this.tbDelete_Click);
      // 
      // tslName
      // 
      this.tslName.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
      this.tslName.DoubleClickEnabled = true;
      this.tslName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.tslName.Name = "tslName";
      this.tslName.Size = new System.Drawing.Size(56, 36);
      this.tslName.Text = "Name";
      this.tslName.DoubleClick += new System.EventHandler(this.tslName_DoubleClick);
      // 
      // btnClear
      // 
      this.btnClear.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnClear.Location = new System.Drawing.Point(542, 79);
      this.btnClear.Name = "btnClear";
      this.btnClear.Size = new System.Drawing.Size(111, 32);
      this.btnClear.TabIndex = 26;
      this.btnClear.Text = "Clear";
      this.btnClear.UseVisualStyleBackColor = false;
      this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
      // 
      // btnDelete
      // 
      this.btnDelete.BackColor = System.Drawing.Color.Red;
      this.btnDelete.ForeColor = System.Drawing.Color.White;
      this.btnDelete.Location = new System.Drawing.Point(542, 280);
      this.btnDelete.Name = "btnDelete";
      this.btnDelete.Size = new System.Drawing.Size(111, 47);
      this.btnDelete.TabIndex = 32;
      this.btnDelete.TabStop = false;
      this.btnDelete.Text = "Delete";
      this.btnDelete.UseVisualStyleBackColor = false;
      this.btnDelete.Visible = false;
      this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
      // 
      // label10
      // 
      this.label10.AutoSize = true;
      this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label10.Location = new System.Drawing.Point(888, 370);
      this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label10.Name = "label10";
      this.label10.Size = new System.Drawing.Size(53, 18);
      this.label10.TabIndex = 42;
      this.label10.Text = "Costs";
      // 
      // label11
      // 
      this.label11.AutoSize = true;
      this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label11.Location = new System.Drawing.Point(787, 395);
      this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label11.Name = "label11";
      this.label11.Size = new System.Drawing.Size(51, 18);
      this.label11.TabIndex = 46;
      this.label11.Text = "Glass:";
      // 
      // label12
      // 
      this.label12.AutoSize = true;
      this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label12.Location = new System.Drawing.Point(792, 449);
      this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label12.Name = "label12";
      this.label12.Size = new System.Drawing.Size(46, 18);
      this.label12.TabIndex = 43;
      this.label12.Text = "Sash:";
      // 
      // label13
      // 
      this.label13.AutoSize = true;
      this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label13.Location = new System.Drawing.Point(792, 422);
      this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label13.Name = "label13";
      this.label13.Size = new System.Drawing.Size(46, 18);
      this.label13.TabIndex = 45;
      this.label13.Text = "Bead:";
      // 
      // label14
      // 
      this.label14.AutoSize = true;
      this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label14.Location = new System.Drawing.Point(740, 476);
      this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label14.Name = "label14";
      this.label14.Size = new System.Drawing.Size(98, 18);
      this.label14.TabIndex = 44;
      this.label14.Text = "Components:";
      // 
      // lblGlassCost
      // 
      this.lblGlassCost.AutoSize = true;
      this.lblGlassCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblGlassCost.Location = new System.Drawing.Point(851, 395);
      this.lblGlassCost.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.lblGlassCost.MinimumSize = new System.Drawing.Size(90, 0);
      this.lblGlassCost.Name = "lblGlassCost";
      this.lblGlassCost.Size = new System.Drawing.Size(90, 18);
      this.lblGlassCost.TabIndex = 50;
      this.lblGlassCost.Text = "$0.00";
      this.lblGlassCost.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // lblBeadCost
      // 
      this.lblBeadCost.AutoSize = true;
      this.lblBeadCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblBeadCost.Location = new System.Drawing.Point(851, 422);
      this.lblBeadCost.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.lblBeadCost.MinimumSize = new System.Drawing.Size(90, 0);
      this.lblBeadCost.Name = "lblBeadCost";
      this.lblBeadCost.Size = new System.Drawing.Size(90, 18);
      this.lblBeadCost.TabIndex = 51;
      this.lblBeadCost.Text = "$0.00";
      this.lblBeadCost.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // lblSashCost
      // 
      this.lblSashCost.AutoSize = true;
      this.lblSashCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblSashCost.Location = new System.Drawing.Point(851, 449);
      this.lblSashCost.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.lblSashCost.MinimumSize = new System.Drawing.Size(90, 0);
      this.lblSashCost.Name = "lblSashCost";
      this.lblSashCost.Size = new System.Drawing.Size(90, 18);
      this.lblSashCost.TabIndex = 52;
      this.lblSashCost.Text = "$0.00";
      this.lblSashCost.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // lblComponentCost
      // 
      this.lblComponentCost.AutoSize = true;
      this.lblComponentCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblComponentCost.Location = new System.Drawing.Point(851, 476);
      this.lblComponentCost.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.lblComponentCost.MinimumSize = new System.Drawing.Size(90, 0);
      this.lblComponentCost.Name = "lblComponentCost";
      this.lblComponentCost.Size = new System.Drawing.Size(90, 18);
      this.lblComponentCost.TabIndex = 53;
      this.lblComponentCost.Text = "$0.00";
      this.lblComponentCost.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // lblTotalCost
      // 
      this.lblTotalCost.AutoSize = true;
      this.lblTotalCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblTotalCost.ForeColor = System.Drawing.Color.Blue;
      this.lblTotalCost.Location = new System.Drawing.Point(851, 536);
      this.lblTotalCost.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.lblTotalCost.MinimumSize = new System.Drawing.Size(90, 0);
      this.lblTotalCost.Name = "lblTotalCost";
      this.lblTotalCost.Size = new System.Drawing.Size(90, 20);
      this.lblTotalCost.TabIndex = 55;
      this.lblTotalCost.Text = "$0.00";
      this.lblTotalCost.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // label20
      // 
      this.label20.AutoSize = true;
      this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label20.ForeColor = System.Drawing.Color.Blue;
      this.label20.Location = new System.Drawing.Point(784, 536);
      this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label20.Name = "label20";
      this.label20.Size = new System.Drawing.Size(54, 20);
      this.label20.TabIndex = 54;
      this.label20.Text = "Total:";
      // 
      // lblTravel
      // 
      this.lblTravel.AutoSize = true;
      this.lblTravel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblTravel.Location = new System.Drawing.Point(851, 506);
      this.lblTravel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.lblTravel.MinimumSize = new System.Drawing.Size(90, 0);
      this.lblTravel.Name = "lblTravel";
      this.lblTravel.Size = new System.Drawing.Size(90, 18);
      this.lblTravel.TabIndex = 58;
      this.lblTravel.Text = "$0.00";
      this.lblTravel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // label16
      // 
      this.label16.AutoSize = true;
      this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label16.Location = new System.Drawing.Point(786, 506);
      this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label16.Name = "label16";
      this.label16.Size = new System.Drawing.Size(52, 18);
      this.label16.TabIndex = 57;
      this.label16.Text = "Travel:";
      // 
      // lblTravelPrice
      // 
      this.lblTravelPrice.AutoSize = true;
      this.lblTravelPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblTravelPrice.Location = new System.Drawing.Point(977, 507);
      this.lblTravelPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.lblTravelPrice.MinimumSize = new System.Drawing.Size(90, 0);
      this.lblTravelPrice.Name = "lblTravelPrice";
      this.lblTravelPrice.Size = new System.Drawing.Size(90, 18);
      this.lblTravelPrice.TabIndex = 65;
      this.lblTravelPrice.Text = "$0.00";
      this.lblTravelPrice.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // lblTotalPrice
      // 
      this.lblTotalPrice.AutoSize = true;
      this.lblTotalPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblTotalPrice.ForeColor = System.Drawing.Color.Blue;
      this.lblTotalPrice.Location = new System.Drawing.Point(977, 537);
      this.lblTotalPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.lblTotalPrice.MinimumSize = new System.Drawing.Size(90, 0);
      this.lblTotalPrice.Name = "lblTotalPrice";
      this.lblTotalPrice.Size = new System.Drawing.Size(90, 20);
      this.lblTotalPrice.TabIndex = 64;
      this.lblTotalPrice.Text = "$0.00";
      this.lblTotalPrice.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // lblCompPrice
      // 
      this.lblCompPrice.AutoSize = true;
      this.lblCompPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblCompPrice.Location = new System.Drawing.Point(977, 477);
      this.lblCompPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.lblCompPrice.MinimumSize = new System.Drawing.Size(90, 0);
      this.lblCompPrice.Name = "lblCompPrice";
      this.lblCompPrice.Size = new System.Drawing.Size(90, 18);
      this.lblCompPrice.TabIndex = 63;
      this.lblCompPrice.Text = "$0.00";
      this.lblCompPrice.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // lblSashPrice
      // 
      this.lblSashPrice.AutoSize = true;
      this.lblSashPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblSashPrice.Location = new System.Drawing.Point(977, 450);
      this.lblSashPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.lblSashPrice.MinimumSize = new System.Drawing.Size(90, 0);
      this.lblSashPrice.Name = "lblSashPrice";
      this.lblSashPrice.Size = new System.Drawing.Size(90, 18);
      this.lblSashPrice.TabIndex = 62;
      this.lblSashPrice.Text = "$0.00";
      this.lblSashPrice.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // lblBeadPrice
      // 
      this.lblBeadPrice.AutoSize = true;
      this.lblBeadPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblBeadPrice.Location = new System.Drawing.Point(977, 423);
      this.lblBeadPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.lblBeadPrice.MinimumSize = new System.Drawing.Size(90, 0);
      this.lblBeadPrice.Name = "lblBeadPrice";
      this.lblBeadPrice.Size = new System.Drawing.Size(90, 18);
      this.lblBeadPrice.TabIndex = 61;
      this.lblBeadPrice.Text = "$0.00";
      this.lblBeadPrice.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // lblGlassPrice
      // 
      this.lblGlassPrice.AutoSize = true;
      this.lblGlassPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblGlassPrice.Location = new System.Drawing.Point(977, 396);
      this.lblGlassPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.lblGlassPrice.MinimumSize = new System.Drawing.Size(90, 0);
      this.lblGlassPrice.Name = "lblGlassPrice";
      this.lblGlassPrice.Size = new System.Drawing.Size(90, 18);
      this.lblGlassPrice.TabIndex = 60;
      this.lblGlassPrice.Text = "$0.00";
      this.lblGlassPrice.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // label23
      // 
      this.label23.AutoSize = true;
      this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label23.Location = new System.Drawing.Point(1020, 370);
      this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label23.Name = "label23";
      this.label23.Size = new System.Drawing.Size(47, 18);
      this.label23.TabIndex = 59;
      this.label23.Text = "Price";
      // 
      // chID
      // 
      this.chID.Frozen = true;
      this.chID.HeaderText = "ID";
      this.chID.Name = "chID";
      this.chID.ReadOnly = true;
      this.chID.Resizable = System.Windows.Forms.DataGridViewTriState.False;
      this.chID.Visible = false;
      this.chID.Width = 25;
      // 
      // chItem
      // 
      this.chItem.Frozen = true;
      this.chItem.HeaderText = "Item";
      this.chItem.Name = "chItem";
      this.chItem.ReadOnly = true;
      this.chItem.Resizable = System.Windows.Forms.DataGridViewTriState.False;
      // 
      // chDesc
      // 
      this.chDesc.HeaderText = "Description";
      this.chDesc.Name = "chDesc";
      this.chDesc.ReadOnly = true;
      this.chDesc.Resizable = System.Windows.Forms.DataGridViewTriState.False;
      this.chDesc.Width = 250;
      // 
      // chQuantity
      // 
      dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
      dataGridViewCellStyle1.Format = "N2";
      dataGridViewCellStyle1.NullValue = null;
      this.chQuantity.DefaultCellStyle = dataGridViewCellStyle1;
      this.chQuantity.HeaderText = "Quantity";
      this.chQuantity.Name = "chQuantity";
      this.chQuantity.Width = 80;
      // 
      // ItemGroupID
      // 
      this.ItemGroupID.HeaderText = "ItemGroupID";
      this.ItemGroupID.Name = "ItemGroupID";
      this.ItemGroupID.ReadOnly = true;
      this.ItemGroupID.Visible = false;
      // 
      // ItemCostID
      // 
      this.ItemCostID.HeaderText = "ItemCostID";
      this.ItemCostID.Name = "ItemCostID";
      this.ItemCostID.ReadOnly = true;
      this.ItemCostID.Visible = false;
      // 
      // RowID
      // 
      this.RowID.HeaderText = "RowID";
      this.RowID.Name = "RowID";
      this.RowID.ReadOnly = true;
      this.RowID.Visible = false;
      // 
      // Retrofit
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.ClientSize = new System.Drawing.Size(1125, 611);
      this.Controls.Add(this.lblTravelPrice);
      this.Controls.Add(this.lblTotalPrice);
      this.Controls.Add(this.lblCompPrice);
      this.Controls.Add(this.lblSashPrice);
      this.Controls.Add(this.lblBeadPrice);
      this.Controls.Add(this.lblGlassPrice);
      this.Controls.Add(this.label23);
      this.Controls.Add(this.lblTravel);
      this.Controls.Add(this.label16);
      this.Controls.Add(this.lblTotalCost);
      this.Controls.Add(this.label20);
      this.Controls.Add(this.lblComponentCost);
      this.Controls.Add(this.lblSashCost);
      this.Controls.Add(this.lblBeadCost);
      this.Controls.Add(this.lblGlassCost);
      this.Controls.Add(this.label11);
      this.Controls.Add(this.label12);
      this.Controls.Add(this.label13);
      this.Controls.Add(this.label14);
      this.Controls.Add(this.label10);
      this.Controls.Add(this.btnDelete);
      this.Controls.Add(this.btnClear);
      this.Controls.Add(this.toolStrip1);
      this.Controls.Add(this.lvData);
      this.Controls.Add(this.gbGlassDetails);
      this.Controls.Add(this.btnComponents);
      this.Controls.Add(this.btnEdit);
      this.Controls.Add(this.btnAdd);
      this.Controls.Add(this.gbComponents);
      this.Controls.Add(this.btnSash);
      this.Controls.Add(this.btnFixed);
      this.Controls.Add(this.dgvData);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.Margin = new System.Windows.Forms.Padding(4);
      this.Name = "Retrofit";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
      this.Text = "Retrofit Glass";
      this.Load += new System.EventHandler(this.Retrofit_Load);
      ((System.ComponentModel.ISupportInitialize)(this.dgvData)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudThickness)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dgvComponent)).EndInit();
      this.gbComponents.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.nudWidth)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudHeight)).EndInit();
      this.gbGlassDetails.ResumeLayout(false);
      this.gbGlassDetails.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.nudLength)).EndInit();
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.DataGridView dgvData;
		private System.Windows.Forms.ComboBox cmbGlassType;
		private System.Windows.Forms.ComboBox cmbGlassCode;
		private System.Windows.Forms.ComboBox cmbOption;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label lblOption;
		private System.Windows.Forms.NumericUpDown nudThickness;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button btnFixed;
		private System.Windows.Forms.Button btnSash;
		internal System.Windows.Forms.DataGridView dgvComponent;
		internal System.Windows.Forms.ComboBox cmbType;
		internal System.Windows.Forms.ComboBox cmbCostItem;
		private System.Windows.Forms.GroupBox gbComponents;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.NumericUpDown nudWidth;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.NumericUpDown nudHeight;
		private System.Windows.Forms.Button btnAdd;
		private System.Windows.Forms.Button btnEdit;
		private System.Windows.Forms.Button btnComponents;
		private System.Windows.Forms.GroupBox gbGlassDetails;
        private System.Windows.Forms.ListView lvData;
        private System.Windows.Forms.ImageList iglProduct;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tbBack;
        private System.Windows.Forms.ToolStripButton tbSave;
        private System.Windows.Forms.ToolStripButton tbDelete;
        public System.Windows.Forms.ToolStripLabel tslName;
        private System.Windows.Forms.Button btnClear;
		private System.Windows.Forms.Button btnDelete;
		private System.Windows.Forms.NumericUpDown nudLength;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Label lblGlassCost;
		private System.Windows.Forms.Label lblBeadCost;
		private System.Windows.Forms.Label lblSashCost;
		private System.Windows.Forms.Label lblComponentCost;
		private System.Windows.Forms.Label lblTotalCost;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.Label lblTravel;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.Label lblTravelPrice;
		private System.Windows.Forms.Label lblTotalPrice;
		private System.Windows.Forms.Label lblCompPrice;
		private System.Windows.Forms.Label lblSashPrice;
		private System.Windows.Forms.Label lblBeadPrice;
		private System.Windows.Forms.Label lblGlassPrice;
		private System.Windows.Forms.Label label23;
    private System.Windows.Forms.Label lblM2;
    private System.Windows.Forms.DataGridViewTextBoxColumn chID;
    private System.Windows.Forms.DataGridViewTextBoxColumn chItem;
    private System.Windows.Forms.DataGridViewTextBoxColumn chDesc;
    private System.Windows.Forms.DataGridViewTextBoxColumn chQuantity;
    private System.Windows.Forms.DataGridViewTextBoxColumn ItemGroupID;
    private System.Windows.Forms.DataGridViewTextBoxColumn ItemCostID;
    private System.Windows.Forms.DataGridViewTextBoxColumn RowID;
  }
}