﻿using System;
using System.Windows.Forms;

namespace workshop_orders
{
  partial class JobItem
  {
    /// <summary>
    ///  Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    ///  Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    ///  Required method for Designer support - do not modify
    ///  the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(JobItem));
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
      this.gbsearch = new System.Windows.Forms.GroupBox();
      this.cmbField = new System.Windows.Forms.ComboBox();
      this.label3 = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this.txtSearch = new System.Windows.Forms.TextBox();
      this.toolStrip1 = new System.Windows.Forms.ToolStrip();
      this.tsClose = new System.Windows.Forms.ToolStripButton();
      this.tsSave = new System.Windows.Forms.ToolStripButton();
      this.tsAdd = new System.Windows.Forms.ToolStripButton();
      this.tsCreateJob = new System.Windows.Forms.ToolStripButton();
      this.gbItemsAdded = new System.Windows.Forms.GroupBox();
      this.dgvItemsAdded = new System.Windows.Forms.DataGridView();
      this.lblItem = new System.Windows.Forms.Label();
      this.gbResult = new System.Windows.Forms.GroupBox();
      this.dgvItems = new System.Windows.Forms.DataGridView();
      this.btnRemoveItem = new System.Windows.Forms.Button();
      this.btnAddItem = new System.Windows.Forms.Button();
      this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chItemStockID = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chAltCode2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chType = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chAltCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Qty = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.gbsearch.SuspendLayout();
      this.toolStrip1.SuspendLayout();
      this.gbItemsAdded.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgvItemsAdded)).BeginInit();
      this.gbResult.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgvItems)).BeginInit();
      this.SuspendLayout();
      // 
      // gbsearch
      // 
      this.gbsearch.Controls.Add(this.cmbField);
      this.gbsearch.Controls.Add(this.label3);
      this.gbsearch.Controls.Add(this.label2);
      this.gbsearch.Controls.Add(this.txtSearch);
      this.gbsearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbsearch.Location = new System.Drawing.Point(12, 39);
      this.gbsearch.Name = "gbsearch";
      this.gbsearch.Size = new System.Drawing.Size(671, 99);
      this.gbsearch.TabIndex = 1;
      this.gbsearch.TabStop = false;
      this.gbsearch.Text = "Search";
      // 
      // cmbField
      // 
      this.cmbField.DisplayMember = "textfield";
      this.cmbField.FormattingEnabled = true;
      this.cmbField.Location = new System.Drawing.Point(99, 22);
      this.cmbField.Name = "cmbField";
      this.cmbField.Size = new System.Drawing.Size(139, 28);
      this.cmbField.TabIndex = 98;
      this.cmbField.ValueMember = "datafield";
      this.cmbField.SelectedIndexChanged += new System.EventHandler(this.cmbField_SelectedIndexChanged);
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Location = new System.Drawing.Point(32, 25);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(43, 20);
      this.label3.TabIndex = 97;
      this.label3.Text = "Field";
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Location = new System.Drawing.Point(15, 59);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(60, 20);
      this.label2.TabIndex = 96;
      this.label2.Text = "Search";
      // 
      // txtSearch
      // 
      this.txtSearch.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
      this.txtSearch.Location = new System.Drawing.Point(99, 56);
      this.txtSearch.Name = "txtSearch";
      this.txtSearch.Size = new System.Drawing.Size(483, 26);
      this.txtSearch.TabIndex = 1;
      this.txtSearch.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
      // 
      // toolStrip1
      // 
      this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsClose,
            this.tsSave,
            this.tsAdd,
            this.tsCreateJob});
      this.toolStrip1.Location = new System.Drawing.Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new System.Drawing.Size(1601, 39);
      this.toolStrip1.TabIndex = 96;
      this.toolStrip1.Text = "toolStrip1";
      // 
      // tsClose
      // 
      this.tsClose.Image = ((System.Drawing.Image)(resources.GetObject("tsClose.Image")));
      this.tsClose.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsClose.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsClose.Name = "tsClose";
      this.tsClose.Size = new System.Drawing.Size(72, 36);
      this.tsClose.Text = "Close";
      this.tsClose.Click += new System.EventHandler(this.toolStripButton1_Click_1);
      // 
      // tsSave
      // 
      this.tsSave.Image = ((System.Drawing.Image)(resources.GetObject("tsSave.Image")));
      this.tsSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsSave.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsSave.Name = "tsSave";
      this.tsSave.Size = new System.Drawing.Size(67, 36);
      this.tsSave.Text = "Save";
      this.tsSave.Click += new System.EventHandler(this.saveToolStripButton2_Click);
      // 
      // tsAdd
      // 
      this.tsAdd.Image = ((System.Drawing.Image)(resources.GetObject("tsAdd.Image")));
      this.tsAdd.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsAdd.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsAdd.Name = "tsAdd";
      this.tsAdd.Size = new System.Drawing.Size(92, 36);
      this.tsAdd.Text = "Add Item";
      this.tsAdd.ToolTipText = "Add ";
      this.tsAdd.Click += new System.EventHandler(this.addtoolStripButton_Click);
      // 
      // tsCreateJob
      // 
      this.tsCreateJob.Image = global::workshop_orders.Properties.Resources.product32;
      this.tsCreateJob.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsCreateJob.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsCreateJob.Name = "tsCreateJob";
      this.tsCreateJob.Size = new System.Drawing.Size(102, 36);
      this.tsCreateJob.Text = "Update Job";
      this.tsCreateJob.Visible = false;
      this.tsCreateJob.Click += new System.EventHandler(this.tsJob_Click);
      // 
      // gbItemsAdded
      // 
      this.gbItemsAdded.Controls.Add(this.dgvItemsAdded);
      this.gbItemsAdded.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbItemsAdded.Location = new System.Drawing.Point(879, 172);
      this.gbItemsAdded.Name = "gbItemsAdded";
      this.gbItemsAdded.Size = new System.Drawing.Size(710, 510);
      this.gbItemsAdded.TabIndex = 98;
      this.gbItemsAdded.TabStop = false;
      this.gbItemsAdded.Text = "Items Added";
      // 
      // dgvItemsAdded
      // 
      this.dgvItemsAdded.AllowUserToAddRows = false;
      this.dgvItemsAdded.AllowUserToDeleteRows = false;
      this.dgvItemsAdded.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      this.dgvItemsAdded.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvItemsAdded.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.chItemStockID,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.chAltCode2,
            this.dataGridViewTextBoxColumn5,
            this.chQuantity});
      this.dgvItemsAdded.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dgvItemsAdded.GridColor = System.Drawing.SystemColors.ControlText;
      this.dgvItemsAdded.Location = new System.Drawing.Point(3, 20);
      this.dgvItemsAdded.Name = "dgvItemsAdded";
      this.dgvItemsAdded.ReadOnly = true;
      this.dgvItemsAdded.RowHeadersWidth = 5;
      this.dgvItemsAdded.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
      this.dgvItemsAdded.Size = new System.Drawing.Size(704, 487);
      this.dgvItemsAdded.TabIndex = 0;
      this.dgvItemsAdded.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvItemsAdded_CellDoubleClick);
      // 
      // lblItem
      // 
      this.lblItem.AutoSize = true;
      this.lblItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblItem.Location = new System.Drawing.Point(15, 151);
      this.lblItem.Name = "lblItem";
      this.lblItem.Size = new System.Drawing.Size(304, 18);
      this.lblItem.TabIndex = 99;
      this.lblItem.Text = "Items used with this Vehicle Previously:";
      // 
      // gbResult
      // 
      this.gbResult.Controls.Add(this.dgvItems);
      this.gbResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbResult.Location = new System.Drawing.Point(15, 172);
      this.gbResult.Name = "gbResult";
      this.gbResult.Size = new System.Drawing.Size(788, 510);
      this.gbResult.TabIndex = 97;
      this.gbResult.TabStop = false;
      this.gbResult.Text = "Results";
      // 
      // dgvItems
      // 
      this.dgvItems.AllowUserToAddRows = false;
      this.dgvItems.AllowUserToDeleteRows = false;
      this.dgvItems.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      this.dgvItems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvItems.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.chType,
            this.chCode,
            this.chAltCode,
            this.chDesc,
            this.Qty,
            this.chCost});
      this.dgvItems.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dgvItems.GridColor = System.Drawing.SystemColors.ControlText;
      this.dgvItems.Location = new System.Drawing.Point(3, 20);
      this.dgvItems.Name = "dgvItems";
      this.dgvItems.ReadOnly = true;
      this.dgvItems.RowHeadersWidth = 5;
      this.dgvItems.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
      this.dgvItems.Size = new System.Drawing.Size(782, 487);
      this.dgvItems.TabIndex = 0;
      this.dgvItems.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.customerDataGrid_CellDoubleClick);
      // 
      // btnRemoveItem
      // 
      this.btnRemoveItem.BackColor = System.Drawing.Color.White;
      this.btnRemoveItem.BackgroundImage = global::workshop_orders.Properties.Resources.arrow_back32;
      this.btnRemoveItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
      this.btnRemoveItem.Location = new System.Drawing.Point(816, 236);
      this.btnRemoveItem.Name = "btnRemoveItem";
      this.btnRemoveItem.Size = new System.Drawing.Size(57, 49);
      this.btnRemoveItem.TabIndex = 98;
      this.btnRemoveItem.UseVisualStyleBackColor = false;
      this.btnRemoveItem.Click += new System.EventHandler(this.btnRemoveItem_Click);
      // 
      // btnAddItem
      // 
      this.btnAddItem.BackColor = System.Drawing.Color.White;
      this.btnAddItem.BackgroundImage = global::workshop_orders.Properties.Resources.arrow_next32;
      this.btnAddItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
      this.btnAddItem.Location = new System.Drawing.Point(816, 181);
      this.btnAddItem.Name = "btnAddItem";
      this.btnAddItem.Size = new System.Drawing.Size(57, 49);
      this.btnAddItem.TabIndex = 97;
      this.btnAddItem.UseVisualStyleBackColor = false;
      this.btnAddItem.Click += new System.EventHandler(this.btnAddItem_Click);
      // 
      // dataGridViewTextBoxColumn1
      // 
      this.dataGridViewTextBoxColumn1.HeaderText = "ID";
      this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
      this.dataGridViewTextBoxColumn1.ReadOnly = true;
      this.dataGridViewTextBoxColumn1.Visible = false;
      // 
      // chItemStockID
      // 
      this.chItemStockID.HeaderText = "itemstockid";
      this.chItemStockID.Name = "chItemStockID";
      this.chItemStockID.ReadOnly = true;
      this.chItemStockID.Visible = false;
      // 
      // dataGridViewTextBoxColumn2
      // 
      this.dataGridViewTextBoxColumn2.HeaderText = "Type";
      this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
      this.dataGridViewTextBoxColumn2.ReadOnly = true;
      // 
      // dataGridViewTextBoxColumn3
      // 
      this.dataGridViewTextBoxColumn3.HeaderText = "Item Code";
      this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
      this.dataGridViewTextBoxColumn3.ReadOnly = true;
      this.dataGridViewTextBoxColumn3.Width = 200;
      // 
      // chAltCode2
      // 
      this.chAltCode2.HeaderText = "Alt Code";
      this.chAltCode2.Name = "chAltCode2";
      this.chAltCode2.ReadOnly = true;
      this.chAltCode2.Width = 120;
      // 
      // dataGridViewTextBoxColumn5
      // 
      this.dataGridViewTextBoxColumn5.HeaderText = "Description";
      this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
      this.dataGridViewTextBoxColumn5.ReadOnly = true;
      this.dataGridViewTextBoxColumn5.Width = 300;
      // 
      // chQuantity
      // 
      this.chQuantity.HeaderText = "Qty Req";
      this.chQuantity.Name = "chQuantity";
      this.chQuantity.ReadOnly = true;
      this.chQuantity.Width = 50;
      // 
      // ID
      // 
      this.ID.DataPropertyName = "itemcostID";
      this.ID.HeaderText = "ID";
      this.ID.Name = "ID";
      this.ID.ReadOnly = true;
      this.ID.Visible = false;
      // 
      // chType
      // 
      this.chType.DataPropertyName = "igSubGroup";
      this.chType.HeaderText = "Type";
      this.chType.Name = "chType";
      this.chType.ReadOnly = true;
      // 
      // chCode
      // 
      this.chCode.DataPropertyName = "icCode";
      this.chCode.HeaderText = "Item Code";
      this.chCode.Name = "chCode";
      this.chCode.ReadOnly = true;
      this.chCode.Width = 200;
      // 
      // chAltCode
      // 
      this.chAltCode.DataPropertyName = "Code";
      this.chAltCode.HeaderText = "Alt Code";
      this.chAltCode.Name = "chAltCode";
      this.chAltCode.ReadOnly = true;
      this.chAltCode.Width = 120;
      // 
      // chDesc
      // 
      this.chDesc.DataPropertyName = "icDescription";
      this.chDesc.HeaderText = "Description";
      this.chDesc.Name = "chDesc";
      this.chDesc.ReadOnly = true;
      this.chDesc.Width = 300;
      // 
      // Qty
      // 
      this.Qty.DataPropertyName = "quantity";
      dataGridViewCellStyle1.NullValue = "0";
      this.Qty.DefaultCellStyle = dataGridViewCellStyle1;
      this.Qty.HeaderText = "Qty In Stock";
      this.Qty.Name = "Qty";
      this.Qty.ReadOnly = true;
      // 
      // chCost
      // 
      this.chCost.DataPropertyName = "icCost";
      this.chCost.HeaderText = "Cost";
      this.chCost.Name = "chCost";
      this.chCost.ReadOnly = true;
      // 
      // JobItem
      // 
      this.AllowDrop = true;
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.AutoScroll = true;
      this.BackColor = System.Drawing.Color.White;
      this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
      this.ClientSize = new System.Drawing.Size(1601, 690);
      this.Controls.Add(this.lblItem);
      this.Controls.Add(this.gbResult);
      this.Controls.Add(this.gbItemsAdded);
      this.Controls.Add(this.btnRemoveItem);
      this.Controls.Add(this.btnAddItem);
      this.Controls.Add(this.toolStrip1);
      this.Controls.Add(this.gbsearch);
      this.Cursor = System.Windows.Forms.Cursors.Default;
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
      this.MaximizeBox = false;
      this.Name = "JobItem";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
      this.Text = "Items on Job";
      this.Load += new System.EventHandler(this.CreateJobForm_Load);
      this.gbsearch.ResumeLayout(false);
      this.gbsearch.PerformLayout();
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.gbItemsAdded.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.dgvItemsAdded)).EndInit();
      this.gbResult.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.dgvItems)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion
    private GroupBox gbsearch;
    private TextBox txtSearch;
    private ToolStrip toolStrip1;
    private ToolStripButton tsClose;
    private ToolStripButton tsSave;
    private ToolStripButton tsAdd;
    private Label label3;
    private Label label2;
    private ToolStripButton tsCreateJob;
    private Button btnAddItem;
    private Button btnRemoveItem;
    private GroupBox gbItemsAdded;
    private DataGridView dgvItemsAdded;
    private Label lblItem;
    private GroupBox gbResult;
    private DataGridView dgvItems;
    private ComboBox cmbField;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
    private DataGridViewTextBoxColumn chItemStockID;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
    private DataGridViewTextBoxColumn chAltCode2;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
    private DataGridViewTextBoxColumn chQuantity;
    private DataGridViewTextBoxColumn ID;
    private DataGridViewTextBoxColumn chType;
    private DataGridViewTextBoxColumn chCode;
    private DataGridViewTextBoxColumn chAltCode;
    private DataGridViewTextBoxColumn chDesc;
    private DataGridViewTextBoxColumn Qty;
    private DataGridViewTextBoxColumn chCost;
  }
}

