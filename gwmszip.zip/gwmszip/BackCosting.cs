﻿using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;
using System.Collections.Generic;
using System.Windows.Forms.DataVisualization.Charting;

namespace workshop_orders
{
  public partial class BackCosting : Form
  {
    private String jobNo;
    private TimeSpan totalTime;
    private double fixedCost;
    private double labourCost;


    public MySqlConnection connectMySql()
    {
      using (MySqlConnection conn = new MySqlConnection(GWMS.connStr))
      {
        try
        {
          Console.WriteLine("Connecting to MySQL...");
          return conn;
        }
        catch (Exception ex)
        {
          MessageBox.Show("Error connecting to server, please contact the administrator.", "Error!");
          return null;
        }
      }
    }


    public BackCosting()
    {
      InitializeComponent();
      if (GWMS.getAdminStatus())
      {
        signOffButton.Enabled = false;
      }
      reset_all_fields();
    }

    public BackCosting(String jobNo)
    {
      InitializeComponent();

      fixedCost = 0.0;
      String fixedCostSql = String.Format("SELECT totalFixed FROM fixedCost;");

      using (MySqlConnection conn = connectMySql())
      {
        try
        {
          conn.Open();
          MySqlCommand cmd = new MySqlCommand(fixedCostSql, conn);
          using (MySqlDataReader rdr = cmd.ExecuteReader())
          {
            rdr.Read();
            fixedCost = double.Parse(rdr["totalFixed"].ToString());
          }
        }
        catch (Exception ex)
        {
          //MessageBox.Show("Fixed Price Data failed to load.");
          DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
          fixedlabel.ForeColor = System.Drawing.Color.Red;
        }
      }
      jobLabel.Text = "Job " + jobNo;
      String customer = String.Format("SELECT cFirstName, cSurname, cCompany FROM customer INNER JOIN job ON customer.cID = job.customerID " +
          "WHERE jobNo = {0};", jobNo);

      using (MySqlConnection conn = connectMySql())
      {
        try
        {
          conn.Open();
          MySqlCommand cmd = new MySqlCommand(customer, conn);
          using (MySqlDataReader rdr = cmd.ExecuteReader())
          {
            rdr.Read();
            jobLabel.Text += " - " + rdr["cFirstName"].ToString() + " " + rdr["cSurname"].ToString() + " - " + rdr["cCompany"].ToString();
          }
        }
        catch (Exception ex)
        {
          MessageBox.Show("Customer Data Failed to Load");
          DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
          fixedlabel.ForeColor = System.Drawing.Color.Red;
        }
      }

      this.jobNo = jobNo;

      if (!GWMS.getAdminStatus())
      {
        signOffButton.Enabled = false;
      }

      String sql = String.Format("SELECT * FROM job INNER JOIN jobStatus ON job.jobNo = jobStatus.jobNo INNER JOIN " +
          "(SELECT jobNo, MAX(date) AS maxdate FROM jobStatus GROUP BY jobNo) jS ON date = maxdate WHERE job.jobNo = {0};", jobNo);

      String parts = String.Format("SELECT pType AS Type, pCode AS MainCode, pAltCode AS AltCode, pNagCode AS NagCode, " +
          "jobPart.buyPrice AS BuyPrice, jobPart.sellPrice AS SellPrice FROM part INNER JOIN jobPart ON part.pID = jobPart.pID " +
          "INNER JOIN (SELECT objID, max(date) AS maxdate FROM jobPart GROUP BY objID) jP " +
          "ON jobPart.objID = jP.objID AND jobPart.date = jP.maxdate WHERE pAllocated = {0};", jobNo);

      String labour = String.Format("SELECT * FROM workshopTiming WHERE jobNo = {0};", jobNo);

      TimeSpan span = TimeSpan.Zero;

      TimeSpan interval = TimeSpan.Parse("00:15:00");

      double totalCost = 0;
      double totalinvoice = 0;

      String errors = "";

      String stamps = String.Format("SELECT staff, day, time, action, jobNo, sName, rate FROM dayStamps " +
          "INNER JOIN staff ON sUsername = staff WHERE jobNo = {0} ORDER BY staff, day, time;",
          jobNo);

      String dayBreaks = String.Format("SELECT * FROM timeStamps;");

      String staffJob = String.Format("SELECT sUsername, sName, rate FROM dayStamps INNER JOIN staff ON sUsername = staff " +
          "WHERE jobNo = {0} GROUP BY staff ORDER BY staff;", jobNo);
      String timeStamps;


      using (MySqlConnection conn = connectMySql())
      {
        try
        {
          conn.Open();
          MySqlCommand cmd = new MySqlCommand(staffJob, conn);
          using (MySqlDataReader rdr = cmd.ExecuteReader())
          {
            while (rdr.Read())
            {
              timeStamps = String.Format("SELECT day, time, action FROM dayStamps WHERE jobNo = {0} AND " +
                  "staff = '{1}' ORDER BY day, time;", jobNo, rdr["sUsername"].ToString());
              using (MySqlConnection conn2 = connectMySql())
              {
                DateTime start = DateTime.Parse("0:00:00");
                DateTime end = DateTime.Parse("0:00:00");
                try
                {
                  conn2.Open();
                  MySqlCommand cmd2 = new MySqlCommand(timeStamps, conn2);
                  using (MySqlDataReader rdr2 = cmd2.ExecuteReader())
                  {
                    while (rdr2.Read())
                    {
                      if (rdr2["action"].ToString() == "START")
                      {
                        start = DateTime.Parse(rdr2["time"].ToString());
                      }
                      else if (rdr2["action"].ToString() == "END")
                      {
                        if (start.ToString("HH:mm:ss") != "00:00:00")
                        {
                          end = DateTime.Parse(rdr2["time"].ToString());
                          span += (end - start);
                          start = DateTime.Parse("0:00:00");
                          end = DateTime.Parse("0:00:00");
                        }
                        else
                        {
                          MessageBox.Show("Error loading some of the timer info.\n" +
                              "Timer appears to have ended before it even started.\n" +
                              "If this issue persist please check error logs, connection to server and/or " +
                              "contact the administrator.");
                          start = DateTime.Parse("0:00:00");
                          end = DateTime.Parse("0:00:00");
                        }
                      }
                    }
                  }
                }
                catch (Exception ex)
                {
                  DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
                }
              }
              actualDataGrid.Rows.Add("Labour", String.Format("${0:0.00}", (double.Parse(rdr["rate"].ToString()) / 60) * (double.Parse(span.ToString("%h")) * 60 + double.Parse(span.ToString("%m")))), rdr["sName"].ToString() + " " + span.ToString());
              span = TimeSpan.Parse("0:00:00");
            }
          }
        }
        catch (Exception ex)
        {
          errors += "ERROR: No Timing is Associated With this Job.\n";
          span = TimeSpan.Parse("1:30:00");
          labourLabel.ForeColor = System.Drawing.Color.Red;
          estLabel.Visible = true;
          incompleteLabel.Visible = true;
          DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
        }
      }
      /*
      if(span == TimeSpan.Zero)
      {
          errors += "ERROR: No Timing is Associated With this Job.\n";
          span = TimeSpan.Parse("1:30:00");
          estLabel.Visible = true;
          incompleteLabel.Visible = true;
          labourLabel.ForeColor = System.Drawing.Color.Red;
      }*/
      totalTime = span;
      labourLabel.Text = "Labour Cost: " + span.ToString() + "$";

      int intervalAmount = 0;
      fixedlabel.Text = "Fixed Cost: $" + fixedCost.ToString();

      TimeSpan copySpan = span;
      while (span > TimeSpan.Zero)
      {
        span = span - interval;
        intervalAmount++;
      }

      totalCost += (30.0 / 4.0) * intervalAmount;
      labourLabel.Text += String.Format("{0:0.00}", totalCost);

      estimatedDataGrid.Rows.Add("Labour (EST)", "$" + String.Format("{0:0.00}", "40.5"), "01:30:00" + "", false);

      estimatedDataGrid.Rows.Add("Fixed Costs", "$" + String.Format("{0:0.00}", "23.34"), null, true);
      actualDataGrid.Rows.Add("Fixed Costs", "$" + String.Format("{0:0.00}", "23.34"), null);

      //estimatedDataGrid.Rows.Add("Windscreen", "$" + String.Format("{0:0.00}", "150"), "SMITH&SMITH", true);
      //actualDataGrid.Rows.Add("Windscreen", "$" + String.Format("{0:0.00}", "150"), "SMITH&SMITH");

      String getProduct = String.Format("SELECT * FROM jobPart INNER JOIN (SELECT objID, MAX(date) AS maxdate FROM jobPart GROUP BY objID) jP " +
          "ON jobPart.objID = jP.objID AND date = maxdate INNER JOIN part ON part.pID = jobPart.pID WHERE pAllocated = {0};", jobNo);

      String code;
      using (MySqlConnection conn = connectMySql())
      {
        try
        {
          conn.Open();
          //estimatedDataGrid.DataSource = dtbl;
          MySqlCommand cmd = new MySqlCommand(getProduct, conn);
          using (MySqlDataReader rdr = cmd.ExecuteReader())
          {
            while (rdr.Read())
            {
              if (rdr["pCode"].ToString() != null)
              {
                code = rdr["pCode"].ToString();
              }
              else if (rdr["pAltCode"].ToString() != null)
              {
                code = rdr["pAltCode"].ToString();
              }
              else if (rdr["pNagCode"].ToString() != null)
              {
                code = rdr["pNagCode"].ToString();
              }
              else
              {
                code = "";
              }
              double buyPrice;
              if (rdr["buyPrice"].ToString() != "")
              {
                buyPrice = double.Parse(rdr["buyPrice"].ToString()) * 1.52;
              }
              else
              {
                buyPrice = 0;
              }
              estimatedDataGrid.Rows.Add(rdr["pType"].ToString(), "$" + String.Format("{0:0.00}",
                  buyPrice), String.Format("{0} ({1})", code,
                   rdr["pDesc"].ToString()), true);

              actualDataGrid.Rows.Add(rdr["pType"].ToString(), "$" + String.Format("{0:0.00}", rdr["buyPrice"].ToString()),
                  String.Format("{0} ({1})", code,
                   rdr["pDesc"].ToString()));
            }
          }
        }
        catch (Exception ex)
        {
          incompleteLabel.Visible = true;
          incompleteLabel.Text = "(Incomplete)";
          DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
        }
        conn.Close();
      }

      double totalCosts = 0.0;
      foreach (DataGridViewRow row in estimatedDataGrid.Rows)
      {
        try
        {
          if (row.Cells[1].Value != null)
          {
            totalCosts += double.Parse(row.Cells[1].Value.ToString().Replace("$", String.Empty));
          }
        }
        catch (Exception ex)
        {
          DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
        }
      }

      estimatedDataGrid.Rows.Add("TOTAL", "$" + String.Format("{0:0.00}", totalCosts), "", false);

      double totalActualCosts = 0.0;
      foreach (DataGridViewRow row in actualDataGrid.Rows)
      {
        try
        {
          if (row.Cells[1].Value != null)
          {
            totalActualCosts += double.Parse(row.Cells[1].Value.ToString().Replace("$", String.Empty));
          }
        }
        catch (Exception ex)
        {
          DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
        }
      }
      actualDataGrid.Rows.Add("TOTAL", "$" + String.Format("{0:0.00}", totalActualCosts), "");

      double totalInvoice = 0.0;
      String getInvoice = String.Format("SELECT * FROM invoice WHERE jobNo = {0};", jobNo);
      using (MySqlConnection conn = connectMySql())
      {
        try
        {
          conn.Open();
          //estimatedDataGrid.DataSource = dtbl;
          MySqlCommand cmd = new MySqlCommand(getInvoice, conn);
          using (MySqlDataReader rdr = cmd.ExecuteReader())
          {
            while (rdr.Read())
            {
              //totalInvoice += double.Parse(rdr["price"].ToString());
              invoiceDataGrid.Rows.Add(rdr["date"].ToString().Split(' ')[0], "$" + String.Format("{0:0.00}", rdr["price"].ToString()), rdr["invoiceNo"].ToString());
              totalInvoice += double.Parse(rdr["price"].ToString());
            }
          }
        }
        catch (Exception ex)
        {
          DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
        }
        conn.Close();
      }


      topDataGrid.Rows.Add("", "$" + String.Format("{0:0.00}", totalCosts), "$" + String.Format("{0:0.00}", totalActualCosts),
          "$" + String.Format("{0:0.00}", totalCosts - totalActualCosts),
          String.Format("{0:0.00}", (totalCosts - totalActualCosts) / totalActualCosts * 100) + "%",
          "$" + String.Format("{0:0.00}", totalInvoice),
          "$" + String.Format("{0:0.00}", totalInvoice - totalActualCosts),
          String.Format("{0:0.00}", (totalInvoice) / totalActualCosts * 100) + "%");

      labourCost = totalCost;

      totalCost += 23.35;
      String timer = String.Format("SELECT * FROM jobTiming WHERE jobNo = {0} AND action = 'START' ORDER BY time;", jobNo);

      using (MySqlConnection conn = connectMySql())
      {
        try
        {
          conn.Open();
          MySqlDataAdapter sqlDa = new MySqlDataAdapter(parts, conn);

          DataTable dtbl = new DataTable();
          sqlDa.Fill(dtbl);
          //estimatedDataGrid.DataSource = dtbl;

          MySqlCommand cmd = new MySqlCommand(parts, conn);
          using (MySqlDataReader rdr = cmd.ExecuteReader())
          {
            while (rdr.Read())
            {
              totalCost += double.Parse(rdr["buyPrice"].ToString());
              totalinvoice += double.Parse(rdr["sellPrice"].ToString());
            }
          }
        }
        catch (Exception ex)
        {
          errors += "ERROR: At Least One Product Used has no pricing info.\n";
          incompleteLabel.Visible = true;
          incompleteLabel.Text = "(Incomplete)";
          DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
        }
        conn.Close();
      }

      double profit = totalinvoice - totalCost;
      double percent = profit / totalCost * 100;

      if (errors != "")
      {
        ErrorLabel.Text = errors;
        ErrorLabel.Visible = true;
      }

      totalLabel.Text = "Total Cost: $" + totalCost.ToString();
      invoicedLabel.Text = "Invoiced: $" + totalinvoice.ToString();
      profitLabel.Text = "Profit/Loss: $" + (profit).ToString();
      percentLabel.Text = "Percentage: " + String.Format("{0:0.00}", percent) + "%";
      reset_all_fields();
    }

    /*Check if String entered into function is a number
     */
    public bool IsNumber(String number)
    {
      return number.All(char.IsNumber);
    }

    /*reset_all_fields method*/
    private void reset_all_fields()
    {

    }

    private void completeJob_Click(object sender, EventArgs e)
    {
      try
      {
        if (estimatedDataGrid.SelectedRows[0].Cells[0].Value != null)
        {

        }
      }
      catch { }
      return;
    }

    private void refreshButton_Click(object sender, EventArgs e)
    {

    }

    private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {

    }

    private void BackCosting_Load(object sender, EventArgs e)
    {

    }

    private void labourLabel_Click(object sender, EventArgs e)
    {

    }

    private void signOffButton_Click(object sender, EventArgs e)
    {
      if (GWMS.getAdminStatus())
      {
        DialogResult dr = MessageBox.Show("Are you sure you want to sign off this Job? Job data cannot be changed until the job has been opened again.", "Confirm?", MessageBoxButtons.YesNo);
        if (dr == DialogResult.Yes)
        {
          String costing = String.Format("INSERT INTO jobCost VALUES ({0}, '{1}', {2}, {3}, '{4}', '{5}');",
              jobNo, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), fixedCost, labourCost, totalTime, GWMS.StaffID);

          //MessageBox.Show(costing);

          using (MySqlConnection conn = connectMySql())
          {
            try
            {
              conn.Open();
              MySqlCommand cmd = new MySqlCommand(costing, conn);
              cmd.ExecuteReader();
              signOffButton.Enabled = false;
            }
            catch (Exception ex)
            {
              MessageBox.Show("An error occured when trying to complete this job. Please try again.");
              DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
            }
            conn.Close();
          }
        }
      }
      else
      {
        MessageBox.Show("You must be an admin to sign off a Job.");
      }
    }

    private void estimatedDataGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
    {

    }

    private void estimatedDataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
    {
      if (e.RowIndex >= 0)
      {
        if (estimatedDataGrid.Rows[e.RowIndex].Cells[3].Value.ToString() == "True")
        {
          estimatedDataGrid.Rows[e.RowIndex].Cells[3].Value = false;
        }
        else
        {
          estimatedDataGrid.Rows[e.RowIndex].Cells[3].Value = true;
        }
      }
    }
  }
}
