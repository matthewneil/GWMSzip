﻿namespace workshop_orders
{
  partial class ErrorView
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
      this.toolstrip = new System.Windows.Forms.ToolStrip();
      this.tsBack = new System.Windows.Forms.ToolStripButton();
      this.tsDelete = new System.Windows.Forms.ToolStripButton();
      this.tsRefresh = new System.Windows.Forms.ToolStripButton();
      this.pnlFilter = new System.Windows.Forms.Panel();
      this.gbFilter = new System.Windows.Forms.GroupBox();
      this.label2 = new System.Windows.Forms.Label();
      this.cmbStaff = new System.Windows.Forms.ComboBox();
      this.label1 = new System.Windows.Forms.Label();
      this.cmbModule = new System.Windows.Forms.ComboBox();
      this.cmbCode = new System.Windows.Forms.ComboBox();
      this.label40 = new System.Windows.Forms.Label();
      this.pnlData = new System.Windows.Forms.Panel();
      this.dgvErrors = new System.Windows.Forms.DataGridView();
      this.ErrorID = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Code = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Message = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Module = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Function = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Command = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Staff = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.toolstrip.SuspendLayout();
      this.pnlFilter.SuspendLayout();
      this.gbFilter.SuspendLayout();
      this.pnlData.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgvErrors)).BeginInit();
      this.SuspendLayout();
      // 
      // toolstrip
      // 
      this.toolstrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsBack,
            this.tsDelete,
            this.tsRefresh});
      this.toolstrip.Location = new System.Drawing.Point(0, 0);
      this.toolstrip.Name = "toolstrip";
      this.toolstrip.Size = new System.Drawing.Size(1790, 39);
      this.toolstrip.TabIndex = 8;
      this.toolstrip.Text = "toolStrip1";
      // 
      // tsBack
      // 
      this.tsBack.Image = global::workshop_orders.Properties.Resources.back;
      this.tsBack.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsBack.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsBack.Name = "tsBack";
      this.tsBack.Size = new System.Drawing.Size(68, 36);
      this.tsBack.Text = "Back";
      this.tsBack.Click += new System.EventHandler(this.tsBack_Click);
      // 
      // tsDelete
      // 
      this.tsDelete.Image = global::workshop_orders.Properties.Resources.delete;
      this.tsDelete.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsDelete.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsDelete.Name = "tsDelete";
      this.tsDelete.Size = new System.Drawing.Size(76, 36);
      this.tsDelete.Text = "Delete";
      this.tsDelete.Click += new System.EventHandler(this.tsDelete_Click);
      // 
      // tsRefresh
      // 
      this.tsRefresh.Image = global::workshop_orders.Properties.Resources.refresh;
      this.tsRefresh.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsRefresh.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsRefresh.Name = "tsRefresh";
      this.tsRefresh.Size = new System.Drawing.Size(82, 36);
      this.tsRefresh.Text = "Refresh";
      this.tsRefresh.Click += new System.EventHandler(this.tsRefresh_Click);
      // 
      // pnlFilter
      // 
      this.pnlFilter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(210)))));
      this.pnlFilter.Controls.Add(this.gbFilter);
      this.pnlFilter.Dock = System.Windows.Forms.DockStyle.Left;
      this.pnlFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.pnlFilter.Location = new System.Drawing.Point(0, 39);
      this.pnlFilter.Name = "pnlFilter";
      this.pnlFilter.Size = new System.Drawing.Size(237, 797);
      this.pnlFilter.TabIndex = 9;
      // 
      // gbFilter
      // 
      this.gbFilter.Controls.Add(this.label2);
      this.gbFilter.Controls.Add(this.cmbStaff);
      this.gbFilter.Controls.Add(this.label1);
      this.gbFilter.Controls.Add(this.cmbModule);
      this.gbFilter.Controls.Add(this.cmbCode);
      this.gbFilter.Controls.Add(this.label40);
      this.gbFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbFilter.ForeColor = System.Drawing.Color.White;
      this.gbFilter.Location = new System.Drawing.Point(7, 10);
      this.gbFilter.Name = "gbFilter";
      this.gbFilter.Size = new System.Drawing.Size(222, 179);
      this.gbFilter.TabIndex = 0;
      this.gbFilter.TabStop = false;
      this.gbFilter.Text = "Filters";
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label2.ForeColor = System.Drawing.Color.White;
      this.label2.Location = new System.Drawing.Point(9, 122);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(39, 16);
      this.label2.TabIndex = 9;
      this.label2.Text = "Staff";
      // 
      // cmbStaff
      // 
      this.cmbStaff.DisplayMember = "textfield";
      this.cmbStaff.DropDownHeight = 350;
      this.cmbStaff.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbStaff.FormattingEnabled = true;
      this.cmbStaff.IntegralHeight = false;
      this.cmbStaff.Items.AddRange(new object[] {
            "All"});
      this.cmbStaff.Location = new System.Drawing.Point(12, 141);
      this.cmbStaff.Name = "cmbStaff";
      this.cmbStaff.Size = new System.Drawing.Size(200, 24);
      this.cmbStaff.TabIndex = 8;
      this.cmbStaff.Text = "<select>";
      this.cmbStaff.ValueMember = "datafield";
      this.cmbStaff.SelectedIndexChanged += new System.EventHandler(this.cmbStaff_SelectedIndexChanged);
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label1.ForeColor = System.Drawing.Color.White;
      this.label1.Location = new System.Drawing.Point(9, 71);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(59, 16);
      this.label1.TabIndex = 7;
      this.label1.Text = "Module";
      // 
      // cmbModule
      // 
      this.cmbModule.DisplayMember = "datafield";
      this.cmbModule.DropDownHeight = 350;
      this.cmbModule.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbModule.FormattingEnabled = true;
      this.cmbModule.IntegralHeight = false;
      this.cmbModule.Location = new System.Drawing.Point(12, 90);
      this.cmbModule.Name = "cmbModule";
      this.cmbModule.Size = new System.Drawing.Size(200, 24);
      this.cmbModule.TabIndex = 6;
      this.cmbModule.Text = "<select>";
      this.cmbModule.ValueMember = "datafield";
      this.cmbModule.SelectedIndexChanged += new System.EventHandler(this.cmbModule_SelectedIndexChanged);
      // 
      // cmbCode
      // 
      this.cmbCode.DisplayMember = "textfield";
      this.cmbCode.DropDownHeight = 350;
      this.cmbCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbCode.FormattingEnabled = true;
      this.cmbCode.IntegralHeight = false;
      this.cmbCode.Items.AddRange(new object[] {
            "All"});
      this.cmbCode.Location = new System.Drawing.Point(12, 38);
      this.cmbCode.Name = "cmbCode";
      this.cmbCode.Size = new System.Drawing.Size(200, 24);
      this.cmbCode.TabIndex = 5;
      this.cmbCode.Text = "<select>";
      this.cmbCode.ValueMember = "datafield";
      this.cmbCode.SelectedIndexChanged += new System.EventHandler(this.cmbCode_SelectedIndexChanged);
      // 
      // label40
      // 
      this.label40.AutoSize = true;
      this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label40.ForeColor = System.Drawing.Color.White;
      this.label40.Location = new System.Drawing.Point(9, 19);
      this.label40.Name = "label40";
      this.label40.Size = new System.Drawing.Size(45, 16);
      this.label40.TabIndex = 4;
      this.label40.Text = "Code";
      // 
      // pnlData
      // 
      this.pnlData.Controls.Add(this.dgvErrors);
      this.pnlData.Dock = System.Windows.Forms.DockStyle.Fill;
      this.pnlData.Location = new System.Drawing.Point(237, 39);
      this.pnlData.Name = "pnlData";
      this.pnlData.Size = new System.Drawing.Size(1553, 797);
      this.pnlData.TabIndex = 10;
      // 
      // dgvErrors
      // 
      this.dgvErrors.AllowUserToAddRows = false;
      this.dgvErrors.AllowUserToDeleteRows = false;
      dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
      this.dgvErrors.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
      this.dgvErrors.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
      dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
      dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
      dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
      dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
      dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
      this.dgvErrors.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
      this.dgvErrors.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvErrors.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ErrorID,
            this.Code,
            this.Message,
            this.Module,
            this.Function,
            this.Command,
            this.Staff,
            this.Date});
      dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
      dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
      dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
      dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
      dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
      dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
      this.dgvErrors.DefaultCellStyle = dataGridViewCellStyle3;
      this.dgvErrors.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dgvErrors.Location = new System.Drawing.Point(0, 0);
      this.dgvErrors.Name = "dgvErrors";
      this.dgvErrors.RowHeadersWidth = 10;
      this.dgvErrors.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
      this.dgvErrors.Size = new System.Drawing.Size(1553, 797);
      this.dgvErrors.TabIndex = 0;
      // 
      // ErrorID
      // 
      this.ErrorID.DataPropertyName = "ErrorID";
      this.ErrorID.HeaderText = "ErrorID";
      this.ErrorID.Name = "ErrorID";
      this.ErrorID.ReadOnly = true;
      this.ErrorID.Visible = false;
      // 
      // Code
      // 
      this.Code.DataPropertyName = "errCode";
      this.Code.HeaderText = "Code";
      this.Code.Name = "Code";
      this.Code.ReadOnly = true;
      // 
      // Message
      // 
      this.Message.DataPropertyName = "errMessage";
      this.Message.HeaderText = "Message";
      this.Message.Name = "Message";
      this.Message.ReadOnly = true;
      this.Message.Width = 500;
      // 
      // Module
      // 
      this.Module.DataPropertyName = "errModule";
      this.Module.HeaderText = "Module";
      this.Module.Name = "Module";
      this.Module.ReadOnly = true;
      this.Module.Width = 120;
      // 
      // Function
      // 
      this.Function.DataPropertyName = "errFunction";
      this.Function.HeaderText = "Function";
      this.Function.Name = "Function";
      this.Function.ReadOnly = true;
      this.Function.Width = 150;
      // 
      // Command
      // 
      this.Command.DataPropertyName = "errCommand";
      this.Command.HeaderText = "Command";
      this.Command.Name = "Command";
      this.Command.ReadOnly = true;
      this.Command.Width = 300;
      // 
      // Staff
      // 
      this.Staff.DataPropertyName = "StaffUsername";
      this.Staff.HeaderText = "Staff";
      this.Staff.Name = "Staff";
      this.Staff.ReadOnly = true;
      // 
      // Date
      // 
      this.Date.DataPropertyName = "errDate";
      this.Date.HeaderText = "Date";
      this.Date.Name = "Date";
      this.Date.ReadOnly = true;
      this.Date.Width = 150;
      // 
      // ErrorView
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(1790, 836);
      this.ControlBox = false;
      this.Controls.Add(this.pnlData);
      this.Controls.Add(this.pnlFilter);
      this.Controls.Add(this.toolstrip);
      this.MaximizeBox = false;
      this.Name = "ErrorView";
      this.ShowIcon = false;
      this.ShowInTaskbar = false;
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
      this.Text = "Errors";
      this.toolstrip.ResumeLayout(false);
      this.toolstrip.PerformLayout();
      this.pnlFilter.ResumeLayout(false);
      this.gbFilter.ResumeLayout(false);
      this.gbFilter.PerformLayout();
      this.pnlData.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.dgvErrors)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.ToolStrip toolstrip;
    private System.Windows.Forms.ToolStripButton tsBack;
    private System.Windows.Forms.Panel pnlFilter;
    private System.Windows.Forms.GroupBox gbFilter;
    private System.Windows.Forms.ComboBox cmbCode;
    private System.Windows.Forms.Label label40;
    private System.Windows.Forms.Panel pnlData;
    private System.Windows.Forms.DataGridView dgvErrors;
    private System.Windows.Forms.ToolStripButton tsDelete;
    private System.Windows.Forms.ToolStripButton tsRefresh;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.ComboBox cmbStaff;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.ComboBox cmbModule;
    private System.Windows.Forms.DataGridViewTextBoxColumn ErrorID;
    private System.Windows.Forms.DataGridViewTextBoxColumn Code;
    private System.Windows.Forms.DataGridViewTextBoxColumn Message;
    private System.Windows.Forms.DataGridViewTextBoxColumn Module;
    private System.Windows.Forms.DataGridViewTextBoxColumn Function;
    private System.Windows.Forms.DataGridViewTextBoxColumn Command;
    private System.Windows.Forms.DataGridViewTextBoxColumn Staff;
    private System.Windows.Forms.DataGridViewTextBoxColumn Date;
  }
}