﻿using System;
using System.Windows.Forms;
using System.Data;

namespace workshop_orders
{
  public partial class Quotes : Form
  {
    private bool fbPageLoad = false;
    private int fiQuoteNo = 0;
    public Quotes()
    {
      InitializeComponent();
      fbPageLoad = false;
      dtpFromDate.Value = DateTime.Now.AddYears(-1);
      dtpToDate.Value = DateTime.Now;
      GetStaff();
      GetCustomers();
      fbPageLoad = true;
      LoadQuotes();
    }
    public void GetCustomers()
    {
      DataTable dt = DataAccess.ExecuteDataTable("SELECT customerID as datafield, CustomerName as textfield FROM vwcustomer WHERE customerID IN (SELECT customerID FROM quote) ORDER BY CustomerName;");
      DataAccess.AddSelect(dt);
      cmbCustomer.DataSource = dt;
    }
    public void GetStaff()
    {
      DataTable dt = DataAccess.ExecuteDataTable("SELECT staffid as datafield, StaffFullName as textfield FROM staff WHERE StaffActive = 1 ORDER BY StaffFullName;");
      DataAccess.AddSelect(dt);
      cmbStaff.DataSource = dt;
    }
    public void LoadQuotes()
    {
      string sSQL = "";
      DataTable dt;
      try
      {
        if (cmbStaff.SelectedIndex > 0)
        {
          sSQL += " AND staffID = '" + cmbStaff.SelectedValue + "' ";
        }
        if (cmbStatus.SelectedIndex > 0)
        {
          sSQL += GetStatus();
        }
        if (cmbCustomer.SelectedIndex > 0)
        {
          sSQL += " AND customerID = '" + cmbCustomer.SelectedValue + "' ";
        }
        //sSQL + " AND dateCreated >= '" + dtp
        dgvData.Rows.Clear();
        dt = DataAccess.ExecuteDataTable(
          String.Format("SELECT QuoteNo, dateCreated, CustomerName, reference, quoteType, StatusName, QuotePrice, CostPrice, MarginP, Comments, StaffFullName " +
          "FROM vwQuote " +
          "WHERE 1=1 " + sSQL + " AND dateCreated BETWEEN '{0}' AND '{1} 23:59:59' ORDER BY QuoteNo DESC;", 
          dtpFromDate.Value.ToString("yyyy-MM-dd"), dtpToDate.Value.ToString("yyyy-MM-dd")));
        if (dt != null && dt.Rows.Count > 0)
        {
          dgvData.AllowUserToAddRows = true;
          foreach (DataRow row in dt.Rows)
          {
            DataGridViewRow drow = (DataGridViewRow)dgvData.Rows[0].Clone();
            drow.Cells[0].Value = int.Parse(row[0].ToString());
            drow.Cells[1].Value = DateTime.Parse(row[1].ToString());
            drow.Cells[2].Value = row[2].ToString();
            drow.Cells[3].Value = row[3].ToString();
            drow.Cells[4].Value = row[4].ToString();
            drow.Cells[5].Value = row[5].ToString();
            drow.Cells[6].Value = decimal.Parse(row[6].ToString());
            drow.Cells[7].Value = decimal.Parse(row[7].ToString());
            drow.Cells[8].Value = decimal.Parse(row[8].ToString());
            drow.Cells[9].Value = row["StaffFullName"].ToString();
            drow.Cells[12].Value = row["Comments"].ToString();
            dgvData.Rows.Add(drow);
          }
        }
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }
      finally
      {
        dgvData.AllowUserToAddRows = false;
        SetSelectedRow();
      }
    }

    private void SetSelectedRow()
    {
      if (dgvData != null && dgvData.Rows.Count > 0)
      {
        dgvData.Rows[0].Selected = true;
        foreach (DataGridViewRow drow in dgvData.Rows)
        {
          if ((int)drow.Cells[0].Value == fiQuoteNo)
          {
            drow.Selected = true;
            return;
          }
        }
        dgvData.FirstDisplayedScrollingRowIndex = dgvData.SelectedRows[0].Index;
      }

    }
    private string GetStatus()
    {
      switch (cmbStatus.SelectedItem)
      {
        case "Accepted":
          return "AND StatusID = 2";
        case "Lost":
          return "AND StatusID = 3";
        case "Cancelled":
          return "AND StatusID = 4";
        case "Closed":
          return "AND StatusID = 5";
        case "New/Pending":
          return "AND StatusID = 1";
        default:
          return "";
      }
    }


    private void searchText_TextChanged(object sender, EventArgs e)
    {
      //LoadQuotes();
    }

    private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
    {
      LoadQuotes();
    }

    private void startDateTime_ValueChanged(object sender, EventArgs e)
    {
      LoadQuotes();
    }

    private void endDateTime_ValueChanged(object sender, EventArgs e)
    {
      LoadQuotes();
    }

    private void BackToolStripButton_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private void NewToolStripButton_Click(object sender, EventArgs e)
    {

      if (FormManagement.IsFormOpen("QuoteDetail") == true)
      {
        DataAccess.ShowMessage("You are currently editing a quote. Please save and close before creating a new quote.");
        FormManagement.ShowChildForm("QuoteDetail");
      }
      else
      {
        try
        {
          FormManagement.ShowDialogForm(new QuoteNew());
        }
        catch (Exception ex)
        {
          DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
            System.Reflection.MethodBase.GetCurrentMethod().Name, "");
        }
      }

    }

    private void StaffCombo_SelectedIndexChanged(object sender, EventArgs e)
    {
      if (fbPageLoad == true)
      {
        LoadQuotes();
      }
    }

    private void QuoteGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      EditQuote();
    }

    private void tsRefresh_Click(object sender, EventArgs e)
    {
      LoadQuotes();
    }
    private void tsDelete_Click(object sender, EventArgs e)
    {
      //Delete Quote
    }
    private void tsEdit_Click(object sender, EventArgs e)
    {
      EditQuote();
    }
    private void EditQuote()
    {
      if (dgvData.SelectedRows.Count == 1 && dgvData.SelectedRows[0].Index > -1)
      {
        if (FormManagement.IsFormOpen("QuoteDetail") == true)
        {
          DataAccess.ShowMessage("You are currently editing a quote. Please save and close before creating/opening a new quote.");
          FormManagement.ShowChildForm("QuoteDetail");
        }
        else
        {
          try
          {
            fiQuoteNo = (int)dgvData.SelectedRows[0].Cells[0].Value;
            ShowQuoteDetail(fiQuoteNo);

          }
          catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
      }
      else
      {
        MessageBox.Show("Please select a quote to edit", "Missing Selection", MessageBoxButtons.OK);
      }

    }
    private void btnQuote1_Click(object sender, EventArgs e)
    {
      FindQuote();
    }
    private void btnQuote_Click(object sender, EventArgs e)
    {
      FindQuote();
    }
    private void FindQuote()
    {
      if (txtQuote.Text != "" && DataAccess.IsNumeric(txtQuote.Text) && int.Parse(txtQuote.Text) > 999)
      {
        DataTable dt = DataAccess.ExecuteDataTable("SELECT * FROM quote WHERE QuoteNo = " + txtQuote.Text);
        if (dt != null && dt.Rows.Count > 0)
        {
          if (FormManagement.IsFormOpen("QuoteDetail") == true)
          {
            DataAccess.ShowMessage("You are currently editing a quote. Please save and close before creating a new quote.");
            FormManagement.ShowChildForm("QuoteDetail");
            return;
          }
          else
          {
            fiQuoteNo = int.Parse(txtQuote.Text);
            ShowQuoteDetail(fiQuoteNo);
            
            return;
          }
        }
      }
      MessageBox.Show("PLease enter a valid Quote Number", "Invalid Quote", MessageBoxButtons.OK);
    }
    private void txtQuote_KeyDown(object sender, KeyEventArgs e)
    {
      if (e.KeyCode == Keys.Enter)
      {
        FindQuote();
      }
    }
    private void ShowQuoteDetail(int QuoteNo)
    {
      FormManagement.ShowChildForm(new QuoteDetail(QuoteNo, this));

    }
    private void dgvData_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      EditQuote();
    }

    private void cmbCustomer_SelectedIndexChanged(object sender, EventArgs e)
    {
      if (fbPageLoad == true)
      {
        LoadQuotes();
      }
    }
  }
}
