﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workshop_orders
{
  public partial class ReportGeneration : Form
  {
    public ReportGeneration()
    {
      InitializeComponent();

      cmbStaff.DataSource = DataAccess.ExecuteDataTable("SELECT StaffID AS datafield, StaffFullName AS textfield FROM staff WHERE StaffActive = 1 ORDER BY StaffFullName");
      LoadReport();
      
    }

    public void LoadReport()
    {

      dgvLoggedHours.Rows.Clear();
      dgvLoggedHours.Columns.Clear();
      dgvLoggedHours.Columns.Add("chLogin", "Log in");
      dgvLoggedHours.Columns.Add("chLogout", "Log out");
      dgvLoggedHours.Columns.Add("chInterval", "Interval");



      DataTable dt = DataAccess.ExecuteDataTable(String.Format(
        "SELECT MIN(StartTime) AS start, MAX(StartTime) AS end " +
        "FROM labour " +
        "WHERE StaffID = {0} " +
        "AND StartTime BETWEEN '{1}' AND '{2} 23:59:59' " +
        "GROUP BY YEAR(StartTime), MONTH(StartTime), DAY(StartTime)",
        cmbStaff.SelectedValue, dtpStart.Value.ToString("yyyy-MM-dd"), dtpEnd.Value.ToString("yyyy-MM-dd")));

      if (dt != null && dt.Rows.Count > 0)
      {
        foreach (DataRow row in dt.Rows)
        {
          dgvLoggedHours.Rows.Add(row[0].ToString(), row[1].ToString(), DateTime.Parse(row[1].ToString()) - DateTime.Parse(row[0].ToString()));


        }
      }


      TimeSpan PhysTime = TimeSpan.Zero;

      dgvJob.Rows.Clear();
      dgvJob.Columns.Clear();
      dgvJob.Columns.Add("chWorkType", "Work Type");
      dgvJob.Columns.Add("chJobDesc", "Job Desc");
      dgvJob.Columns.Add("chDate", "Date");
      dgvJob.Columns.Add("chQuoted", "Quoted");
      dgvJob.Columns.Add("chActual", "Actual");
      dgvJob.Columns.Add("chVariance", "Variance");
      dgvJob.Columns.Add("chPerformance", "Performance");

      DataTable dt2 = DataAccess.ExecuteDataTable(String.Format(
        "SELECT TypeName, CONCAT(JobID, ': ', CustomerName) AS job, StartTime, EndTime " +
        "FROM labour l " +
        "INNER JOIN vwjob j ON l.JobTaskID = j.JobID " +
        "WHERE l.StaffID = {0} " +
        "AND StartTime BETWEEN '{1}' AND '{2} 23:59:59' " +
        "AND l.JobTaskID >= 1000 " + //anything below 1000 is not a job
        "ORDER BY StartTime",
        cmbStaff.SelectedValue, dtpStart.Value.ToString("yyyy-MM-dd"), dtpEnd.Value.ToString("yyyy-MM-dd")));

      if (dt2 != null)
      {
        foreach (DataRow row in dt2.Rows)
        {
          dgvJob.Rows.Add(row["TypeName"].ToString(), row["job"].ToString(), row["StartTime"].ToString(), "1:00:00",
            DateTime.Parse(row["EndTime"].ToString()) - DateTime.Parse(row["StartTime"].ToString()), 
            (DateTime.Parse(row["EndTime"].ToString()) - DateTime.Parse(row["StartTime"].ToString())) - TimeSpan.Parse("1:00:00"),
            "0%");


          PhysTime += DateTime.Parse(row["EndTime"].ToString()) - DateTime.Parse(row["StartTime"].ToString());

        }

      }

      TimeSpan AdminTime = TimeSpan.Zero;
      dgvAdmin.Rows.Clear();
      dgvAdmin.Columns.Clear();
      dgvAdmin.Columns.Add("chAdminTask", "Admin Task");
      dgvAdmin.Columns.Add("chDateAdmin", "Date");
      dgvAdmin.Columns.Add("chTimeTaken", "Time Taken");

      DataTable dt3 = DataAccess.ExecuteDataTable(String.Format(
        "SELECT AdminTaskName, StartTime, EndTime " +
        "FROM labour l " +
        "INNER JOIN admintask a ON l.JobTaskID = a.AdminTaskID " +
        "WHERE l.StaffID = {0} " +
        "AND StartTime BETWEEN '{1}' AND '{2} 23:59:59' " +
        "AND l.JobTaskID < 1000 " +
        "ORDER BY StartTime",
        cmbStaff.SelectedValue, dtpStart.Value.ToString("yyyy-MM-dd"), dtpEnd.Value.ToString("yyyy-MM-dd")));

      if (dt3 != null)
      {
        foreach (DataRow row in dt3.Rows)
        {
          dgvAdmin.Rows.Add(row["AdminTaskName"].ToString(), row["StartTime"].ToString(), DateTime.Parse(row["EndTime"].ToString()) - DateTime.Parse(row["StartTime"].ToString()));
          AdminTime += DateTime.Parse(row["EndTime"].ToString()) - DateTime.Parse(row["StartTime"].ToString());

        }

      }

      chPerformance.Series.Clear();
      chPerformance.Series.Add("Std. Time");
      chPerformance.Series.Add("Phys. Time");
      chPerformance.Series.Add("Admin Time");

      chPerformance.Series["Std. Time"].Points.AddXY(cmbStaff.Text, 1);
      chPerformance.Series["Phys. Time"].Points.AddXY(cmbStaff.Text, PhysTime.TotalHours);
      chPerformance.Series["Admin Time"].Points.AddXY(cmbStaff.Text, AdminTime.TotalHours);

      chPerformance.ResetAutoValues();
    }

    private void cmbStaff_SelectedIndexChanged(object sender, EventArgs e)
    {
      LoadReport();
    }

    private void dtpStart_ValueChanged(object sender, EventArgs e)
    {
      if (!chkEnd.Checked)
      {
        dtpEnd.Value = dtpStart.Value;
      }    
      else if (dtpStart.Value > dtpEnd.Value)
      {
        dtpEnd.Value = dtpStart.Value;
      }
      LoadReport();
    }

    private void dtpEnd_ValueChanged(object sender, EventArgs e)
    {
      if(dtpEnd.Value < dtpStart.Value)
      {
        dtpEnd.Value = dtpStart.Value;
      }
      LoadReport();
    }

    private void chkEnd_CheckedChanged(object sender, EventArgs e)
    {
      dtpEnd.Enabled = chkEnd.Checked;
    }
  }
}
