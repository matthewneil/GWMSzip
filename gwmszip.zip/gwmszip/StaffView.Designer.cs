﻿namespace workshop_orders
{
  partial class StaffView
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
      this.dgvStaff = new System.Windows.Forms.DataGridView();
      this.toolStrip1 = new System.Windows.Forms.ToolStrip();
      this.pnlFilter = new System.Windows.Forms.Panel();
      this.gbFilter = new System.Windows.Forms.GroupBox();
      this.cmbStatus = new System.Windows.Forms.ComboBox();
      this.label40 = new System.Windows.Forms.Label();
      this.pnlData = new System.Windows.Forms.Panel();
      this.tsClose = new System.Windows.Forms.ToolStripButton();
      this.tsNew = new System.Windows.Forms.ToolStripButton();
      this.tsEdit = new System.Windows.Forms.ToolStripButton();
      this.tsRefresh = new System.Windows.Forms.ToolStripButton();
      this.chItemID = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chGroupID = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chPrice = new System.Windows.Forms.DataGridViewCheckBoxColumn();
      this.chUOM = new System.Windows.Forms.DataGridViewCheckBoxColumn();
      ((System.ComponentModel.ISupportInitialize)(this.dgvStaff)).BeginInit();
      this.toolStrip1.SuspendLayout();
      this.pnlFilter.SuspendLayout();
      this.gbFilter.SuspendLayout();
      this.pnlData.SuspendLayout();
      this.SuspendLayout();
      // 
      // dgvStaff
      // 
      this.dgvStaff.AllowUserToAddRows = false;
      this.dgvStaff.AllowUserToDeleteRows = false;
      dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
      this.dgvStaff.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
      this.dgvStaff.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
      dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
      dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
      dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
      dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
      dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
      this.dgvStaff.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
      this.dgvStaff.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvStaff.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.chItemID,
            this.chGroupID,
            this.chCode,
            this.chDescription,
            this.chPrice,
            this.chUOM});
      dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
      dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
      dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
      dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
      dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
      dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
      this.dgvStaff.DefaultCellStyle = dataGridViewCellStyle5;
      this.dgvStaff.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dgvStaff.Location = new System.Drawing.Point(0, 0);
      this.dgvStaff.Name = "dgvStaff";
      dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
      dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
      dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
      dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
      dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
      dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
      this.dgvStaff.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
      this.dgvStaff.RowHeadersWidth = 20;
      dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.dgvStaff.RowsDefaultCellStyle = dataGridViewCellStyle7;
      this.dgvStaff.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
      this.dgvStaff.Size = new System.Drawing.Size(941, 531);
      this.dgvStaff.TabIndex = 0;
      this.dgvStaff.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvItems_CellDoubleClick);
      // 
      // toolStrip1
      // 
      this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsClose,
            this.tsNew,
            this.tsEdit,
            this.tsRefresh});
      this.toolStrip1.Location = new System.Drawing.Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new System.Drawing.Size(1178, 39);
      this.toolStrip1.TabIndex = 1;
      this.toolStrip1.Text = "toolStrip1";
      // 
      // pnlFilter
      // 
      this.pnlFilter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(210)))));
      this.pnlFilter.Controls.Add(this.gbFilter);
      this.pnlFilter.Dock = System.Windows.Forms.DockStyle.Left;
      this.pnlFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.pnlFilter.Location = new System.Drawing.Point(0, 39);
      this.pnlFilter.Name = "pnlFilter";
      this.pnlFilter.Size = new System.Drawing.Size(237, 531);
      this.pnlFilter.TabIndex = 6;
      // 
      // gbFilter
      // 
      this.gbFilter.Controls.Add(this.cmbStatus);
      this.gbFilter.Controls.Add(this.label40);
      this.gbFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbFilter.ForeColor = System.Drawing.Color.White;
      this.gbFilter.Location = new System.Drawing.Point(7, 10);
      this.gbFilter.Name = "gbFilter";
      this.gbFilter.Size = new System.Drawing.Size(222, 76);
      this.gbFilter.TabIndex = 0;
      this.gbFilter.TabStop = false;
      this.gbFilter.Text = "Filters";
      // 
      // cmbStatus
      // 
      this.cmbStatus.DropDownHeight = 350;
      this.cmbStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbStatus.FormattingEnabled = true;
      this.cmbStatus.IntegralHeight = false;
      this.cmbStatus.Items.AddRange(new object[] {
            "Active",
            "Admin",
            "Regular User",
            "Workshop",
            "Inactive"});
      this.cmbStatus.Location = new System.Drawing.Point(12, 38);
      this.cmbStatus.Name = "cmbStatus";
      this.cmbStatus.Size = new System.Drawing.Size(200, 28);
      this.cmbStatus.TabIndex = 5;
      this.cmbStatus.Text = "Active";
      this.cmbStatus.SelectedIndexChanged += new System.EventHandler(this.cmbStatus_SelectedIndexChanged);
      // 
      // label40
      // 
      this.label40.AutoSize = true;
      this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label40.ForeColor = System.Drawing.Color.White;
      this.label40.Location = new System.Drawing.Point(9, 19);
      this.label40.Name = "label40";
      this.label40.Size = new System.Drawing.Size(50, 16);
      this.label40.TabIndex = 4;
      this.label40.Text = "Group";
      // 
      // pnlData
      // 
      this.pnlData.Controls.Add(this.dgvStaff);
      this.pnlData.Dock = System.Windows.Forms.DockStyle.Fill;
      this.pnlData.Location = new System.Drawing.Point(237, 39);
      this.pnlData.Name = "pnlData";
      this.pnlData.Size = new System.Drawing.Size(941, 531);
      this.pnlData.TabIndex = 7;
      // 
      // tsClose
      // 
      this.tsClose.Image = global::workshop_orders.Properties.Resources.back;
      this.tsClose.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsClose.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsClose.Name = "tsClose";
      this.tsClose.Size = new System.Drawing.Size(72, 36);
      this.tsClose.Text = "Close";
      this.tsClose.Click += new System.EventHandler(this.tbClose_Click);
      // 
      // tsNew
      // 
      this.tsNew.Image = global::workshop_orders.Properties.Resources.addnew;
      this.tsNew.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsNew.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsNew.Name = "tsNew";
      this.tsNew.Size = new System.Drawing.Size(67, 36);
      this.tsNew.Text = "New";
      this.tsNew.Click += new System.EventHandler(this.tsNew_Click);
      // 
      // tsEdit
      // 
      this.tsEdit.Image = global::workshop_orders.Properties.Resources.edit;
      this.tsEdit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsEdit.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsEdit.Name = "tsEdit";
      this.tsEdit.Size = new System.Drawing.Size(63, 36);
      this.tsEdit.Text = "Edit";
      this.tsEdit.Click += new System.EventHandler(this.tsEdit_Click);
      // 
      // tsRefresh
      // 
      this.tsRefresh.Image = global::workshop_orders.Properties.Resources.refresh;
      this.tsRefresh.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsRefresh.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsRefresh.Name = "tsRefresh";
      this.tsRefresh.Size = new System.Drawing.Size(82, 36);
      this.tsRefresh.Text = "Refresh";
      this.tsRefresh.Click += new System.EventHandler(this.tsRefresh_Click);
      // 
      // chItemID
      // 
      this.chItemID.DataPropertyName = "StaffID";
      this.chItemID.HeaderText = "ID";
      this.chItemID.Name = "chItemID";
      this.chItemID.ReadOnly = true;
      this.chItemID.Visible = false;
      this.chItemID.Width = 28;
      // 
      // chGroupID
      // 
      this.chGroupID.DataPropertyName = "StaffFullName";
      this.chGroupID.HeaderText = "Full Name";
      this.chGroupID.Name = "chGroupID";
      this.chGroupID.ReadOnly = true;
      this.chGroupID.Width = 200;
      // 
      // chCode
      // 
      this.chCode.DataPropertyName = "StaffUsername";
      this.chCode.HeaderText = "Login Name";
      this.chCode.Name = "chCode";
      this.chCode.ReadOnly = true;
      this.chCode.Width = 120;
      // 
      // chDescription
      // 
      this.chDescription.DataPropertyName = "StaffEmail";
      this.chDescription.HeaderText = "Email";
      this.chDescription.Name = "chDescription";
      this.chDescription.ReadOnly = true;
      this.chDescription.Width = 300;
      // 
      // chPrice
      // 
      this.chPrice.DataPropertyName = "StaffAdmin";
      dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
      dataGridViewCellStyle3.NullValue = "False";
      dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Transparent;
      this.chPrice.DefaultCellStyle = dataGridViewCellStyle3;
      this.chPrice.HeaderText = "Admin";
      this.chPrice.Name = "chPrice";
      this.chPrice.ReadOnly = true;
      this.chPrice.Resizable = System.Windows.Forms.DataGridViewTriState.True;
      this.chPrice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
      this.chPrice.Width = 74;
      // 
      // chUOM
      // 
      this.chUOM.DataPropertyName = "StaffWorkshop";
      dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
      dataGridViewCellStyle4.NullValue = false;
      dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.Transparent;
      this.chUOM.DefaultCellStyle = dataGridViewCellStyle4;
      this.chUOM.HeaderText = "Workshop";
      this.chUOM.Name = "chUOM";
      this.chUOM.ReadOnly = true;
      this.chUOM.Resizable = System.Windows.Forms.DataGridViewTriState.True;
      this.chUOM.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
      this.chUOM.Width = 103;
      // 
      // StaffView
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.ClientSize = new System.Drawing.Size(1178, 570);
      this.ControlBox = false;
      this.Controls.Add(this.pnlData);
      this.Controls.Add(this.pnlFilter);
      this.Controls.Add(this.toolStrip1);
      this.Name = "StaffView";
      this.ShowIcon = false;
      this.ShowInTaskbar = false;
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
      this.Text = "Staff";
      ((System.ComponentModel.ISupportInitialize)(this.dgvStaff)).EndInit();
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.pnlFilter.ResumeLayout(false);
      this.gbFilter.ResumeLayout(false);
      this.gbFilter.PerformLayout();
      this.pnlData.ResumeLayout(false);
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.DataGridView dgvStaff;
    private System.Windows.Forms.ToolStrip toolStrip1;
    private System.Windows.Forms.ToolStripButton tsClose;
    private System.Windows.Forms.ToolStripButton tsNew;
    private System.Windows.Forms.ToolStripButton tsRefresh;
    private System.Windows.Forms.ToolStripButton tsEdit;
    private System.Windows.Forms.Panel pnlFilter;
    private System.Windows.Forms.GroupBox gbFilter;
    private System.Windows.Forms.ComboBox cmbStatus;
    private System.Windows.Forms.Label label40;
    private System.Windows.Forms.Panel pnlData;
    private System.Windows.Forms.DataGridViewTextBoxColumn chItemID;
    private System.Windows.Forms.DataGridViewTextBoxColumn chGroupID;
    private System.Windows.Forms.DataGridViewTextBoxColumn chCode;
    private System.Windows.Forms.DataGridViewTextBoxColumn chDescription;
    private System.Windows.Forms.DataGridViewCheckBoxColumn chPrice;
    private System.Windows.Forms.DataGridViewCheckBoxColumn chUOM;
  }
}