﻿namespace workshop_orders
{
  partial class ItemView
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
      this.dgvItems = new System.Windows.Forms.DataGridView();
      this.toolStrip1 = new System.Windows.Forms.ToolStrip();
      this.tsClose = new System.Windows.Forms.ToolStripButton();
      this.tsNew = new System.Windows.Forms.ToolStripButton();
      this.tsEdit = new System.Windows.Forms.ToolStripButton();
      this.tsRefresh = new System.Windows.Forms.ToolStripButton();
      this.pnlFilter = new System.Windows.Forms.Panel();
      this.Panel3 = new System.Windows.Forms.Panel();
      this.btnQuote = new System.Windows.Forms.Button();
      this.btnCode = new System.Windows.Forms.Button();
      this.txtCode = new System.Windows.Forms.TextBox();
      this.lnkFind = new System.Windows.Forms.LinkLabel();
      this.gbFilter = new System.Windows.Forms.GroupBox();
      this.cmbStatus = new System.Windows.Forms.ComboBox();
      this.label40 = new System.Windows.Forms.Label();
      this.pnlData = new System.Windows.Forms.Panel();
      this.chItemID = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chGroupID = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chUOM = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chMinimum = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Allowance = new System.Windows.Forms.DataGridViewTextBoxColumn();
      ((System.ComponentModel.ISupportInitialize)(this.dgvItems)).BeginInit();
      this.toolStrip1.SuspendLayout();
      this.pnlFilter.SuspendLayout();
      this.Panel3.SuspendLayout();
      this.gbFilter.SuspendLayout();
      this.pnlData.SuspendLayout();
      this.SuspendLayout();
      // 
      // dgvItems
      // 
      this.dgvItems.AllowUserToAddRows = false;
      this.dgvItems.AllowUserToDeleteRows = false;
      dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
      this.dgvItems.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
      this.dgvItems.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
      this.dgvItems.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
      dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
      dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
      dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
      dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
      dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
      this.dgvItems.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
      this.dgvItems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvItems.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.chItemID,
            this.chGroupID,
            this.chCode,
            this.chDescription,
            this.chCost,
            this.chPrice,
            this.chUOM,
            this.chMinimum,
            this.Allowance});
      dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
      dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
      dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
      dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
      dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
      dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
      this.dgvItems.DefaultCellStyle = dataGridViewCellStyle5;
      this.dgvItems.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dgvItems.Location = new System.Drawing.Point(0, 0);
      this.dgvItems.Name = "dgvItems";
      dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
      dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
      dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
      dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
      dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
      dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
      this.dgvItems.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
      this.dgvItems.RowHeadersWidth = 20;
      dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.dgvItems.RowsDefaultCellStyle = dataGridViewCellStyle7;
      this.dgvItems.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
      this.dgvItems.Size = new System.Drawing.Size(941, 531);
      this.dgvItems.TabIndex = 0;
      this.dgvItems.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvItems_CellDoubleClick);
      // 
      // toolStrip1
      // 
      this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsClose,
            this.tsNew,
            this.tsEdit,
            this.tsRefresh});
      this.toolStrip1.Location = new System.Drawing.Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new System.Drawing.Size(1178, 39);
      this.toolStrip1.TabIndex = 1;
      this.toolStrip1.Text = "toolStrip1";
      // 
      // tsClose
      // 
      this.tsClose.Image = global::workshop_orders.Properties.Resources.back;
      this.tsClose.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsClose.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsClose.Name = "tsClose";
      this.tsClose.Size = new System.Drawing.Size(72, 36);
      this.tsClose.Text = "Close";
      this.tsClose.Click += new System.EventHandler(this.tbClose_Click);
      // 
      // tsNew
      // 
      this.tsNew.Image = global::workshop_orders.Properties.Resources.addnew;
      this.tsNew.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsNew.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsNew.Name = "tsNew";
      this.tsNew.Size = new System.Drawing.Size(67, 36);
      this.tsNew.Text = "New";
      this.tsNew.Click += new System.EventHandler(this.tsNew_Click);
      // 
      // tsEdit
      // 
      this.tsEdit.Image = global::workshop_orders.Properties.Resources.edit;
      this.tsEdit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsEdit.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsEdit.Name = "tsEdit";
      this.tsEdit.Size = new System.Drawing.Size(63, 36);
      this.tsEdit.Text = "Edit";
      this.tsEdit.Click += new System.EventHandler(this.tsEdit_Click);
      // 
      // tsRefresh
      // 
      this.tsRefresh.Image = global::workshop_orders.Properties.Resources.refresh;
      this.tsRefresh.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsRefresh.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsRefresh.Name = "tsRefresh";
      this.tsRefresh.Size = new System.Drawing.Size(82, 36);
      this.tsRefresh.Text = "Refresh";
      this.tsRefresh.Click += new System.EventHandler(this.tsRefresh_Click);
      // 
      // pnlFilter
      // 
      this.pnlFilter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(210)))));
      this.pnlFilter.Controls.Add(this.Panel3);
      this.pnlFilter.Controls.Add(this.gbFilter);
      this.pnlFilter.Dock = System.Windows.Forms.DockStyle.Left;
      this.pnlFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.pnlFilter.Location = new System.Drawing.Point(0, 39);
      this.pnlFilter.Name = "pnlFilter";
      this.pnlFilter.Size = new System.Drawing.Size(237, 531);
      this.pnlFilter.TabIndex = 6;
      // 
      // Panel3
      // 
      this.Panel3.BackColor = System.Drawing.Color.White;
      this.Panel3.Controls.Add(this.btnQuote);
      this.Panel3.Controls.Add(this.btnCode);
      this.Panel3.Controls.Add(this.txtCode);
      this.Panel3.Controls.Add(this.lnkFind);
      this.Panel3.Location = new System.Drawing.Point(12, 92);
      this.Panel3.Name = "Panel3";
      this.Panel3.Size = new System.Drawing.Size(205, 58);
      this.Panel3.TabIndex = 84;
      this.Panel3.Visible = false;
      // 
      // btnQuote
      // 
      this.btnQuote.Location = new System.Drawing.Point(173, 29);
      this.btnQuote.Name = "btnQuote";
      this.btnQuote.Size = new System.Drawing.Size(10, 20);
      this.btnQuote.TabIndex = 73;
      this.btnQuote.Text = "..";
      this.btnQuote.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      this.btnQuote.UseVisualStyleBackColor = true;
      // 
      // btnCode
      // 
      this.btnCode.BackColor = System.Drawing.Color.Transparent;
      this.btnCode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
      this.btnCode.Image = global::workshop_orders.Properties.Resources.find;
      this.btnCode.Location = new System.Drawing.Point(5, 5);
      this.btnCode.Name = "btnCode";
      this.btnCode.Size = new System.Drawing.Size(48, 48);
      this.btnCode.TabIndex = 0;
      this.btnCode.UseVisualStyleBackColor = false;
      this.btnCode.Click += new System.EventHandler(this.btnCode_Click);
      // 
      // txtCode
      // 
      this.txtCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtCode.Location = new System.Drawing.Point(59, 28);
      this.txtCode.Name = "txtCode";
      this.txtCode.Size = new System.Drawing.Size(108, 23);
      this.txtCode.TabIndex = 72;
      // 
      // lnkFind
      // 
      this.lnkFind.AutoSize = true;
      this.lnkFind.DisabledLinkColor = System.Drawing.Color.White;
      this.lnkFind.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lnkFind.LinkColor = System.Drawing.Color.Black;
      this.lnkFind.Location = new System.Drawing.Point(59, 10);
      this.lnkFind.Name = "lnkFind";
      this.lnkFind.Size = new System.Drawing.Size(69, 16);
      this.lnkFind.TabIndex = 65;
      this.lnkFind.TabStop = true;
      this.lnkFind.Text = "Find Code";
      // 
      // gbFilter
      // 
      this.gbFilter.Controls.Add(this.cmbStatus);
      this.gbFilter.Controls.Add(this.label40);
      this.gbFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbFilter.ForeColor = System.Drawing.Color.White;
      this.gbFilter.Location = new System.Drawing.Point(7, 10);
      this.gbFilter.Name = "gbFilter";
      this.gbFilter.Size = new System.Drawing.Size(222, 76);
      this.gbFilter.TabIndex = 0;
      this.gbFilter.TabStop = false;
      this.gbFilter.Text = "Filters";
      // 
      // cmbStatus
      // 
      this.cmbStatus.DropDownHeight = 350;
      this.cmbStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbStatus.FormattingEnabled = true;
      this.cmbStatus.IntegralHeight = false;
      this.cmbStatus.Items.AddRange(new object[] {
            "All",
            "Glass",
            "Sash",
            "Bead",
            "Handle",
            "Hinge",
            "Stay",
            "Connector",
            "Travel",
            "Labour",
            "Uncommon"});
      this.cmbStatus.Location = new System.Drawing.Point(12, 38);
      this.cmbStatus.Name = "cmbStatus";
      this.cmbStatus.Size = new System.Drawing.Size(200, 24);
      this.cmbStatus.TabIndex = 5;
      this.cmbStatus.Text = "All";
      this.cmbStatus.SelectedIndexChanged += new System.EventHandler(this.cmbStatus_SelectedIndexChanged);
      // 
      // label40
      // 
      this.label40.AutoSize = true;
      this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label40.ForeColor = System.Drawing.Color.White;
      this.label40.Location = new System.Drawing.Point(9, 19);
      this.label40.Name = "label40";
      this.label40.Size = new System.Drawing.Size(50, 16);
      this.label40.TabIndex = 4;
      this.label40.Text = "Group";
      // 
      // pnlData
      // 
      this.pnlData.Controls.Add(this.dgvItems);
      this.pnlData.Dock = System.Windows.Forms.DockStyle.Fill;
      this.pnlData.Location = new System.Drawing.Point(237, 39);
      this.pnlData.Name = "pnlData";
      this.pnlData.Size = new System.Drawing.Size(941, 531);
      this.pnlData.TabIndex = 7;
      // 
      // chItemID
      // 
      this.chItemID.DataPropertyName = "itemCostID";
      this.chItemID.HeaderText = "ID";
      this.chItemID.Name = "chItemID";
      this.chItemID.ReadOnly = true;
      this.chItemID.Visible = false;
      this.chItemID.Width = 28;
      // 
      // chGroupID
      // 
      this.chGroupID.DataPropertyName = "itemGroupID";
      this.chGroupID.HeaderText = "Group ID";
      this.chGroupID.Name = "chGroupID";
      this.chGroupID.ReadOnly = true;
      this.chGroupID.Visible = false;
      this.chGroupID.Width = 74;
      // 
      // chCode
      // 
      this.chCode.DataPropertyName = "icCode";
      this.chCode.HeaderText = "Code";
      this.chCode.Name = "chCode";
      this.chCode.ReadOnly = true;
      this.chCode.Width = 69;
      // 
      // chDescription
      // 
      this.chDescription.DataPropertyName = "icDescription";
      this.chDescription.HeaderText = "Description";
      this.chDescription.Name = "chDescription";
      this.chDescription.ReadOnly = true;
      this.chDescription.Width = 108;
      // 
      // chCost
      // 
      this.chCost.DataPropertyName = "icCost";
      dataGridViewCellStyle3.Format = "C2";
      dataGridViewCellStyle3.NullValue = null;
      this.chCost.DefaultCellStyle = dataGridViewCellStyle3;
      this.chCost.HeaderText = "Cost";
      this.chCost.Name = "chCost";
      this.chCost.ReadOnly = true;
      this.chCost.Width = 65;
      // 
      // chPrice
      // 
      this.chPrice.DataPropertyName = "icPrice";
      dataGridViewCellStyle4.Format = "C2";
      dataGridViewCellStyle4.NullValue = null;
      this.chPrice.DefaultCellStyle = dataGridViewCellStyle4;
      this.chPrice.HeaderText = "Price";
      this.chPrice.Name = "chPrice";
      this.chPrice.ReadOnly = true;
      this.chPrice.Width = 67;
      // 
      // chUOM
      // 
      this.chUOM.DataPropertyName = "uom";
      this.chUOM.HeaderText = "UoM";
      this.chUOM.Name = "chUOM";
      this.chUOM.ReadOnly = true;
      this.chUOM.Width = 66;
      // 
      // chMinimum
      // 
      this.chMinimum.DataPropertyName = "minQuantity";
      this.chMinimum.HeaderText = "Min Qty";
      this.chMinimum.Name = "chMinimum";
      this.chMinimum.ReadOnly = true;
      this.chMinimum.Width = 84;
      // 
      // Allowance
      // 
      this.Allowance.DataPropertyName = "allowance";
      this.Allowance.HeaderText = "Allowance";
      this.Allowance.Name = "Allowance";
      // 
      // ItemView
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.ClientSize = new System.Drawing.Size(1178, 570);
      this.ControlBox = false;
      this.Controls.Add(this.pnlData);
      this.Controls.Add(this.pnlFilter);
      this.Controls.Add(this.toolStrip1);
      this.Name = "ItemView";
      this.ShowIcon = false;
      this.ShowInTaskbar = false;
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
      this.Text = "Glass Item List";
      ((System.ComponentModel.ISupportInitialize)(this.dgvItems)).EndInit();
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.pnlFilter.ResumeLayout(false);
      this.Panel3.ResumeLayout(false);
      this.Panel3.PerformLayout();
      this.gbFilter.ResumeLayout(false);
      this.gbFilter.PerformLayout();
      this.pnlData.ResumeLayout(false);
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.DataGridView dgvItems;
    private System.Windows.Forms.ToolStrip toolStrip1;
    private System.Windows.Forms.ToolStripButton tsClose;
    private System.Windows.Forms.ToolStripButton tsNew;
    private System.Windows.Forms.ToolStripButton tsRefresh;
    private System.Windows.Forms.ToolStripButton tsEdit;
    private System.Windows.Forms.Panel pnlFilter;
    internal System.Windows.Forms.Panel Panel3;
    internal System.Windows.Forms.Button btnQuote;
    internal System.Windows.Forms.Button btnCode;
    internal System.Windows.Forms.TextBox txtCode;
    internal System.Windows.Forms.LinkLabel lnkFind;
    private System.Windows.Forms.GroupBox gbFilter;
    private System.Windows.Forms.ComboBox cmbStatus;
    private System.Windows.Forms.Label label40;
    private System.Windows.Forms.Panel pnlData;
    private System.Windows.Forms.DataGridViewTextBoxColumn chItemID;
    private System.Windows.Forms.DataGridViewTextBoxColumn chGroupID;
    private System.Windows.Forms.DataGridViewTextBoxColumn chCode;
    private System.Windows.Forms.DataGridViewTextBoxColumn chDescription;
    private System.Windows.Forms.DataGridViewTextBoxColumn chCost;
    private System.Windows.Forms.DataGridViewTextBoxColumn chPrice;
    private System.Windows.Forms.DataGridViewTextBoxColumn chUOM;
    private System.Windows.Forms.DataGridViewTextBoxColumn chMinimum;
    private System.Windows.Forms.DataGridViewTextBoxColumn Allowance;
  }
}