﻿using System;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace workshop_orders
{
  /*A form for adding a customer to the database, so their details can be retrieved if they were to come back.
   */
  public partial class SearchVehicle : Form
  {
    public int jobNo = 0;
    private int vehicleID = 0;
    private bool update = true;
    private int form = 1; //1 = JobEdit, 2 = JobNew

    public SearchVehicle(int vID, int form)
    {
      InitializeComponent();
      this.vehicleID = vID;
      this.form = form;

      if (form > 0) tsSave.Text = "Select";

      if (vID == 0)
      {
        gbResult.Visible = true;
        gbMainDetails.Visible = false;
      }
      else
      {
        LoadVehicle(vID.ToString());
      }
      DataAccess.FormState(this.AccessibilityObject.Name, tsSave);
    }




    private void CreateJobForm_Load(object sender, EventArgs e)
    {
    }

    private void LoadVehicle(String customerID)
    {
      if (vehicleID > 0)
      {
        gbResult.Visible = false;
        gbMainDetails.Visible = true;

        try
        {
          DataTable dt = DataAccess.ExecuteDataTable(String.Format("SELECT * FROM Vehicle WHERE VehicleID = {0};", vehicleID));
          txtRegistration.Text = dt.Rows[0]["vRegistration"].ToString();

          txtMake.Text = dt.Rows[0]["vMake"].ToString();
          txtModel.Text = dt.Rows[0]["vModel"].ToString();
          txtYear.Text = dt.Rows[0]["vYear"].ToString();

          if ((int)dt.Rows[0]["vRecalibration"] == 1)
          {
            rbYesRecal.Checked = true;
          }
          else
          {
            rbNoRecal.Checked = true;
          }
        } catch (Exception ex)
        {

        }
      }
      else
      {
        gbResult.Visible = true;
        gbMainDetails.Visible = false;
      }
    }

    private void WebRegistrationSearch()
    {
      if (cmbField.Text == "Registration")
      {
        lblSearchWeb.Visible = true;

        this.Refresh();

        try
        {
          String cmds = @"\\GWGFS\GWGFiles\BMS\Python\vehiclewebsearch.py";
          String result = "";
          ProcessStartInfo start = new ProcessStartInfo();
          start.FileName = @"\\GWGFS\GWGFiles\BMS\Python\Python38\python.exe";
          start.Arguments = string.Format("{0} {1}", cmds, txtSearch.Text);
          start.UseShellExecute = false;
          start.RedirectStandardOutput = true;
          start.CreateNoWindow = true;
          using (Process process = Process.Start(start))
          {
            using (StreamReader reader = process.StandardOutput)
            {

              result = reader.ReadToEnd();
            }
          }
          if (result != "")
          {
            try
            {
              String[] res = result.Split('\n');
              NewVehicle();
              txtRegistration.Text = txtSearch.Text;
              txtMake.Text = res[0];
              txtModel.Text = res[1];
              txtYear.Text = res[2];
            }
            catch (Exception ex)
            {
              DataAccess.ShowMessage("An error occured loading vehicle data from the web. Please try again.");
              DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
              this.Close();
            }

          }
          else
          {
            DataAccess.ShowMessage("Either this vehicle was not found on thatcar.nz, or an error occured.\n\n" +
              "Double check the registration entered and try again.");
          }
          lblSearchWeb.Visible = false;

        }
        catch { }
      }
    }

    private void SearchDatabase()
    {
      vehicleID = 0;
      update = true;
      dgvCustomer.Rows.Clear();
      try
      {
        String sql = null;

        this.vehicleID = 0;

        gbResult.Visible = true;
        gbMainDetails.Visible = false;

        switch (cmbField.Text)
        {
          case "Registration":
            sql = String.Format("SELECT * FROM vehicle WHERE vRegistration LIKE '{0}%' AND VehicleID > 0;", txtSearch.Text);
            break;
          case "Make":
            sql = String.Format("SELECT * FROM vehicle WHERE vMake LIKE '{0}%' AND VehicleID > 0;", txtSearch.Text);
            break;
          case "Model":
            sql = String.Format("SELECT * FROM vehicle WHERE vModel LIKE '{0}%' AND VehicleID > 0;", txtSearch.Text);
            break;
        }

        if (sql != null)
        {
          int amount = 0;
          DataTable dt = DataAccess.ExecuteDataTable(sql);
          foreach (DataRow row in dt.Rows)
          {
            amount++;
            dgvCustomer.Rows.Add(row["VehicleID"].ToString(), row["vRegistration"].ToString(),
              row["vMake"].ToString() + " " + row["vModel"].ToString() + " " + row["vYear"].ToString());
          }

          if (amount == 0)
          {
            if (cmbField.Text == "Registration")
            {
              btnWebSearch.Visible = true;
            }
            else
            {
              btnWebSearch.Visible = false;
            }
            //DataAccess.ShowMessage("No Vehicle Records Found. Please change your selection or add new customer.");
          }
          else
          {
            btnWebSearch.Visible = false;
          }
        }
      }
      catch (Exception ex)
      {
        DataAccess.ShowMessage("Error: Couldn't fetch Vehicle data.");
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                  System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }
    }

    private void cmbField_SelectedIndexChanged(object sender, EventArgs e)
    {
      SearchDatabase();
    }


    private void textBox1_TextChanged(object sender, EventArgs e)
    {
      SearchDatabase();
    }

    private void toolStripButton1_Click_1(object sender, EventArgs e)
    {
      this.Close();
    }

    private void ClearAllFields()
    {
      txtRegistration.Text = "";

      txtMake.Text = "";
      txtModel.Text = "";
      txtYear.Text = "";
    }

    private void addtoolStripButton_Click(object sender, EventArgs e)
    {
      NewVehicle();
    }

    private void NewVehicle()
    {
      gbMainDetails.Visible = true;
      gbResult.Visible = false;
      gbsearch.Enabled = false;
      rbYesRecal.Checked = false;
      rbNoRecal.Checked = false;
      update = false;
      vehicleID = 0;
      ClearAllFields();
    }

    private void saveToolStripButton2_Click(object sender, EventArgs e)
    {
      SaveVehicle();      
    }

    private void SaveVehicle()
    {
      if (this.vehicleID == 0 && update == true)
      {
        DataAccess.ShowMessage("You haven't selected a vehicle!");
        return;
      }

      String errors = "Unable to save vehicle details due to the following issues:\n\n";

      if (!update)
      {
        DataTable dtRegoCheck = DataAccess.ExecuteDataTable("SELECT * FROM Vehicle WHERE vRegistration = '" + txtRegistration.Text + "'");
        if (dtRegoCheck != null && dtRegoCheck.Rows.Count > 0)
        {
          errors += " - This registration is already in use in this system. Please use the search bar to find it.\n";
          DataAccess.ShowMessage(errors);
          return;
        }
      }
      if (txtRegistration.Text == "")
      {
        errors += " - You must enter in a Vehicle Name.\n";
      }

      if (txtMake.Text == "")
      {
        errors += " - You must enter in a Make\n";
      }

      if (txtModel.Text == "")
      {
        errors += " - You must enter in a Model\n";
      }


      if (txtYear.Text == "" && !DataAccess.IsNumeric(txtYear.Text))
      {
        errors += " - Year is not a valid number.\n";
      }

      int recal = 0;
      if(!rbYesRecal.Checked && !rbNoRecal.Checked)
      {
        errors += " - No Recalibration Mode is selected.\n";
      }
      if (rbYesRecal.Checked)
      {
        recal = 1;
      }

      if (errors != "Unable to save vehicle details due to the following issues:\n\n")
      {
        DataAccess.ShowMessage(errors);
        return;
      }
      try
      {
        DataAccess.VehicleManage(vehicleID, txtRegistration.Text, txtMake.Text, txtModel.Text, int.Parse(txtYear.Text), recal);
      }
      catch (Exception ex)
      {
        DataAccess.ShowMessage("Vehicle failed to save, please contact the administrator");
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                  System.Reflection.MethodBase.GetCurrentMethod().Name, "");
        return;
      }

      if (form == 0) DataAccess.ShowMessage("Vehicle saved Successfully");

      if (!update)
      {
        DataTable dt = DataAccess.ExecuteDataTable("SELECT MAX(VehicleID) AS MaxID FROM vehicle");
        vehicleID = (int)dt.Rows[0]["MaxID"];
      }

      if (this.vehicleID > 0)
      {
        if (form == 1)
        {
          JobEdit.VehicleID = vehicleID;
        }
        else if (form == 2)
        {
          JobNew.VehicleID = vehicleID;
        }

        this.Close();
      }
    }

    private void customerDataGrid_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      if (e.RowIndex >= 0)
      {
        update = true;

        gbResult.Visible = false;
        gbMainDetails.Visible = true;
        //searchText.Enabled = false;
        DataGridViewRow row = this.dgvCustomer.Rows[e.RowIndex];
        this.vehicleID = int.Parse(row.Cells["ID"].Value.ToString());
        LoadVehicle(row.Cells["ID"].Value.ToString());
      }

    }

    private void btnWebSearch_Click(object sender, EventArgs e)
    {
      WebRegistrationSearch();
    }

    
  }
}
