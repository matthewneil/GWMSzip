﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workshop_orders
{
  public partial class ucLabourJob : UserControl
  {
    public static Workshop frm;
    public int JobID = -1;

    public ucLabourJob(String JobID, String JobType, String BookingDate, String BookingTime, String Vehicle, String Customer, String Area, String Reference, String TypeColor)
    {
      InitializeComponent();
      lblJobID.Text = JobID;
      lblType.Text = JobType;
      lblBooking.Text = BookingDate;
      lblTime.Text = BookingTime;
      lblVehicle.Text = Vehicle;
      lblCustomer.Text = Customer;
      lblArea.Text = Area;
      lblReference.Text = Reference;

      if(DateTime.Parse(BookingDate) < DateTime.Today)
      {
        lblType.BackColor = Color.FromName(TypeColor);
        BackColor = Color.LightGray;
      }
      else
      {
        BackColor = Color.FromName(TypeColor);
      }

      this.JobID = int.Parse(JobID);
    }

    private void JobCardClicked()
    {
      FormManagement.CloseChildForm("JobEdit");
      JobEdit jobfrm = new JobEdit(JobID, 1);
      JobEdit.frm = frm;
      
      FormManagement.ShowChildForm(jobfrm);
    }
    private void ucLabourJob_Click(object sender, EventArgs e)
    {
      JobCardClicked();
    }

    private void lblJobID_Click(object sender, EventArgs e)
    {
      JobCardClicked();
    }

    private void lblType_Click(object sender, EventArgs e)
    {
      JobCardClicked();
    }

    private void lblBooking_Click(object sender, EventArgs e)
    {
      JobCardClicked();
    }

    private void lblTime_Click(object sender, EventArgs e)
    {
      JobCardClicked();
    }

    private void lblVehicle_Click(object sender, EventArgs e)
    {
      JobCardClicked();
    }

    private void lblCustomer_Click(object sender, EventArgs e)
    {
      JobCardClicked();
    }

    private void lblArea_Click(object sender, EventArgs e)
    {
      JobCardClicked();
    }

    private void lblReference_Click(object sender, EventArgs e)
    {
      JobCardClicked();
    }
  }
}
