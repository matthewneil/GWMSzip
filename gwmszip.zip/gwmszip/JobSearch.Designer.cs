﻿using System;
using System.Windows.Forms;

namespace workshop_orders
{
    partial class JobSearch
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(JobSearch));
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle85 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle86 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle95 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle96 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle87 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle88 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle89 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle90 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle91 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle92 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle93 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle94 = new System.Windows.Forms.DataGridViewCellStyle();
      this.pnlFilter = new System.Windows.Forms.Panel();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.txtSearch = new System.Windows.Forms.TextBox();
      this.Panel3 = new System.Windows.Forms.Panel();
      this.btnQuote = new System.Windows.Forms.Button();
      this.btnQuote1 = new System.Windows.Forms.Button();
      this.txtJob = new System.Windows.Forms.TextBox();
      this.lnkFind = new System.Windows.Forms.LinkLabel();
      this.gbFilter = new System.Windows.Forms.GroupBox();
      this.chkInvoice = new System.Windows.Forms.CheckBox();
      this.cmbType = new System.Windows.Forms.ComboBox();
      this.label3 = new System.Windows.Forms.Label();
      this.btnReset = new System.Windows.Forms.Button();
      this.cmbCustomer = new System.Windows.Forms.ComboBox();
      this.label2 = new System.Windows.Forms.Label();
      this.cmbStaff = new System.Windows.Forms.ComboBox();
      this.label1 = new System.Windows.Forms.Label();
      this.cmbStatus = new System.Windows.Forms.ComboBox();
      this.label40 = new System.Windows.Forms.Label();
      this.dtpToDate = new System.Windows.Forms.DateTimePicker();
      this.label39 = new System.Windows.Forms.Label();
      this.dtpFromDate = new System.Windows.Forms.DateTimePicker();
      this.label38 = new System.Windows.Forms.Label();
      this.ts = new System.Windows.Forms.ToolStrip();
      this.tbBack = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
      this.tbNew = new System.Windows.Forms.ToolStripButton();
      this.tsEdit = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
      this.tsDelete = new System.Windows.Forms.ToolStripButton();
      this.tsRefresh = new System.Windows.Forms.ToolStripButton();
      this.pnlBody = new System.Windows.Forms.Panel();
      this.dgvData = new System.Windows.Forms.DataGridView();
      this.chJobID = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chVehicle = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chCustomer = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chType = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chReference = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chNote = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chBookDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chArea = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chPayment = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chStaff = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.pnlFilter.SuspendLayout();
      this.groupBox1.SuspendLayout();
      this.Panel3.SuspendLayout();
      this.gbFilter.SuspendLayout();
      this.ts.SuspendLayout();
      this.pnlBody.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgvData)).BeginInit();
      this.SuspendLayout();
      // 
      // pnlFilter
      // 
      this.pnlFilter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(210)))));
      this.pnlFilter.Controls.Add(this.chkInvoice);
      this.pnlFilter.Controls.Add(this.groupBox1);
      this.pnlFilter.Controls.Add(this.Panel3);
      this.pnlFilter.Controls.Add(this.gbFilter);
      this.pnlFilter.Dock = System.Windows.Forms.DockStyle.Left;
      this.pnlFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.pnlFilter.Location = new System.Drawing.Point(0, 39);
      this.pnlFilter.Name = "pnlFilter";
      this.pnlFilter.Size = new System.Drawing.Size(237, 1002);
      this.pnlFilter.TabIndex = 5;
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.Add(this.txtSearch);
      this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.groupBox1.ForeColor = System.Drawing.Color.White;
      this.groupBox1.Location = new System.Drawing.Point(9, 5);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(222, 51);
      this.groupBox1.TabIndex = 86;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Search";
      // 
      // txtSearch
      // 
      this.txtSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtSearch.Location = new System.Drawing.Point(8, 19);
      this.txtSearch.Name = "txtSearch";
      this.txtSearch.Size = new System.Drawing.Size(200, 26);
      this.txtSearch.TabIndex = 85;
      this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
      // 
      // Panel3
      // 
      this.Panel3.BackColor = System.Drawing.Color.White;
      this.Panel3.Controls.Add(this.btnQuote);
      this.Panel3.Controls.Add(this.btnQuote1);
      this.Panel3.Controls.Add(this.txtJob);
      this.Panel3.Controls.Add(this.lnkFind);
      this.Panel3.Location = new System.Drawing.Point(12, 444);
      this.Panel3.Name = "Panel3";
      this.Panel3.Size = new System.Drawing.Size(205, 58);
      this.Panel3.TabIndex = 84;
      // 
      // btnQuote
      // 
      this.btnQuote.Location = new System.Drawing.Point(173, 29);
      this.btnQuote.Name = "btnQuote";
      this.btnQuote.Size = new System.Drawing.Size(13, 20);
      this.btnQuote.TabIndex = 73;
      this.btnQuote.Text = "..";
      this.btnQuote.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      this.btnQuote.UseVisualStyleBackColor = true;
      this.btnQuote.Click += new System.EventHandler(this.btnQuote_Click);
      // 
      // btnQuote1
      // 
      this.btnQuote1.BackColor = System.Drawing.Color.Transparent;
      this.btnQuote1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
      this.btnQuote1.Image = global::workshop_orders.Properties.Resources.find;
      this.btnQuote1.Location = new System.Drawing.Point(5, 5);
      this.btnQuote1.Name = "btnQuote1";
      this.btnQuote1.Size = new System.Drawing.Size(48, 48);
      this.btnQuote1.TabIndex = 0;
      this.btnQuote1.UseVisualStyleBackColor = false;
      this.btnQuote1.Click += new System.EventHandler(this.btnQuote1_Click);
      // 
      // txtJob
      // 
      this.txtJob.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtJob.Location = new System.Drawing.Point(59, 28);
      this.txtJob.Name = "txtJob";
      this.txtJob.Size = new System.Drawing.Size(108, 23);
      this.txtJob.TabIndex = 72;
      this.txtJob.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtQuote_KeyDown);
      // 
      // lnkFind
      // 
      this.lnkFind.AutoSize = true;
      this.lnkFind.DisabledLinkColor = System.Drawing.Color.White;
      this.lnkFind.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lnkFind.LinkColor = System.Drawing.Color.Black;
      this.lnkFind.Location = new System.Drawing.Point(59, 10);
      this.lnkFind.Name = "lnkFind";
      this.lnkFind.Size = new System.Drawing.Size(59, 16);
      this.lnkFind.TabIndex = 65;
      this.lnkFind.TabStop = true;
      this.lnkFind.Text = "Find Job";
      // 
      // gbFilter
      // 
      this.gbFilter.Controls.Add(this.cmbType);
      this.gbFilter.Controls.Add(this.label3);
      this.gbFilter.Controls.Add(this.btnReset);
      this.gbFilter.Controls.Add(this.cmbCustomer);
      this.gbFilter.Controls.Add(this.label2);
      this.gbFilter.Controls.Add(this.cmbStaff);
      this.gbFilter.Controls.Add(this.label1);
      this.gbFilter.Controls.Add(this.cmbStatus);
      this.gbFilter.Controls.Add(this.label40);
      this.gbFilter.Controls.Add(this.dtpToDate);
      this.gbFilter.Controls.Add(this.label39);
      this.gbFilter.Controls.Add(this.dtpFromDate);
      this.gbFilter.Controls.Add(this.label38);
      this.gbFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbFilter.ForeColor = System.Drawing.Color.White;
      this.gbFilter.Location = new System.Drawing.Point(9, 62);
      this.gbFilter.Name = "gbFilter";
      this.gbFilter.Size = new System.Drawing.Size(222, 376);
      this.gbFilter.TabIndex = 0;
      this.gbFilter.TabStop = false;
      this.gbFilter.Text = "Filters";
      // 
      // chkInvoice
      // 
      this.chkInvoice.AutoSize = true;
      this.chkInvoice.Location = new System.Drawing.Point(48, 519);
      this.chkInvoice.Name = "chkInvoice";
      this.chkInvoice.Size = new System.Drawing.Size(122, 21);
      this.chkInvoice.TabIndex = 88;
      this.chkInvoice.Text = "Has No Invoice";
      this.chkInvoice.UseVisualStyleBackColor = true;
      this.chkInvoice.Visible = false;
      this.chkInvoice.CheckedChanged += new System.EventHandler(this.chkInvoice_CheckedChanged);
      // 
      // cmbType
      // 
      this.cmbType.DisplayMember = "textfield";
      this.cmbType.DropDownHeight = 350;
      this.cmbType.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbType.FormattingEnabled = true;
      this.cmbType.IntegralHeight = false;
      this.cmbType.Location = new System.Drawing.Point(12, 141);
      this.cmbType.Name = "cmbType";
      this.cmbType.Size = new System.Drawing.Size(200, 24);
      this.cmbType.TabIndex = 87;
      this.cmbType.ValueMember = "datafield";
      this.cmbType.SelectedIndexChanged += new System.EventHandler(this.cmbType_SelectedIndexChanged);
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label3.ForeColor = System.Drawing.Color.White;
      this.label3.Location = new System.Drawing.Point(10, 123);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(44, 16);
      this.label3.TabIndex = 86;
      this.label3.Text = "Type";
      // 
      // btnReset
      // 
      this.btnReset.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnReset.ForeColor = System.Drawing.Color.Black;
      this.btnReset.Image = global::workshop_orders.Properties.Resources.reset;
      this.btnReset.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
      this.btnReset.Location = new System.Drawing.Point(43, 325);
      this.btnReset.Name = "btnReset";
      this.btnReset.Padding = new System.Windows.Forms.Padding(5, 0, 5, 0);
      this.btnReset.Size = new System.Drawing.Size(118, 36);
      this.btnReset.TabIndex = 85;
      this.btnReset.Text = "Reset";
      this.btnReset.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      this.btnReset.UseVisualStyleBackColor = true;
      // 
      // cmbCustomer
      // 
      this.cmbCustomer.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
      this.cmbCustomer.DisplayMember = "textfield";
      this.cmbCustomer.DropDownHeight = 300;
      this.cmbCustomer.DropDownWidth = 250;
      this.cmbCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbCustomer.FormattingEnabled = true;
      this.cmbCustomer.IntegralHeight = false;
      this.cmbCustomer.Location = new System.Drawing.Point(12, 235);
      this.cmbCustomer.Name = "cmbCustomer";
      this.cmbCustomer.Size = new System.Drawing.Size(200, 24);
      this.cmbCustomer.TabIndex = 9;
      this.cmbCustomer.ValueMember = "datafield";
      this.cmbCustomer.SelectedIndexChanged += new System.EventHandler(this.cmbCustomer_SelectedIndexChanged);
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label2.ForeColor = System.Drawing.Color.White;
      this.label2.Location = new System.Drawing.Point(12, 217);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(73, 16);
      this.label2.TabIndex = 8;
      this.label2.Text = "Customer";
      // 
      // cmbStaff
      // 
      this.cmbStaff.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
      this.cmbStaff.DisplayMember = "textfield";
      this.cmbStaff.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbStaff.FormattingEnabled = true;
      this.cmbStaff.Location = new System.Drawing.Point(12, 285);
      this.cmbStaff.Name = "cmbStaff";
      this.cmbStaff.Size = new System.Drawing.Size(200, 24);
      this.cmbStaff.TabIndex = 7;
      this.cmbStaff.ValueMember = "datafield";
      this.cmbStaff.SelectedIndexChanged += new System.EventHandler(this.StaffCombo_SelectedIndexChanged);
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label1.ForeColor = System.Drawing.Color.White;
      this.label1.Location = new System.Drawing.Point(12, 267);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(39, 16);
      this.label1.TabIndex = 6;
      this.label1.Text = "Staff";
      // 
      // cmbStatus
      // 
      this.cmbStatus.DropDownHeight = 350;
      this.cmbStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbStatus.FormattingEnabled = true;
      this.cmbStatus.IntegralHeight = false;
      this.cmbStatus.Items.AddRange(new object[] {
            "All",
            "Current",
            "Complete",
            "Invoiced",
            "Cancelled"});
      this.cmbStatus.Location = new System.Drawing.Point(12, 187);
      this.cmbStatus.Name = "cmbStatus";
      this.cmbStatus.Size = new System.Drawing.Size(200, 24);
      this.cmbStatus.TabIndex = 5;
      this.cmbStatus.Text = "All";
      this.cmbStatus.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
      // 
      // label40
      // 
      this.label40.AutoSize = true;
      this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label40.ForeColor = System.Drawing.Color.White;
      this.label40.Location = new System.Drawing.Point(12, 171);
      this.label40.Name = "label40";
      this.label40.Size = new System.Drawing.Size(51, 16);
      this.label40.TabIndex = 4;
      this.label40.Text = "Status";
      // 
      // dtpToDate
      // 
      this.dtpToDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.dtpToDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
      this.dtpToDate.Location = new System.Drawing.Point(12, 94);
      this.dtpToDate.Name = "dtpToDate";
      this.dtpToDate.Size = new System.Drawing.Size(102, 22);
      this.dtpToDate.TabIndex = 3;
      this.dtpToDate.Value = new System.DateTime(2021, 12, 9, 12, 50, 7, 0);
      this.dtpToDate.CloseUp += new System.EventHandler(this.endDateTime_ValueChanged);
      // 
      // label39
      // 
      this.label39.AutoSize = true;
      this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label39.ForeColor = System.Drawing.Color.White;
      this.label39.Location = new System.Drawing.Point(12, 75);
      this.label39.Name = "label39";
      this.label39.Size = new System.Drawing.Size(64, 16);
      this.label39.TabIndex = 2;
      this.label39.Text = "To Date";
      // 
      // dtpFromDate
      // 
      this.dtpFromDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.dtpFromDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
      this.dtpFromDate.Location = new System.Drawing.Point(12, 46);
      this.dtpFromDate.Name = "dtpFromDate";
      this.dtpFromDate.Size = new System.Drawing.Size(102, 22);
      this.dtpFromDate.TabIndex = 1;
      this.dtpFromDate.Value = new System.DateTime(2021, 12, 9, 12, 50, 7, 0);
      this.dtpFromDate.CloseUp += new System.EventHandler(this.startDateTime_ValueChanged);
      // 
      // label38
      // 
      this.label38.AutoSize = true;
      this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label38.ForeColor = System.Drawing.Color.White;
      this.label38.Location = new System.Drawing.Point(12, 27);
      this.label38.Name = "label38";
      this.label38.Size = new System.Drawing.Size(80, 16);
      this.label38.TabIndex = 0;
      this.label38.Text = "From Date";
      // 
      // ts
      // 
      this.ts.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tbBack,
            this.toolStripSeparator1,
            this.tbNew,
            this.tsEdit,
            this.toolStripSeparator2,
            this.tsDelete,
            this.tsRefresh});
      this.ts.Location = new System.Drawing.Point(0, 0);
      this.ts.Name = "ts";
      this.ts.Size = new System.Drawing.Size(1904, 39);
      this.ts.TabIndex = 6;
      this.ts.Text = "toolStrip1";
      // 
      // tbBack
      // 
      this.tbBack.Image = ((System.Drawing.Image)(resources.GetObject("tbBack.Image")));
      this.tbBack.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tbBack.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tbBack.Name = "tbBack";
      this.tbBack.Size = new System.Drawing.Size(68, 36);
      this.tbBack.Text = "Back";
      this.tbBack.Click += new System.EventHandler(this.BackToolStripButton_Click);
      // 
      // toolStripSeparator1
      // 
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
      // 
      // tbNew
      // 
      this.tbNew.Image = ((System.Drawing.Image)(resources.GetObject("tbNew.Image")));
      this.tbNew.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tbNew.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tbNew.Name = "tbNew";
      this.tbNew.Size = new System.Drawing.Size(67, 36);
      this.tbNew.Text = "New";
      this.tbNew.Click += new System.EventHandler(this.NewToolStripButton_Click);
      // 
      // tsEdit
      // 
      this.tsEdit.Image = global::workshop_orders.Properties.Resources.edit;
      this.tsEdit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsEdit.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsEdit.Name = "tsEdit";
      this.tsEdit.Size = new System.Drawing.Size(63, 36);
      this.tsEdit.Text = "Edit";
      this.tsEdit.ToolTipText = "Edit";
      this.tsEdit.Click += new System.EventHandler(this.tsEdit_Click);
      // 
      // toolStripSeparator2
      // 
      this.toolStripSeparator2.Name = "toolStripSeparator2";
      this.toolStripSeparator2.Size = new System.Drawing.Size(6, 39);
      // 
      // tsDelete
      // 
      this.tsDelete.ForeColor = System.Drawing.Color.Red;
      this.tsDelete.Image = global::workshop_orders.Properties.Resources.delete;
      this.tsDelete.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsDelete.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsDelete.Name = "tsDelete";
      this.tsDelete.Size = new System.Drawing.Size(76, 36);
      this.tsDelete.Text = "Delete";
      this.tsDelete.Visible = false;
      this.tsDelete.Click += new System.EventHandler(this.tsDelete_Click);
      // 
      // tsRefresh
      // 
      this.tsRefresh.Image = global::workshop_orders.Properties.Resources.refresh;
      this.tsRefresh.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsRefresh.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsRefresh.Name = "tsRefresh";
      this.tsRefresh.Size = new System.Drawing.Size(82, 36);
      this.tsRefresh.Text = "Refresh";
      this.tsRefresh.Click += new System.EventHandler(this.tsRefresh_Click);
      // 
      // pnlBody
      // 
      this.pnlBody.Controls.Add(this.dgvData);
      this.pnlBody.Dock = System.Windows.Forms.DockStyle.Fill;
      this.pnlBody.Location = new System.Drawing.Point(237, 39);
      this.pnlBody.Name = "pnlBody";
      this.pnlBody.Size = new System.Drawing.Size(1667, 1002);
      this.pnlBody.TabIndex = 7;
      // 
      // dgvData
      // 
      this.dgvData.AllowUserToAddRows = false;
      this.dgvData.AllowUserToDeleteRows = false;
      this.dgvData.AllowUserToResizeRows = false;
      dataGridViewCellStyle85.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
      this.dgvData.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle85;
      this.dgvData.BackgroundColor = System.Drawing.Color.White;
      this.dgvData.BorderStyle = System.Windows.Forms.BorderStyle.None;
      this.dgvData.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
      dataGridViewCellStyle86.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
      dataGridViewCellStyle86.BackColor = System.Drawing.SystemColors.Control;
      dataGridViewCellStyle86.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      dataGridViewCellStyle86.ForeColor = System.Drawing.SystemColors.WindowText;
      dataGridViewCellStyle86.SelectionBackColor = System.Drawing.SystemColors.Highlight;
      dataGridViewCellStyle86.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
      dataGridViewCellStyle86.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
      this.dgvData.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle86;
      this.dgvData.ColumnHeadersHeight = 28;
      this.dgvData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
      this.dgvData.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.chJobID,
            this.chVehicle,
            this.chCustomer,
            this.chType,
            this.chReference,
            this.chNote,
            this.chBookDate,
            this.chArea,
            this.chPayment,
            this.chStatus,
            this.chStaff});
      this.dgvData.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dgvData.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
      this.dgvData.Location = new System.Drawing.Point(0, 0);
      this.dgvData.MultiSelect = false;
      this.dgvData.Name = "dgvData";
      dataGridViewCellStyle95.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
      dataGridViewCellStyle95.BackColor = System.Drawing.SystemColors.Control;
      dataGridViewCellStyle95.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      dataGridViewCellStyle95.ForeColor = System.Drawing.SystemColors.WindowText;
      dataGridViewCellStyle95.SelectionBackColor = System.Drawing.SystemColors.Highlight;
      dataGridViewCellStyle95.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
      dataGridViewCellStyle95.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
      this.dgvData.RowHeadersDefaultCellStyle = dataGridViewCellStyle95;
      this.dgvData.RowHeadersVisible = false;
      dataGridViewCellStyle96.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.dgvData.RowsDefaultCellStyle = dataGridViewCellStyle96;
      this.dgvData.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
      this.dgvData.ShowEditingIcon = false;
      this.dgvData.Size = new System.Drawing.Size(1667, 1002);
      this.dgvData.TabIndex = 74;
      this.dgvData.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvData_CellDoubleClick);
      // 
      // chJobID
      // 
      this.chJobID.DataPropertyName = "JobID";
      dataGridViewCellStyle87.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
      dataGridViewCellStyle87.NullValue = null;
      this.chJobID.DefaultCellStyle = dataGridViewCellStyle87;
      this.chJobID.HeaderText = "Job";
      this.chJobID.Name = "chJobID";
      this.chJobID.ReadOnly = true;
      this.chJobID.Width = 70;
      // 
      // chVehicle
      // 
      this.chVehicle.DataPropertyName = "Vehicle";
      this.chVehicle.HeaderText = "Vehicle";
      this.chVehicle.Name = "chVehicle";
      this.chVehicle.ReadOnly = true;
      this.chVehicle.Width = 250;
      // 
      // chCustomer
      // 
      this.chCustomer.DataPropertyName = "CustomerName";
      dataGridViewCellStyle88.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
      this.chCustomer.DefaultCellStyle = dataGridViewCellStyle88;
      this.chCustomer.HeaderText = "Customer";
      this.chCustomer.Name = "chCustomer";
      this.chCustomer.ReadOnly = true;
      this.chCustomer.Width = 150;
      // 
      // chType
      // 
      this.chType.DataPropertyName = "TypeName";
      dataGridViewCellStyle89.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
      dataGridViewCellStyle89.NullValue = null;
      this.chType.DefaultCellStyle = dataGridViewCellStyle89;
      this.chType.HeaderText = "Type";
      this.chType.Name = "chType";
      this.chType.ReadOnly = true;
      this.chType.Width = 150;
      // 
      // chReference
      // 
      this.chReference.DataPropertyName = "JobReference";
      this.chReference.HeaderText = "Reference";
      this.chReference.Name = "chReference";
      this.chReference.ReadOnly = true;
      this.chReference.Width = 200;
      // 
      // chNote
      // 
      this.chNote.DataPropertyName = "JobNote";
      this.chNote.HeaderText = "Notes";
      this.chNote.Name = "chNote";
      this.chNote.ReadOnly = true;
      this.chNote.Width = 350;
      // 
      // chBookDate
      // 
      this.chBookDate.DataPropertyName = "JobBookingDateBlank";
      dataGridViewCellStyle90.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
      dataGridViewCellStyle90.Format = "g";
      dataGridViewCellStyle90.NullValue = null;
      this.chBookDate.DefaultCellStyle = dataGridViewCellStyle90;
      this.chBookDate.HeaderText = "Book Date";
      this.chBookDate.Name = "chBookDate";
      this.chBookDate.ReadOnly = true;
      this.chBookDate.Width = 120;
      // 
      // chArea
      // 
      this.chArea.DataPropertyName = "AreaName";
      dataGridViewCellStyle91.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
      dataGridViewCellStyle91.NullValue = null;
      this.chArea.DefaultCellStyle = dataGridViewCellStyle91;
      this.chArea.HeaderText = "Area";
      this.chArea.Name = "chArea";
      this.chArea.ReadOnly = true;
      this.chArea.Resizable = System.Windows.Forms.DataGridViewTriState.True;
      // 
      // chPayment
      // 
      this.chPayment.DataPropertyName = "Payment";
      dataGridViewCellStyle92.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
      dataGridViewCellStyle92.NullValue = null;
      this.chPayment.DefaultCellStyle = dataGridViewCellStyle92;
      this.chPayment.HeaderText = "Payment";
      this.chPayment.Name = "chPayment";
      this.chPayment.ReadOnly = true;
      this.chPayment.Width = 120;
      // 
      // chStatus
      // 
      this.chStatus.DataPropertyName = "StatusName";
      dataGridViewCellStyle93.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
      this.chStatus.DefaultCellStyle = dataGridViewCellStyle93;
      this.chStatus.HeaderText = "Status";
      this.chStatus.Name = "chStatus";
      this.chStatus.ReadOnly = true;
      this.chStatus.Width = 110;
      // 
      // chStaff
      // 
      this.chStaff.DataPropertyName = "StaffFullName";
      dataGridViewCellStyle94.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
      dataGridViewCellStyle94.NullValue = null;
      this.chStaff.DefaultCellStyle = dataGridViewCellStyle94;
      this.chStaff.HeaderText = "Created By";
      this.chStaff.Name = "chStaff";
      this.chStaff.ReadOnly = true;
      this.chStaff.Width = 120;
      // 
      // JobSearch
      // 
      this.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
      this.ClientSize = new System.Drawing.Size(1904, 1041);
      this.ControlBox = false;
      this.Controls.Add(this.pnlBody);
      this.Controls.Add(this.pnlFilter);
      this.Controls.Add(this.ts);
      this.Name = "JobSearch";
      this.ShowIcon = false;
      this.ShowInTaskbar = false;
      this.Text = "Jobs";
      this.pnlFilter.ResumeLayout(false);
      this.pnlFilter.PerformLayout();
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.Panel3.ResumeLayout(false);
      this.Panel3.PerformLayout();
      this.gbFilter.ResumeLayout(false);
      this.gbFilter.PerformLayout();
      this.ts.ResumeLayout(false);
      this.ts.PerformLayout();
      this.pnlBody.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.dgvData)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

        }

        #endregion
        private Panel pnlFilter;
        private GroupBox gbFilter;
        private ComboBox cmbStatus;
        private Label label40;
        private ToolStrip ts;
        private ToolStripButton tbBack;
        private ToolStripButton tbNew;
		internal Panel Panel3;
		internal Button btnQuote;
		internal Button btnQuote1;
		internal TextBox txtJob;
		internal LinkLabel lnkFind;
		private Panel pnlBody;
		internal ToolStripButton tsEdit;
		internal ToolStripButton tsDelete;
		internal ToolStripButton tsRefresh;
		private ToolStripSeparator toolStripSeparator1;
		private ToolStripSeparator toolStripSeparator2;
		internal DataGridView dgvData;
    internal Button btnReset;
    private ComboBox cmbCustomer;
    private Label label2;
    private ComboBox cmbStaff;
    private Label label1;
    private DateTimePicker dtpToDate;
    private Label label39;
    private DateTimePicker dtpFromDate;
    private Label label38;
    private TextBox txtSearch;
    private GroupBox groupBox1;
    private ComboBox cmbType;
    private Label label3;
    private CheckBox chkInvoice;
    private DataGridViewTextBoxColumn chJobID;
    private DataGridViewTextBoxColumn chVehicle;
    private DataGridViewTextBoxColumn chCustomer;
    private DataGridViewTextBoxColumn chType;
    private DataGridViewTextBoxColumn chReference;
    private DataGridViewTextBoxColumn chNote;
    private DataGridViewTextBoxColumn chBookDate;
    private DataGridViewTextBoxColumn chArea;
    private DataGridViewTextBoxColumn chPayment;
    private DataGridViewTextBoxColumn chStatus;
    private DataGridViewTextBoxColumn chStaff;
  }
}

