-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: localhost    Database: gwms
-- ------------------------------------------------------
-- Server version	8.0.25

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `quoteitemgroup`
--

DROP TABLE IF EXISTS `quoteitemgroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quoteitemgroup` (
  `quoteitemgroupid` int NOT NULL AUTO_INCREMENT,
  `QuoteNo` int NOT NULL,
  `GroupName` varchar(45) NOT NULL,
  PRIMARY KEY (`quoteitemgroupid`),
  UNIQUE KEY `quoteitemgroupid_UNIQUE` (`quoteitemgroupid`)
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quoteitemgroup`
--

LOCK TABLES `quoteitemgroup` WRITE;
/*!40000 ALTER TABLE `quoteitemgroup` DISABLE KEYS */;
INSERT INTO `quoteitemgroup` VALUES (53,1006,'Travel Costs'),(54,1006,'Office Window'),(59,1007,'Dining 1'),(61,1007,'Dining 2'),(62,1007,'Dining 3 slider '),(63,1007,'Lounge 1 East side '),(64,1007,'Lounge 2 East side '),(65,1007,'Lounge 3 North '),(66,1007,'Lounge 3 West '),(69,1007,'labour '),(70,1007,'Travel Costs'),(71,1008,'extra window #1'),(72,1008,'extra window #2 '),(73,1008,'labour '),(75,1009,'Travel Costs'),(77,1009,'Toilet Southside '),(78,1009,'#2 anti clockwise for the toilet window'),(79,1009,'#3 '),(80,1009,'#4'),(81,1009,'#5'),(82,1009,'#6 Slider '),(83,1009,'Upstairs southside Left - anti clockwise'),(84,1009,'Upstairs #2'),(85,1009,'Upstairs #3'),(86,1009,'Upstairs #4'),(87,1009,'Upstairs #5'),(88,1009,'Upstairs #6'),(89,1009,'Upstairs #7'),(90,1009,'Upstairs #8'),(91,1009,'Upstairs #9'),(92,1009,'Upstairs #10'),(93,1009,'Update #11'),(94,1009,'Upstairs #12'),(95,1009,'labour'),(97,1009,'Argon'),(98,1010,'Kitchen Window'),(99,1010,'Lounge long obscure windows '),(100,1010,'Lounge 1 North '),(101,1010,'Lounge Slider '),(102,1010,'Bed 1 '),(103,1010,'Bed 2 '),(104,1011,'Sliding door '),(105,1011,'Travel Costs'),(106,1011,'labour'),(107,1010,'Bed 2 Driveway'),(108,1010,'labour'),(109,1012,'kitchen'),(111,1013,'Kitchen '),(112,1013,'Bed 1 Driveway '),(113,1013,'Bed 1 #2 '),(114,1013,'Bed 2 #1 '),(115,1013,'Bed 2 #2 '),(116,1013,'Lounge '),(117,1013,'Bed 3  #1'),(118,1013,'Bed 3 #2'),(119,1013,'Timber windows x 2 '),(120,1014,'Kitchen '),(121,1014,'Dining'),(122,1014,'Lounge '),(124,1015,'Sliding door #1 '),(125,1015,'Sliding door #2'),(126,1014,'Travel Costs'),(127,1016,'Lounge North');
/*!40000 ALTER TABLE `quoteitemgroup` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-18 16:31:42
