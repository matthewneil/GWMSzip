﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workshop_orders
{
  public partial class StaffEdit : Form
  {
    private int StaffID;
    private String username;

    public StaffEdit(int StaffID)
    {
      InitializeComponent();
      this.StaffID = StaffID;

      Text = "New User";
      if (StaffID > 0)
      {
        Text = "Edit User";
        LoadData();
      }
    }

    public void LoadData()
    {
      chkAdmin.Checked = false;
      chkActive.Checked = false;
      chkWorkshop.Checked = false;

      DataTable dt = DataAccess.ExecuteDataTable("SELECT * FROM Staff WHERE StaffID = " + StaffID);
      try
      {
        if (dt != null && dt.Rows.Count > 0)
        {
          txtUsername.Text = dt.Rows[0]["StaffUsername"].ToString();
          username = dt.Rows[0]["StaffUsername"].ToString();
          txtPassword.Text = dt.Rows[0]["StaffPassword"].ToString();
          txtFullName.Text = dt.Rows[0]["StaffFullName"].ToString();
          txtEmail.Text = dt.Rows[0]["StaffEmail"].ToString();

          if (dt.Rows[0]["StaffAdmin"].ToString() == "1")
          {
            chkAdmin.Checked = true;
          }
          if (dt.Rows[0]["StaffWorkshop"].ToString() == "1")
          {
            chkWorkshop.Checked = true;
          }

          if (dt.Rows[0]["StaffActive"].ToString() == "1")
          {
            chkActive.Checked = true;
          }
          nudRate.Text = dt.Rows[0]["StaffRate"].ToString();
        }
      }
      catch (Exception ex)
      {
        MessageBox.Show("There was an error loading Staff Data");
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
          System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }

      DataTable dtRole = DataAccess.ExecuteDataTable("SELECT * FROM role r LEFT JOIN (SELECT RoleID AS RID, ReadOnly FROM staffrole WHERE StaffID = " + StaffID + ") s ON r.RoleID = s.RID");
      try
      {
        if(dtRole.Rows.Count > 0)
        {
          int i = 0;
          foreach(DataRow row in dtRole.Rows)
          {
            //Check if this role is applied to staff member, if so, check it
            int apply = 0;
            int rdonly = 0;
            if (row["RID"].ToString() != "") apply = 1;
            if (row["ReadOnly"].ToString() == "1") rdonly = 1;

            dgvRoles.Rows.Add(row["RoleID"].ToString(), apply, row["RoleName"].ToString(), rdonly, row["RoleDesc"].ToString());

            if(apply == 0 || row["RoleID"].ToString() == "1" || row["RoleID"].ToString() == "2") //If role is not applied to user OR selected role is admin or dev, disable the readonly check box
            {
              //dgvRoles.Rows[i].Cells[3].ReadOnly = true;
            }
            i++;
            /*
            //Add Role Name with check box
            lvRoles.Items.Add(row["RoleName"].ToString());

            
            //Sets the Name of the checkbox to the RoleID so it can be used later when updating
            lvRoles.Items[i].Name = row["RoleID"].ToString();

            //Gives the readonly column a value (not working as theres no checkbox)
            lvRoles.Items[i].SubItems.Add("Read Only");

            //Gives the description column a value
            lvRoles.Items[i].SubItems.Add(row["RoleDesc"].ToString());
            i++;*/
          }
        }
      }
      catch(Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
          System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }

    }

    private void tsClose_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private bool ValidateUsername(String user)
    {
      return user.Any(ch => !Char.IsLetterOrDigit(ch));
    }


    private void tsSave_Click(object sender, EventArgs e)
    {
      //ERROR CHECK
      String errors = "Unable to save due to the following issues:\n\n";
      txtUsername.Text = txtUsername.Text.Trim();
      if(txtUsername.Text == "")
      {
        errors += "- Username (Blank)\n";
      }
      else if (ValidateUsername(txtUsername.Text))
      {
        errors += "- Username (Must have no spaces or $pecial characters)\n";
      }
      else if (txtUsername.Text != username && DataAccess.ExecuteScalarInt("SELECT COUNT(0) FROM Staff WHERE StaffUsername = '" + txtUsername.Text + "'") > 0)
      {
        errors += "- Username (Already in use)\n";
      }
      if(txtPassword.Text == "" || txtPassword.Text.Length < 4)
      {
        errors += "- Password (Too Short - Needs at least 4 characters)\n";
      }
      if (txtFullName.Text == "")
      { 
        errors += "- Full Name (Blank)\n";
      }
      if (txtEmail.Text != "" && !DataAccess.ValidateEmail(txtEmail.Text))
      {
        errors += "- Email (Isn't formatted correctly)\n";
      }

      if (errors == "Unable to save due to the following issues:\n\n")
      {        
        //OLD ROLE CODE, DELETE
        int active = 0;
        int admin = 0;
        int workshop = 0;

        if (chkActive.Checked) active = 1;
        if (chkAdmin.Checked) admin = 1;
        if (chkWorkshop.Checked) workshop = 1;

        // Add/Update Staff Details
        DataAccess.StaffManage(StaffID, txtUsername.Text, txtPassword.Text, txtFullName.Text, txtEmail.Text, active, admin, workshop, nudRate.Value);

        //Applies the new Roles to the user
        foreach (DataGridViewRow row in dgvRoles.Rows)
        {
          int RemoveRole = 0;
          if (row.Cells[1].Value.ToString() == "0") RemoveRole = 1;

          DataAccess.StaffRoleManage(StaffID, int.Parse(row.Cells[0].Value.ToString()), int.Parse(row.Cells[3].Value.ToString()), RemoveRole);

        }
        /*
        foreach (ListViewItem item in lvRoles.Items)
        {
          int RemoveRole = 0;
          if (!item.Checked) RemoveRole = 1;

          if (item.Checked)
          {
            DataAccess.StaffRoleManage(StaffID, int.Parse(item.Name), 0, RemoveRole);
          }
        }*/
        this.Close();
      }
      else
      {
        DataAccess.ShowMessage(errors);
      }
    }


    private void label3_Click(object sender, EventArgs e)
    {

    }

    private void label4_Click(object sender, EventArgs e)
    {

    }

    private void txtUsername_TextChanged(object sender, EventArgs e)
    {
      
    }

    private void txtFullName_TextChanged(object sender, EventArgs e)
    {
      if(StaffID == 0)
      {
        txtUsername.Text = txtFullName.Text.Split(' ')[0];
      }
    }

    private void dgvRoles_CellContentClick(object sender, DataGridViewCellEventArgs e)
    {
      //This code makes sure the checkbox value is set correctly when changed
      int check;
      switch (dgvRoles.CurrentCell.ColumnIndex)
      {
        case 1: //Role check box
          check = 0;
          if (dgvRoles.Rows[dgvRoles.CurrentCell.RowIndex].Cells[1].Value.ToString() == "0") check = 1; //if checkbox isnt checked, set check to 1

          dgvRoles.Rows[dgvRoles.CurrentCell.RowIndex].Cells[1].Value = check; // set new check box value

          if (check == 0) dgvRoles.Rows[dgvRoles.CurrentCell.RowIndex].Cells[3].Value = 0; //Set readonly checkbox to null
          break;

        case 3: //Readonly check box
          if (dgvRoles.Rows[dgvRoles.CurrentCell.RowIndex].Cells[1].Value.ToString() == "0") //check if first checkbox is ticked, if not then set readonly check to false
          {
            dgvRoles.Rows[dgvRoles.CurrentCell.RowIndex].Cells[3].Value = false;
            return;
          }

          check = 0;
          if (dgvRoles.Rows[dgvRoles.CurrentCell.RowIndex].Cells[3].Value.ToString() == "0") check = 1; //if checkbox isnt checked, set check to 1

          dgvRoles.Rows[dgvRoles.CurrentCell.RowIndex].Cells[3].Value = check; // set new check box value
          break;
      }
    }
  }
}
