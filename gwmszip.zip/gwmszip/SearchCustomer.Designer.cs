﻿using System;
using System.Windows.Forms;

namespace workshop_orders
{
    partial class SearchCustomer
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SearchCustomer));
      this.txtFullName = new System.Windows.Forms.TextBox();
      this.lblCustomerName = new System.Windows.Forms.Label();
      this.txtSurname = new System.Windows.Forms.TextBox();
      this.lblSurname = new System.Windows.Forms.Label();
      this.txtPhone1 = new System.Windows.Forms.TextBox();
      this.phone1Label = new System.Windows.Forms.Label();
      this.txtPhone2 = new System.Windows.Forms.TextBox();
      this.phone2Label = new System.Windows.Forms.Label();
      this.txtEmail = new System.Windows.Forms.TextBox();
      this.label1 = new System.Windows.Forms.Label();
      this.gbMainDetails = new System.Windows.Forms.GroupBox();
      this.chkBusiness = new System.Windows.Forms.CheckBox();
      this.txtAccountNo = new System.Windows.Forms.TextBox();
      this.txtSuburb = new System.Windows.Forms.TextBox();
      this.label4 = new System.Windows.Forms.Label();
      this.lblAccountNo = new System.Windows.Forms.Label();
      this.txtAddress = new System.Windows.Forms.TextBox();
      this.txtAccountName = new System.Windows.Forms.TextBox();
      this.label16 = new System.Windows.Forms.Label();
      this.label7 = new System.Windows.Forms.Label();
      this.label13 = new System.Windows.Forms.Label();
      this.txtPostcode = new System.Windows.Forms.TextBox();
      this.txtCity = new System.Windows.Forms.TextBox();
      this.label14 = new System.Windows.Forms.Label();
      this.gbsearch = new System.Windows.Forms.GroupBox();
      this.label3 = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this.cmbField = new System.Windows.Forms.ComboBox();
      this.txtSearch = new System.Windows.Forms.TextBox();
      this.dgvCustomer = new System.Windows.Forms.DataGridView();
      this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.CustomerName = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Phone = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Address = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Email = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.toolStrip1 = new System.Windows.Forms.ToolStrip();
      this.tsClose = new System.Windows.Forms.ToolStripButton();
      this.tsSave = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
      this.tsAdd = new System.Windows.Forms.ToolStripButton();
      this.gbResult = new System.Windows.Forms.GroupBox();
      this.gbMainDetails.SuspendLayout();
      this.gbsearch.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgvCustomer)).BeginInit();
      this.toolStrip1.SuspendLayout();
      this.gbResult.SuspendLayout();
      this.SuspendLayout();
      // 
      // txtFullName
      // 
      this.txtFullName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
      this.txtFullName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtFullName.Location = new System.Drawing.Point(211, 37);
      this.txtFullName.MaxLength = 50;
      this.txtFullName.Name = "txtFullName";
      this.txtFullName.Size = new System.Drawing.Size(317, 31);
      this.txtFullName.TabIndex = 1;
      this.txtFullName.TextChanged += new System.EventHandler(this.txtFullName_TextChanged);
      // 
      // lblCustomerName
      // 
      this.lblCustomerName.AutoSize = true;
      this.lblCustomerName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblCustomerName.Location = new System.Drawing.Point(90, 40);
      this.lblCustomerName.Name = "lblCustomerName";
      this.lblCustomerName.Size = new System.Drawing.Size(115, 25);
      this.lblCustomerName.TabIndex = 23;
      this.lblCustomerName.Text = "Full Name:";
      // 
      // txtSurname
      // 
      this.txtSurname.BackColor = System.Drawing.SystemColors.ButtonFace;
      this.txtSurname.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtSurname.Location = new System.Drawing.Point(316, 74);
      this.txtSurname.MaxLength = 50;
      this.txtSurname.Name = "txtSurname";
      this.txtSurname.Size = new System.Drawing.Size(212, 31);
      this.txtSurname.TabIndex = 2;
      // 
      // lblSurname
      // 
      this.lblSurname.AutoSize = true;
      this.lblSurname.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblSurname.Location = new System.Drawing.Point(206, 77);
      this.lblSurname.Name = "lblSurname";
      this.lblSurname.Size = new System.Drawing.Size(104, 25);
      this.lblSurname.TabIndex = 24;
      this.lblSurname.Text = "Surname:";
      // 
      // txtPhone1
      // 
      this.txtPhone1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtPhone1.Location = new System.Drawing.Point(211, 161);
      this.txtPhone1.MaxLength = 15;
      this.txtPhone1.Name = "txtPhone1";
      this.txtPhone1.Size = new System.Drawing.Size(317, 31);
      this.txtPhone1.TabIndex = 3;
      // 
      // phone1Label
      // 
      this.phone1Label.AutoSize = true;
      this.phone1Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.phone1Label.Location = new System.Drawing.Point(57, 161);
      this.phone1Label.Name = "phone1Label";
      this.phone1Label.Size = new System.Drawing.Size(150, 25);
      this.phone1Label.TabIndex = 26;
      this.phone1Label.Text = "Mobile Phone:";
      // 
      // txtPhone2
      // 
      this.txtPhone2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtPhone2.Location = new System.Drawing.Point(211, 198);
      this.txtPhone2.MaxLength = 15;
      this.txtPhone2.Name = "txtPhone2";
      this.txtPhone2.Size = new System.Drawing.Size(317, 31);
      this.txtPhone2.TabIndex = 4;
      // 
      // phone2Label
      // 
      this.phone2Label.AutoSize = true;
      this.phone2Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.phone2Label.Location = new System.Drawing.Point(113, 200);
      this.phone2Label.Name = "phone2Label";
      this.phone2Label.Size = new System.Drawing.Size(98, 25);
      this.phone2Label.TabIndex = 26;
      this.phone2Label.Text = "Phone 2:";
      // 
      // txtEmail
      // 
      this.txtEmail.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
      this.txtEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtEmail.Location = new System.Drawing.Point(211, 235);
      this.txtEmail.MaxLength = 50;
      this.txtEmail.Name = "txtEmail";
      this.txtEmail.Size = new System.Drawing.Size(317, 31);
      this.txtEmail.TabIndex = 88;
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label1.Location = new System.Drawing.Point(137, 238);
      this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(71, 25);
      this.label1.TabIndex = 89;
      this.label1.Text = "Email:";
      // 
      // gbMainDetails
      // 
      this.gbMainDetails.Controls.Add(this.chkBusiness);
      this.gbMainDetails.Controls.Add(this.txtAccountNo);
      this.gbMainDetails.Controls.Add(this.txtSuburb);
      this.gbMainDetails.Controls.Add(this.label4);
      this.gbMainDetails.Controls.Add(this.lblAccountNo);
      this.gbMainDetails.Controls.Add(this.txtAddress);
      this.gbMainDetails.Controls.Add(this.lblCustomerName);
      this.gbMainDetails.Controls.Add(this.txtAccountName);
      this.gbMainDetails.Controls.Add(this.label16);
      this.gbMainDetails.Controls.Add(this.label7);
      this.gbMainDetails.Controls.Add(this.label1);
      this.gbMainDetails.Controls.Add(this.label13);
      this.gbMainDetails.Controls.Add(this.txtFullName);
      this.gbMainDetails.Controls.Add(this.txtPostcode);
      this.gbMainDetails.Controls.Add(this.txtEmail);
      this.gbMainDetails.Controls.Add(this.txtCity);
      this.gbMainDetails.Controls.Add(this.txtSurname);
      this.gbMainDetails.Controls.Add(this.label14);
      this.gbMainDetails.Controls.Add(this.lblSurname);
      this.gbMainDetails.Controls.Add(this.txtPhone1);
      this.gbMainDetails.Controls.Add(this.phone1Label);
      this.gbMainDetails.Controls.Add(this.txtPhone2);
      this.gbMainDetails.Controls.Add(this.phone2Label);
      this.gbMainDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbMainDetails.Location = new System.Drawing.Point(12, 144);
      this.gbMainDetails.Name = "gbMainDetails";
      this.gbMainDetails.Size = new System.Drawing.Size(867, 538);
      this.gbMainDetails.TabIndex = 90;
      this.gbMainDetails.TabStop = false;
      this.gbMainDetails.Text = "Main Details";
      this.gbMainDetails.Visible = false;
      // 
      // chkBusiness
      // 
      this.chkBusiness.AutoSize = true;
      this.chkBusiness.Location = new System.Drawing.Point(211, 111);
      this.chkBusiness.Name = "chkBusiness";
      this.chkBusiness.Size = new System.Drawing.Size(154, 24);
      this.chkBusiness.TabIndex = 97;
      this.chkBusiness.Text = "This is a Business";
      this.chkBusiness.UseVisualStyleBackColor = true;
      this.chkBusiness.CheckedChanged += new System.EventHandler(this.chkBusiness_CheckedChanged);
      // 
      // txtAccountNo
      // 
      this.txtAccountNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtAccountNo.Location = new System.Drawing.Point(211, 325);
      this.txtAccountNo.MaxLength = 20;
      this.txtAccountNo.Name = "txtAccountNo";
      this.txtAccountNo.Size = new System.Drawing.Size(317, 31);
      this.txtAccountNo.TabIndex = 95;
      // 
      // txtSuburb
      // 
      this.txtSuburb.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtSuburb.Location = new System.Drawing.Point(211, 414);
      this.txtSuburb.MaxLength = 20;
      this.txtSuburb.Name = "txtSuburb";
      this.txtSuburb.Size = new System.Drawing.Size(317, 31);
      this.txtSuburb.TabIndex = 90;
      // 
      // label4
      // 
      this.label4.AutoSize = true;
      this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label4.Location = new System.Drawing.Point(117, 419);
      this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(87, 25);
      this.label4.TabIndex = 91;
      this.label4.Text = "Suburb:";
      // 
      // lblAccountNo
      // 
      this.lblAccountNo.AutoSize = true;
      this.lblAccountNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblAccountNo.Location = new System.Drawing.Point(75, 328);
      this.lblAccountNo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.lblAccountNo.Name = "lblAccountNo";
      this.lblAccountNo.Size = new System.Drawing.Size(129, 25);
      this.lblAccountNo.TabIndex = 96;
      this.lblAccountNo.Text = "Account No:";
      // 
      // txtAddress
      // 
      this.txtAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtAddress.Location = new System.Drawing.Point(211, 377);
      this.txtAddress.MaxLength = 50;
      this.txtAddress.Name = "txtAddress";
      this.txtAddress.Size = new System.Drawing.Size(317, 31);
      this.txtAddress.TabIndex = 5;
      // 
      // txtAccountName
      // 
      this.txtAccountName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtAccountName.Location = new System.Drawing.Point(211, 288);
      this.txtAccountName.MaxLength = 50;
      this.txtAccountName.Name = "txtAccountName";
      this.txtAccountName.Size = new System.Drawing.Size(317, 31);
      this.txtAccountName.TabIndex = 92;
      // 
      // label16
      // 
      this.label16.AutoSize = true;
      this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label16.Location = new System.Drawing.Point(100, 490);
      this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label16.Name = "label16";
      this.label16.Size = new System.Drawing.Size(108, 25);
      this.label16.TabIndex = 83;
      this.label16.Text = "Postcode:";
      // 
      // label7
      // 
      this.label7.AutoSize = true;
      this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label7.Location = new System.Drawing.Point(46, 291);
      this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label7.Name = "label7";
      this.label7.Size = new System.Drawing.Size(158, 25);
      this.label7.TabIndex = 94;
      this.label7.Text = "Account Name:";
      // 
      // label13
      // 
      this.label13.AutoSize = true;
      this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label13.Location = new System.Drawing.Point(47, 383);
      this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label13.Name = "label13";
      this.label13.Size = new System.Drawing.Size(161, 25);
      this.label13.TabIndex = 79;
      this.label13.Text = "Billing Address:";
      // 
      // txtPostcode
      // 
      this.txtPostcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtPostcode.Location = new System.Drawing.Point(211, 487);
      this.txtPostcode.MaxLength = 6;
      this.txtPostcode.Name = "txtPostcode";
      this.txtPostcode.Size = new System.Drawing.Size(111, 31);
      this.txtPostcode.TabIndex = 7;
      // 
      // txtCity
      // 
      this.txtCity.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtCity.Location = new System.Drawing.Point(211, 450);
      this.txtCity.MaxLength = 20;
      this.txtCity.Name = "txtCity";
      this.txtCity.Size = new System.Drawing.Size(317, 31);
      this.txtCity.TabIndex = 6;
      // 
      // label14
      // 
      this.label14.AutoSize = true;
      this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label14.Location = new System.Drawing.Point(94, 453);
      this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.label14.Name = "label14";
      this.label14.Size = new System.Drawing.Size(113, 25);
      this.label14.TabIndex = 81;
      this.label14.Text = "City/Town:";
      // 
      // gbsearch
      // 
      this.gbsearch.Controls.Add(this.label3);
      this.gbsearch.Controls.Add(this.label2);
      this.gbsearch.Controls.Add(this.cmbField);
      this.gbsearch.Controls.Add(this.txtSearch);
      this.gbsearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbsearch.Location = new System.Drawing.Point(12, 39);
      this.gbsearch.Name = "gbsearch";
      this.gbsearch.Size = new System.Drawing.Size(867, 99);
      this.gbsearch.TabIndex = 1;
      this.gbsearch.TabStop = false;
      this.gbsearch.Text = "Search";
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Location = new System.Drawing.Point(32, 25);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(43, 20);
      this.label3.TabIndex = 97;
      this.label3.Text = "Field";
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Location = new System.Drawing.Point(15, 59);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(60, 20);
      this.label2.TabIndex = 96;
      this.label2.Text = "Search";
      // 
      // cmbField
      // 
      this.cmbField.FormattingEnabled = true;
      this.cmbField.Items.AddRange(new object[] {
            "Email",
            "Name",
            "Phone No.",
            "Surname"});
      this.cmbField.Location = new System.Drawing.Point(99, 22);
      this.cmbField.Name = "cmbField";
      this.cmbField.Size = new System.Drawing.Size(149, 28);
      this.cmbField.Sorted = true;
      this.cmbField.TabIndex = 95;
      this.cmbField.Text = "Name";
      // 
      // txtSearch
      // 
      this.txtSearch.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
      this.txtSearch.Location = new System.Drawing.Point(99, 56);
      this.txtSearch.Name = "txtSearch";
      this.txtSearch.Size = new System.Drawing.Size(483, 26);
      this.txtSearch.TabIndex = 1;
      this.txtSearch.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
      // 
      // dgvCustomer
      // 
      this.dgvCustomer.AllowUserToAddRows = false;
      this.dgvCustomer.AllowUserToDeleteRows = false;
      dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
      this.dgvCustomer.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
      this.dgvCustomer.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      this.dgvCustomer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvCustomer.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.CustomerName,
            this.Phone,
            this.Address,
            this.Email});
      this.dgvCustomer.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dgvCustomer.GridColor = System.Drawing.SystemColors.ControlText;
      this.dgvCustomer.Location = new System.Drawing.Point(3, 20);
      this.dgvCustomer.Name = "dgvCustomer";
      this.dgvCustomer.ReadOnly = true;
      this.dgvCustomer.RowHeadersWidth = 5;
      this.dgvCustomer.Size = new System.Drawing.Size(861, 515);
      this.dgvCustomer.TabIndex = 0;
      this.dgvCustomer.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.customerDataGrid_CellDoubleClick);
      // 
      // ID
      // 
      this.ID.HeaderText = "ID";
      this.ID.Name = "ID";
      this.ID.ReadOnly = true;
      this.ID.Visible = false;
      // 
      // CustomerName
      // 
      this.CustomerName.HeaderText = "Name";
      this.CustomerName.Name = "CustomerName";
      this.CustomerName.ReadOnly = true;
      this.CustomerName.Width = 200;
      // 
      // Phone
      // 
      this.Phone.HeaderText = "Phone";
      this.Phone.Name = "Phone";
      this.Phone.ReadOnly = true;
      this.Phone.Width = 120;
      // 
      // Address
      // 
      this.Address.HeaderText = "Address";
      this.Address.Name = "Address";
      this.Address.ReadOnly = true;
      this.Address.Width = 250;
      // 
      // Email
      // 
      this.Email.HeaderText = "Email";
      this.Email.Name = "Email";
      this.Email.ReadOnly = true;
      this.Email.Width = 250;
      // 
      // toolStrip1
      // 
      this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsClose,
            this.tsSave,
            this.toolStripSeparator1,
            this.tsAdd});
      this.toolStrip1.Location = new System.Drawing.Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new System.Drawing.Size(891, 39);
      this.toolStrip1.TabIndex = 96;
      this.toolStrip1.Text = "toolStrip1";
      // 
      // tsClose
      // 
      this.tsClose.Image = ((System.Drawing.Image)(resources.GetObject("tsClose.Image")));
      this.tsClose.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsClose.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsClose.Name = "tsClose";
      this.tsClose.Size = new System.Drawing.Size(72, 36);
      this.tsClose.Text = "Close";
      this.tsClose.Click += new System.EventHandler(this.toolStripButton1_Click_1);
      // 
      // tsSave
      // 
      this.tsSave.Image = ((System.Drawing.Image)(resources.GetObject("tsSave.Image")));
      this.tsSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsSave.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsSave.Name = "tsSave";
      this.tsSave.Size = new System.Drawing.Size(67, 36);
      this.tsSave.Text = "Save";
      this.tsSave.Click += new System.EventHandler(this.saveToolStripButton2_Click);
      // 
      // toolStripSeparator1
      // 
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
      // 
      // tsAdd
      // 
      this.tsAdd.Image = ((System.Drawing.Image)(resources.GetObject("tsAdd.Image")));
      this.tsAdd.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsAdd.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsAdd.Name = "tsAdd";
      this.tsAdd.Size = new System.Drawing.Size(122, 36);
      this.tsAdd.Text = "New Customer";
      this.tsAdd.ToolTipText = "Add ";
      this.tsAdd.Click += new System.EventHandler(this.addtoolStripButton_Click);
      // 
      // gbResult
      // 
      this.gbResult.Controls.Add(this.dgvCustomer);
      this.gbResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbResult.Location = new System.Drawing.Point(12, 144);
      this.gbResult.Name = "gbResult";
      this.gbResult.Size = new System.Drawing.Size(867, 538);
      this.gbResult.TabIndex = 97;
      this.gbResult.TabStop = false;
      this.gbResult.Text = "Results";
      // 
      // SearchCustomer
      // 
      this.AllowDrop = true;
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.AutoScroll = true;
      this.BackColor = System.Drawing.Color.White;
      this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
      this.ClientSize = new System.Drawing.Size(891, 690);
      this.Controls.Add(this.gbResult);
      this.Controls.Add(this.toolStrip1);
      this.Controls.Add(this.gbsearch);
      this.Controls.Add(this.gbMainDetails);
      this.Cursor = System.Windows.Forms.Cursors.Default;
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
      this.MaximizeBox = false;
      this.Name = "SearchCustomer";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
      this.Text = "Customer Search";
      this.Load += new System.EventHandler(this.CreateJobForm_Load);
      this.gbMainDetails.ResumeLayout(false);
      this.gbMainDetails.PerformLayout();
      this.gbsearch.ResumeLayout(false);
      this.gbsearch.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgvCustomer)).EndInit();
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.gbResult.ResumeLayout(false);
      this.ResumeLayout(false);
      this.PerformLayout();

        }

        #endregion
        private TextBox txtFullName;
        private Label lblCustomerName;
        private TextBox txtSurname;
        private Label lblSurname;
        private TextBox txtPhone1;
        private Label phone1Label;
        private TextBox txtPhone2;
        private Label phone2Label;
        private TextBox txtEmail;
        private Label label1;
        private GroupBox gbMainDetails;
        private GroupBox gbsearch;
        private TextBox txtSearch;
        private ToolStrip toolStrip1;
        private ToolStripButton tsClose;
        private ToolStripButton tsSave;
        private ComboBox cmbField;
        private ToolStripButton tsAdd;
        private TextBox txtAddress;
        private Label label16;
        private Label label13;
        private TextBox txtCity;
        private Label label14;
        private DataGridView dgvCustomer;
        private Label label3;
        private Label label2;
    private TextBox txtSuburb;
    private Label label4;
    private TextBox txtPostcode;
    private TextBox txtAccountNo;
    private Label lblAccountNo;
    private TextBox txtAccountName;
    private Label label7;
    private GroupBox gbResult;
    private DataGridViewTextBoxColumn ID;
    private DataGridViewTextBoxColumn CustomerName;
    private DataGridViewTextBoxColumn Phone;
    private DataGridViewTextBoxColumn Address;
    private DataGridViewTextBoxColumn Email;
    private CheckBox chkBusiness;
    private ToolStripSeparator toolStripSeparator1;
  }
}

