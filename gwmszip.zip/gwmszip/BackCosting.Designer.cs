﻿using System;
using System.Windows.Forms;

namespace workshop_orders
{
    partial class BackCosting
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.insurLabel = new System.Windows.Forms.Label();
            this.estimatedDataGrid = new System.Windows.Forms.DataGridView();
            this.ItemType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Description = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Copy = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.jobLabel = new System.Windows.Forms.Label();
            this.totalLabel = new System.Windows.Forms.Label();
            this.invoicedLabel = new System.Windows.Forms.Label();
            this.profitLabel = new System.Windows.Forms.Label();
            this.percentLabel = new System.Windows.Forms.Label();
            this.fixedlabel = new System.Windows.Forms.Label();
            this.labourLabel = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.signOffButton = new System.Windows.Forms.Button();
            this.estLabel = new System.Windows.Forms.Label();
            this.incompleteLabel = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.topDataGrid = new System.Windows.Forms.DataGridView();
            this.Reference = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.JobPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CostPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CostDiff = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NetMargin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.InvoicePrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.InvoiceDiff = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Gross = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ActualCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ActualNet = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ActualGross = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.invoiceDataGrid = new System.Windows.Forms.DataGridView();
            this.Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Invoice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.actualDataGrid = new System.Windows.Forms.DataGridView();
            this.ItemTypeS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Desciption = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ErrorLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.estimatedDataGrid)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.topDataGrid)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.invoiceDataGrid)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.actualDataGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // insurLabel
            // 
            this.insurLabel.AutoSize = true;
            this.insurLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.insurLabel.Location = new System.Drawing.Point(26, 167);
            this.insurLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.insurLabel.Name = "insurLabel";
            this.insurLabel.Size = new System.Drawing.Size(198, 31);
            this.insurLabel.TabIndex = 47;
            this.insurLabel.Text = "Insurance Job";
            // 
            // estimatedDataGrid
            // 
            this.estimatedDataGrid.AllowUserToAddRows = false;
            this.estimatedDataGrid.AllowUserToDeleteRows = false;
            this.estimatedDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.estimatedDataGrid.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.estimatedDataGrid.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.estimatedDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.estimatedDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ItemType,
            this.dataGridViewTextBoxColumn1,
            this.Description,
            this.Copy});
            this.estimatedDataGrid.Location = new System.Drawing.Point(7, 27);
            this.estimatedDataGrid.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.estimatedDataGrid.Name = "estimatedDataGrid";
            this.estimatedDataGrid.ReadOnly = true;
            this.estimatedDataGrid.Size = new System.Drawing.Size(670, 604);
            this.estimatedDataGrid.TabIndex = 26;
            this.estimatedDataGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.estimatedDataGrid_CellClick);
            this.estimatedDataGrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.estimatedDataGrid_CellContentClick);
            this.estimatedDataGrid.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            // 
            // ItemType
            // 
            this.ItemType.Frozen = true;
            this.ItemType.HeaderText = "Item Type";
            this.ItemType.Name = "ItemType";
            this.ItemType.ReadOnly = true;
            this.ItemType.Width = 104;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.Frozen = true;
            this.dataGridViewTextBoxColumn1.HeaderText = "Job Price";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 99;
            // 
            // Description
            // 
            this.Description.Frozen = true;
            this.Description.HeaderText = "Description";
            this.Description.Name = "Description";
            this.Description.ReadOnly = true;
            this.Description.Width = 114;
            // 
            // Copy
            // 
            this.Copy.HeaderText = "Copy";
            this.Copy.Name = "Copy";
            this.Copy.ReadOnly = true;
            this.Copy.Width = 51;
            // 
            // jobLabel
            // 
            this.jobLabel.AutoSize = true;
            this.jobLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jobLabel.Location = new System.Drawing.Point(19, 20);
            this.jobLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.jobLabel.Name = "jobLabel";
            this.jobLabel.Size = new System.Drawing.Size(505, 31);
            this.jobLabel.TabIndex = 53;
            this.jobLabel.Text = "Job 0000 - DEFAULT TEXT (ERROR)";
            // 
            // totalLabel
            // 
            this.totalLabel.AutoSize = true;
            this.totalLabel.Location = new System.Drawing.Point(139, 572);
            this.totalLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(85, 20);
            this.totalLabel.TabIndex = 56;
            this.totalLabel.Text = "Total Cost:";
            this.totalLabel.Visible = false;
            // 
            // invoicedLabel
            // 
            this.invoicedLabel.AutoSize = true;
            this.invoicedLabel.Location = new System.Drawing.Point(152, 634);
            this.invoicedLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.invoicedLabel.Name = "invoicedLabel";
            this.invoicedLabel.Size = new System.Drawing.Size(72, 20);
            this.invoicedLabel.TabIndex = 58;
            this.invoicedLabel.Text = "Invoiced:";
            this.invoicedLabel.Visible = false;
            // 
            // profitLabel
            // 
            this.profitLabel.AutoSize = true;
            this.profitLabel.Location = new System.Drawing.Point(136, 669);
            this.profitLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.profitLabel.Name = "profitLabel";
            this.profitLabel.Size = new System.Drawing.Size(88, 20);
            this.profitLabel.TabIndex = 59;
            this.profitLabel.Text = "Profit/Loss:";
            this.profitLabel.Visible = false;
            // 
            // percentLabel
            // 
            this.percentLabel.AutoSize = true;
            this.percentLabel.Location = new System.Drawing.Point(128, 701);
            this.percentLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.percentLabel.Name = "percentLabel";
            this.percentLabel.Size = new System.Drawing.Size(95, 20);
            this.percentLabel.TabIndex = 60;
            this.percentLabel.Text = "Percentage:";
            this.percentLabel.Visible = false;
            // 
            // fixedlabel
            // 
            this.fixedlabel.AutoSize = true;
            this.fixedlabel.Location = new System.Drawing.Point(128, 540);
            this.fixedlabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.fixedlabel.Name = "fixedlabel";
            this.fixedlabel.Size = new System.Drawing.Size(96, 20);
            this.fixedlabel.TabIndex = 61;
            this.fixedlabel.Text = "Fixed Costs:";
            this.fixedlabel.Visible = false;
            // 
            // labourLabel
            // 
            this.labourLabel.AutoSize = true;
            this.labourLabel.Location = new System.Drawing.Point(128, 786);
            this.labourLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labourLabel.Name = "labourLabel";
            this.labourLabel.Size = new System.Drawing.Size(221, 20);
            this.labourLabel.TabIndex = 62;
            this.labourLabel.Text = "Labour Cost: 01:30:00 @ $30:";
            this.labourLabel.Visible = false;
            this.labourLabel.Click += new System.EventHandler(this.labourLabel_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(128, 744);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(95, 20);
            this.label7.TabIndex = 64;
            this.label7.Text = "Actual Cost:";
            this.label7.Visible = false;
            // 
            // signOffButton
            // 
            this.signOffButton.BackColor = System.Drawing.Color.White;
            this.signOffButton.Location = new System.Drawing.Point(1598, 11);
            this.signOffButton.Name = "signOffButton";
            this.signOffButton.Size = new System.Drawing.Size(247, 52);
            this.signOffButton.TabIndex = 65;
            this.signOffButton.Text = "Sign off / Approve";
            this.signOffButton.UseVisualStyleBackColor = false;
            this.signOffButton.Click += new System.EventHandler(this.signOffButton_Click);
            // 
            // estLabel
            // 
            this.estLabel.AutoSize = true;
            this.estLabel.Location = new System.Drawing.Point(29, 786);
            this.estLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.estLabel.Name = "estLabel";
            this.estLabel.Size = new System.Drawing.Size(91, 20);
            this.estLabel.TabIndex = 66;
            this.estLabel.Text = "(Estimated)";
            this.estLabel.Visible = false;
            // 
            // incompleteLabel
            // 
            this.incompleteLabel.AutoSize = true;
            this.incompleteLabel.Location = new System.Drawing.Point(37, 669);
            this.incompleteLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.incompleteLabel.Name = "incompleteLabel";
            this.incompleteLabel.Size = new System.Drawing.Size(91, 20);
            this.incompleteLabel.TabIndex = 67;
            this.incompleteLabel.Text = "(Estimated)";
            this.incompleteLabel.Visible = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.topDataGrid);
            this.groupBox1.Location = new System.Drawing.Point(25, 69);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1827, 81);
            this.groupBox1.TabIndex = 68;
            this.groupBox1.TabStop = false;
            // 
            // topDataGrid
            // 
            this.topDataGrid.AllowUserToAddRows = false;
            this.topDataGrid.AllowUserToDeleteRows = false;
            this.topDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.topDataGrid.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.topDataGrid.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.topDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.topDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Reference,
            this.JobPrice,
            this.CostPrice,
            this.CostDiff,
            this.NetMargin,
            this.InvoicePrice,
            this.InvoiceDiff,
            this.Gross,
            this.ActualCost,
            this.ActualNet,
            this.ActualGross});
            this.topDataGrid.Location = new System.Drawing.Point(7, 15);
            this.topDataGrid.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.topDataGrid.Name = "topDataGrid";
            this.topDataGrid.ReadOnly = true;
            this.topDataGrid.Size = new System.Drawing.Size(1813, 53);
            this.topDataGrid.TabIndex = 71;
            // 
            // Reference
            // 
            this.Reference.HeaderText = "Reference";
            this.Reference.Name = "Reference";
            this.Reference.ReadOnly = true;
            this.Reference.Width = 109;
            // 
            // JobPrice
            // 
            this.JobPrice.HeaderText = "Job Price";
            this.JobPrice.Name = "JobPrice";
            this.JobPrice.ReadOnly = true;
            this.JobPrice.Width = 99;
            // 
            // CostPrice
            // 
            this.CostPrice.HeaderText = "Cost Price";
            this.CostPrice.Name = "CostPrice";
            this.CostPrice.ReadOnly = true;
            this.CostPrice.Width = 106;
            // 
            // CostDiff
            // 
            this.CostDiff.HeaderText = "Cost Diff";
            this.CostDiff.Name = "CostDiff";
            this.CostDiff.ReadOnly = true;
            this.CostDiff.Width = 96;
            // 
            // NetMargin
            // 
            this.NetMargin.HeaderText = "Net Margin";
            this.NetMargin.Name = "NetMargin";
            this.NetMargin.ReadOnly = true;
            this.NetMargin.Width = 111;
            // 
            // InvoicePrice
            // 
            this.InvoicePrice.HeaderText = "Invoice Price";
            this.InvoicePrice.Name = "InvoicePrice";
            this.InvoicePrice.ReadOnly = true;
            this.InvoicePrice.Width = 123;
            // 
            // InvoiceDiff
            // 
            this.InvoiceDiff.HeaderText = "Invoice Diff";
            this.InvoiceDiff.Name = "InvoiceDiff";
            this.InvoiceDiff.ReadOnly = true;
            this.InvoiceDiff.Width = 113;
            // 
            // Gross
            // 
            this.Gross.HeaderText = "GrossMargin";
            this.Gross.Name = "Gross";
            this.Gross.ReadOnly = true;
            this.Gross.Width = 125;
            // 
            // ActualCost
            // 
            this.ActualCost.HeaderText = "ActualCost";
            this.ActualCost.Name = "ActualCost";
            this.ActualCost.ReadOnly = true;
            this.ActualCost.Width = 112;
            // 
            // ActualNet
            // 
            this.ActualNet.HeaderText = "Actual Net";
            this.ActualNet.Name = "ActualNet";
            this.ActualNet.ReadOnly = true;
            this.ActualNet.Width = 108;
            // 
            // ActualGross
            // 
            this.ActualGross.HeaderText = "Actual Gross";
            this.ActualGross.Name = "ActualGross";
            this.ActualGross.ReadOnly = true;
            this.ActualGross.Width = 126;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.invoiceDataGrid);
            this.groupBox2.Location = new System.Drawing.Point(25, 201);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(332, 605);
            this.groupBox2.TabIndex = 69;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Customer Invoices";
            // 
            // invoiceDataGrid
            // 
            this.invoiceDataGrid.AllowUserToAddRows = false;
            this.invoiceDataGrid.AllowUserToDeleteRows = false;
            this.invoiceDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.invoiceDataGrid.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.invoiceDataGrid.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.invoiceDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.invoiceDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Date,
            this.Price,
            this.Invoice});
            this.invoiceDataGrid.Location = new System.Drawing.Point(7, 27);
            this.invoiceDataGrid.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.invoiceDataGrid.Name = "invoiceDataGrid";
            this.invoiceDataGrid.ReadOnly = true;
            this.invoiceDataGrid.Size = new System.Drawing.Size(318, 570);
            this.invoiceDataGrid.TabIndex = 70;
            // 
            // Date
            // 
            this.Date.HeaderText = "Date";
            this.Date.Name = "Date";
            this.Date.ReadOnly = true;
            this.Date.Width = 69;
            // 
            // Price
            // 
            this.Price.HeaderText = "Price";
            this.Price.Name = "Price";
            this.Price.ReadOnly = true;
            this.Price.Width = 69;
            // 
            // Invoice
            // 
            this.Invoice.HeaderText = "Invoice";
            this.Invoice.Name = "Invoice";
            this.Invoice.ReadOnly = true;
            this.Invoice.Width = 84;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.estimatedDataGrid);
            this.groupBox3.Location = new System.Drawing.Point(363, 167);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(684, 639);
            this.groupBox3.TabIndex = 69;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Factory Job Costs";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.actualDataGrid);
            this.groupBox4.Location = new System.Drawing.Point(1053, 167);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(799, 639);
            this.groupBox4.TabIndex = 69;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Invoiced Costs";
            // 
            // actualDataGrid
            // 
            this.actualDataGrid.AllowUserToAddRows = false;
            this.actualDataGrid.AllowUserToDeleteRows = false;
            this.actualDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.actualDataGrid.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.actualDataGrid.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.actualDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.actualDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ItemTypeS,
            this.dataGridViewTextBoxColumn2,
            this.Desciption});
            this.actualDataGrid.Location = new System.Drawing.Point(7, 27);
            this.actualDataGrid.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.actualDataGrid.Name = "actualDataGrid";
            this.actualDataGrid.ReadOnly = true;
            this.actualDataGrid.Size = new System.Drawing.Size(785, 604);
            this.actualDataGrid.TabIndex = 27;
            // 
            // ItemTypeS
            // 
            this.ItemTypeS.HeaderText = "Item Type";
            this.ItemTypeS.Name = "ItemTypeS";
            this.ItemTypeS.ReadOnly = true;
            this.ItemTypeS.Width = 104;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Cost Price";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 106;
            // 
            // Desciption
            // 
            this.Desciption.HeaderText = "Description";
            this.Desciption.Name = "Desciption";
            this.Desciption.ReadOnly = true;
            this.Desciption.Width = 114;
            // 
            // ErrorLabel
            // 
            this.ErrorLabel.AutoSize = true;
            this.ErrorLabel.ForeColor = System.Drawing.Color.Red;
            this.ErrorLabel.Location = new System.Drawing.Point(1187, 11);
            this.ErrorLabel.Name = "ErrorLabel";
            this.ErrorLabel.Size = new System.Drawing.Size(56, 20);
            this.ErrorLabel.TabIndex = 70;
            this.ErrorLabel.Text = "Errors:";
            this.ErrorLabel.Visible = false;
            // 
            // BackCosting
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1878, 834);
            this.Controls.Add(this.ErrorLabel);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.incompleteLabel);
            this.Controls.Add(this.estLabel);
            this.Controls.Add(this.signOffButton);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.labourLabel);
            this.Controls.Add(this.fixedlabel);
            this.Controls.Add(this.percentLabel);
            this.Controls.Add(this.profitLabel);
            this.Controls.Add(this.invoicedLabel);
            this.Controls.Add(this.totalLabel);
            this.Controls.Add(this.jobLabel);
            this.Controls.Add(this.insurLabel);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximizeBox = false;
            this.Name = "BackCosting";
            this.Text = "BMS - Costs";
            this.Load += new System.EventHandler(this.BackCosting_Load);
            ((System.ComponentModel.ISupportInitialize)(this.estimatedDataGrid)).EndInit();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.topDataGrid)).EndInit();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.invoiceDataGrid)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.actualDataGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Label insurLabel;
        private DataGridView estimatedDataGrid;
        private Label jobLabel;
        private Label totalLabel;
        private Label invoicedLabel;
        private Label profitLabel;
        private Label percentLabel;
        private Label fixedlabel;
        private Label labourLabel;
        private Label label7;
        private Button signOffButton;
        private Label estLabel;
        private Label incompleteLabel;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private GroupBox groupBox3;
        private GroupBox groupBox4;
        private DataGridView actualDataGrid;
        private DataGridView invoiceDataGrid;
        private DataGridView topDataGrid;
        private DataGridViewTextBoxColumn Reference;
        private DataGridViewTextBoxColumn JobPrice;
        private DataGridViewTextBoxColumn CostPrice;
        private DataGridViewTextBoxColumn CostDiff;
        private DataGridViewTextBoxColumn NetMargin;
        private DataGridViewTextBoxColumn InvoicePrice;
        private DataGridViewTextBoxColumn InvoiceDiff;
        private DataGridViewTextBoxColumn Gross;
        private DataGridViewTextBoxColumn ActualCost;
        private DataGridViewTextBoxColumn ActualNet;
        private DataGridViewTextBoxColumn ActualGross;
        private DataGridViewTextBoxColumn ItemTypeS;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private DataGridViewTextBoxColumn Desciption;
        private DataGridViewTextBoxColumn Date;
        private DataGridViewTextBoxColumn Price;
        private DataGridViewTextBoxColumn Invoice;
        private Label ErrorLabel;
        private DataGridViewTextBoxColumn ItemType;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private DataGridViewTextBoxColumn Description;
        private DataGridViewCheckBoxColumn Copy;
    }
}

