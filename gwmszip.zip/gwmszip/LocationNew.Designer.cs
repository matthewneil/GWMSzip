﻿
namespace workshop_orders
{
  partial class LocationNew
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.cmbGroup = new System.Windows.Forms.ComboBox();
      this.cmbSubGroup = new System.Windows.Forms.ComboBox();
      this.label1 = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this.txtGroup = new System.Windows.Forms.TextBox();
      this.txtSubGroup = new System.Windows.Forms.TextBox();
      this.btnNewGroup = new System.Windows.Forms.Button();
      this.btnNewSubGroup = new System.Windows.Forms.Button();
      this.txtCode = new System.Windows.Forms.TextBox();
      this.txtDescription = new System.Windows.Forms.TextBox();
      this.label3 = new System.Windows.Forms.Label();
      this.label4 = new System.Windows.Forms.Label();
      this.toolStrip1 = new System.Windows.Forms.ToolStrip();
      this.tsBack = new System.Windows.Forms.ToolStripButton();
      this.tsSave = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
      this.groupBox1.SuspendLayout();
      this.toolStrip1.SuspendLayout();
      this.SuspendLayout();
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.Add(this.label4);
      this.groupBox1.Controls.Add(this.label3);
      this.groupBox1.Controls.Add(this.txtDescription);
      this.groupBox1.Controls.Add(this.txtCode);
      this.groupBox1.Controls.Add(this.btnNewSubGroup);
      this.groupBox1.Controls.Add(this.btnNewGroup);
      this.groupBox1.Controls.Add(this.txtSubGroup);
      this.groupBox1.Controls.Add(this.txtGroup);
      this.groupBox1.Controls.Add(this.label2);
      this.groupBox1.Controls.Add(this.label1);
      this.groupBox1.Controls.Add(this.cmbSubGroup);
      this.groupBox1.Controls.Add(this.cmbGroup);
      this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.groupBox1.Location = new System.Drawing.Point(0, 39);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(800, 411);
      this.groupBox1.TabIndex = 0;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "New Location";
      // 
      // cmbGroup
      // 
      this.cmbGroup.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.cmbGroup.Enabled = false;
      this.cmbGroup.FormattingEnabled = true;
      this.cmbGroup.Location = new System.Drawing.Point(104, 34);
      this.cmbGroup.Name = "cmbGroup";
      this.cmbGroup.Size = new System.Drawing.Size(154, 26);
      this.cmbGroup.TabIndex = 0;
      // 
      // cmbSubGroup
      // 
      this.cmbSubGroup.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.cmbSubGroup.FormattingEnabled = true;
      this.cmbSubGroup.Location = new System.Drawing.Point(104, 66);
      this.cmbSubGroup.Name = "cmbSubGroup";
      this.cmbSubGroup.Size = new System.Drawing.Size(154, 26);
      this.cmbSubGroup.TabIndex = 1;
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(48, 37);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(50, 18);
      this.label1.TabIndex = 2;
      this.label1.Text = "Group";
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Location = new System.Drawing.Point(18, 69);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(80, 18);
      this.label2.TabIndex = 3;
      this.label2.Text = "Sub Group";
      // 
      // txtGroup
      // 
      this.txtGroup.Location = new System.Drawing.Point(104, 34);
      this.txtGroup.Name = "txtGroup";
      this.txtGroup.Size = new System.Drawing.Size(154, 24);
      this.txtGroup.TabIndex = 4;
      this.txtGroup.Visible = false;
      this.txtGroup.TextChanged += new System.EventHandler(this.txtGroup_TextChanged);
      // 
      // txtSubGroup
      // 
      this.txtSubGroup.Location = new System.Drawing.Point(104, 68);
      this.txtSubGroup.Name = "txtSubGroup";
      this.txtSubGroup.Size = new System.Drawing.Size(154, 24);
      this.txtSubGroup.TabIndex = 5;
      this.txtSubGroup.Visible = false;
      // 
      // btnNewGroup
      // 
      this.btnNewGroup.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnNewGroup.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
      this.btnNewGroup.Image = global::workshop_orders.Properties.Resources.addnew1;
      this.btnNewGroup.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
      this.btnNewGroup.Location = new System.Drawing.Point(264, 32);
      this.btnNewGroup.Name = "btnNewGroup";
      this.btnNewGroup.Size = new System.Drawing.Size(26, 28);
      this.btnNewGroup.TabIndex = 6;
      this.btnNewGroup.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      this.btnNewGroup.UseVisualStyleBackColor = false;
      this.btnNewGroup.Visible = false;
      this.btnNewGroup.Click += new System.EventHandler(this.btnNewGroup_Click);
      // 
      // btnNewSubGroup
      // 
      this.btnNewSubGroup.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnNewSubGroup.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
      this.btnNewSubGroup.Image = global::workshop_orders.Properties.Resources.addnew1;
      this.btnNewSubGroup.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
      this.btnNewSubGroup.Location = new System.Drawing.Point(264, 64);
      this.btnNewSubGroup.Name = "btnNewSubGroup";
      this.btnNewSubGroup.Size = new System.Drawing.Size(26, 28);
      this.btnNewSubGroup.TabIndex = 7;
      this.btnNewSubGroup.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      this.btnNewSubGroup.UseVisualStyleBackColor = false;
      this.btnNewSubGroup.Click += new System.EventHandler(this.btnNewSubGroup_Click);
      // 
      // txtCode
      // 
      this.txtCode.Location = new System.Drawing.Point(104, 98);
      this.txtCode.MaxLength = 45;
      this.txtCode.Name = "txtCode";
      this.txtCode.Size = new System.Drawing.Size(186, 24);
      this.txtCode.TabIndex = 8;
      this.txtCode.Visible = false;
      // 
      // txtDescription
      // 
      this.txtDescription.AcceptsReturn = true;
      this.txtDescription.Location = new System.Drawing.Point(104, 128);
      this.txtDescription.Multiline = true;
      this.txtDescription.Name = "txtDescription";
      this.txtDescription.Size = new System.Drawing.Size(368, 166);
      this.txtDescription.TabIndex = 9;
      this.txtDescription.Visible = false;
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Location = new System.Drawing.Point(18, 131);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(83, 18);
      this.label3.TabIndex = 10;
      this.label3.Text = "Description";
      // 
      // label4
      // 
      this.label4.AutoSize = true;
      this.label4.Location = new System.Drawing.Point(54, 101);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(44, 18);
      this.label4.TabIndex = 11;
      this.label4.Text = "Code";
      // 
      // toolStrip1
      // 
      this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsBack,
            this.tsSave,
            this.toolStripSeparator1});
      this.toolStrip1.Location = new System.Drawing.Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new System.Drawing.Size(800, 39);
      this.toolStrip1.TabIndex = 1;
      this.toolStrip1.Text = "toolStrip1";
      // 
      // tsBack
      // 
      this.tsBack.Image = global::workshop_orders.Properties.Resources.back;
      this.tsBack.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsBack.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsBack.Name = "tsBack";
      this.tsBack.Size = new System.Drawing.Size(68, 36);
      this.tsBack.Text = "Back";
      this.tsBack.Click += new System.EventHandler(this.tsBack_Click);
      // 
      // tsSave
      // 
      this.tsSave.Image = global::workshop_orders.Properties.Resources.save;
      this.tsSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsSave.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsSave.Name = "tsSave";
      this.tsSave.Size = new System.Drawing.Size(67, 36);
      this.tsSave.Text = "Save";
      this.tsSave.Click += new System.EventHandler(this.tsSave_Click);
      // 
      // toolStripSeparator1
      // 
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
      // 
      // LocationNew
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.ClientSize = new System.Drawing.Size(800, 450);
      this.Controls.Add(this.groupBox1);
      this.Controls.Add(this.toolStrip1);
      this.Name = "LocationNew";
      this.Text = "New Location";
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.Button btnNewGroup;
    private System.Windows.Forms.TextBox txtSubGroup;
    private System.Windows.Forms.TextBox txtGroup;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.ComboBox cmbSubGroup;
    private System.Windows.Forms.ComboBox cmbGroup;
    private System.Windows.Forms.Button btnNewSubGroup;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.TextBox txtDescription;
    private System.Windows.Forms.TextBox txtCode;
    private System.Windows.Forms.ToolStrip toolStrip1;
    private System.Windows.Forms.ToolStripButton tsBack;
    private System.Windows.Forms.ToolStripButton tsSave;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
  }
}