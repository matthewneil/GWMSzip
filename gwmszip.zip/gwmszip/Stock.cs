﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workshop_orders
{
  public partial class Stock : Form
  {
    private string section = "all";
    public Stock()
    {
      InitializeComponent();

      LoadData();
		}

    private string FilterField()
    {
      if (rbDescription.Checked) return "icDescription";
      return "icCode";
    }

    private string FilterLimit()
    {
      if (chkLimit.Checked) return "LIMIT 100";
      return "";
    }

    private string FilterType()
    {
      if (rbAuto.Checked) return "AND igSubGroup = 'Auto'";
      if (rbGlass.Checked) return "AND igSubGroup = 'Glass'";
      return "";
    }

    private string FilterInStock()
    {
      if (chkInStock.Checked) return "AND (LocationID IS NOT NULL AND LocationID != -1)";
      return "";
    }

    private void LoadData()
    {
      SetSelectedColor();
      dgvItems.AutoGenerateColumns = false;
      switch (section)
      {
        case "notordered":
          try
          {
            /*DataTable dt = DataAccess.ExecuteDataTable(
              "SELECT j.jobitemID AS itemcostID, ItemStockID, i.icCode, i.icDescription, i.icCost, i.icPrice, i.uom, 1 AS quantity FROM itemcost i " +
              "INNER JOIN jobitem j ON i.ItemCostID = j.ItemCostID " +
              "INNER JOIN itemgroup g ON g.ItemGroupID = i.ItemGroupID " +
              "WHERE j.StatusID = 15;"); //StatusID '15' is 'Credit'

            DataTable dt2 = DataAccess.ExecuteDataTable(
              String.Format("SELECT jobitemID, JobID, ItemStockID, icCode, icDescription, StatusName, uom, quantity FROM vwitemstock " +
              "WHERE {0} LIKE '{1}%' " +
                "{2} " +
                "AND StatusID = 12 " + //'12' is 'Not Ordered'
                "ORDER BY {0} {3};",
                FilterField(), txtSearch.Text, FilterType(), FilterLimit()));*/

            DataTable dt = DataAccess.ExecuteDataTable(
              String.Format("SELECT ic.ItemCostID, ji.JobItemID, c.Code, ji.ItemStockID, ji.JobID, ic.icCode, ic.icDescription, ic.icCost, ic.icPrice, ic.uom, COUNT(*) AS Quantity, s.StatusName " +
              "FROM JobItem ji " +
              "INNER JOIN itemcost ic ON ji.ItemCostID = ic.ItemCostID " +
              "INNER JOIN status s ON s.StatusID = ji.StatusID " +
              "LEFT JOIN itemcode c ON c.LinkID = ic.ItemCostID " +
              "WHERE {0} LIKE '{1}%' " +
              "AND ji.StatusID = 12 " +
              "GROUP BY ji.JobID, ic.ItemCostID"
              , FilterField(), txtSearch.Text));

            /*DataTable dt3 = DataAccess.ExecuteDataTable(
              String.Format(
                "SELECT ItemCostID, ItemStockID, JobItemID, icCode, icDescription, icCost, icPrice, JobID " +
                "FROM vwitemlocationstock " +
                "WHERE {0} LIKE '{1}%' " +
                "{2} " +
                "AND StatusID = 12" + //Location 3 is Onorder
                "ORDER BY {0} {3};",
                FilterField(), txtSearch.Text, FilterType(), FilterLimit()));*/


            dgvItems.DataSource = dt;
            chActionBtn.Text = "On Order";

          }
          catch (Exception ex)
          {
            DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
              System.Reflection.MethodBase.GetCurrentMethod().Name, "");
          }
          break;

        case "onorder":
          try
          {
            DataTable dt = DataAccess.ExecuteDataTable(
              String.Format(
                "SELECT ItemCostID, ItemStockID, JobItemID, icCode, code, icDescription, icCost, icPrice, Quantity, JobID " +
                "FROM vwitemlocationstock " +
                "WHERE {0} LIKE '{1}%' " +
                "{2} " +
                "AND LocationID = 3 " +
                "AND Quantity > 0 " + //Location 3 is Onorder
                "ORDER BY {0} {3};",
                FilterField(), txtSearch.Text, FilterType(),  FilterLimit()));


            dgvItems.DataSource = dt;

            chActionBtn.Text = "Receipt";
            /*
            DataTable dt = DataAccess.ExecuteDataTable(
              String.Format("SELECT jobitemID, JobID, ItemStockID, icCode, icDescription, StatusName, uom, quantity, LocationCode FROM vwitemstock " +
              "WHERE {0} LIKE '{1}%' " +
                "{2} " +
                "AND StatusID = 13 " + 
                "ORDER BY {0} {3};",
                FilterField(), txtSearch.Text, FilterType(), FilterLimit()));


            dgvJobItem.DataSource = dt;
            dgvItems.Visible = false;
            dgvJobItem.Visible = true;*/
          }
          catch (Exception ex)
          {
            DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
              System.Reflection.MethodBase.GetCurrentMethod().Name, "");
          }
          break;

        case "returns":
          try
          {
            DataTable dt = DataAccess.ExecuteDataTable(
              String.Format(
                "SELECT ItemCostID, ItemStockID, icCode, code, icDescription, icCost, icPrice, uom, Quantity " +
                "FROM vwitemstock " +
                "WHERE {0} LIKE '{1}%' " +
                "{2} " +
                "AND LocationID = 4 " +
                "AND Quantity > 0 " +  //Location ID 4 is Credit
                "ORDER BY {0} {3};",
                FilterField(), txtSearch.Text, FilterType(), FilterLimit()));
            chActionBtn.Text = "Return";

            dgvItems.DataSource = dt;
          }
          catch (Exception ex)
          {
            DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
              System.Reflection.MethodBase.GetCurrentMethod().Name, "");
          }
          break;

        case "reservations":
          try
          {
           /* DataTable dt2 = DataAccess.ExecuteDataTable(
               String.Format(
                 "SELECT ItemCostID, ItemStockID, icCode, icDescription, icCost, icPrice, Quantity, JobID " +
                 "FROM vwitemlocationstock " +
                 "WHERE {0} LIKE '{1}%' " +
                 "{2} " +
                 "AND MovementTypeID = 4 " + //MovementTypeID 4 indicates the stock added is a reservation
                 "ORDER BY {0} {3};",
                 FilterField(), txtSearch.Text, FilterType(), FilterLimit()));*/

            DataTable dt = DataAccess.ExecuteDataTable(
               String.Format(
                 "SELECT c.ItemCostID, s.ItemStockID, icCode, code, icDescription, icCost, icPrice, Quantity, JobID, ItemMovementID, ji.JobItemID " +
                 "FROM ItemMovement im INNER JOIN ItemStock s ON im.ItemStockID = s.ItemStockID " +
                 "INNER JOIN ItemCost c ON s.ItemCostID = c.ItemCostID " +
                 "INNER JOIN JobItem ji ON s.ItemStockID = ji.ItemStockID " +
                 "LEFT JOIN itemcode ic ON ic.LinkID = c.ItemCostID " +
                 "WHERE {0} LIKE '{1}%' " +
                 "{2} " +
                 "AND MovementTypeID = 4 " + //MovementTypeID 4 indicates the stock added is a reservation
                 "ORDER BY {0} {3};",
                 FilterField(), txtSearch.Text, FilterType(), FilterLimit()));

            chActionBtn.Text = "Reserve";
            dgvItems.DataSource = dt;
          }
          catch (Exception ex)
          {
            DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
              System.Reflection.MethodBase.GetCurrentMethod().Name, "");
          }
          break;

        default:
          try
          {
            DataTable dt = DataAccess.ExecuteDataTable(
              String.Format(
                "SELECT ItemCostID, ItemStockID, icCode, icDescription, icCost, icPrice, uom, Quantity " +
                "FROM vwitemstock " +
                "WHERE {0} LIKE '{1}%' " +
                "{2} " +
                "{3} " +
                "ORDER BY {0} {4};", 
                FilterField(), txtSearch.Text, FilterType(), FilterInStock(), FilterLimit()));

            if (txtSearch.Text.Trim() == "")
            {
              dt.Rows.Clear();
            }
            dgvItems.DataSource = dt;
          }
          catch (Exception ex)
          {
            DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
              System.Reflection.MethodBase.GetCurrentMethod().Name, "SELECT * FROM vwitemstock;");
          }
          break;
      }

      try
      {
        int count = DataAccess.ExecuteScalarInt(
              String.Format("SELECT COUNT(*) " +
              "FROM JobItem ji " +
              "INNER JOIN itemcost ic ON ji.ItemCostID = ic.ItemCostID " +
              "INNER JOIN status s ON s.StatusID = ji.StatusID " +
              "WHERE ji.StatusID = 12 " +
              "GROUP BY ic.ItemCostID"
              ));

        tsNotOrdered.Text = "Not Ordered (" + count + ")";
      }
      catch (Exception ex)
      {
        tsNotOrdered.Text = "Not Ordered";
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
            System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }

      try
      {
        int count = DataAccess.ExecuteScalarInt(
                "SELECT COUNT(*) " +
                "FROM vwitemlocationstock " +
                "WHERE LocationID = 3 " +
                "AND Quantity > 0 "//Location 3 is Onorder 
                );

        tsOnOrder.Text = "On Order (" + count + ")";
      }
      catch (Exception ex)
      {
        tsOnOrder.Text = "On Order";
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
            System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }

      try
      {
        int count = DataAccess.ExecuteScalarInt(
              String.Format(
                "SELECT COUNT(*) " +
                "FROM vwitemstock " +
                "WHERE LocationID = 4 " +
                "AND Quantity > 0 " //Location 4 is credit
                ));

        tsReturns.Text = "Returns (" + count + ")";
      }
      catch (Exception ex)
      {
        tsReturns.Text = "Returns";
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
            System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }

      try
      {
        int count = DataAccess.ExecuteScalarInt(
              "SELECT COUNT(*) " +
               "FROM ItemMovement im INNER JOIN ItemStock s ON im.ItemStockID = s.ItemStockID " +
                 "INNER JOIN ItemCost c ON s.ItemCostID = c.ItemCostID " +
                 "LEFT JOIN JobItem ji ON s.ItemStockID = ji.ItemStockID " +
                 "WHERE MovementTypeID = 4 ");//MovementTypeID 4 indicates the stock added is a reservation

        tsReservations.Text = "Reservations (" + count + ")";
      } 
      catch (Exception ex)
      {
        tsReservations.Text = "Reservations";
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
            System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }
    }

    private void cmbStatus_SelectedIndexChanged(object sender, EventArgs e)
    {
      LoadData();
    }

    


    private void tbClose_Click(object sender, EventArgs e)
    {
			this.Close();
    }

    private void dgvItems_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      EditItem();
    }

    private void EditItem()
    {
      if (dgvItems.SelectedRows.Count > 0 && dgvItems.SelectedRows[0].Index > -1)
      {
        FormManagement.ShowChildForm(new ItemEdit((int)dgvItems.SelectedRows[0].Cells["chItemID"].Value));
        return;
        
      }
    }

    private void Action()
    {
      if (dgvItems.SelectedRows.Count > 0 && dgvItems.SelectedRows[0].Index > -1)
      {
        switch (section)
        {
          case "notordered":
            FormManagement.ShowDialogForm("MaterialMovement", (int)dgvItems.SelectedRows[0].Cells["chJobItemID"].Value);
            LoadData();
            break;

          case "onorder":
            try
            {
              ItemLocation ilFrm = new ItemLocation(int.Parse(dgvItems.SelectedRows[0].Cells["stockID"].Value.ToString()), int.Parse(dgvItems.SelectedRows[0].Cells["chItemID"].Value.ToString()), int.Parse(dgvItems.SelectedRows[0].Cells["chJobItemID"].Value.ToString()), 1);
              FormManagement.ShowDialogForm(ilFrm);
              LoadData();
            } 
            catch (Exception ex)
            {
              DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
            System.Reflection.MethodBase.GetCurrentMethod().Name, "");
            }
            break;

          case "returns":
            bool res = DataAccess.ShowMessage("Click 'Yes' to Return this product to the vendor,\n\n or Click 'No' to return item to stock", "Return", false);
            if (res)
            {
              DataAccess.ItemMovementManage(int.Parse(dgvItems.SelectedRows[0].Cells["stockID"].Value.ToString()), 3 /*return to vendor*/, -1, DataAccess.InternalIDType.Item, -1, 0, "Returned to vendor", 0);
            }
            else
            {
              ItemLocation ilFrm2 = new ItemLocation(int.Parse(dgvItems.SelectedRows[0].Cells["stockID"].Value.ToString()), int.Parse(dgvItems.SelectedRows[0].Cells["chItemID"].Value.ToString()), -1, 1);
              FormManagement.ShowDialogForm(ilFrm2);
            }
            LoadData();
            break;

          case "reservations":
            bool res2 = DataAccess.ShowMessage("Click 'Yes' if this product is avaliable to allocate,\n\n or Click 'No' and send this record to the not ordered list", "Allocate", false);
            if (res2)
            {
              try
              {
                ItemLocation ilFrm3 = new ItemLocation((int)dgvItems.SelectedRows[0].Cells["stockID"].Value, (int)dgvItems.SelectedRows[0].Cells["chItemID"].Value, -1, 1);
                FormManagement.ShowDialogForm(ilFrm3);
                DataAccess.JobItemManage(int.Parse(dgvItems.SelectedRows[0].Cells["chJobItemID"].Value.ToString()), -1, -1, 17, 0, 0, -1);
                //MessageBox.Show("DELETE FROM itemmovement WHERE ItemMovementID = " + dgvItems.SelectedRows[0].Cells["chItemMovementID"].Value + " AND MovementTypeID = 4");
                DataAccess.ExecuteNonQuery("DELETE FROM itemmovement WHERE ItemMovementID = " + dgvItems.SelectedRows[0].Cells["chItemMovementID"].Value + " AND MovementTypeID = 4");
              }
              catch (Exception ex){ MessageBox.Show(ex.ToString()); }
            }
            else
            {
              try
              {
                DataAccess.JobItemManage(int.Parse(dgvItems.SelectedRows[0].Cells["chJobItemID"].Value.ToString()), -1, -1, 12, 0, 0, -1);
                DataAccess.ExecuteNonQuery("DELETE FROM itemmovement WHERE ItemMovementID = " + dgvItems.SelectedRows[0].Cells["chItemMovementID"].Value + " AND MovementTypeID = 4");
              }
              catch { }
            }
            LoadData();
            break; 

          default:
            FormManagement.ShowChildForm(new ItemEdit((int)dgvItems.SelectedRows[0].Cells["chItemID"].Value));
            break;
        }
      }

    }

    private void tsNew_Click(object sender, EventArgs e)
    {
      ItemEdit frm = new ItemEdit(0);
      FormManagement.ShowDialogForm(frm);
    }

    private void tsRefresh_Click(object sender, EventArgs e)
    {
      LoadData();
    }

    private void tsEdit_Click(object sender, EventArgs e)
    {
      EditItem();
    }

    private void btnCode_Click(object sender, EventArgs e)
    {
      FindItem();
    }
    private void FindItem()
    {
      if (txtCode.Text != "")
      {
        DataTable dt = DataAccess.ExecuteDataTable("SELECT * FROM itemcost WHERE icCode = '" + txtCode.Text + "'");
        if (dt != null && dt.Rows.Count > 0)
        {
          ItemEdit frm = new ItemEdit(int.Parse(dt.Rows[0]["ItemCostID"].ToString()));
          FormManagement.ShowDialogForm(frm);
          return;
        }
      }
      MessageBox.Show("Please enter a valid Item Code", "Invalid Item Code", MessageBoxButtons.OK);
    }

    private void tcStock_SelectedIndexChanged(object sender, EventArgs e)
    {
      LoadData();
    }

    private void dgvCredit_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      DataAccess.ShowMessage("Do you want to generate a Credit report for Smith and Smith?", "Credit", true);
    }

    private void dgvApprove_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      DataAccess.ShowMessage("Approve this auto allocated item to job?", "Approve", true);
    }

    private void txtSearch_TextChanged(object sender, EventArgs e)
    {
      LoadData();
    }

    private void rbDescription_CheckedChanged(object sender, EventArgs e)
    {
      //LoadData();
    }

    private void rbCode_CheckedChanged(object sender, EventArgs e)
    {
      LoadData();
    }

    private void chkLimit_CheckedChanged(object sender, EventArgs e)
    {
      LoadData();
    }

    private void rbAll_CheckedChanged(object sender, EventArgs e)
    {
      if (rbAll.Checked) LoadData();
    }



    private void rbAuto_CheckedChanged(object sender, EventArgs e)
    {
      if (rbAuto.Checked) LoadData();
    }

    private void rbGlass_CheckedChanged(object sender, EventArgs e)
    {
      if (rbGlass.Checked) LoadData();
    }

    private void tsReturns_Click(object sender, EventArgs e)
    {
      section = "notordered";
      lblSection.Text = "Not Ordered";
      viewbuttons(true);
      LoadData();
    }

    private void tsReservations_Click(object sender, EventArgs e)
    {
      section = "reservations";
      lblSection.Text = "Reservations";
      viewbuttons(true);
      LoadData();
    }

    private void tsLocations_Click(object sender, EventArgs e)
    {
      FormManagement.ShowChildForm("LocationView");
    }

    private void chkInStock_CheckedChanged(object sender, EventArgs e)
    {
      LoadData();
    }

    private void tsOnorder_Click(object sender, EventArgs e)
    {
      section = "onorder";
      lblSection.Text = "On Order";
      viewbuttons(true);
      LoadData();
    }



    private void tsReturns_Click_1(object sender, EventArgs e)
    {
      section = "returns";
      lblSection.Text = "Returns";
      viewbuttons(true);
      chJobBtn.Visible = false;
      chRemoveBtn.Visible = false;
      LoadData();
    }

    private void tsAllStock_Click(object sender, EventArgs e)
    {
      section = "all";
      lblSection.Text = "All Stock";
      viewbuttons(false);
      LoadData();
    }

    private void viewbuttons(bool visible)
    {
      chJobBtn.Visible = visible;
      chActionBtn.Visible = visible;
      chRemoveBtn.Visible = visible;
    }

    private void SetSelectedColor()
    {
      tsAllStock.BackColor = Color.Transparent;
      tsNotOrdered.BackColor = Color.Transparent;
      tsOnOrder.BackColor = Color.Transparent;
      tsReturns.BackColor = Color.Transparent;
      tsReservations.BackColor = Color.Transparent;

      switch (section)
      {
        case "all":
          tsAllStock.BackColor = Color.Yellow;
          break;

        case "notordered":
          tsNotOrdered.BackColor = Color.Yellow;
          break;

        case "onorder":
          tsOnOrder.BackColor = Color.Yellow;
          break;

        case "returns":
          tsReturns.BackColor = Color.Yellow;
          break;

        case "reservations":
          tsReservations.BackColor = Color.Yellow;
          break;

        default:
          tsAllStock.BackColor = Color.Yellow;
          break;
      }
    }

    private void dgvJobItem_CellContentClick(object sender, DataGridViewCellEventArgs e)
    {
      /*
      if (dgvJobItem.SelectedRows.Count > 0 && dgvJobItem.SelectedRows[0].Index > -1)
      {
        if (e.ColumnIndex == 9)
        {
          if((int)dgvJobItem.SelectedRows[0].Cells["chJobID"].Value != -1){
            FormManagement.ShowChildForm(new JobEdit((int)dgvJobItem.SelectedRows[0].Cells["chJobID"].Value));
          }
        }
        else if (e.ColumnIndex == 10)
        {
          MessageBox.Show("onorder");
        }
      }*/

    }

    private void dgvItems_CellContentClick(object sender, DataGridViewCellEventArgs e)
    {
      if (dgvItems.SelectedRows.Count > 0 && dgvItems.SelectedRows[0].Index > -1)
      {
        if (e.ColumnIndex == 15) //Column is View Job Link
        {
          try
          {
            if ((int)dgvItems.SelectedRows[0].Cells["chJobID"].Value != -1)
            {
              FormManagement.ShowChildForm(new JobEdit((int)dgvItems.SelectedRows[0].Cells["chJobID"].Value));
            }
          }
          catch { }
        }
        else if (e.ColumnIndex == 16) //Column is action for specific list
        {
          Action();
        }
        else if (e.ColumnIndex == 17) //Remove item from current list
        {
          bool res = DataAccess.ShowMessage("Are you sure you want to remove this item?", "Remove", false);
          if (!res) return;
          switch (section)
          {
            case "notordered":
              DataAccess.JobItemDelete((int)dgvItems.SelectedRows[0].Cells["chJobItemID"].Value);
              break;

            case "onorder":
              DataAccess.JobItemDelete((int)dgvItems.SelectedRows[0].Cells["chJobItemID"].Value);
              int newitemstockID = DataAccess.ExecuteScalarInt("SELECT ItemStockID FROM ItemStock WHERE ItemCostID = " +
                dgvItems.SelectedRows[0].Cells["chItemID"].Value + " AND LocationID = 4");
              if (newitemstockID == 0)
              {
                DataAccess.ItemStockManage(0, (int)dgvItems.SelectedRows[0].Cells["chItemID"].Value, 4, 0);
                newitemstockID = DataAccess.ExecuteScalarInt("SELECT ItemStockID FROM ItemStock WHERE ItemCostID = " +
                  dgvItems.SelectedRows[0].Cells["chItemID"].Value + " AND LocationID = 4");
              }
              DataAccess.ItemMovementManage(int.Parse(dgvItems.SelectedRows[0].Cells["stockID"].Value.ToString()), 3, -1, DataAccess.InternalIDType.Item, -1, 0, "", newitemstockID);
              break;
          }
          LoadData();
        }
      }
    }
  }
}
