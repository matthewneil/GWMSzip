﻿using System;
using System.Windows.Forms;

namespace workshop_orders
{
    partial class Index

    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Index));
      this.financeBox = new System.Windows.Forms.PictureBox();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.groupBox2 = new System.Windows.Forms.GroupBox();
      this.pictureBox1 = new System.Windows.Forms.PictureBox();
      this.groupBox3 = new System.Windows.Forms.GroupBox();
      this.pictureBox2 = new System.Windows.Forms.PictureBox();
      this.groupBox4 = new System.Windows.Forms.GroupBox();
      this.productionLink = new System.Windows.Forms.PictureBox();
      this.ProductionGroup = new System.Windows.Forms.GroupBox();
      this.button1 = new System.Windows.Forms.Button();
      ((System.ComponentModel.ISupportInitialize)(this.financeBox)).BeginInit();
      this.groupBox1.SuspendLayout();
      this.groupBox2.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
      this.groupBox3.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
      this.groupBox4.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.productionLink)).BeginInit();
      this.ProductionGroup.SuspendLayout();
      this.SuspendLayout();
      // 
      // financeBox
      // 
      this.financeBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
      this.financeBox.Image = ((System.Drawing.Image)(resources.GetObject("financeBox.Image")));
      this.financeBox.Location = new System.Drawing.Point(15, 25);
      this.financeBox.Name = "financeBox";
      this.financeBox.Size = new System.Drawing.Size(139, 88);
      this.financeBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
      this.financeBox.TabIndex = 0;
      this.financeBox.TabStop = false;
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.Add(this.financeBox);
      this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.groupBox1.Location = new System.Drawing.Point(12, 12);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(167, 129);
      this.groupBox1.TabIndex = 4;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Finance";
      // 
      // groupBox2
      // 
      this.groupBox2.Controls.Add(this.pictureBox1);
      this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.groupBox2.Location = new System.Drawing.Point(12, 444);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new System.Drawing.Size(167, 129);
      this.groupBox2.TabIndex = 5;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Sales";
      // 
      // pictureBox1
      // 
      this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
      this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
      this.pictureBox1.Location = new System.Drawing.Point(15, 25);
      this.pictureBox1.Name = "pictureBox1";
      this.pictureBox1.Size = new System.Drawing.Size(139, 88);
      this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
      this.pictureBox1.TabIndex = 0;
      this.pictureBox1.TabStop = false;
      // 
      // groupBox3
      // 
      this.groupBox3.Controls.Add(this.pictureBox2);
      this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.groupBox3.Location = new System.Drawing.Point(12, 299);
      this.groupBox3.Name = "groupBox3";
      this.groupBox3.Size = new System.Drawing.Size(167, 129);
      this.groupBox3.TabIndex = 5;
      this.groupBox3.TabStop = false;
      this.groupBox3.Text = "Purchasing";
      // 
      // pictureBox2
      // 
      this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
      this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
      this.pictureBox2.Location = new System.Drawing.Point(15, 25);
      this.pictureBox2.Name = "pictureBox2";
      this.pictureBox2.Size = new System.Drawing.Size(139, 88);
      this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
      this.pictureBox2.TabIndex = 0;
      this.pictureBox2.TabStop = false;
      // 
      // groupBox4
      // 
      this.groupBox4.Controls.Add(this.productionLink);
      this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.groupBox4.Location = new System.Drawing.Point(12, 155);
      this.groupBox4.Name = "groupBox4";
      this.groupBox4.Size = new System.Drawing.Size(167, 129);
      this.groupBox4.TabIndex = 5;
      this.groupBox4.TabStop = false;
      this.groupBox4.Text = "Production";
      // 
      // productionLink
      // 
      this.productionLink.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
      this.productionLink.Image = ((System.Drawing.Image)(resources.GetObject("productionLink.Image")));
      this.productionLink.Location = new System.Drawing.Point(15, 25);
      this.productionLink.Name = "productionLink";
      this.productionLink.Size = new System.Drawing.Size(139, 88);
      this.productionLink.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
      this.productionLink.TabIndex = 0;
      this.productionLink.TabStop = false;
      this.productionLink.Click += new System.EventHandler(this.productionLink_Click);
      // 
      // ProductionGroup
      // 
      this.ProductionGroup.Controls.Add(this.button1);
      this.ProductionGroup.Location = new System.Drawing.Point(185, 13);
      this.ProductionGroup.Name = "ProductionGroup";
      this.ProductionGroup.Size = new System.Drawing.Size(231, 561);
      this.ProductionGroup.TabIndex = 6;
      this.ProductionGroup.TabStop = false;
      this.ProductionGroup.Text = "Production";
      // 
      // button1
      // 
      this.button1.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.button1.Location = new System.Drawing.Point(7, 24);
      this.button1.Name = "button1";
      this.button1.Size = new System.Drawing.Size(218, 36);
      this.button1.TabIndex = 0;
      this.button1.Text = "Installation Costs";
      this.button1.UseVisualStyleBackColor = false;
      // 
      // Index
      // 
      this.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.ClientSize = new System.Drawing.Size(1904, 1041);
      this.ControlBox = false;
      this.Controls.Add(this.ProductionGroup);
      this.Controls.Add(this.groupBox2);
      this.Controls.Add(this.groupBox3);
      this.Controls.Add(this.groupBox4);
      this.Controls.Add(this.groupBox1);
      this.Name = "Index";
      this.ShowIcon = false;
      this.ShowInTaskbar = false;
      this.Text = "BMS - Home Page";
      ((System.ComponentModel.ISupportInitialize)(this.financeBox)).EndInit();
      this.groupBox1.ResumeLayout(false);
      this.groupBox2.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
      this.groupBox3.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
      this.groupBox4.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.productionLink)).EndInit();
      this.ProductionGroup.ResumeLayout(false);
      this.ResumeLayout(false);

        }

        #endregion

        private PictureBox financeBox;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private PictureBox pictureBox1;
        private GroupBox groupBox3;
        private PictureBox pictureBox2;
        private GroupBox groupBox4;
        private PictureBox productionLink;
        private GroupBox ProductionGroup;
        private Button button1;
    }
}

