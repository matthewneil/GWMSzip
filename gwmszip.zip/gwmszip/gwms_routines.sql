-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: localhost    Database: gwms
-- ------------------------------------------------------
-- Server version	8.0.25

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `vwquotesummary`
--

DROP TABLE IF EXISTS `vwquotesummary`;
/*!50001 DROP VIEW IF EXISTS `vwquotesummary`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vwquotesummary` AS SELECT 
 1 AS `quoteNo`,
 1 AS `quotetype`,
 1 AS `reference`,
 1 AS `CustomerID`,
 1 AS `CustomerName`,
 1 AS `dateCreated`,
 1 AS `discount`,
 1 AS `cMobilePhone`,
 1 AS `cEmail`,
 1 AS `StaffFullName`,
 1 AS `GroupName`,
 1 AS `QuotePrice`,
 1 AS `QuoteLetterText`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vwquoteitem`
--

DROP TABLE IF EXISTS `vwquoteitem`;
/*!50001 DROP VIEW IF EXISTS `vwquoteitem`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vwquoteitem` AS SELECT 
 1 AS `quoteNo`,
 1 AS `quotetype`,
 1 AS `reference`,
 1 AS `CustomerID`,
 1 AS `CustomerName`,
 1 AS `staffID`,
 1 AS `dateCreated`,
 1 AS `dateModified`,
 1 AS `workersNo`,
 1 AS `distance`,
 1 AS `workDays`,
 1 AS `hoursPerDay`,
 1 AS `statusID`,
 1 AS `dateAccepted`,
 1 AS `discount`,
 1 AS `StatusName`,
 1 AS `StatusGroup`,
 1 AS `cMobilePhone`,
 1 AS `cEmail`,
 1 AS `StaffFullName`,
 1 AS `comments`,
 1 AS `quoteItemID`,
 1 AS `Quantity`,
 1 AS `size`,
 1 AS `width`,
 1 AS `height`,
 1 AS `quoteitemCost`,
 1 AS `quoteitemPrice`,
 1 AS `linkid`,
 1 AS `quoteitemtype`,
 1 AS `quoteItemGroupId`,
 1 AS `GroupName`,
 1 AS `itemCostID`,
 1 AS `itemgroupid`,
 1 AS `icCode`,
 1 AS `icDescription`,
 1 AS `igDescription`,
 1 AS `igSubGroup`,
 1 AS `igType`,
 1 AS `GlassThickness`,
 1 AS `uom`,
 1 AS `allowance`,
 1 AS `Amount`,
 1 AS `minquantity`,
 1 AS `CostPrice`,
 1 AS `QuotePrice`,
 1 AS `igSort`,
 1 AS `ComponentGroup`,
 1 AS `QuoteLetterText`,
 1 AS `description`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vwquotelist`
--

DROP TABLE IF EXISTS `vwquotelist`;
/*!50001 DROP VIEW IF EXISTS `vwquotelist`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vwquotelist` AS SELECT 
 1 AS `QuoteNo`,
 1 AS `quoteType`,
 1 AS `reference`,
 1 AS `CustomerID`,
 1 AS `StaffID`,
 1 AS `dateCreated`,
 1 AS `dateModified`,
 1 AS `WorkersNo`,
 1 AS `distance`,
 1 AS `workDays`,
 1 AS `hoursPerDay`,
 1 AS `statusID`,
 1 AS `dateAccepted`,
 1 AS `discount`,
 1 AS `comments`,
 1 AS `StatusName`,
 1 AS `StatusGroup`,
 1 AS `CustomerName`,
 1 AS `cMobilePhone`,
 1 AS `cEmail`,
 1 AS `StaffFullName`,
 1 AS `CostPrice`,
 1 AS `QuotePrice`,
 1 AS `MarginP`,
 1 AS `Margin`,
 1 AS `Name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vwitemlocation`
--

DROP TABLE IF EXISTS `vwitemlocation`;
/*!50001 DROP VIEW IF EXISTS `vwitemlocation`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vwitemlocation` AS SELECT 
 1 AS `ItemCostID`,
 1 AS `ItemStockID`,
 1 AS `Quantity`,
 1 AS `LocationGroup`,
 1 AS `LocationSubGroup`,
 1 AS `LocationCode`,
 1 AS `LocationDescription`,
 1 AS `Reservation`,
 1 AS `Stock`,
 1 AS `Available`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vwquoteitemgroup`
--

DROP TABLE IF EXISTS `vwquoteitemgroup`;
/*!50001 DROP VIEW IF EXISTS `vwquoteitemgroup`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vwquoteitemgroup` AS SELECT 
 1 AS `QuoteNo`,
 1 AS `QuoteItemGroupID`,
 1 AS `GroupName`,
 1 AS `FixedGlass`,
 1 AS `SashGlass`,
 1 AS `Components`,
 1 AS `CostPrice`,
 1 AS `QuotePrice`,
 1 AS `ItemGroupID`,
 1 AS `description`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vwitemstock`
--

DROP TABLE IF EXISTS `vwitemstock`;
/*!50001 DROP VIEW IF EXISTS `vwitemstock`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vwitemstock` AS SELECT 
 1 AS `ItemCostID`,
 1 AS `icCode`,
 1 AS `Code`,
 1 AS `icDescription`,
 1 AS `icCost`,
 1 AS `icPrice`,
 1 AS `uom`,
 1 AS `igSubGroup`,
 1 AS `LocationID`,
 1 AS `LocationCode`,
 1 AS `ItemStockID`,
 1 AS `Quantity`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vwquote`
--

DROP TABLE IF EXISTS `vwquote`;
/*!50001 DROP VIEW IF EXISTS `vwquote`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vwquote` AS SELECT 
 1 AS `QuoteNo`,
 1 AS `quoteType`,
 1 AS `reference`,
 1 AS `CustomerID`,
 1 AS `StaffID`,
 1 AS `dateCreated`,
 1 AS `dateModified`,
 1 AS `WorkersNo`,
 1 AS `distance`,
 1 AS `workDays`,
 1 AS `hoursPerDay`,
 1 AS `statusID`,
 1 AS `dateAccepted`,
 1 AS `discount`,
 1 AS `comments`,
 1 AS `StatusName`,
 1 AS `StatusGroup`,
 1 AS `CustomerName`,
 1 AS `cMobilePhone`,
 1 AS `cEmail`,
 1 AS `StaffFullName`,
 1 AS `CostPrice`,
 1 AS `QuotePrice`,
 1 AS `MarginP`,
 1 AS `Margin`,
 1 AS `QuoteLetterText`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vwitemlocationstock`
--

DROP TABLE IF EXISTS `vwitemlocationstock`;
/*!50001 DROP VIEW IF EXISTS `vwitemlocationstock`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vwitemlocationstock` AS SELECT 
 1 AS `JobItemID`,
 1 AS `JobID`,
 1 AS `ItemCostID`,
 1 AS `Code`,
 1 AS `icCode`,
 1 AS `icDescription`,
 1 AS `icCost`,
 1 AS `icPrice`,
 1 AS `LocationID`,
 1 AS `LocationCode`,
 1 AS `ItemStockID`,
 1 AS `Quantity`,
 1 AS `MovementTypeID`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vwjobitem`
--

DROP TABLE IF EXISTS `vwjobitem`;
/*!50001 DROP VIEW IF EXISTS `vwjobitem`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vwjobitem` AS SELECT 
 1 AS `JobID`,
 1 AS `TypeName`,
 1 AS `CustomerName`,
 1 AS `Phone`,
 1 AS `pType`,
 1 AS `Vehicle`,
 1 AS `StaffFullName`,
 1 AS `StatusName`,
 1 AS `AreaID`,
 1 AS `AreaName`,
 1 AS `InsuranceName`,
 1 AS `QuoteNo`,
 1 AS `DateCreated`,
 1 AS `JobBookingDate`,
 1 AS `JobBookingDateBlank`,
 1 AS `JobNote`,
 1 AS `JobIviisNo`,
 1 AS `JobMilage`,
 1 AS `MilageRequired`,
 1 AS `JobReference`,
 1 AS `Payment`,
 1 AS `TypeGroup`,
 1 AS `JobSiteAddress`,
 1 AS `icCode`,
 1 AS `icPrice`,
 1 AS `icDescription`,
 1 AS `igDescription`,
 1 AS `JobItemStockID`,
 1 AS `TimeOfDay`,
 1 AS `code`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vwlocationcount`
--

DROP TABLE IF EXISTS `vwlocationcount`;
/*!50001 DROP VIEW IF EXISTS `vwlocationcount`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vwlocationcount` AS SELECT 
 1 AS `ItemStockID`,
 1 AS `ItemCostID`,
 1 AS `LocationCode`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vwcustomer`
--

DROP TABLE IF EXISTS `vwcustomer`;
/*!50001 DROP VIEW IF EXISTS `vwcustomer`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vwcustomer` AS SELECT 
 1 AS `CustomerID`,
 1 AS `CustomerName`,
 1 AS `cSurname`,
 1 AS `cBusiness`,
 1 AS `cMobilePhone`,
 1 AS `cPhone2`,
 1 AS `cAddress`,
 1 AS `cSuburb`,
 1 AS `cCity`,
 1 AS `cPostcode`,
 1 AS `cEmail`,
 1 AS `cAccountName`,
 1 AS `cAccountNo`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vwallowance`
--

DROP TABLE IF EXISTS `vwallowance`;
/*!50001 DROP VIEW IF EXISTS `vwallowance`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vwallowance` AS SELECT 
 1 AS `linkid`,
 1 AS `allowance`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vwquotecost`
--

DROP TABLE IF EXISTS `vwquotecost`;
/*!50001 DROP VIEW IF EXISTS `vwquotecost`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vwquotecost` AS SELECT 
 1 AS `QuoteNo`,
 1 AS `quoteType`,
 1 AS `reference`,
 1 AS `CustomerID`,
 1 AS `StaffID`,
 1 AS `dateCreated`,
 1 AS `dateModified`,
 1 AS `WorkersNo`,
 1 AS `distance`,
 1 AS `workDays`,
 1 AS `hoursPerDay`,
 1 AS `statusID`,
 1 AS `dateAccepted`,
 1 AS `discount`,
 1 AS `comments`,
 1 AS `StatusName`,
 1 AS `StatusGroup`,
 1 AS `CustomerName`,
 1 AS `cMobilePhone`,
 1 AS `cEmail`,
 1 AS `StaffFullName`,
 1 AS `CostPrice`,
 1 AS `QuotePrice`,
 1 AS `MarginP`,
 1 AS `Margin`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vwjob`
--

DROP TABLE IF EXISTS `vwjob`;
/*!50001 DROP VIEW IF EXISTS `vwjob`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vwjob` AS SELECT 
 1 AS `JobID`,
 1 AS `TypeID`,
 1 AS `TypeColor`,
 1 AS `TypeName`,
 1 AS `CustomerID`,
 1 AS `CustomerName`,
 1 AS `cSurname`,
 1 AS `cMobilePhone`,
 1 AS `pType`,
 1 AS `Vehicle`,
 1 AS `vMake`,
 1 AS `vModel`,
 1 AS `vYear`,
 1 AS `StaffID`,
 1 AS `StaffFullName`,
 1 AS `StatusID`,
 1 AS `StatusName`,
 1 AS `AreaName`,
 1 AS `InsuranceName`,
 1 AS `QuoteNo`,
 1 AS `DateCreated`,
 1 AS `JobBookingDate`,
 1 AS `JobBookingDateBlank`,
 1 AS `JobNote`,
 1 AS `JobIviisNo`,
 1 AS `JobMilage`,
 1 AS `MilageRequired`,
 1 AS `JobReference`,
 1 AS `Payment`,
 1 AS `TypeGroup`,
 1 AS `JobSiteAddress`,
 1 AS `vRecalibration`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vwlabour`
--

DROP TABLE IF EXISTS `vwlabour`;
/*!50001 DROP VIEW IF EXISTS `vwlabour`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vwlabour` AS SELECT 
 1 AS `LabourID`,
 1 AS `JobTaskID`,
 1 AS `StaffFullName`,
 1 AS `StaffRate`,
 1 AS `Cost`,
 1 AS `Price`,
 1 AS `Percent`,
 1 AS `TimeLength`,
 1 AS `StartTime`,
 1 AS `EndTime`,
 1 AS `Note`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vwitemcost`
--

DROP TABLE IF EXISTS `vwitemcost`;
/*!50001 DROP VIEW IF EXISTS `vwitemcost`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vwitemcost` AS SELECT 
 1 AS `ItemCostID`,
 1 AS `ItemGroupID`,
 1 AS `icCode`,
 1 AS `icDescription`,
 1 AS `icPrice`,
 1 AS `icCost`,
 1 AS `uom`,
 1 AS `allowance`,
 1 AS `minquantity`,
 1 AS `igDescription`,
 1 AS `igSubGroup`,
 1 AS `igType`,
 1 AS `igSort`,
 1 AS `GlassThickness`,
 1 AS `Tint`,
 1 AS `LowEPlus`,
 1 AS `LowEMax`,
 1 AS `LowEXcel`,
 1 AS `M2Rate`,
 1 AS `SubGroup`,
 1 AS `ComponentGroup`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vwcomponent`
--

DROP TABLE IF EXISTS `vwcomponent`;
/*!50001 DROP VIEW IF EXISTS `vwcomponent`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vwcomponent` AS SELECT 
 1 AS `quoteNo`,
 1 AS `dateCreated`,
 1 AS `CustomerName`,
 1 AS `reference`,
 1 AS `igSubGroup`,
 1 AS `ComponentGroup`,
 1 AS `icCode`,
 1 AS `icDescription`,
 1 AS `igSort`,
 1 AS `uom`,
 1 AS `allowance`,
 1 AS `Quantity`,
 1 AS `quoteitemCost`,
 1 AS `CostPrice`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `vwquotesummary`
--

/*!50001 DROP VIEW IF EXISTS `vwquotesummary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vwquotesummary` AS select `i`.`quoteNo` AS `quoteNo`,`i`.`quotetype` AS `quotetype`,`i`.`reference` AS `reference`,`i`.`CustomerID` AS `CustomerID`,`i`.`CustomerName` AS `CustomerName`,`i`.`dateCreated` AS `dateCreated`,`i`.`discount` AS `discount`,`i`.`cMobilePhone` AS `cMobilePhone`,`i`.`cEmail` AS `cEmail`,`i`.`StaffFullName` AS `StaffFullName`,`g`.`GroupName` AS `GroupName`,sum(`i`.`quoteitemPrice`) AS `QuotePrice`,`i`.`QuoteLetterText` AS `QuoteLetterText` from (`vwquoteitem` `i` join `quoteitemgroup` `g` on((`i`.`quoteItemGroupId` = `g`.`quoteitemgroupid`))) group by `i`.`quoteNo`,`i`.`quotetype`,`i`.`reference`,`i`.`CustomerID`,`i`.`CustomerName`,`i`.`dateCreated`,`i`.`discount`,`i`.`cMobilePhone`,`i`.`cEmail`,`i`.`StaffFullName`,`i`.`quoteItemGroupId`,`g`.`GroupName` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vwquoteitem`
--

/*!50001 DROP VIEW IF EXISTS `vwquoteitem`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vwquoteitem` AS select `q`.`QuoteNo` AS `quoteNo`,`q`.`quoteType` AS `quotetype`,`q`.`reference` AS `reference`,`q`.`CustomerID` AS `CustomerID`,`q`.`CustomerName` AS `CustomerName`,`q`.`StaffID` AS `staffID`,`q`.`dateCreated` AS `dateCreated`,`q`.`dateModified` AS `dateModified`,`q`.`WorkersNo` AS `workersNo`,`q`.`distance` AS `distance`,`q`.`workDays` AS `workDays`,`q`.`hoursPerDay` AS `hoursPerDay`,`q`.`statusID` AS `statusID`,`q`.`dateAccepted` AS `dateAccepted`,`q`.`discount` AS `discount`,`q`.`StatusName` AS `StatusName`,`q`.`StatusGroup` AS `StatusGroup`,`q`.`cMobilePhone` AS `cMobilePhone`,`q`.`cEmail` AS `cEmail`,`q`.`StaffFullName` AS `StaffFullName`,`q`.`comments` AS `comments`,`i`.`quoteItemID` AS `quoteItemID`,`i`.`quantity` AS `Quantity`,`i`.`size` AS `size`,`i`.`width` AS `width`,`i`.`height` AS `height`,`i`.`quoteitemCost` AS `quoteitemCost`,`i`.`quoteitemPrice` AS `quoteitemPrice`,`i`.`linkid` AS `linkid`,`i`.`quoteitemtype` AS `quoteitemtype`,`g`.`quoteitemgroupid` AS `quoteItemGroupId`,`g`.`GroupName` AS `GroupName`,`c`.`ItemCostID` AS `itemCostID`,`c`.`ItemGroupID` AS `itemgroupid`,`c`.`icCode` AS `icCode`,`c`.`icDescription` AS `icDescription`,`c`.`igDescription` AS `igDescription`,`c`.`igSubGroup` AS `igSubGroup`,`c`.`igType` AS `igType`,`c`.`GlassThickness` AS `GlassThickness`,`c`.`uom` AS `uom`,ifnull(`a`.`allowance`,0) AS `allowance`,(case when (`c`.`igSubGroup` = 'Glass') then concat(round((`i`.`height` - (`a`.`allowance` * 2)),0),' x ',round((`i`.`width` - (`a`.`allowance` * 2)),0)) else '' end) AS `Amount`,`c`.`minquantity` AS `minquantity`,(`i`.`quantity` * `i`.`quoteitemCost`) AS `CostPrice`,(`i`.`quantity` * `i`.`quoteitemPrice`) AS `QuotePrice`,`c`.`igSort` AS `igSort`,`c`.`ComponentGroup` AS `ComponentGroup`,`q`.`QuoteLetterText` AS `QuoteLetterText`,`i`.`description` AS `description` from ((((`vwquote` `q` join `quoteitems` `i` on((`q`.`QuoteNo` = `i`.`quoteNo`))) join `quoteitemgroup` `g` on((`i`.`quoteitemGroupID` = `g`.`quoteitemgroupid`))) left join `vwitemcost` `c` on((`c`.`ItemCostID` = `i`.`itemCostID`))) left join `vwallowance` `a` on((`i`.`linkid` = `a`.`linkid`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vwquotelist`
--

/*!50001 DROP VIEW IF EXISTS `vwquotelist`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vwquotelist` AS select `q`.`quoteNo` AS `QuoteNo`,`q`.`type` AS `quoteType`,`q`.`reference` AS `reference`,`c`.`CustomerID` AS `CustomerID`,`q`.`staffID` AS `StaffID`,`q`.`dateCreated` AS `dateCreated`,`q`.`dateModified` AS `dateModified`,`q`.`workersNo` AS `WorkersNo`,`q`.`distance` AS `distance`,`q`.`workDays` AS `workDays`,`q`.`hoursPerDay` AS `hoursPerDay`,`q`.`statusID` AS `statusID`,`q`.`dateAccepted` AS `dateAccepted`,`q`.`discount` AS `discount`,ifnull(`q`.`comments`,'') AS `comments`,`s`.`StatusName` AS `StatusName`,`s`.`StatusGroup` AS `StatusGroup`,`c`.`CustomerName` AS `CustomerName`,`c`.`cMobilePhone` AS `cMobilePhone`,`c`.`cEmail` AS `cEmail`,`u`.`StaffFullName` AS `StaffFullName`,ifnull(sum((`i`.`quantity` * `i`.`quoteitemCost`)),0) AS `CostPrice`,ifnull((sum((`i`.`quantity` * `i`.`quoteitemPrice`)) - `q`.`discount`),0) AS `QuotePrice`,ifnull((case when (sum(`i`.`quoteitemPrice`) = 0) then 0 else ((sum((`i`.`quantity` * `i`.`quoteitemPrice`)) - sum((`i`.`quantity` * `i`.`quoteitemCost`))) / sum((`i`.`quantity` * `i`.`quoteitemPrice`))) end),0) AS `MarginP`,ifnull((sum((`i`.`quantity` * `i`.`quoteitemPrice`)) - sum((`i`.`quantity` * `i`.`quoteitemCost`))),0) AS `Margin`,`g`.`GroupName` AS `Name` from (((((`quote` `q` join `customer` `c` on((`q`.`customerID` = `c`.`CustomerID`))) join `status` `s` on((`q`.`statusID` = `s`.`StatusID`))) join `staff` `u` on((`q`.`staffID` = `u`.`StaffID`))) left join `vwquoteitemgroup` `g` on((`q`.`quoteNo` = `g`.`QuoteNo`))) left join `quoteitems` `i` on((`q`.`quoteNo` = `i`.`quoteNo`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vwitemlocation`
--

/*!50001 DROP VIEW IF EXISTS `vwitemlocation`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vwitemlocation` AS select `s`.`ItemCostID` AS `ItemCostID`,`s`.`ItemStockID` AS `ItemStockID`,sum(`m`.`imQuantity`) AS `Quantity`,`l`.`LocationGroup` AS `LocationGroup`,`l`.`LocationSubGroup` AS `LocationSubGroup`,`l`.`LocationCode` AS `LocationCode`,`l`.`LocationDescription` AS `LocationDescription`,sum((case when (`m`.`MovementTypeID` = 4) then `m`.`imQuantity` else 0 end)) AS `Reservation`,sum((case when (`m`.`MovementTypeID` <> 4) then `m`.`imQuantity` else 0 end)) AS `Stock`,(sum((case when (`m`.`MovementTypeID` <> 4) then `m`.`imQuantity` else 0 end)) - sum((case when (`m`.`MovementTypeID` = 4) then `m`.`imQuantity` else 0 end))) AS `Available` from ((`itemstock` `s` join `location` `l` on((`s`.`LocationID` = `l`.`LocationID`))) join `itemmovement` `m` on((`s`.`ItemStockID` = `m`.`ItemStockID`))) group by `s`.`ItemStockID` having (sum(`m`.`imQuantity`) > 0) order by `l`.`LocationGroup`,`l`.`LocationSubGroup`,`l`.`LocationCode` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vwquoteitemgroup`
--

/*!50001 DROP VIEW IF EXISTS `vwquoteitemgroup`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vwquoteitemgroup` AS select `g`.`QuoteNo` AS `QuoteNo`,`g`.`quoteitemgroupid` AS `QuoteItemGroupID`,`g`.`GroupName` AS `GroupName`,sum((case when ((`i`.`quoteitemtype` = 'Fixed Glass') and (`i`.`igSubGroup` = 'GLASS')) then 1 else 0 end)) AS `FixedGlass`,sum((case when ((`i`.`quoteitemtype` = 'Sash Glass') and (`i`.`igSubGroup` = 'GLASS')) then 1 else 0 end)) AS `SashGlass`,sum((case when (`i`.`quoteitemtype` = 'Component') then 1 else 0 end)) AS `Components`,sum((`i`.`Quantity` * `i`.`quoteitemCost`)) AS `CostPrice`,sum((`i`.`Quantity` * `i`.`quoteitemPrice`)) AS `QuotePrice`,max(`i`.`itemgroupid`) AS `ItemGroupID`,`i`.`description` AS `description` from (`quoteitemgroup` `g` left join `vwquoteitem` `i` on((`i`.`quoteItemGroupId` = `g`.`quoteitemgroupid`))) group by `g`.`quoteitemgroupid`,`g`.`GroupName` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vwitemstock`
--

/*!50001 DROP VIEW IF EXISTS `vwitemstock`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vwitemstock` AS select `i`.`ItemCostID` AS `ItemCostID`,`i`.`icCode` AS `icCode`,`c`.`Code` AS `Code`,`i`.`icDescription` AS `icDescription`,`i`.`icCost` AS `icCost`,`i`.`icPrice` AS `icPrice`,`m`.`uomName` AS `uom`,`g`.`igSubGroup` AS `igSubGroup`,ifnull(`s`.`LocationID`,0) AS `LocationID`,ifnull(`l`.`LocationCode`,'Non-Stock Item') AS `LocationCode`,ifnull(`s`.`ItemStockID`,0) AS `ItemStockID`,ifnull(sum(`im`.`imQuantity`),0.0000) AS `Quantity` from ((((((`itemcost` `i` left join `itemstock` `s` on((`s`.`ItemCostID` = `i`.`ItemCostID`))) left join `itemgroup` `g` on((`i`.`ItemGroupID` = `g`.`ItemGroupID`))) left join `location` `l` on((`s`.`LocationID` = `l`.`LocationID`))) left join `uom` `m` on((`i`.`uom` = `m`.`uomID`))) left join `itemcode` `c` on((`c`.`LinkID` = `i`.`ItemCostID`))) left join `itemmovement` `im` on((`s`.`ItemStockID` = `im`.`ItemStockID`))) group by `i`.`ItemCostID` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vwquote`
--

/*!50001 DROP VIEW IF EXISTS `vwquote`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vwquote` AS select `q`.`quoteNo` AS `QuoteNo`,`q`.`type` AS `quoteType`,`q`.`reference` AS `reference`,`c`.`CustomerID` AS `CustomerID`,`q`.`staffID` AS `StaffID`,`q`.`dateCreated` AS `dateCreated`,`q`.`dateModified` AS `dateModified`,`q`.`workersNo` AS `WorkersNo`,`q`.`distance` AS `distance`,`q`.`workDays` AS `workDays`,`q`.`hoursPerDay` AS `hoursPerDay`,`q`.`statusID` AS `statusID`,`q`.`dateAccepted` AS `dateAccepted`,`q`.`discount` AS `discount`,ifnull(`q`.`comments`,'') AS `comments`,`s`.`StatusName` AS `StatusName`,`s`.`StatusGroup` AS `StatusGroup`,`c`.`CustomerName` AS `CustomerName`,`c`.`cMobilePhone` AS `cMobilePhone`,`c`.`cEmail` AS `cEmail`,`u`.`StaffFullName` AS `StaffFullName`,ifnull(sum((`i`.`quantity` * `i`.`quoteitemCost`)),0) AS `CostPrice`,ifnull((sum((`i`.`quantity` * `i`.`quoteitemPrice`)) - `q`.`discount`),0) AS `QuotePrice`,ifnull((case when (sum(`i`.`quoteitemPrice`) = 0) then 0 else ((sum((`i`.`quantity` * `i`.`quoteitemPrice`)) - sum((`i`.`quantity` * `i`.`quoteitemCost`))) / sum((`i`.`quantity` * `i`.`quoteitemPrice`))) end),0) AS `MarginP`,ifnull((sum((`i`.`quantity` * `i`.`quoteitemPrice`)) - sum((`i`.`quantity` * `i`.`quoteitemCost`))),0) AS `Margin`,`q`.`QuoteLetterText` AS `QuoteLetterText` from ((((`quote` `q` join `customer` `c` on((`q`.`customerID` = `c`.`CustomerID`))) join `status` `s` on((`q`.`statusID` = `s`.`StatusID`))) join `staff` `u` on((`q`.`staffID` = `u`.`StaffID`))) left join `quoteitems` `i` on((`q`.`quoteNo` = `i`.`quoteNo`))) group by `q`.`quoteNo`,`q`.`type`,`q`.`reference`,`c`.`CustomerID`,`q`.`staffID`,`q`.`dateCreated`,`q`.`dateModified`,`q`.`workersNo`,`q`.`distance`,`q`.`workDays`,`q`.`hoursPerDay`,`q`.`statusID`,`q`.`dateAccepted`,`q`.`discount`,`s`.`StatusName`,`s`.`StatusGroup`,`c`.`CustomerName`,`c`.`cMobilePhone`,`c`.`cEmail`,`u`.`StaffFullName`,`q`.`comments` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vwitemlocationstock`
--

/*!50001 DROP VIEW IF EXISTS `vwitemlocationstock`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vwitemlocationstock` AS select `ji`.`JobItemID` AS `JobItemID`,`ji`.`JobID` AS `JobID`,`s`.`ItemCostID` AS `ItemCostID`,`c`.`Code` AS `Code`,`ic`.`icCode` AS `icCode`,`ic`.`icDescription` AS `icDescription`,`ic`.`icCost` AS `icCost`,`ic`.`icPrice` AS `icPrice`,ifnull(`s`.`LocationID`,0) AS `LocationID`,ifnull(`l`.`LocationCode`,'Non-Stock Item') AS `LocationCode`,ifnull(`s`.`ItemStockID`,0) AS `ItemStockID`,ifnull(sum(`m`.`imQuantity`),0.0000) AS `Quantity`,`m`.`MovementTypeID` AS `MovementTypeID` from (((((`jobitem` `ji` join `itemcost` `ic` on((`ji`.`ItemCostID` = `ic`.`ItemCostID`))) left join `itemstock` `s` on((`ji`.`ItemStockID` = `s`.`ItemStockID`))) left join `itemmovement` `m` on((`s`.`ItemStockID` = `m`.`ItemStockID`))) left join `location` `l` on((`l`.`LocationID` = `s`.`LocationID`))) left join `itemcode` `c` on((`c`.`LinkID` = `ic`.`ItemCostID`))) group by `ji`.`JobItemID` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vwjobitem`
--

/*!50001 DROP VIEW IF EXISTS `vwjobitem`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vwjobitem` AS select `j`.`JobID` AS `JobID`,`t`.`TypeName` AS `TypeName`,`c`.`CustomerName` AS `CustomerName`,(case when (`c`.`cMobilePhone` is null) then `c`.`cPhone2` else `c`.`cMobilePhone` end) AS `Phone`,`p`.`pType` AS `pType`,(case when (`v`.`VehicleID` > 0) then concat(coalesce(`v`.`vRegistration`,''),' - ',coalesce(`v`.`vMake`,''),' ',coalesce(`v`.`vModel`,''),' ',coalesce(`v`.`vYear`,'')) else '(No Vehicle)' end) AS `Vehicle`,`staff`.`StaffFullName` AS `StaffFullName`,`s`.`StatusName` AS `StatusName`,`j`.`AreaID` AS `AreaID`,`a`.`AreaName` AS `AreaName`,`i`.`InsuranceName` AS `InsuranceName`,`q`.`quoteNo` AS `QuoteNo`,`j`.`DateCreated` AS `DateCreated`,`j`.`JobBookingDate` AS `JobBookingDate`,(case when (`j`.`JobBookingDate` < '2000-01-01') then '' else `j`.`JobBookingDate` end) AS `JobBookingDateBlank`,`j`.`JobNote` AS `JobNote`,`j`.`JobiViisNo` AS `JobIviisNo`,`j`.`JobMilage` AS `JobMilage`,`j`.`MilageRequired` AS `MilageRequired`,`j`.`JobReference` AS `JobReference`,`p`.`pType` AS `Payment`,`t`.`TypeGroup` AS `TypeGroup`,`j`.`JobSiteAddress` AS `JobSiteAddress`,`ic`.`icCode` AS `icCode`,`ic`.`icPrice` AS `icPrice`,`ic`.`icDescription` AS `icDescription`,`ig`.`igDescription` AS `igDescription`,(case when (`ji`.`ItemStockID` = 0) then `ji`.`ItemCostID` else `ji`.`ItemStockID` end) AS `JobItemStockID`,(case when (hour(`j`.`JobBookingDate`) < 12) then 'Morning' else 'Afternoon' end) AS `TimeOfDay`,`icode`.`Code` AS `code` from ((((((((((((((`job` `j` join `jobtype` `t` on((`j`.`TypeID` = `t`.`TypeID`))) join `customer` `c` on((`j`.`CustomerID` = `c`.`CustomerID`))) join `payment` `p` on((`j`.`PaymentID` = `p`.`PaymentID`))) left join `vehicle` `v` on((`j`.`VehicleID` = `v`.`VehicleID`))) join `staff` on((`j`.`StaffID` = `staff`.`StaffID`))) join `status` `s` on((`j`.`StatusID` = `s`.`StatusID`))) left join `area` `a` on((`j`.`AreaID` = `a`.`AreaID`))) left join `insurance` `i` on((`j`.`InsuranceID` = `i`.`InsuranceID`))) left join `quote` `q` on((`j`.`QuoteID` = `q`.`quoteNo`))) left join `jobitem` `ji` on((`j`.`JobID` = `ji`.`JobID`))) left join `itemcost` `ic` on((`ji`.`ItemCostID` = `ic`.`ItemCostID`))) left join `itemgroup` `ig` on((`ig`.`ItemGroupID` = `ic`.`ItemGroupID`))) left join `itemstock` `ist` on((`ji`.`ItemStockID` = `ist`.`ItemStockID`))) left join `itemcode` `icode` on((`ic`.`ItemCostID` = `icode`.`LinkID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vwlocationcount`
--

/*!50001 DROP VIEW IF EXISTS `vwlocationcount`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vwlocationcount` AS select `s`.`ItemStockID` AS `ItemStockID`,`c`.`ItemCostID` AS `ItemCostID`,(case when (count(`l`.`LocationID`) > 1) then concat(count(`l`.`LocationID`),' Locations') else `l`.`LocationCode` end) AS `LocationCode` from ((`itemstock` `s` left join `itemcost` `c` on((`c`.`ItemCostID` = `s`.`ItemCostID`))) left join `location` `l` on((`s`.`LocationID` = `l`.`LocationID`))) group by `c`.`ItemCostID` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vwcustomer`
--

/*!50001 DROP VIEW IF EXISTS `vwcustomer`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vwcustomer` AS select `customer`.`CustomerID` AS `CustomerID`,`customer`.`CustomerName` AS `CustomerName`,`customer`.`cSurname` AS `cSurname`,`customer`.`cBusiness` AS `cBusiness`,`customer`.`cMobilePhone` AS `cMobilePhone`,`customer`.`cPhone2` AS `cPhone2`,`customer`.`cAddress` AS `cAddress`,`customer`.`cSuburb` AS `cSuburb`,`customer`.`cCity` AS `cCity`,`customer`.`cPostcode` AS `cPostcode`,`customer`.`cEmail` AS `cEmail`,`customer`.`cAccountName` AS `cAccountName`,`customer`.`cAccountNo` AS `cAccountNo` from `customer` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vwallowance`
--

/*!50001 DROP VIEW IF EXISTS `vwallowance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vwallowance` AS select `i`.`linkid` AS `linkid`,max(`c`.`allowance`) AS `allowance` from (`quoteitems` `i` join `itemcost` `c` on((`i`.`itemCostID` = `c`.`ItemCostID`))) group by `i`.`linkid` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vwquotecost`
--

/*!50001 DROP VIEW IF EXISTS `vwquotecost`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vwquotecost` AS select `q`.`QuoteNo` AS `QuoteNo`,`q`.`quoteType` AS `quoteType`,`q`.`reference` AS `reference`,`q`.`CustomerID` AS `CustomerID`,`q`.`StaffID` AS `StaffID`,`q`.`dateCreated` AS `dateCreated`,`q`.`dateModified` AS `dateModified`,`q`.`WorkersNo` AS `WorkersNo`,`q`.`distance` AS `distance`,`q`.`workDays` AS `workDays`,`q`.`hoursPerDay` AS `hoursPerDay`,`q`.`statusID` AS `statusID`,`q`.`dateAccepted` AS `dateAccepted`,`q`.`discount` AS `discount`,`q`.`comments` AS `comments`,`q`.`StatusName` AS `StatusName`,`q`.`StatusGroup` AS `StatusGroup`,`q`.`CustomerName` AS `CustomerName`,`q`.`cMobilePhone` AS `cMobilePhone`,`q`.`cEmail` AS `cEmail`,`q`.`StaffFullName` AS `StaffFullName`,`q`.`CostPrice` AS `CostPrice`,`q`.`QuotePrice` AS `QuotePrice`,`q`.`MarginP` AS `MarginP`,`q`.`Margin` AS `Margin` from (`vwquote` `q` join `vwquoteitemgroup` `g` on((`q`.`QuoteNo` = `g`.`QuoteNo`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vwjob`
--

/*!50001 DROP VIEW IF EXISTS `vwjob`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vwjob` AS select `j`.`JobID` AS `JobID`,`t`.`TypeID` AS `TypeID`,`t`.`TypeColor` AS `TypeColor`,`t`.`TypeName` AS `TypeName`,`c`.`CustomerID` AS `CustomerID`,`c`.`CustomerName` AS `CustomerName`,`c`.`cSurname` AS `cSurname`,`c`.`cMobilePhone` AS `cMobilePhone`,`p`.`pType` AS `pType`,concat(coalesce(`v`.`vRegistration`,''),' ',coalesce(`v`.`vMake`,''),' ',coalesce(`v`.`vModel`,''),' ',coalesce(`v`.`vYear`,'')) AS `Vehicle`,`v`.`vMake` AS `vMake`,`v`.`vModel` AS `vModel`,`v`.`vYear` AS `vYear`,`staff`.`StaffID` AS `StaffID`,`staff`.`StaffFullName` AS `StaffFullName`,`s`.`StatusID` AS `StatusID`,`s`.`StatusName` AS `StatusName`,`a`.`AreaName` AS `AreaName`,`i`.`InsuranceName` AS `InsuranceName`,`q`.`quoteNo` AS `QuoteNo`,`j`.`DateCreated` AS `DateCreated`,`j`.`JobBookingDate` AS `JobBookingDate`,(case when (`j`.`JobBookingDate` < '2000-01-01') then '' else `j`.`JobBookingDate` end) AS `JobBookingDateBlank`,`j`.`JobNote` AS `JobNote`,`j`.`JobiViisNo` AS `JobIviisNo`,`j`.`JobMilage` AS `JobMilage`,`j`.`MilageRequired` AS `MilageRequired`,`j`.`JobReference` AS `JobReference`,`p`.`pType` AS `Payment`,`t`.`TypeGroup` AS `TypeGroup`,`j`.`JobSiteAddress` AS `JobSiteAddress`,`v`.`vRecalibration` AS `vRecalibration` from (((((((((`job` `j` join `jobtype` `t` on((`j`.`TypeID` = `t`.`TypeID`))) join `customer` `c` on((`j`.`CustomerID` = `c`.`CustomerID`))) join `payment` `p` on((`j`.`PaymentID` = `p`.`PaymentID`))) left join `vehicle` `v` on((`j`.`VehicleID` = `v`.`VehicleID`))) join `staff` on((`j`.`StaffID` = `staff`.`StaffID`))) join `status` `s` on((`j`.`StatusID` = `s`.`StatusID`))) left join `area` `a` on((`j`.`AreaID` = `a`.`AreaID`))) left join `insurance` `i` on((`j`.`InsuranceID` = `i`.`InsuranceID`))) left join `quote` `q` on((`j`.`QuoteID` = `q`.`quoteNo`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vwlabour`
--

/*!50001 DROP VIEW IF EXISTS `vwlabour`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vwlabour` AS select `labour`.`LabourID` AS `LabourID`,`labour`.`JobTaskID` AS `JobTaskID`,`staff`.`StaffFullName` AS `StaffFullName`,`staff`.`StaffRate` AS `StaffRate`,(((time_to_sec(timediff(`labour`.`EndTime`,`labour`.`StartTime`)) / 60) / 60) * `staff`.`StaffRate`) AS `Cost`,((((time_to_sec(timediff(`labour`.`EndTime`,`labour`.`StartTime`)) / 60) / 60) * `staff`.`StaffRate`) * 1.5) AS `Price`,`labour`.`Percent` AS `Percent`,timediff(`labour`.`EndTime`,`labour`.`StartTime`) AS `TimeLength`,`labour`.`StartTime` AS `StartTime`,`labour`.`EndTime` AS `EndTime`,`labour`.`Note` AS `Note` from (`labour` join `staff` on((`staff`.`StaffID` = `labour`.`StaffID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vwitemcost`
--

/*!50001 DROP VIEW IF EXISTS `vwitemcost`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vwitemcost` AS select `i`.`ItemCostID` AS `ItemCostID`,`i`.`ItemGroupID` AS `ItemGroupID`,`i`.`icCode` AS `icCode`,`i`.`icDescription` AS `icDescription`,`i`.`icPrice` AS `icPrice`,`i`.`icCost` AS `icCost`,`i`.`uom` AS `uom`,`i`.`allowance` AS `allowance`,`i`.`minQuantity` AS `minquantity`,`g`.`igDescription` AS `igDescription`,`g`.`igSubGroup` AS `igSubGroup`,`g`.`igType` AS `igType`,`g`.`igSort` AS `igSort`,(case when (`g`.`igSubGroup` = 'Glass') then substr(`i`.`icCode`,1,2) else 0 end) AS `GlassThickness`,(case when (`i`.`icCode` like '%GYFL%') then 1 else 0 end) AS `Tint`,(case when (`i`.`icCode` like '%CLPL%') then 1 else 0 end) AS `LowEPlus`,(case when (`i`.`icCode` like '%CLMX%') then 1 else 0 end) AS `LowEMax`,(case when (`i`.`icCode` like '%CLXL%') then 1 else 0 end) AS `LowEXcel`,cast((`i`.`icPrice` * 1599.50) as decimal(18,2)) AS `M2Rate`,(case when ((`g`.`igSubGroup` = 'Glass') and (`i`.`icCode` like '%GYFL%')) then 'Tint' when ((`g`.`igSubGroup` = 'Glass') and (`i`.`icCode` like '%CLPL%')) then 'LowEPlus' when ((`g`.`igSubGroup` = 'Glass') and (`i`.`icCode` like '%CLMX%')) then 'LowEMax' when ((`g`.`igSubGroup` = 'Glass') and (`i`.`icCode` like '%CLXL%')) then 'LowEXcel' when (`g`.`igSubGroup` = 'Glass') then 'Clear' else `g`.`igSubGroup` end) AS `SubGroup`,(case when (`g`.`ItemGroupID` < 1000) then `g`.`igSubGroup` else 'COMPONENTS' end) AS `ComponentGroup` from (`itemcost` `i` join `itemgroup` `g` on((`i`.`ItemGroupID` = `g`.`ItemGroupID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vwcomponent`
--

/*!50001 DROP VIEW IF EXISTS `vwcomponent`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vwcomponent` AS select `vwquoteitem`.`quoteNo` AS `quoteNo`,`vwquoteitem`.`dateCreated` AS `dateCreated`,`vwquoteitem`.`CustomerName` AS `CustomerName`,`vwquoteitem`.`reference` AS `reference`,`vwquoteitem`.`igSubGroup` AS `igSubGroup`,`vwquoteitem`.`ComponentGroup` AS `ComponentGroup`,`vwquoteitem`.`icCode` AS `icCode`,`vwquoteitem`.`icDescription` AS `icDescription`,`vwquoteitem`.`igSort` AS `igSort`,`vwquoteitem`.`uom` AS `uom`,`vwquoteitem`.`allowance` AS `allowance`,sum(`vwquoteitem`.`Quantity`) AS `Quantity`,sum(`vwquoteitem`.`quoteitemCost`) AS `quoteitemCost`,sum(`vwquoteitem`.`CostPrice`) AS `CostPrice` from `vwquoteitem` group by `vwquoteitem`.`quoteNo`,`vwquoteitem`.`dateCreated`,`vwquoteitem`.`CustomerName`,`vwquoteitem`.`reference`,`vwquoteitem`.`igSubGroup`,`vwquoteitem`.`icDescription`,`vwquoteitem`.`igSort`,`vwquoteitem`.`uom` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-18 16:31:44
