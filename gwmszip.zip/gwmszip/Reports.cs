﻿using DocumentFormat.OpenXml.Drawing;
using MySql.Data.MySqlClient;
//using MySql.Data.X.XDevAPI.Common;
using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Web.UI;
using System.Web.UI.WebControls.WebParts;
using System.Windows.Forms;
using System.IO;
using PdfSharp.Pdf;
using PdfSharp.Drawing;
using System.Windows.Forms.DataVisualization.Charting;

namespace workshop_orders
{
  /*This is a form is view all the created jobs in the database*
   * This data can a queried and filter so you can only display the job you want to see*/
  public partial class Reports : Form
  {
    private bool update = false;
    private string jobNumber;
    private String[] staff = { "Barry", "Dylan", "John", "Shane", "Brad" }; //TODO: Load this data from db, not hardcoded
    private String[] days = { "Mon", "Tues", "Wed", "Thu", "Fri", "Sat", "Sun" };
    private String directory = @"\\DATABASE\GWGFiles\BMS\";
    private String directory2 = @"C:\Users\Public\BMSLocalFiles\";

    /*A method to connect to the GoreGlassJob database*/
    public MySqlConnection connectMySql()
    {
      using (MySqlConnection conn = new MySqlConnection(GWMS.connStr))
      {
        try
        {
          Console.WriteLine("Connecting to MySQL...");

          return conn;
        }
        catch (Exception ex)
        {
          MessageBox.Show("Error connecting to server, please contact the administrator.", "Error!");
          return null;
        }

      }
    }

    private DateTime RoundUp(DateTime dt, TimeSpan d)
    {
      return new DateTime((dt.Ticks + d.Ticks - 1) / d.Ticks * d.Ticks, dt.Kind);
    }
    /*Initializes the component and add the database varible names to the 'WHERE' box, used for querying the job database job*/
    public Reports()
    {
      InitializeComponent();


      //string text = System.IO.File.ReadAllText(@"C:\Users\User\Documents\Production\Publication1.pub");
      //MessageBox.Show(text);
      //text = String.Format(text, 1, 2, 3, 4, 5, 15);

      //File.Delete(@"C:\Forms\quality.html");
      //using (System.IO.StreamWriter file = new System.IO.StreamWriter(@"C:\Users\User\Documents\Publication1.pub", true))
      //{
      //file.WriteLine(text);
      //}

      startDate.Value = DateTime.Now.AddDays(-1);
      endDate.Value = DateTime.Now.AddDays(-1);



      timer1.Enabled = true;
    }



    /*Check if String entered into function is a number
     */
    public bool IsNumber(String number)
    {
      return number.All(char.IsNumber);
    }

    /*reset_all_fields method
     * Resets all the fields in the form to empty
     * Also refreshes the Today's orders' box to reflect any changes that may have happened to the database.
     */
    private void reset_all_fields()
    {
    }

    private String convertTime(TimeSpan time)
    {
      try
      {
        String timeStr = time.ToString();


        int day = Int32.Parse(timeStr.Split(':')[0].Split('.')[0]);
        int hour = Int32.Parse(timeStr.Split(':')[0].Split('.')[1]);
        String min = timeStr.Split(':')[1];
        String sec = timeStr.Split(':')[2];

        hour = hour + (day * 24);


        return String.Format("{0}:{1}:{2}", hour, min, sec);
      }
      catch (Exception ex)
      {
        return time.ToString();
      }
    }



    private void Form1_Load(object sender, EventArgs e)
    {

    }

    private void executeSQL(string sql)
    {
      using (MySqlConnection conn = connectMySql())
      {
        try
        {
          conn.Open();
          MySqlCommand cmd = new MySqlCommand(sql, conn);
          cmd.ExecuteReader();
        }
        catch (Exception ex)
        {
          Console.WriteLine(ex.ToString());
          MessageBox.Show("Error communicating with database. If this problem persists, please contact the administrator.\n" + ex.ToString());
        }
        conn.Close();
      }
    }

    private String quote(string x)
    {
      return "'" + x + "'";
    }




    private void updateButton_Click(object sender, EventArgs e)
    {
      dataGridView1.Rows.Clear();
      DateTime start1 = startDate.Value;
      DateTime end = endDate.Value;
      String test;

      try
      {
        if (reportTree.SelectedNode == null)
        {
          return;
        }
      }
      catch
      {
        return;
      }


      if (reportTree.SelectedNode.Name == "logtimes")
      {
        foreach (string s in staff)
        {
          string startDay;
          string sql = String.Format("SELECT MIN(time) AS mintime FROM dayStamps WHERE staff = '{1}' " +
                  "AND day BETWEEN '{0}' AND '{0} 23:59:59' ORDER BY day, time;",
                  start1.ToString("yyyy-MM-dd"), s);

          using (MySqlConnection conn = connectMySql())
          {
            try
            {
              conn.Open();
              MySqlCommand cmd = new MySqlCommand(sql, conn);
              MySqlDataReader rdr = cmd.ExecuteReader();
              rdr.Read();
              startDay = rdr["mintime"].ToString();

            }
            catch (Exception ex)
            {
              Console.WriteLine(ex.ToString());
              startDay = "Missing Log in Record";
              //MessageBox.Show("ERROR!.\n" + ex.ToString());
            }
            conn.Close();
          }

          string endDay;
          sql = String.Format("SELECT MAX(time) AS maxtime FROM dayStamps WHERE staff = '{1}' " +
                  "AND day BETWEEN '{0}' AND '{0} 23:59:59' ORDER BY day, time;",
                  start1.ToString("yyyy-MM-dd"), s);

          using (MySqlConnection conn = connectMySql())
          {
            try
            {
              conn.Open();
              MySqlCommand cmd = new MySqlCommand(sql, conn);
              MySqlDataReader rdr = cmd.ExecuteReader();
              rdr.Read();
              endDay = rdr["maxtime"].ToString();
            }
            catch (Exception ex)
            {
              Console.WriteLine(ex.ToString());
              endDay = "Missing Log out Record";
              //MessageBox.Show("ERROR!.\n" + ex.ToString());
            }
            conn.Close();
          }
          dataGridView1.Rows.Add(s, startDay, endDay);
        }
      }
      else if (reportTree.SelectedNode.Name == "performance")
      {
        foreach (String s in staff)
        {

          chart1.Series[0].Points.Clear();
          chart1.Series[1].Points.Clear();
          chart1.Series[2].Points.Clear();

          string reportTemplate = System.IO.File.ReadAllText(
              directory + @"Reports\Performance\performance.html");

          string logtable = System.IO.File.ReadAllText(
              directory + @"Reports\Performance\logheadingtemp.html");

          string logdatatemp = System.IO.File.ReadAllText(
              directory + @"Reports\Performance\logdatatemp.html");

          string logtotaltemp = System.IO.File.ReadAllText(
              directory + @"Reports\Performance\logtotaltemp.html");

          string staff = "dylan";

          DateTime start = startDate.Value;
          DateTime stop = endDate.Value;

          TimeSpan total = TimeSpan.Parse("00:00:00");
          while (start <= stop)
          {
            string startDay;
            string sql = String.Format("SELECT MIN(time) AS mintime FROM dayStamps WHERE staff = '{1}' " +
                    "AND day BETWEEN '{0}' AND '{0} 23:59:59' ORDER BY day, time;",
                    start.ToString("yyyy-MM-dd"), s);

            using (MySqlConnection conn = connectMySql())
            {
              try
              {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                MySqlDataReader rdr = cmd.ExecuteReader();
                rdr.Read();
                startDay = rdr["mintime"].ToString();
              }
              catch (Exception ex)
              {
                Console.WriteLine(ex.ToString());
                startDay = "";

                //MessageBox.Show("ERROR!.\n" + ex.ToString());
              }
              conn.Close();
            }

            string endDay;
            sql = String.Format("SELECT MAX(time) AS maxtime FROM dayStamps WHERE staff = '{1}' " +
                    "AND day BETWEEN '{0}' AND '{0} 23:59:59' ORDER BY day, time;",
                    start.ToString("yyyy-MM-dd"), s);

            using (MySqlConnection conn = connectMySql())
            {
              try
              {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                MySqlDataReader rdr = cmd.ExecuteReader();
                rdr.Read();
                endDay = rdr["maxtime"].ToString();
              }
              catch (Exception ex)
              {
                Console.WriteLine(ex.ToString());
                endDay = "";

                //MessageBox.Show("ERROR!.\n" + ex.ToString());
              }
              conn.Close();
            }
            TimeSpan diff;

            if (startDay == "" && endDay == "")
            {
            }
            else if (startDay == "" || endDay == "")
            {
              diff = TimeSpan.Parse("00:00:00");
              logtable += String.Format(logdatatemp, start.ToString("ddd, dd/MM/yyyy ") + startDay,
              start.ToString("ddd, dd/MM/yyyy ") + endDay, diff);
            }
            else if (startDay != "" && endDay != "")
            {
              diff = TimeSpan.Parse(endDay) - TimeSpan.Parse(startDay) - TimeSpan.Parse("00:30:00");
              logtable += String.Format(logdatatemp, start.ToString("ddd, dd/MM/yyyy ") + startDay,
              start.ToString("ddd, dd/MM/yyyy ") + endDay, diff);
              total = total.Add(diff);
            }

            start = start.AddDays(1);
          }
          logtable += String.Format(logtotaltemp, convertTime(total));


          //Performance part of report.

          string perftable = System.IO.File.ReadAllText(
              directory + @"Reports\Performance\perfheadingtemp.html");

          string perfdatatemp = System.IO.File.ReadAllText(
              directory + @"Reports\Performance\perfdatatemp.html");

          string perftotaltemp = System.IO.File.ReadAllText(
              directory + @"Reports\Performance\perftotaltemp.html");

          start = startDate.Value;

          TimeSpan totalExpected = TimeSpan.Parse("00:00:00");
          TimeSpan totalActual = TimeSpan.Parse("00:00:00");
          TimeSpan totalVariance = TimeSpan.Parse("00:00:00");
          Double totalPerformance = 0;
          Double totalJobs = 0;

          while (start <= end)
          {
            String sql = String.Format("SELECT * FROM dayStamps LEFT JOIN job ON job.jobNo = dayStamps.jobNo " +
                "LEFT JOIN customer ON customer.cID = job.customerID WHERE staff = '{0}' AND day BETWEEN '{1}' AND '{1} 23:59:59'",
                s, start.ToString("yyyy-MM-dd"));
            DateTime previous = DateTime.Parse("00:00:00");
            TimeSpan expected = TimeSpan.Parse("00:00:00");

            //String previousDate = "";

            TimeSpan totalQuotedHours = TimeSpan.Parse("00:00:00");
            TimeSpan totalActualHours = TimeSpan.Parse("00:00:00");
            using (MySqlConnection conn = connectMySql())
            {
              try
              {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                using (MySqlDataReader rdr = cmd.ExecuteReader())
                {
                  while (rdr.Read())
                  {

                    expected = TimeSpan.Parse("00:00:00");
                    if (previous != DateTime.Parse("00:00:00"))
                    {
                      if (rdr["jobNo"].ToString() != "")
                      {

                        if (Int32.Parse(rdr["jobNo"].ToString()) >= 1000)
                        {
                          if (rdr["type"].ToString() == "Car Screen")
                          {
                            expected = TimeSpan.Parse("01:30:00");
                          }
                          if (rdr["type"].ToString() == "Chip")
                          {
                            expected = TimeSpan.Parse("00:30:00");
                          }
                          if (rdr["type"].ToString() == "Truck Screen")
                          {
                            expected = TimeSpan.Parse("02:00:00");
                          }
                          if (rdr["type"].ToString() == "Body Glass")
                          {
                            expected = TimeSpan.Parse("1:00:00");
                          }
                          if (rdr["type"].ToString() == "Rework")
                          {
                            expected = TimeSpan.Parse("01:30:00");
                          }
                          if (rdr["type"].ToString() == "Other")
                          {
                            expected = TimeSpan.Parse("01:00:00");
                          }

                          decimal percentage = (decimal)1;

                          if (rdr["percentage"].ToString() != "")
                          {
                            percentage = decimal.Parse(rdr["percentage"].ToString()) / (decimal)100;
                          }

                          expected = TimeSpan.FromTicks(expected.Ticks / (long)((decimal)1.0 / percentage));

                          TimeSpan actual = DateTime.Parse(rdr["time"].ToString()) - previous;
                          TimeSpan variance = actual - expected;

                          double performance = ((double)expected.Ticks / (double)actual.Ticks) * 100;

                          perftable += String.Format(perfdatatemp,
                              rdr["type"].ToString(), rdr["jobNo"].ToString() + ": " + rdr["cFirstName"].ToString() + " " +
                              rdr["cSurname"].ToString() + " | " + rdr["cCompany"].ToString(),
                              DateTime.Parse(rdr["day"].ToString()).ToString("ddd, dd/MM/yyyy ") + " " + rdr["time"].ToString(),
                              (percentage * 100).ToString() + "%",
                              expected.ToString(), actual, variance,
                              String.Format("{0:0.##}%", performance));

                          totalExpected += expected;
                          totalActual += actual;
                          totalVariance += variance;
                          totalPerformance += performance;
                          totalJobs++;

                          totalQuotedHours += expected;
                          totalActualHours += actual;

                        }
                      }
                    }
                    previous = DateTime.Parse(rdr["time"].ToString());
                  }
                }
              }
              catch (Exception ex)
              {
                MessageBox.Show("Error Loading Time Sheets.");

                DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");

              }
              conn.Close();
            }

            if (totalActualHours.ToString() != "00:00:00")
            {
              double performance = ((double)totalQuotedHours.Ticks / (double)totalActualHours.Ticks) * 100;
              perftable += String.Format(perfdatatemp,
                                             "", "", "",
                                             "<b>Day Total</b>",
                                             "<b>" + totalQuotedHours.ToString() + "</b>", "<b>" + totalActualHours.ToString() + "</b>",
                                             "<b>" + (totalActualHours - totalQuotedHours).ToString() + "</b>",
                                             "<b>" + String.Format("{0:0.##}%", performance) + "</b>");
            }
            start = start.AddDays(1);
          }

          chart1.Series["Std Time"].Points.AddXY(s, totalExpected.TotalHours);
          chart1.Series["Phys Time"].Points.AddXY(s, totalActual.TotalHours);


          perftable += String.Format(perftotaltemp, convertTime(totalExpected), convertTime(totalActual),
              convertTime(totalVariance),
              String.Format("{0:0.##}%", (double)totalExpected.Ticks / (double)totalActual.Ticks * 100));

          //admin part of report

          TimeSpan totalWork = totalActual;

          start = startDate.Value;

          string admintable = System.IO.File.ReadAllText(
              directory + @"Reports\Performance\adminheadingtemp.html");

          string admindatatemp = System.IO.File.ReadAllText(
              directory + @"Reports\Performance\admindatatemp.html");

          string admintotaltemp = System.IO.File.ReadAllText(
              directory + @"Reports\Performance\admintotaltemp.html");

          totalActual = TimeSpan.Parse("00:00:00");

          while (start <= end)
          {
            String sql = String.Format("SELECT * FROM dayStamps LEFT JOIN admin ON jobNo = code WHERE staff = '{0}' AND day = '{1}' AND '{1} 23:59:59'",
                s, start.ToString("yyyy-MM-dd"));
            DateTime previous = DateTime.Parse("00:00:00");
            TimeSpan expected = TimeSpan.Parse("00:00:00");

            TimeSpan totalHours = TimeSpan.Parse("00:00:00");
            using (MySqlConnection conn = connectMySql())
            {
              try
              {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                using (MySqlDataReader rdr = cmd.ExecuteReader())
                {
                  while (rdr.Read())
                  {
                    expected = TimeSpan.Parse("00:00:00");

                    if (previous != DateTime.Parse("00:00:00"))
                    {
                      if (rdr["jobNo"].ToString() != "")
                      {
                        if (Int32.Parse(rdr["jobNo"].ToString()) < 1000)
                        {
                          TimeSpan actual = DateTime.Parse(rdr["time"].ToString()) - previous;
                          //TimeSpan variance = actual - expected;

                          //double performance = ((double)expected.Ticks / (double)actual.Ticks) * 100;



                          admintable += String.Format(admindatatemp,
                              rdr["name"].ToString(), rdr["note"].ToString(), DateTime.Parse(rdr["day"].ToString()).ToString("ddd, dd/MM/yyyy ") + " " + rdr["time"].ToString(),
                              actual);

                          totalActual += actual;

                          totalHours += actual;
                        }
                      }
                    }
                    previous = DateTime.Parse(rdr["time"].ToString());
                  }
                }
              }
              catch (Exception ex)
              {
                MessageBox.Show("Error Loading Time Sheets.");
                DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
              }
              conn.Close();
            }
            if (totalHours.ToString() != "00:00:00")
            {
              admintable += String.Format(admindatatemp,
                                          "", "", "<b>Day Total</b>", "<b>" + totalHours.ToString() + "</b>");
            }
            start = start.AddDays(1);
          }

          admintable += String.Format(admintotaltemp, convertTime(totalActual));

          chart1.Series["Admin Time"].Points.AddXY(s, totalActual.TotalHours);


          String chartImage = @"C:\Users\Public\BMSLocalFiles\Reports\Performance\" + s + "chart.png";
          chart1.SaveImage(chartImage, ChartImageFormat.Png);


          reportTemplate = String.Format(reportTemplate,
              startDate.Value.ToString("ddd, dd/MM/yyyy"), stop.ToString("ddd, dd/MM/yyyy"), s,
              logtable, perftable, admintable, s + "chart.png");

          File.WriteAllText(@"C:\Users\Public\BMSLocalFiles\Reports\Performance\" + s + ".html", reportTemplate);
          //MessageBox.Show(webBrowser1.Version.Major.ToString());
          /*webBrowser1.DocumentText = System.IO.File.ReadAllText(
              @"C:\Users\Public\BMSLocalFiles\Reports\Performance\" + s + ".html");*/


          if (PrintCheck.Checked)
          {
            webBrowser1.Url = new Uri(@"C:\Users\Public\BMSLocalFiles\Reports\Performance\" + s + ".html");
            webBrowser1.Print();
          }

          if (DisplayCheck.Checked)
          {
            System.Diagnostics.Process.Start(@"C:\Users\Public\BMSLocalFiles\Reports\Performance\" + s + ".html");
          }
        }
      }

      else if (reportTree.SelectedNode.Name == "timesheets")
      {
        foreach (String s in staff)
        {
          string timesheets = System.IO.File.ReadAllText(
              @"C:\Users\Public\BMSLocalFiles\Reports\Timesheets\timesheets.html");

          //Performance part of report.

          string timetable = System.IO.File.ReadAllText(
              @"C:\Users\Public\BMSLocalFiles\Reports\Timesheets\timeheadingtemp.html");

          string timedatatemp = System.IO.File.ReadAllText(
              @"C:\Users\Public\BMSLocalFiles\Reports\Timesheets\timedatatemp.html");

          string timetotaltemp = System.IO.File.ReadAllText(
              @"C:\Users\Public\BMSLocalFiles\Reports\Timesheets\timetotaltemp.html");

          DateTime start = startDate.Value;
          TimeSpan totalExpected = TimeSpan.Parse("00:00:00");
          TimeSpan totalActual = TimeSpan.Parse("00:00:00");
          TimeSpan totalVariance = TimeSpan.Parse("00:00:00");
          Double totalPerformance = 0;
          Double totalJobs = 0;

          while (start <= end)
          {
            String sql = String.Format("SELECT * FROM dayStamps LEFT JOIN job ON job.jobNo = dayStamps.jobNo " +
                "LEFT JOIN customer ON customer.cID = job.customerID WHERE staff = '{0}' AND day = '{1}' AND '{1} 23:59:59'",
                s, start.ToString("yyyy-MM-dd"));
            DateTime previous = DateTime.Parse("00:00:00");
            TimeSpan expected = TimeSpan.Parse("00:00:00");

            using (MySqlConnection conn = connectMySql())
            {
              try
              {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                using (MySqlDataReader rdr = cmd.ExecuteReader())
                {
                  while (rdr.Read())
                  {
                    expected = TimeSpan.Parse("00:00:00");
                    if (previous != DateTime.Parse("00:00:00"))
                    {
                      if (rdr["jobNo"].ToString() != "")
                      {
                        if (rdr["type"].ToString() == "Car Screen")
                        {
                          expected = TimeSpan.Parse("01:30:00");
                        }
                        if (rdr["type"].ToString() == "Chip")
                        {
                          expected = TimeSpan.Parse("00:30:00");
                        }
                        if (rdr["type"].ToString() == "Truck Screen")
                        {
                          expected = TimeSpan.Parse("02:00:00");
                        }
                        if (rdr["type"].ToString() == "Body Glass")
                        {
                          expected = TimeSpan.Parse("1:00:00");
                        }
                        if (rdr["type"].ToString() == "Rework")
                        {
                          expected = TimeSpan.Parse("01:30:00");
                        }
                        if (rdr["type"].ToString() == "Other")
                        {
                          expected = TimeSpan.Parse("01:00:00");
                        }

                        TimeSpan actual = DateTime.Parse(rdr["time"].ToString()) - previous;
                        TimeSpan variance = actual - expected;

                        double performance = ((double)expected.Ticks / (double)actual.Ticks) * 100;

                        timetable += String.Format(timedatatemp,
                            rdr["type"].ToString(), rdr["jobNo"].ToString() + ": " + rdr["cFirstName"].ToString() + " " +
                            rdr["cSurname"].ToString() + " | " + rdr["cCompany"].ToString(), expected.ToString(), actual, variance,
                            String.Format("{0:0.##}%", performance));

                        totalExpected += expected;
                        totalActual += actual;
                        totalVariance += variance;
                        totalPerformance += performance;
                        totalJobs++;
                      }
                    }
                    previous = DateTime.Parse(rdr["time"].ToString());
                  }
                }
              }
              catch (Exception ex)
              {
                MessageBox.Show("Error Loading Time Sheets.");
                DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
              }
              conn.Close();
            }
            start = start.AddDays(1);
          }

          timetable += String.Format(timetotaltemp, totalExpected, totalActual, totalVariance,
              String.Format("{0:0.##}%", (double)totalExpected.Ticks / (double)totalActual.Ticks * 100));

          timesheets = String.Format(timesheets,
              startDate.Value.ToString("ddd, dd/MM/yyyy"), s, timetable);



          File.WriteAllText(@"C:\Users\Public\BMSLocalFiles\Reports\Timesheets\" + s + ".html", timesheets);


        }
      }

      else if (reportTree.SelectedNode.Name == "production")
      {
        chart1.Series["Std Time"].Points.Clear();
        chart1.Series["Phys Time"].Points.Clear();

        TimeSpan diff = TimeSpan.Parse("0:00:00");
        bool nodata = false;

        foreach (string s in staff)
        {
          nodata = false;

          DateTime startRange = startDate.Value;
          diff = TimeSpan.Parse("0:00:00");
          //MessageBox.Show(startRange.ToString("yyyy-MM-dd"), endDate.Value.ToString("yyyy-MM-dd"));
          while (startRange <= endDate.Value)
          {
            String sql2 = String.Format("SELECT MIN(time) AS min, MAX(time) AS max FROM dayStamps WHERE staff = '{1}' " +
                "AND day BETWEEN '{0}' AND '{0} 23:59:59' ORDER BY day, time;",
                startRange.ToString("yyyy-MM-dd"), s);

            using (MySqlConnection conn = connectMySql())
            {
              try
              {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand(sql2, conn);
                MySqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                  diff += DateTime.Parse(rdr["max"].ToString()).Subtract(DateTime.Parse(rdr["min"].ToString()));
                  //min = rdr["min"].ToString();
                  //max = rdr["max"].ToString();
                }
              }
              catch (Exception ex)
              {
                Console.WriteLine(ex.ToString());
                //MessageBox.Show("ERROR!.\n" + ex.ToString());
              }
              conn.Close();
            }
            startRange = startRange.AddDays(1);
          }

          if (diff.ToString() == "00:00:00")
          {
            nodata = true;
          }
          //start1 = start1.AddDays(1);

          String sql = String.Format("SELECT * FROM dayStamps " +
              "LEFT JOIN job ON job.jobNo = dayStamps.jobNo WHERE staff = '{2}' " +
              "AND day BETWEEN '{0}' AND '{1} 23:59:59' ORDER BY day, time;",
              startDate.Value.ToString("yyyy-MM-dd"), endDate.Value.ToString("yyyy-MM-dd"), s);

          TimeSpan expected = TimeSpan.Parse("0:00:00");
          TimeSpan physical = TimeSpan.Parse("0:00:00");
          using (MySqlConnection conn = connectMySql())
          {
            try
            {
              conn.Open();
              MySqlCommand cmd = new MySqlCommand(sql, conn);
              MySqlDataReader rdr = cmd.ExecuteReader();
              while (rdr.Read())
              {
                if (rdr["type"].ToString() == "Car Screen" && rdr["action"].ToString() == "END")
                {
                  expected += TimeSpan.Parse("01:30:00");
                }
                if (rdr["type"].ToString() == "Chip" && rdr["action"].ToString() == "END")
                {
                  expected += TimeSpan.Parse("00:30:00");
                }
                if (rdr["type"].ToString() == "Truck Screen" && rdr["action"].ToString() == "END")
                {
                  expected += TimeSpan.Parse("02:00:00");
                }
                if (rdr["type"].ToString() == "Body Glass" && rdr["action"].ToString() == "END")
                {
                  expected += TimeSpan.Parse("0:30:00");
                }
              }
            }
            catch (Exception ex)
            {
              Console.WriteLine(ex.ToString());
              MessageBox.Show("ERROR!.\n" + ex.ToString());
            }
            conn.Close();
          }
          //totalExpected += expected;
          //MessageBox.Show(expected.ToString());

          sql = String.Format("SELECT * FROM dayStamps " +
              "LEFT JOIN job ON job.jobNo = dayStamps.jobNo WHERE staff = '{2}' " +
              "AND day BETWEEN '{0}' AND '{1} 23:59:59' ORDER BY day, time;",
              startDate.Value.ToString("yyyy-MM-dd"), endDate.Value.ToString("yyyy-MM-dd"), s);

          //start = DateTime.Parse("0:00:00");

          using (MySqlConnection conn = connectMySql())
          {
            try
            {
              conn.Open();
              MySqlCommand cmd = new MySqlCommand(sql, conn);
              MySqlDataReader rdr = cmd.ExecuteReader();

              DateTime previous = DateTime.Parse("0:00:00");
              while (rdr.Read())
              {

                if (rdr["jobNo"].ToString() != "" && previous != DateTime.Parse("0:00:00"))
                {
                  if (int.Parse(rdr["jobNo"].ToString()) >= 1000 || rdr["jobNo"].ToString() == "100" ||
                      rdr["jobNo"].ToString() == "108" || rdr["jobNo"].ToString() == "109")
                  {
                    physical += (DateTime.Parse(rdr["time"].ToString()) - previous);
                    previous = DateTime.Parse(rdr["time"].ToString());
                  }
                  else
                  {

                  }
                }
                previous = DateTime.Parse(rdr["time"].ToString());
                /*
                    if (rdr["action"].ToString() == "START")
                    {
                        start = DateTime.Parse(rdr["time"].ToString());
                    }
                    else if (rdr["action"].ToString() == "END" && start.ToString("HH:mm:ss") != "00:00:00")
                    {
                        physical += (DateTime.Parse(rdr["time"].ToString()) - start);
                        start = DateTime.Parse("0:00:00");
                    }*/

              }
            }
            catch (Exception ex)
            {
              Console.WriteLine(ex.ToString());
              MessageBox.Show("ERROR!.\n" + ex.ToString());
            }
            conn.Close();
          }
          /*
          using (MySqlConnection conn = connectMySql())
          {
              try
              {
                  conn.Open();
                  MySqlCommand cmd = new MySqlCommand(sql, conn);
                  MySqlDataReader rdr = cmd.ExecuteReader();
                  while (rdr.Read())
                  {

                      if (rdr["action"].ToString() == "START")
                      {
                          start = DateTime.Parse(rdr["time"].ToString());
                      }
                      else if (rdr["action"].ToString() == "END" && start.ToString("HH:mm:ss") != "00:00:00")
                      {
                          physical += (DateTime.Parse(rdr["time"].ToString()) - start);
                          start = DateTime.Parse("0:00:00");
                      }
                  }
              }
              catch (Exception ex)
              {
                  Console.WriteLine(ex.ToString());
                  MessageBox.Show("ERROR!.\n" + ex.ToString());
              }
              conn.Close();
          }*/

          //totalPhys += physical;
          // MessageBox.Show(physical.ToString());


          TimeSpan variance = expected - physical;
          //TimeSpan totalVariance = totalExpected - totalPhys;
          //MessageBox.Show(variance.ToString());

          double performance = ((double)variance.Ticks / (double)physical.Ticks) + 1;
          //MessageBox.Show(performance.ToString());
          double admin = ((((double)diff.Ticks - (double)physical.Ticks) / (double)diff.Ticks));


          chart1.Series["Std Time"].Points.AddXY(s, expected.TotalHours);
          chart1.Series["Phys Time"].Points.AddXY(s, physical.TotalHours);

          int totalHours = diff.Hours + (diff.Days * 24);
          String totalPhys = totalHours.ToString() + ":" + diff.Hours + ":" + diff.Minutes;
          dataGridView1.Rows.Add(s, totalPhys, String.Format("{0:P2}", admin), expected, physical, variance, String.Format("{0:P2}", performance));
          if (nodata)
          {
            int length = dataGridView1.Rows.Count;
            dataGridView1.Rows[length - 1].Cells[1].Style.BackColor = Color.Red;
          }

          //MessageBox.Show(((double)diff.Ticks).ToString() + "-" + ((double)physical.Ticks).ToString() + "/" + ((double)diff.Ticks).ToString());

          //performance = (((double)totalVariance.Ticks / (double)totalPhys.Ticks) + 1);

          //dataGridView1.Rows.Add("TOTAL", totalDiff, "0%", totalExpected, totalPhys, totalExpected - totalPhys, String.Format("{0:P2}", performance));
        }
      }
    }




    private string quoteNull(String str)
    {
      if (str == "")
      {
        return "NULL";
      }
      else
      {
        return quote(str);
      }
    }

    private void ViewJobForm_Resize(object sender, EventArgs e)
    {

    }

    /* https://www.c-sharpcorner.com/blogs/reset-all-controls-in-groupbox1 */
    private void ResetAll(GroupBox gbox)
    {
      foreach (System.Windows.Forms.Control ctrl in gbox.Controls)
      {
        if (ctrl is TextBox)
        {
          TextBox textBox = (TextBox)ctrl;
          textBox.Text = null;
        }
        if (ctrl is ComboBox)
        {
          ComboBox comboBox = (ComboBox)ctrl;
          comboBox.SelectedIndex = -1;
        }
        if (ctrl is CheckBox)
        {
          CheckBox checkBox = (CheckBox)ctrl;
          checkBox.Checked = false;
        }
        if (ctrl is RadioButton)
        {
          RadioButton radioButton = (RadioButton)ctrl;
          radioButton.Checked = false;
        }
        if (ctrl is ListBox)
        {
          ListBox listBox = (ListBox)ctrl;
          listBox.ClearSelected();
        }
      }
    }

    private void completeRadio_CheckedChanged(object sender, EventArgs e)
    {


    }

    private void rebookRadio_CheckedChanged(object sender, EventArgs e)
    {

    }

    private void cancelRadio_CheckedChanged(object sender, EventArgs e)
    {

    }
    private void staffRadio_CheckedChanged(object sender, EventArgs e)
    {

    }

    private void customerRadio_CheckedChanged(object sender, EventArgs e)
    {

    }

    private void supplierRadio_CheckedChanged(object sender, EventArgs e)
    {

    }

    private void otherSourceRadio_CheckedChanged(object sender, EventArgs e)
    {


    }

    private void dateGroupEnabled()
    {

    }

    private void incorrectRadio_CheckedChanged(object sender, EventArgs e)
    {
      dateGroupEnabled();
    }

    private void damagedRadio_CheckedChanged(object sender, EventArgs e)
    {
      dateGroupEnabled();
    }

    private void noPartRadio_CheckedChanged(object sender, EventArgs e)
    {
      dateGroupEnabled();
    }

    private void makeItRadio_CheckedChanged(object sender, EventArgs e)
    {
      dateGroupEnabled();
    }

    private void staffnpRadio_CheckedChanged(object sender, EventArgs e)
    {
      dateGroupEnabled();
    }

    private void otherRadio_CheckedChanged(object sender, EventArgs e)
    {

    }

    private void forgotRadio_CheckedChanged(object sender, EventArgs e)
    {
      dateGroupEnabled();
    }

    private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
    {

    }

    private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
    {

    }

    private void upButton_Click(object sender, EventArgs e)
    {
    }

    private void downButton_Click(object sender, EventArgs e)
    {
    }

    private void timer1_Tick(object sender, EventArgs e)
    {

    }

    private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
    {

    }

    private void endDate_ValueChanged(object sender, EventArgs e)
    {
      if (endDate.Value < startDate.Value)
      {
        endDate.Value = startDate.Value;
      }
    }

    private void startDate_ValueChanged(object sender, EventArgs e)
    {
      if (endDate.Value < startDate.Value)
      {
        endDate.Value = startDate.Value;
      }
    }
  }
}
