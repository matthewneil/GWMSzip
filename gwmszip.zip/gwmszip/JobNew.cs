﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workshop_orders
{
  public partial class JobNew : Form
  {
    public static int CustomerID = -1;
    public static int VehicleID = -1;
    private int QuoteID = -1;

    private String[] times = { "8:00", "9:00", "10:30", "12:00", "12:30", "13:30", "14:30", "15:15" };

    public static int partID;
    private int timepos = 0;


    public bool _load = true;
    public JobNew(int QuoteID)
    {
      
      InitializeComponent();
      DisplaySection();
      LoadJobTypes();
      LoadPaymentTypes();
      LoadInsuranceProviders();
      LoadOnsiteAddress();

      CustomerID = -1;
      VehicleID = -1;
      cmbPayment.SelectedIndex = cmbPayment.FindString("Insurance");
      dtpBookDate.Value = DateTime.Today;

      if (QuoteID > 0)
      {
        this.QuoteID = QuoteID;
        DataTable dt = DataAccess.ExecuteDataTable("SELECT reference, customerID, comments FROM quote WHERE quoteNo = " + QuoteID);
        rbGlass.Checked = true;
        cmbType.SelectedValue = 47; //retrofit - hardcoded for now
        CustomerID = (int)dt.Rows[0]["customerID"];
        txtNote.Text = dt.Rows[0]["comments"].ToString();
        txtReference.Text = dt.Rows[0]["reference"].ToString();


        btnCustomer.Enabled = false;
        gbType.Enabled = false;

        LoadCustomerFromID();
        EnableRadioOnPanel(true);
        ValidateCustomer();
      }

      _load = false;
      SetButtonState(DataAccess.FormState(this.AccessibilityObject.Name, tsSave));
    }

    private void SetButtonState(Boolean bState)
    {
      btnSave.Visible = bState;
    }


    private void LoadJobTypes()
    {
      if (rbAuto.Checked)
      {
        DataTable dt = DataAccess.ExecuteDataTable(
          "SELECT TypeID AS datafield, TypeName AS textfield FROM JobType WHERE TypeGroup = 'Auto' ORDER BY TypeName");
        //DataAccess.AddSelect(dt);
        cmbType.DataSource = dt;
        cmbType.SelectedIndex = cmbType.FindString("Car Screen");
      }
      else
      {
        DataTable dt = DataAccess.ExecuteDataTable(
          "SELECT TypeID AS datafield, TypeName AS textfield FROM JobType WHERE TypeGroup = 'Glass' ORDER BY TypeName");
        //DataAccess.AddSelect(dt);
        cmbType.DataSource = dt;
        cmbType.SelectedIndex = cmbType.FindString("Flat Glass");
      }
    }

    public void LoadPaymentTypes()
    {
      DataTable dt = DataAccess.ExecuteDataTable(
        "SELECT PaymentID AS datafield, pType AS textfield FROM Payment");
      //DataAccess.AddSelect(dt);
      cmbPayment.DataSource = dt;
      cmbPayment.SelectedIndex = cmbPayment.FindString("Cash Sale");
    }

    public void LoadInsuranceProviders()
    {
      DataTable dt = DataAccess.ExecuteDataTable(
        "SELECT InsuranceID AS datafield, InsuranceName AS textfield FROM Insurance");
      DataAccess.AddSelect(dt);
      cmbInsurance.DataSource = dt;
    }

    public void LoadOnsiteAddress()
    {
      DataTable dt = DataAccess.ExecuteDataTable(
        "SELECT AreaID AS datafield, AreaName AS textfield FROM Area");
      DataAccess.AddSelect(dt);
      cmbArea.DataSource = dt;
    }

    private void LoadVehicleFromID()
    {
      if (VehicleID > 0)
      {
        DataTable dt = DataAccess.ExecuteDataTable(
          "SELECT * FROM vehicle WHERE VehicleID = " + VehicleID);
        txtVehicle.Text = dt.Rows[0]["vRegistration"].ToString() + " - " + dt.Rows[0]["vMake"].ToString() + " " + dt.Rows[0]["vModel"].ToString() + " " + dt.Rows[0]["vYear"].ToString();
      }
      else
      {
        txtVehicle.Text = "";
      }
    }

    private void LoadCustomerFromID()
    {
      if (CustomerID > 0)
      {
        DataTable dt = DataAccess.ExecuteDataTable(
          "SELECT * FROM customer WHERE CustomerID = " + CustomerID);
        txtCustomer.Text = dt.Rows[0]["CustomerName"].ToString();
        txtAccountName.Text = dt.Rows[0]["cAccountName"].ToString();
        txtAccountNo.Text = dt.Rows[0]["cAccountNo"].ToString();

        DataTable dtVehicle = DataAccess.ExecuteDataTable(
          "SELECT v.VehicleID, v.vRegistration, CONCAT(v.vMake, ' ', v.vModel, ' ', v.vYear) AS vehicle FROM Vehicle v " +
          "INNER JOIN job j ON v.VehicleID = j.VehicleID " +
          "WHERE CustomerID = " + CustomerID + " GROUP BY v.VehicleID");
        dgvVehicle.DataSource = dtVehicle;
      }
      else
      {
        txtCustomer.Text = "";
      }
    }



    private void ValidateType()
    {
      if (_load) return;

      rbType.ForeColor = Color.Lime;
    }

    private void ValidateCustomer()
    {
      if (_load) return;

      if (CustomerID > 0)
      {
        rbCustomer.ForeColor = Color.Lime;
      }
      else
      {
        rbCustomer.ForeColor = Color.Yellow;
      }
    }

    private void ValidateVehicle()
    {
      if (_load) return;
      if (VehicleID > 0)
      {
        rbVehicle.ForeColor = Color.Lime;
      }
      else
      {
        rbVehicle.ForeColor = Color.Yellow;
      }

    }

    private void ValidateAccounts()
    {
      if (_load) return;
      if ((int)cmbPayment.SelectedValue <= 1)
      {
        SetEnabledAccounts(false);
        if ((int)cmbPayment.SelectedValue == 1) // CASH SALE
        {
          rbAccount.ForeColor = Color.Lime;
        }
        else
        {
          rbAccount.ForeColor = Color.Yellow;
        }
      }
      else // INSURANCE(2) OR ACCOUNT (3)
      {
        SetEnabledAccounts(true);
        if ((int)cmbInsurance.SelectedValue != -1 && txtAccountName.Text != "" && txtAccountNo.Text != "")
        {
          rbAccount.ForeColor = Color.Lime;
        }
        else
        {
          rbAccount.ForeColor = Color.Yellow;
        }
      }

    }

    private void ValidateOnsite()
    {
      if (_load) return;
      rbOnsitePanel.ForeColor = Color.Yellow;
      if (rbWorkshop.Checked)
      {
        SetEnabledOnsite(false);
        rbOnsitePanel.ForeColor = Color.Lime;
      }
      else if (rbOnsite.Checked)
      {
        SetEnabledOnsite(true);
        if ((int)cmbArea.SelectedValue != -1 && txtAddress.Text != "")
        {
          rbOnsitePanel.ForeColor = Color.Lime;
        }
      }

    }

    private void ValidateBooking()
    {
      if (_load) return;
      if (chkBooking.Checked)
      {
        rbBooking.ForeColor = Color.Yellow;
      }
      else
      {
        rbBooking.ForeColor = Color.Lime;
      }

    }

    private void ValidateNote()
    {
      if (_load) return;
      if (txtReference.Text != "" || txtNote.Text != "")
      {
        rbReference.ForeColor = Color.Lime;
      }
      else
      {
        rbReference.ForeColor = Color.Yellow;
      }

    }
    private void ValidateItem()
    {


    }

    private void DisplaySection()
    {
      tsPrevious.Enabled = true;
      tsNext.Enabled = true;
      if (rbType.Checked)
      {
        gbType.BringToFront();     
      }
      else if (rbCustomer.Checked)
      {
        gbCustomer.BringToFront();
        tsPrevious.Enabled = false;
      }
      else if (rbVehicle.Checked)
      {
        gbVehicle.BringToFront();
      }
      else if (rbAccount.Checked)
      {
        gbAccount.BringToFront();
      }
      else if (rbOnsitePanel.Checked)
      {
        gbOnsite.BringToFront();
      }
      else if (rbBooking.Checked)
      {
        gbBooking.BringToFront();
      }
      else if (rbReference.Checked)
      {
        gbReference.BringToFront();
      }

    }


    private void rbType_CheckedChanged(object sender, EventArgs e)
    {
      DisplaySection();
      ValidateType();
    }

    private void rbCustomer_CheckedChanged(object sender, EventArgs e)
    {
      DisplaySection();
      ValidateCustomer();
    }

    private void rbVehicle_CheckedChanged(object sender, EventArgs e)
    {
      DisplaySection();
      ValidateVehicle();
    }

    private void rbAccount_CheckedChanged(object sender, EventArgs e)
    {
      DisplaySection();
      ValidateAccounts();
    }

    private void rbOnsite_CheckedChanged(object sender, EventArgs e)
    {
      DisplaySection();
      ValidateOnsite();
    }

    private void rbBooking_CheckedChanged(object sender, EventArgs e)
    {
      DisplaySection();
      ValidateBooking();
    }

    private void rbReference_CheckedChanged(object sender, EventArgs e)
    {
      DisplaySection();
      ValidateNote();
    }

    private void rbItems_CheckedChanged(object sender, EventArgs e)
    {
      DisplaySection();
      ValidateItem();
    }

    private void tsBack_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private void tsPrevious_Click(object sender, EventArgs e)
    {
      if (rbType.Checked)
      {
        rbCustomer.Checked = true;
      }
      else if (rbVehicle.Checked)
      {
        rbType.Checked = true;
      }
      else if (rbAccount.Checked)
      {
        if (!rbGlass.Checked)
        {
          rbVehicle.Checked = true;
        }
        else
        {
          rbType.Checked = true;
        }
      }
      else if (rbOnsitePanel.Checked)
      {
        rbAccount.Checked = true;
      }
      else if (rbBooking.Checked)
      {
        rbOnsitePanel.Checked = true;
      }
      else if (rbReference.Checked)
      {
        rbBooking.Checked = true;
        tsNext.Visible = true;
        tsSave.Visible = false;
      }
    }

    private void tsNext_Click(object sender, EventArgs e)
    {
      if (rbCustomer.Checked)
      {
        if (CustomerID < 1)
        {
          DataAccess.ShowMessage("You must select a customer first!");
        }
        else
        {
          rbType.Checked = true;
          btnSave.Enabled = true;
          
        }
      }
      else if (rbType.Checked)
      {
        if (!rbGlass.Checked)
        {
          rbVehicle.Checked = true;
        }
        else
        {
          rbAccount.Checked = true;
        }
      }
      else if (rbVehicle.Checked)
      {
        rbAccount.Checked = true;
      }
      else if (rbAccount.Checked)
      {
        rbOnsitePanel.Checked = true;
      }
      else if (rbOnsitePanel.Checked)
      {
        rbBooking.Checked = true;
        
      }
      else if (rbBooking.Checked)
      {
        rbReference.Checked = true;
        tsNext.Visible = false;
        tsSave.Visible = true;
      }

    }

    private void rbAuto_CheckedChanged(object sender, EventArgs e)
    {
      TypeChanged();
    }

    private void rbGlass_CheckedChanged(object sender, EventArgs e)
    {
      TypeChanged();
    }

    private void TypeChanged()
    {
      cmbType.Enabled = true;
      LoadJobTypes();
      if (rbAuto.Checked)
      {
        rbVehicle.Enabled = true;
        chkMilage.Visible = true;
        if (rbAccount.ForeColor != Color.Yellow && rbAccount.ForeColor != Color.Lime) //dont change payment type if section has been viewed
        {
          cmbPayment.SelectedIndex = cmbPayment.FindString("Insurance");
        }
      }
      else
      {
        rbVehicle.Enabled = false;
        VehicleID = -1;
        chkMilage.Visible = false;
        chkMilage.Checked = false;
        if (rbAccount.ForeColor != Color.Yellow && rbAccount.ForeColor != Color.Lime) //dont change payment type if section has been viewed
        {
          cmbPayment.SelectedIndex = cmbPayment.FindString("Cash Sale");
        }
      }
    }

    private void cmbType_SelectedIndexChanged(object sender, EventArgs e)
    {
      ValidateType();
    }



    private void btnCustomer_Click(object sender, EventArgs e)
    {
      SearchCustomer form = new SearchCustomer(CustomerID, 2);
      FormManagement.ShowDialogForm(form);

      if (CustomerID > 0)
      {
        LoadCustomerFromID();
        EnableRadioOnPanel(true);
      }
      else
      {
        txtCustomer.Text = "";
      }
      ValidateCustomer();
    }



    private void btnVehicle_Click(object sender, EventArgs e)
    {
      SearchVehicle form = new SearchVehicle(VehicleID, 2);
      FormManagement.ShowDialogForm(form);
      if (VehicleID > 0)
      {
        LoadVehicleFromID();
      }
      else
      {
        txtVehicle.Text = "";
      }
      ValidateVehicle();
    }



    private void cmbPayment_SelectedValueChanged(object sender, EventArgs e)
    {
      if (rbAccount.ForeColor != Color.White)
      {
        ValidateAccounts();
      }
    }

    private void SetEnabledAccounts(bool enabled)
    {
      cmbInsurance.Enabled = enabled;
      lblInsurance.Enabled = enabled;

      txtAccountName.Enabled = enabled;
      lblAccountName.Enabled = enabled;

      txtAccountNo.Enabled = enabled;
      lblAccountNo.Enabled = enabled;

      if (!enabled)
      {
        cmbInsurance.SelectedIndex = cmbInsurance.FindString("<select>");
        txtAccountName.Text = "";
        txtAccountNo.Text = "";
      }
    }



    private void cmbInsurance_SelectedValueChanged(object sender, EventArgs e)
    {
      ValidateAccounts();
    }

    private void txtAccountName_TextChanged(object sender, EventArgs e)
    {
      ValidateAccounts();
    }

    private void txtAccountNo_TextChanged(object sender, EventArgs e)
    {
      ValidateAccounts();
    }

    private void rbWorkshop_CheckedChanged(object sender, EventArgs e)
    {
      ValidateOnsite();
    }

    private void rbOnsite_CheckedChanged_1(object sender, EventArgs e)
    {
      ValidateOnsite();
    }



    private void SetEnabledOnsite(bool Enabled)
    {
      lblArea.Enabled = Enabled;
      cmbArea.Enabled = Enabled;
      lblAddress.Enabled = Enabled;
      txtAddress.Enabled = Enabled;

      if (!Enabled)
      {
        cmbArea.SelectedValue = -1;
        cmbArea.SelectedIndex = cmbArea.FindString("<select>");
        txtAddress.Text = "";
      }
    }

    private void cmbArea_SelectedValueChanged(object sender, EventArgs e)
    {
      ValidateOnsite();
    }

    private void txtAddress_TextChanged(object sender, EventArgs e)
    {
      ValidateOnsite();
    }

    private void chkBooking_CheckedChanged(object sender, EventArgs e)
    {
      ValidateBooking();
      if (chkBooking.Checked)
      {
        dtpBookDate.Enabled = false;
        dtpBookTime.Enabled = false;
        btnTimeBack.Enabled = false;
        btnTimeForward.Enabled = false;
      }
      else
      {
        dtpBookDate.Enabled = true;
        dtpBookTime.Enabled = true;
        btnTimeBack.Enabled = true;
        btnTimeForward.Enabled = true;
      }
    }



    private void txtReference_TextChanged(object sender, EventArgs e)
    {
      ValidateNote();
    }

    private void txtNote_TextChanged(object sender, EventArgs e)
    {
      ValidateNote();
    }

    private void tsSave_Click(object sender, EventArgs e)
    {
     
    }

    private void SaveJob()
    {
      String warnings = "Before creating this job, please review the following warnings:\n\n";

      if (VehicleID < 1 && rbAuto.Checked)
      {
        warnings += "- No Vehicle assigned to this auto job.\n";
      }
      if (((int)cmbPayment.SelectedValue == 2 || (int)cmbPayment.SelectedValue == 3) && //2 = Insurance, 3 = Accounts
        ((int)cmbInsurance.SelectedValue == -1 || txtAccountName.Text == "" || txtAccountNo.Text == ""))
      {
        warnings += "- Incomplete insurance/account details\n";
      }
      if (rbOnsite.Checked && ((int)cmbArea.SelectedValue == -1 || txtAddress.Text == ""))
      {
        warnings += "- Incomplete address information for onsite job.\n";
      }
      if (chkBooking.Checked)
      {
        warnings += "- No set booking date\n";
      }

      warnings += "\nAre you sure you want to continue?";

      if (warnings != "Before creating this job, please review the following warnings:\n\n\nAre you sure you want to continue?")
      {
        bool save = DataAccess.ShowMessage(warnings, "Warning", true);
        if (!save) return;
      }

      int milage = 0;
      if (chkMilage.Checked) milage = 1;

      DateTime bookdate = DateTime.Parse(dtpBookDate.Value.ToString("yyyy-MM-dd ") + dtpBookTime.Value.ToString("HH:mm:ss"));
      if (chkBooking.Checked) bookdate = DateTime.Parse("1998-01-01 0:00:00");

      DataAccess.JobManage(0, (int)cmbType.SelectedValue, CustomerID, (int)cmbPayment.SelectedValue, VehicleID, 9,
       (int)cmbArea.SelectedValue, (int)cmbInsurance.SelectedValue, 0, txtAddress.Text,
       bookdate, txtNote.Text, 0, 0, txtReference.Text,
       txtAccountName.Text, txtAccountNo.Text, milage);

      DataAccess.ShowMessage("Job saved successfully");
      int maxID = DataAccess.ExecuteScalarInt("SELECT MAX(JobID) FROM Job;");
      FormManagement.ShowChildForm(new JobEdit(maxID));
      this.Close();
    }
    private void btnSave_Click(object sender, EventArgs e)
    {
      SaveJob();
    }

    private void button2_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private void EnableRadioOnPanel(bool enabled)
    {
      rbCustomer.Enabled = enabled;
      rbType.Enabled = enabled;
      if (rbAuto.Checked) {
        rbVehicle.Enabled = enabled;
      }
      rbAccount.Enabled = enabled;
      rbOnsitePanel.Enabled = enabled;
      rbBooking.Enabled = enabled;
      rbReference.Enabled = enabled;
    }

    private void btnTimeBack_Click(object sender, EventArgs e)
    {
      if (timepos > 0) timepos--;
      dtpBookTime.Value = DateTime.Parse(times[timepos]);
    }

    private void btnTimeForward_Click(object sender, EventArgs e)
    {
      if (timepos < times.Length - 1) timepos++;
      dtpBookTime.Value = DateTime.Parse(times[timepos]);
    }

    private void tsSave_Click_1(object sender, EventArgs e)
    {
      SaveJob();
    }

    private void dgvVehicle_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      if (dgvVehicle.SelectedRows.Count == 1 && dgvVehicle.SelectedRows[0].Index > -1)
      {
        try
        {
          SearchVehicle form = new SearchVehicle((int)dgvVehicle.SelectedRows[0].Cells["chID"].Value, 2);
          FormManagement.ShowDialogForm(form);
          if (VehicleID > 0)
          {
            LoadVehicleFromID();
          }
          else
          {
            txtVehicle.Text = "";
          }
          ValidateVehicle();
        }
        catch (Exception ex)
        {
          DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.ToString(), this.Name,
                  System.Reflection.MethodBase.GetCurrentMethod().Name, "");
        }
      }
      
    }
  }
}
