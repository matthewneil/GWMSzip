﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace workshop_orders
{
    /*This is a form is view all the created jobjobs in the database*
     * This data can a queried and filter so you can only display the job you want to see*/
    public partial class ChangeJobPart : Form
    {
        private bool update = false;
        private String pID;
        private String objID;
        private String jobNo;

        /*A method to connect to the GoreGlassJob database*/
        public MySqlConnection connectMySql()
        {
            string connStr = "server=10.1.1.70;user=admin;database=GWGJOBS;port=3306;password=aQuack1nce4^";
            using (MySqlConnection conn = new MySqlConnection(GWMS.connStr))
            {
                try
                {
                    Console.WriteLine("Connecting to MySQL...");
                    
                    return conn;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error connecting to server, please contact the administrator.", "Error!");
                    return null;
                }

            }
        }

        /*Initializes the component and add the database varible names to the 'WHERE' box, used for querying the job database job*/
        public ChangeJobPart()
        {
            InitializeComponent();
            partTypeCombo.Items.Add("WINDSCREEN");
            partTypeCombo.Items.Add("REARSCREEN");
            partTypeCombo.Items.Add("SIDEGLASS-LHF");
            partTypeCombo.Items.Add("SIDEGLASS-RHF");
            partTypeCombo.Items.Add("SIDEGLASS-LHR");
            partTypeCombo.Items.Add("SIDEGLASS-RHR");
            partTypeCombo.Items.Add("SIDEGLASS-LHF-1/4");
            partTypeCombo.Items.Add("SIDEGLASS-RHF-1/4");
            partTypeCombo.Items.Add("SIDEGLASS-LHR-1/4");
            partTypeCombo.Items.Add("SIDEGLASS-RHR-1/4");
            partTypeCombo.Items.Add("CANOPY-REAR");
            partTypeCombo.Items.Add("CANOPY-SIDE-L");
            partTypeCombo.Items.Add("CANOPY-SIDE-R");

            statusCombo.Items.Add("ON-ORDER");
            statusCombo.Items.Add("NOT-ORDERED");

            statusCombo.Items.Add("IN-STOCK");

            statusCombo.Items.Add("DAMAGED");
            statusCombo.Items.Add("INCORRECT");

            statusCombo.Items.Add("RETURNED");
            statusCombo.Items.Add("TO-BE-RETURNED");

            statusCombo.Items.Add("COMPLETE");

            statusCombo.Items.Add("MISSING");
            statusCombo.Items.Add("DELETED");


            String sql = String.Format("SELECT pCode, pAltCode, pNagCode FROM part;");
            using (MySqlConnection conn = connectMySql())
            {
                try
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    using (MySqlDataReader rdr = cmd.ExecuteReader())
                    {


                        while (rdr.Read())
                        {
                            altCodeText.AutoCompleteCustomSource.Add(rdr["pAltCode"].ToString());
                            partCodeText.AutoCompleteCustomSource.Add(rdr["pCode"].ToString());
                            nagCodeText.AutoCompleteCustomSource.Add(rdr["pNagCode"].ToString());
                        }
                    }
                } catch (Exception ex)
                {

                }
                conn.Close();
            }
            reset_all_fields();
        }

        public ChangeJobPart(int objID)
        {
            InitializeComponent();


        
            partTypeCombo.Items.Add("REARSCREEN");
            partTypeCombo.Items.Add("SIDEGLASS-LHF");
            partTypeCombo.Items.Add("SIDEGLASS-RHF");
            partTypeCombo.Items.Add("SIDEGLASS-LHR");
            partTypeCombo.Items.Add("SIDEGLASS-RHR");
            partTypeCombo.Items.Add("SIDEGLASS-LHF-1/4");
            partTypeCombo.Items.Add("SIDEGLASS-RHF-1/4");
            partTypeCombo.Items.Add("SIDEGLASS-LHR-1/4");
            partTypeCombo.Items.Add("SIDEGLASS-RHR-1/4");
            partTypeCombo.Items.Add("CANOPY-REAR");
            partTypeCombo.Items.Add("CANOPY-SIDE-L");
            partTypeCombo.Items.Add("CANOPY-SIDE-R");

            statusCombo.Items.Add("ON-ORDER");
            statusCombo.Items.Add("NOT-ORDERED");

            statusCombo.Items.Add("IN-STOCK");

            statusCombo.Items.Add("DAMAGED");
            statusCombo.Items.Add("INCORRECT");

            statusCombo.Items.Add("RETURNED");
            statusCombo.Items.Add("TO-BE-RETURNED");

            statusCombo.Items.Add("COMPLETE");

            statusCombo.Items.Add("MISSING");
            statusCombo.Items.Add("DELETED");

            String sql = String.Format("SELECT * FROM jobPart INNER JOIN (SELECT objID, MAX(date) AS maxdate FROM jobPart GROUP BY objID) jP " +
                "ON date = maxdate AND jP.objID = jobPart.objID INNER JOIN part ON part.pID = jobPart.pID WHERE jobPart.objID = {0};", objID);
            using (MySqlConnection conn = connectMySql())
            {
                try
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    using (MySqlDataReader rdr = cmd.ExecuteReader())
                    {

                        rdr.Read();

                        partTypeCombo.Text = rdr["pType"].ToString();
                        partCodeText.Text = rdr["pCode"].ToString();
                        altCodeText.Text = rdr["pAltCode"].ToString();
                        nagCodeText.Text = rdr["pNagCode"].ToString();

                        jobLabel.Text = jobLabel.Text + rdr["pAllocated"].ToString();

                        statusCombo.Text = rdr["pState"].ToString();

                        this.jobNo = rdr["pAllocated"].ToString();

                        if(this.jobNo == "")
                        {
                            jobNo = "NULL";
                        }
                        this.objID = rdr["objID"].ToString();
                        this.pID = rdr["pID"].ToString();

                        while (rdr.Read())
                        {
                            altCodeText.AutoCompleteCustomSource.Add(rdr["pAltCode"].ToString());
                            partCodeText.AutoCompleteCustomSource.Add(rdr["pCode"].ToString());
                            nagCodeText.AutoCompleteCustomSource.Add(rdr["pNagCode"].ToString());
                        }
                    }
                }catch (Exception ex)
                {

                }

                conn.Close();
            }
            //partTypeCombo.Enabled = false;
            //partCodeText.Enabled = false;

            update = true;
        }

        /*Check if String entered into function is a number
         */
        public bool IsNumber(String number)
        {
            return number.All(char.IsNumber);
        }

        /*reset_all_fields method
         * Resets all the fields in the form to empty
         * Also refreshes the Today's orders' box to reflect any changes that may have happened to the database.
         */
        private void reset_all_fields()
        {
        }

        public void updateButton_Click()
        {
            
        }

        /**methods below are unused*/
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void executeSQL(string sql, bool errors)
        {
            
            try
            {
                using(MySqlConnection conn = connectMySql())
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    cmd.ExecuteReader();
                    conn.Close();
                }            
                
            }
            catch (Exception ex)
            {
                if (errors)
                {
                    MessageBox.Show("Error communicating with database. If this problem persists, please contact the administrator.\n" + ex.ToString());
                    Console.WriteLine(ex.ToString());
                }
                
            }
        }

        private String quote(string x)
        {
            return "'" + x + "'";
        }



        private void partButton_Click(object sender, EventArgs e)
        {
            String objID = this.objID;
            String pID = this.pID;
            String newID= "";
            
            if (dealloCheck.Checked)
            {
                jobNo = "NULL";
            }

            String jobNo2 = jobNo;

            if (reorderCheck.Checked)
            {
                String maxID = "SELECT MAX(objID) AS max FROM jobPart;";
                using (MySqlConnection conn = connectMySql())
                {
                    try
                    {
                        conn.Open();
                        MySqlCommand cmd = new MySqlCommand(maxID, conn);
                        using (MySqlDataReader rdr = cmd.ExecuteReader())
                        {
                            rdr.Read();
                            newID = (int.Parse(rdr["max"].ToString()) + 1).ToString();
                        }
                    } catch (Exception ex)
                    {

                    }
                    conn.Close();
                }
            }

            String state = statusCombo.Text;

            String active = "true";
            String reason = "Updated Using the Stock Update Form.";
            String info;

            if (infoText.Text != "")
            {
                info = quote(infoText.Text);
            } 
            else
            {
                info = "NULL";
            }

            String sql = String.Format("INSERT INTO jobPart VALUES ({0}, '{1}', {2}, {3}, '{4}', {5}, '{6}', '{7}', {8}, null, null, null, null);",
                objID, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), pID, jobNo, state, active, GWMS.StaffID, reason, info);

            if (reorderCheck.Checked)
            {
                sql += String.Format("INSERT INTO jobPart VALUES ({0}, '{1}', {2}, {3}, '{4}', {5}, '{6}', '{7}', {8}, null, null, null, null);",
                newID, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), pID, jobNo2, "NOT-ORDERED", active, GWMS.StaffID, "Reordered After Part was Damaged.", "NULL");
            }

            executeSQL(sql, true);

            this.Close();
        }

        private void ViewJobForm_Resize(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void altCodeText_TextChanged(object sender, EventArgs e)
        {
            if (altCodeText.AutoCompleteCustomSource.Contains(altCodeText.Text))
            {
                altCodeText.Text.Trim();
                String code = altCodeText.Text;
                using (MySqlConnection conn = connectMySql())
                {
                    try
                    {
                        conn.Open();
                        string sql = String.Format("SELECT * FROM part WHERE pAltCode = '{0}';", code);
                        MySqlCommand cmd = new MySqlCommand(sql, conn);
                        using (MySqlDataReader rdr = cmd.ExecuteReader())
                        {
                            rdr.Read();
                            nagCodeText.Text = rdr["pNagCode"].ToString();
                            partCodeText.Text = rdr["pCode"].ToString();
                            partTypeCombo.Text = rdr["pType"].ToString();
                            //this.pID = int.Parse(rdr["pID"].ToString());
                            update = true;
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.ToString());
                        MessageBox.Show("Issue. Please Contact Administrator.\nError Information:\n" + ex.ToString());
                        update = false;
                        //this.pID = 0;
                    }
                    conn.Close();
                }
            }
            else { 
                update = false;
                //this.pID = 0;
                //nagCodeText.Text = "";
                //partCodeText.Text = "";
                //partTypeCombo.Text = "";
            }
        }

        private void statusCombo_TextChanged(object sender, EventArgs e)
        {
            if(statusCombo.Text == "DAMAGED" || statusCombo.Text == "MISSING")
            {
                reorderCheck.Enabled = true;
                reorderCheck.Checked = true;
                dealloCheck.Checked = true;
            }
            else if (statusCombo.Text == "INCORRECT" || statusCombo.Text == "DELETED")
            {
                dealloCheck.Checked = true;
                reorderCheck.Enabled = false;
                reorderCheck.Checked = false;
            }
            else
            {
                reorderCheck.Enabled = false;
                reorderCheck.Checked = false;
                dealloCheck.Checked = false;
            }
        }

        private void statusCombo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
