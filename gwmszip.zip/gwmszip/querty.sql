
SELECT * FROm vwOurnewquerey  WHERE CostItem IN (SELECT CostItemID FROM JobItem WHERE Status "ISNOTORDERED" GROUP BY CostItemID)