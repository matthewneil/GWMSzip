﻿using System;
using System.IO;
using System.Windows.Forms;

namespace workshop_orders
{
    partial class AddPartForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.partButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.partCodeText = new System.Windows.Forms.TextBox();
            this.partTypeCombo = new System.Windows.Forms.ComboBox();
            this.altCodeText = new System.Windows.Forms.TextBox();
            this.quantity = new System.Windows.Forms.NumericUpDown();
            this.nagCodeText = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.allocateCheck = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.quanLabel = new System.Windows.Forms.Label();
            this.infoText = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.buyText = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.locationCombo = new System.Windows.Forms.ComboBox();
            this.indexCombo = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.sellText = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.quantity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // partButton
            // 
            this.partButton.BackColor = System.Drawing.Color.White;
            this.partButton.Location = new System.Drawing.Point(383, 327);
            this.partButton.Name = "partButton";
            this.partButton.Size = new System.Drawing.Size(177, 30);
            this.partButton.TabIndex = 6;
            this.partButton.Text = "Add Product(s)";
            this.partButton.UseVisualStyleBackColor = false;
            this.partButton.Click += new System.EventHandler(this.partButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 20);
            this.label1.TabIndex = 36;
            this.label1.Text = "Part Type";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(251, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(165, 20);
            this.label2.TabIndex = 37;
            this.label2.Text = "Eurocode (New Code)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(214, 285);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 20);
            this.label3.TabIndex = 38;
            this.label3.Text = "Quantity";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(251, 15);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(160, 20);
            this.label4.TabIndex = 39;
            this.label4.Text = "Part Code (Old Code)";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // partCodeText
            // 
            this.partCodeText.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.partCodeText.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.partCodeText.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.partCodeText.Location = new System.Drawing.Point(255, 109);
            this.partCodeText.Name = "partCodeText";
            this.partCodeText.Size = new System.Drawing.Size(305, 26);
            this.partCodeText.TabIndex = 2;
            // 
            // partTypeCombo
            // 
            this.partTypeCombo.FormattingEnabled = true;
            this.partTypeCombo.Location = new System.Drawing.Point(21, 38);
            this.partTypeCombo.Name = "partTypeCombo";
            this.partTypeCombo.Size = new System.Drawing.Size(212, 28);
            this.partTypeCombo.TabIndex = 1;
            // 
            // altCodeText
            // 
            this.altCodeText.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.altCodeText.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.altCodeText.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.altCodeText.Location = new System.Drawing.Point(255, 38);
            this.altCodeText.MaxLength = 6;
            this.altCodeText.Name = "altCodeText";
            this.altCodeText.Size = new System.Drawing.Size(305, 26);
            this.altCodeText.TabIndex = 4;
            // 
            // quantity
            // 
            this.quantity.Location = new System.Drawing.Point(218, 308);
            this.quantity.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.quantity.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            -2147483648});
            this.quantity.Name = "quantity";
            this.quantity.Size = new System.Drawing.Size(64, 26);
            this.quantity.TabIndex = 5;
            this.quantity.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nagCodeText
            // 
            this.nagCodeText.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.nagCodeText.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.nagCodeText.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.nagCodeText.Location = new System.Drawing.Point(21, 109);
            this.nagCodeText.MaxLength = 20;
            this.nagCodeText.Name = "nagCodeText";
            this.nagCodeText.Size = new System.Drawing.Size(212, 26);
            this.nagCodeText.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 86);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 20);
            this.label5.TabIndex = 44;
            this.label5.Text = "Nags Code";
            // 
            // allocateCheck
            // 
            this.allocateCheck.AutoSize = true;
            this.allocateCheck.Location = new System.Drawing.Point(383, 295);
            this.allocateCheck.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.allocateCheck.Name = "allocateCheck";
            this.allocateCheck.Size = new System.Drawing.Size(171, 24);
            this.allocateCheck.TabIndex = 51;
            this.allocateCheck.Text = "Auto Allocate to Job";
            this.allocateCheck.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(19, 345);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(140, 20);
            this.label6.TabIndex = 52;
            this.label6.Text = "Currently In-Stock:";
            this.label6.Visible = false;
            // 
            // quanLabel
            // 
            this.quanLabel.AutoSize = true;
            this.quanLabel.Location = new System.Drawing.Point(161, 345);
            this.quanLabel.Name = "quanLabel";
            this.quanLabel.Size = new System.Drawing.Size(18, 20);
            this.quanLabel.TabIndex = 53;
            this.quanLabel.Text = "0";
            this.quanLabel.Visible = false;
            this.quanLabel.Click += new System.EventHandler(this.quanLabel_Click);
            // 
            // infoText
            // 
            this.infoText.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.infoText.Location = new System.Drawing.Point(20, 182);
            this.infoText.MaxLength = 150;
            this.infoText.Name = "infoText";
            this.infoText.Size = new System.Drawing.Size(540, 26);
            this.infoText.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(17, 159);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 20);
            this.label7.TabIndex = 55;
            this.label7.Text = "Comments";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 370);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(785, 292);
            this.dataGridView1.TabIndex = 56;
            this.dataGridView1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            // 
            // buyText
            // 
            this.buyText.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.buyText.Location = new System.Drawing.Point(20, 243);
            this.buyText.MaxLength = 150;
            this.buyText.Name = "buyText";
            this.buyText.Size = new System.Drawing.Size(159, 26);
            this.buyText.TabIndex = 57;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(19, 220);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(75, 20);
            this.label8.TabIndex = 58;
            this.label8.Text = "Buy Price";
            // 
            // locationCombo
            // 
            this.locationCombo.FormattingEnabled = true;
            this.locationCombo.Location = new System.Drawing.Point(218, 241);
            this.locationCombo.Name = "locationCombo";
            this.locationCombo.Size = new System.Drawing.Size(144, 28);
            this.locationCombo.TabIndex = 59;
            this.locationCombo.TextChanged += new System.EventHandler(this.locationCombo_TextChanged);
            // 
            // indexCombo
            // 
            this.indexCombo.FormattingEnabled = true;
            this.indexCombo.Location = new System.Drawing.Point(368, 241);
            this.indexCombo.Name = "indexCombo";
            this.indexCombo.Size = new System.Drawing.Size(191, 28);
            this.indexCombo.TabIndex = 60;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(368, 220);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 20);
            this.label9.TabIndex = 61;
            this.label9.Text = "Index:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(214, 218);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(74, 20);
            this.label10.TabIndex = 62;
            this.label10.Text = "Location:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(19, 285);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(74, 20);
            this.label11.TabIndex = 64;
            this.label11.Text = "Sell Price";
            // 
            // sellText
            // 
            this.sellText.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.sellText.Location = new System.Drawing.Point(20, 308);
            this.sellText.MaxLength = 150;
            this.sellText.Name = "sellText";
            this.sellText.Size = new System.Drawing.Size(159, 26);
            this.sellText.TabIndex = 63;
            // 
            // AddPartForm
            // 
            this.AcceptButton = this.partButton;
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(810, 677);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.sellText);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.indexCombo);
            this.Controls.Add(this.locationCombo);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.buyText);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.infoText);
            this.Controls.Add(this.quanLabel);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.allocateCheck);
            this.Controls.Add(this.nagCodeText);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.quantity);
            this.Controls.Add(this.altCodeText);
            this.Controls.Add(this.partTypeCombo);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.partCodeText);
            this.Controls.Add(this.partButton);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.MaximizeBox = false;
            this.Name = "AddPartForm";
            this.Text = "BMS - Create Product";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Resize += new System.EventHandler(this.ViewJobForm_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.quantity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Button partButton;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox partCodeText;
        private ComboBox partTypeCombo;
        private TextBox altCodeText;
        private NumericUpDown quantity;
        private TextBox nagCodeText;
        private Label label5;
        private CheckBox allocateCheck;
        private Label label6;
        private Label quanLabel;
        private TextBox infoText;
        private Label label7;
        private DataGridView dataGridView1;
        private TextBox buyText;
        private Label label8;
        private ComboBox locationCombo;
        private ComboBox indexCombo;
        private Label label9;
        private Label label10;
        private Label label11;
        private TextBox sellText;
    }
}

