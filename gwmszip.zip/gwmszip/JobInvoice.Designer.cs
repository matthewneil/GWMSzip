﻿using System;
using System.Windows.Forms;

namespace workshop_orders
{
    partial class JobInvoice
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
      this.txtInvoiceNo = new System.Windows.Forms.TextBox();
      this.surnameLabel = new System.Windows.Forms.Label();
      this.phone2Label = new System.Windows.Forms.Label();
      this.gbInvoice = new System.Windows.Forms.GroupBox();
      this.nudAmount = new System.Windows.Forms.NumericUpDown();
      this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
      this.toolStrip1 = new System.Windows.Forms.ToolStrip();
      this.tsBack = new System.Windows.Forms.ToolStripButton();
      this.tsSave = new System.Windows.Forms.ToolStripButton();
      this.gbInvoice.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.nudAmount)).BeginInit();
      this.toolStrip1.SuspendLayout();
      this.SuspendLayout();
      // 
      // txtInvoiceNo
      // 
      this.txtInvoiceNo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
      this.txtInvoiceNo.Location = new System.Drawing.Point(123, 33);
      this.txtInvoiceNo.Margin = new System.Windows.Forms.Padding(6);
      this.txtInvoiceNo.MaxLength = 6;
      this.txtInvoiceNo.Name = "txtInvoiceNo";
      this.txtInvoiceNo.Size = new System.Drawing.Size(174, 26);
      this.txtInvoiceNo.TabIndex = 2;
      // 
      // surnameLabel
      // 
      this.surnameLabel.AutoSize = true;
      this.surnameLabel.Location = new System.Drawing.Point(24, 36);
      this.surnameLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
      this.surnameLabel.Name = "surnameLabel";
      this.surnameLabel.Size = new System.Drawing.Size(87, 20);
      this.surnameLabel.TabIndex = 24;
      this.surnameLabel.Text = "Invoice No:";
      // 
      // phone2Label
      // 
      this.phone2Label.AutoSize = true;
      this.phone2Label.Location = new System.Drawing.Point(42, 76);
      this.phone2Label.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
      this.phone2Label.Name = "phone2Label";
      this.phone2Label.Size = new System.Drawing.Size(69, 20);
      this.phone2Label.TabIndex = 26;
      this.phone2Label.Text = "Amount:";
      // 
      // gbInvoice
      // 
      this.gbInvoice.Controls.Add(this.nudAmount);
      this.gbInvoice.Controls.Add(this.surnameLabel);
      this.gbInvoice.Controls.Add(this.txtInvoiceNo);
      this.gbInvoice.Controls.Add(this.phone2Label);
      this.gbInvoice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbInvoice.Location = new System.Drawing.Point(12, 47);
      this.gbInvoice.Name = "gbInvoice";
      this.gbInvoice.Size = new System.Drawing.Size(322, 117);
      this.gbInvoice.TabIndex = 30;
      this.gbInvoice.TabStop = false;
      this.gbInvoice.Text = "Invoice Details";
      // 
      // nudAmount
      // 
      this.nudAmount.DecimalPlaces = 2;
      this.nudAmount.Location = new System.Drawing.Point(123, 74);
      this.nudAmount.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
      this.nudAmount.Name = "nudAmount";
      this.nudAmount.Size = new System.Drawing.Size(174, 26);
      this.nudAmount.TabIndex = 28;
      // 
      // openFileDialog1
      // 
      this.openFileDialog1.DefaultExt = "pdf";
      this.openFileDialog1.InitialDirectory = "\\\\SERVER\\C\\INVOICES";
      this.openFileDialog1.Title = "Find Invoice PDF File";
      // 
      // toolStrip1
      // 
      this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsBack,
            this.tsSave});
      this.toolStrip1.Location = new System.Drawing.Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new System.Drawing.Size(353, 39);
      this.toolStrip1.TabIndex = 31;
      this.toolStrip1.Text = "toolStrip1";
      // 
      // tsBack
      // 
      this.tsBack.Image = global::workshop_orders.Properties.Resources.back;
      this.tsBack.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsBack.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsBack.Name = "tsBack";
      this.tsBack.Size = new System.Drawing.Size(68, 36);
      this.tsBack.Text = "Back";
      this.tsBack.Click += new System.EventHandler(this.tsBack_Click);
      // 
      // tsSave
      // 
      this.tsSave.Image = global::workshop_orders.Properties.Resources.save;
      this.tsSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsSave.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsSave.Name = "tsSave";
      this.tsSave.Size = new System.Drawing.Size(67, 36);
      this.tsSave.Text = "Save";
      this.tsSave.Click += new System.EventHandler(this.tsSave_Click);
      // 
      // JobInvoice
      // 
      this.AllowDrop = true;
      this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.AutoScroll = true;
      this.BackColor = System.Drawing.Color.White;
      this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
      this.ClientSize = new System.Drawing.Size(353, 179);
      this.Controls.Add(this.toolStrip1);
      this.Controls.Add(this.gbInvoice);
      this.Cursor = System.Windows.Forms.Cursors.Default;
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.Margin = new System.Windows.Forms.Padding(6);
      this.MaximizeBox = false;
      this.Name = "JobInvoice";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
      this.Text = "Edit Invoice";
      this.gbInvoice.ResumeLayout(false);
      this.gbInvoice.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.nudAmount)).EndInit();
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

        }

        #endregion
        private TextBox txtInvoiceNo;
        private Label surnameLabel;
        private Label phone2Label;
        private GroupBox gbInvoice;
        private OpenFileDialog openFileDialog1;
        private NumericUpDown nudAmount;
    private ToolStrip toolStrip1;
    private ToolStripButton tsBack;
    private ToolStripButton tsSave;
  }
}

