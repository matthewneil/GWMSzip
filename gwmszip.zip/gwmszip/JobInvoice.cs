﻿
using System;
using System.Data;
using System.Windows.Forms;

namespace workshop_orders
{
  public partial class JobInvoice : Form
  {
    private int invoiceID = 0;
    private int jobID = 0;
    private String oldInvoiceNo = "";

    public JobInvoice(int invoiceID, int jobID) //Update Invoice
    {

      InitializeComponent();

      if (invoiceID == 0)
      {
        this.Text = "New Invoice";
      }

      this.invoiceID = invoiceID;
      this.jobID = jobID;
      LoadInvoiceData();
      DataAccess.FormState(this.AccessibilityObject.Name, tsSave);
    }


    private void LoadInvoiceData()
    {
      if (invoiceID > 0)
      {
        DataTable dt = DataAccess.ExecuteDataTable("SELECT * FROM invoice WHERE InvoiceID = " + invoiceID);
        txtInvoiceNo.Text = dt.Rows[0]["invNo"].ToString();
        nudAmount.Text = dt.Rows[0]["invPrice"].ToString();
        oldInvoiceNo = dt.Rows[0]["invNo"].ToString();
      }
    }

    private void tsBack_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private void tsSave_Click(object sender, EventArgs e)
    {
      SaveInvoice();

    }

    private void SaveInvoice()
    {
      decimal amount = nudAmount.Value;

      String errors = "Unable to create/update invoice due to the following issues:\n\n";

      /* Check if invoice number has already been used.
      if (txtInvoiceNo.Text.Trim() != "" &&  txtInvoiceNo.Text.Trim() != oldInvoiceNo) {
        DataTable dtInvoiceCheck = DataAccess.ExecuteDataTable("SELECT * FROM Invoice WHERE invNo = " + txtInvoiceNo.Text);
        if (dtInvoiceCheck != null && dtInvoiceCheck.Rows.Count > 0)
        {
          errors += " - This Invoice Number is already in use in this system.\n";
          DataAccess.ShowMessage(errors);
          return;
        }
      }*/

      if(txtInvoiceNo.Text.Trim() == "")
      {
        errors += "- Invoice Number must not be empty.\n";
      }

      if (!DataAccess.IsNumeric(txtInvoiceNo.Text))
      {
        errors += "- Invoice Number is not a valid number.\n";
      }

      if (errors != "Unable to create/update invoice due to the following issues:\n\n")
      {
        DataAccess.ShowMessage(errors);
        return;
      }

      try
      {
        DataAccess.InvoiceManage(invoiceID, jobID, int.Parse(txtInvoiceNo.Text.Trim()), amount);
      } catch(Exception ex)
      {
        DataAccess.ShowMessage("An error occured while saving this invoice. Please contact the administrator");
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                  System.Reflection.MethodBase.GetCurrentMethod().Name, "");
        return;
      }

      DataAccess.ShowMessage("Invoice saved successfully");
      this.Close();
    }
  }
}
