﻿namespace workshop_orders
{
  partial class DisplayMessage
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.lblMessage = new System.Windows.Forms.Label();
      this.btnOkay = new System.Windows.Forms.Button();
      this.panel1 = new System.Windows.Forms.Panel();
      this.btnYes = new System.Windows.Forms.Button();
      this.pnlSide = new System.Windows.Forms.Panel();
      this.panel1.SuspendLayout();
      this.SuspendLayout();
      // 
      // lblMessage
      // 
      this.lblMessage.AutoSize = true;
      this.lblMessage.Dock = System.Windows.Forms.DockStyle.Fill;
      this.lblMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblMessage.Location = new System.Drawing.Point(65, 0);
      this.lblMessage.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.lblMessage.MaximumSize = new System.Drawing.Size(1000, 900);
      this.lblMessage.Name = "lblMessage";
      this.lblMessage.Padding = new System.Windows.Forms.Padding(10, 20, 20, 30);
      this.lblMessage.Size = new System.Drawing.Size(99, 68);
      this.lblMessage.TabIndex = 0;
      this.lblMessage.Text = "Message";
      this.lblMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // btnOkay
      // 
      this.btnOkay.Dock = System.Windows.Forms.DockStyle.Right;
      this.btnOkay.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnOkay.Location = new System.Drawing.Point(77, 9);
      this.btnOkay.Margin = new System.Windows.Forms.Padding(4);
      this.btnOkay.Name = "btnOkay";
      this.btnOkay.Size = new System.Drawing.Size(69, 31);
      this.btnOkay.TabIndex = 1;
      this.btnOkay.Text = "Ok";
      this.btnOkay.UseVisualStyleBackColor = true;
      this.btnOkay.Click += new System.EventHandler(this.btnOkay_Click);
      // 
      // panel1
      // 
      this.panel1.BackColor = System.Drawing.SystemColors.Control;
      this.panel1.Controls.Add(this.btnYes);
      this.panel1.Controls.Add(this.btnOkay);
      this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
      this.panel1.Location = new System.Drawing.Point(0, 72);
      this.panel1.Margin = new System.Windows.Forms.Padding(4, 10, 4, 4);
      this.panel1.Name = "panel1";
      this.panel1.Padding = new System.Windows.Forms.Padding(10, 9, 10, 9);
      this.panel1.Size = new System.Drawing.Size(156, 49);
      this.panel1.TabIndex = 2;
      // 
      // btnYes
      // 
      this.btnYes.Dock = System.Windows.Forms.DockStyle.Right;
      this.btnYes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnYes.Location = new System.Drawing.Point(8, 9);
      this.btnYes.Margin = new System.Windows.Forms.Padding(4);
      this.btnYes.Name = "btnYes";
      this.btnYes.Size = new System.Drawing.Size(69, 31);
      this.btnYes.TabIndex = 2;
      this.btnYes.Text = "Yes";
      this.btnYes.UseVisualStyleBackColor = true;
      this.btnYes.Visible = false;
      this.btnYes.Click += new System.EventHandler(this.btnYes_Click);
      // 
      // pnlSide
      // 
      this.pnlSide.Dock = System.Windows.Forms.DockStyle.Left;
      this.pnlSide.Location = new System.Drawing.Point(0, 0);
      this.pnlSide.Name = "pnlSide";
      this.pnlSide.Padding = new System.Windows.Forms.Padding(20, 10, 5, 10);
      this.pnlSide.Size = new System.Drawing.Size(65, 72);
      this.pnlSide.TabIndex = 4;
      // 
      // DisplayMessage
      // 
      this.AcceptButton = this.btnOkay;
      this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.AutoSize = true;
      this.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.ClientSize = new System.Drawing.Size(156, 121);
      this.Controls.Add(this.lblMessage);
      this.Controls.Add(this.pnlSide);
      this.Controls.Add(this.panel1);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
      this.ImeMode = System.Windows.Forms.ImeMode.Disable;
      this.Margin = new System.Windows.Forms.Padding(4);
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = "DisplayMessage";
      this.ShowIcon = false;
      this.ShowInTaskbar = false;
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
      this.panel1.ResumeLayout(false);
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Label lblMessage;
    private System.Windows.Forms.Button btnOkay;
    private System.Windows.Forms.Panel panel1;
    private System.Windows.Forms.Panel pnlSide;
    private System.Windows.Forms.Button btnYes;
  }
}