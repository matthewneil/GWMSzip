﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workshop_orders
{
	public partial class Orders : Form
	{
    string fsFilter = "";
    int fiOrderNo = 0;
    bool fbPageLoad = false;
    public Orders()
		{
			InitializeComponent();
		}
    private void Orders_Load(object sender, EventArgs e)
    {
      fbPageLoad = false;
      dtpEndDate.Value = System.DateTime.Today.AddDays(1);
      DataAccess.FilterPanel(true, scMain, scData);
      pnlHeader.Left = GWMS.HeaderPanelPosition(pnlHeader, this);
      GetSuppliers();
      GetStaff();
      GetOrderType();
      LoadData("");
      fbPageLoad = true;
    }

    
    private void GetSuppliers()
    {
      DataTable dt = DataAccess.ExecuteDataTable("SELECT SupplierID AS 'datafield', supName AS 'textfield' FROM Supplier WHERE supDisabled = 0 ORDER BY supName");
      DataAccess.AddSelect(dt);
      cmbSupplier.DataSource = dt;
    }
    private void GetOrderType()
    {
      DataTable dt = DataAccess.ExecuteDataTable("SELECT OrderType AS 'datafield', OrderType AS 'textfield' FROM OrderType ORDER BY otSort");
      DataAccess.AddSelect(dt);
      cmbType.DataSource = dt;
    }
    private void GetStaff()
    {
      DataTable dt = DataAccess.ExecuteDataTable("SELECT staffid as datafield, StaffFullName as textfield FROM staff WHERE StaffActive = 1 AND StaffID > 0 ORDER BY StaffFullName;");
			DataAccess.AddSelect(dt);
      cmbStaff.DataSource = dt;
    }
    public void LoadData(string sFilter)
    {
      string sSQL = "";
      this.Cursor = Cursors.WaitCursor;
      try
      {
        dgvData.Rows.Clear();
        fsFilter = sFilter;
        sSQL = "SELECT OrderNo, SupplierName, ordDate, ordDateRequired, FullInternalID, ordReference, ordInstructions, StaffName, ordType, SupplierID " +
               "FROM vworder " +
               "WHERE OrderNo > 0 " +
               "AND ordDate >='" + String.Format(dtpStartDate.Value.ToString(), "yyyy.MM.dd") + "' " +
               "AND ordDate <='" + String.Format(dtpEndDate.Value.ToString(), "yyyy.MM.dd") + "' " + sFilter + " " +
               "ORDER BY OrderNo DESC";

        DataTable dt = DataAccess.ExecuteDataTable(sSQL);
        dgvData.AllowUserToAddRows = true;
        foreach (DataRow row in dt.Rows)
        {
          DataGridViewRow drow = (DataGridViewRow)dgvData.Rows[0].Clone();
          drow.Cells[0].Value = row["OrderNo"];
          drow.Cells[1].Value = row["SupplierName"];
          drow.Cells[2].Value = row["ordDate"];
          drow.Cells[3].Value = row["ordDateRequired"];
          drow.Cells[4].Value = row["FullInternalID"];
          drow.Cells[5].Value = row["ordReference"];
          drow.Cells[6].Value = row["ordInstructions"];
          drow.Cells[7].Value = row["StaffName"];
          drow.Cells[9].Value = row["ordType"];
          dgvData.Rows.Add(drow);
        }
        dgvData.AllowUserToAddRows = false;
        if (dgvData.Rows.Count > 0)
        {
          fiOrderNo = (int) dgvData.Rows[0].Cells[0].Value;
          dgvData.Rows[0].Selected = true;
        }
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name, System.Reflection.MethodBase.GetCurrentMethod().Name, sSQL);
      }
      finally
      {
        this.Cursor = Cursors.Default;
      }
    }
    private void tsClose_Click(object sender, EventArgs e)
		{
			this.Close();
		}
    public void SetFilters()
		{
      if (fbPageLoad == false) { return; }
      string sFilter = "";
      if (cmbSupplier.SelectedIndex > 0) { sFilter += " AND SupplierID = " + cmbSupplier.SelectedValue.ToString(); }
      if (cmbStaff.SelectedIndex > 0) { sFilter += " AND StaffID = " + cmbStaff.SelectedValue.ToString(); }
      if (cmbType.SelectedIndex > 0) { sFilter += " AND ordType = " + cmbType.SelectedValue.ToString(); }
      if (txtOrder.Text.Length > 3 && DataAccess.IsNumeric(txtOrder.Text)) { sFilter += " AND OrderNo = " + int.Parse(txtOrder.Text); }
      if (txtInternalID.Text.Length > 3 && DataAccess.IsNumeric(txtInternalID.Text)) { sFilter += " AND InternalID = " + int.Parse(txtInternalID.Text); }
      LoadData(sFilter);
    }



		private void pbHide_Click(object sender, EventArgs e)
		{
      DataAccess.FilterPanel(false, scMain, scData);
    }
		private void pbShow_Click(object sender, EventArgs e)
		{
      DataAccess.FilterPanel(true, scMain, scData);
    }
    private void cmbSupplier_SelectedIndexChanged(object sender, EventArgs e)
    {
      SetFilters();
    }
    private void cmbStaff_SelectedIndexChanged(object sender, EventArgs e)
		{
      SetFilters();
		}
		private void txtOrder_KeyDown(object sender, KeyEventArgs e)
		{
      if (e.KeyCode == Keys.Enter) { SetFilters(); }
		}
		private void cmbType_SelectedIndexChanged(object sender, EventArgs e)
		{
      SetFilters();
		}

		private void txtInternalID_KeyDown(object sender, KeyEventArgs e)
		{
      if (e.KeyCode == Keys.Enter) { SetFilters(); }
    }
		private void btnReset_Click(object sender, EventArgs e)
		{
      cmbStaff.SelectedIndex = 0;
      cmbSupplier.SelectedIndex = 0;
      cmbType.SelectedIndex = 0;
      txtInternalID.Text = "";
      txtOrder.Text = "";
		}
		private void tsRefresh_Click(object sender, EventArgs e)
		{
      SetFilters();
		}

		private void tsDelete_Click(object sender, EventArgs e)
		{

		}

		private void tsAdd_Click(object sender, EventArgs e)
		{
      OrderDetail(0);
    }
		private void tsEdit_Click(object sender, EventArgs e)
		{
      OrderDetail((int)dgvData.SelectedRows[0].Cells[0].Value);
    }
    private void OrderDetail(int iOrderNo)
		{
      OrderDetails frm = new OrderDetails(this, iOrderNo);
      FormManagement.ShowChildForm(frm, iOrderNo);

    }


	}
}
