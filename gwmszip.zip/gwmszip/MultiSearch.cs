﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace workshop_orders
{
  /*A form for adding a customer to the database, so their details can be retrieved if they were to come back.
   */
  public partial class MultiSearch : Form
  {
    public int quoteNo = -1;
    public int vehicleID = -1;
    private int itemID = -1;
    private bool update = true;
    public static int quantity;
    private int type = 1; // 1 = Item, 2 = Location
    public static BasicQuote frm;

    public MultiSearch(int type)
    {
      this.type = type;
      InitializeComponent();
      LoadItemGroup();
      SearchItems();

      if (type == 2)
      {
        dgvLocation.Visible = true;
        dgvItems.Visible = false;
        Text = "Location Search";
        btnAddItem.Visible = false;
        btnRemoveItem.Visible = false;
        gbItemsAdded.Visible = false;
        //this.Width = 705;
      }
    }

    

    private void CreateJobForm_Load(object sender, EventArgs e)
    {
      
      LoadItemGroup();
      SearchItems();
    }

    private void SearchItems()
    {
      update = true;

      itemID = 0;

      if (type == 1 || type == 3)
      {
        try
        {
          String sql = null;

          this.itemID = 0;

          gbResult.Visible = true;

            String group = cmbField.SelectedValue.ToString();
            if (group == "-1")
            {
              group = "%";
            }


          sql = String.Format("SELECT ic.ItemCostID, igSubGroup, icCode, icDescription, s.quantity, icCost FROM itemcost ic " +
            "INNER JOIN itemgroup ig ON ic.ItemGroupID = ig.ItemGroupID " +
            "LEFT JOIN itemstock s ON ic.ItemCostID = s.ItemCostID " +
            "WHERE icCode LIKE '{0}%' AND ic.ItemCostID > 0 and igSubGroup LIKE '{1}';", txtSearch.Text, group);


          if (sql != null)
          {
            DataTable dt = DataAccess.ExecuteDataTable(sql);
            dgvItems.DataSource = dt;

            int amount = dgvItems.Rows.Count;
            if (amount == 0)
            {
              //DataAccess.ShowMessage("No Items Found. Please change your selection or add new item.");
            }
            else if (amount == 1)
            {
              //searchText.Text = rdr["cSurname"].ToString();
              //LoadCustomer(rdr["cID"].ToString());
            }
          }
        }
        catch (Exception ex)
        {
          MessageBox.Show(ex.ToString());
          DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
        }
      }
      else if (type == 2)
      {
        try
        {
          String sql = null;

          this.itemID = 0;

          gbResult.Visible = true;

          String group;
          try
          {
            group = cmbField.SelectedValue.ToString();
            if (group == "-1")
            {
              group = "%";
            }
          } catch { group = "%";  }

          sql = String.Format("SELECT LocationID, LocationGroup, LocationSubGroup, LocationCode, LocationDescription FROM Location l " +
            "WHERE LocationCode LIKE '{0}%' AND LocationSubGroup LIKE '{1}';", txtSearch.Text, group);


          if (sql != null)
          {
            DataTable dt = DataAccess.ExecuteDataTable(sql);
            dgvLocation.DataSource = dt;

            int amount = dgvLocation.Rows.Count;
            if (amount == 0)
            {
              //DataAccess.ShowMessage("No Location Found. Please change your selection or add a new location.");
            }
            else if (amount == 1)
            {
              //searchText.Text = rdr["cSurname"].ToString();
              //LoadCustomer(rdr["cID"].ToString());
            }
          }
        }
        catch (Exception ex)
        {
          DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
        }
      }

    }

    public void LoadItemGroup()
    {
      if(type == 1 || type == 3)
      {
        DataTable dt = DataAccess.ExecuteDataTable(
        "SELECT igSubGroup AS datafield, igSubGroup AS textfield FROM ItemGroup GROUP BY igSubGroup ORDER BY igDescription");
        DataAccess.AddSelect(dt);
        cmbField.DataSource = dt;
      }
      else if (type == 2)
      {
        DataTable dt = DataAccess.ExecuteDataTable(
        "SELECT LocationSubGroup AS datafield, LocationSubGroup AS textfield FROM Location GROUP BY LocationSubGroup");
        DataAccess.AddSelect(dt);
        cmbField.DataSource = dt;
      }
      
    }

    private void textBox1_TextChanged(object sender, EventArgs e)
    {
      SearchItems();   
    }

    private void toolStripButton1_Click_1(object sender, EventArgs e)
    {
      this.Close();
    }

   

    private void addtoolStripButton_Click(object sender, EventArgs e)
    {
      ItemEdit frm = new ItemEdit(0);
      FormManagement.ShowDialogForm(frm);
    }

    private void saveToolStripButton2_Click(object sender, EventArgs e)
    {
      SaveItems();      
    }

    private void SaveItems()
    {
      if (type == 1)
      {
        foreach (DataGridViewRow row in dgvItemsAdded.Rows)
        {
          int i = 0;
          while (i < (int)row.Cells[4].Value)
          {
            DataAccess.JobItemManage(0, (int)row.Cells[0].Value, quoteNo, 12, 0, 0, -1);
            i++;
          }

        }

        DataAccess.ShowMessage("Items successfully added to job.");
        this.Close();
      }
    }

    private void customerDataGrid_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      AddItem();

    }
    
    private void AddItem()
    {
      if (type == 1)
      {
        if (dgvItems.SelectedRows.Count > 0 && dgvItems.SelectedRows[0].Index > -1)
        {
          Quantity quantityfrm = new Quantity();
          FormManagement.ShowDialogForm(quantityfrm);
        }
      }
      else if (type == 2)
      {
        if (dgvLocation.SelectedRows.Count > 0 && dgvLocation.SelectedRows[0].Index > -1)
        {
          try
          {
            ItemLocation.NewLocationID = (int)dgvLocation.SelectedRows[0].Cells["chLocationID"].Value;
            //locationfrm.LoadNewLocation(dgvItems.SelectedRows[0].Cells["chCode"].Value.ToString(), dgvItems.SelectedRows[0].Cells["chDesc"].Value.ToString(), (decimal)dgvItems.SelectedRows[0].Cells["chCost"].Value, quantity);            
          }
          catch (Exception ex)
          {
            DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
          }
          this.Close();
        }
      }
      else if (type == 3)
      {
        OrderDetails.itemcode = dgvItems.SelectedRows[0].Cells["chCode"].Value.ToString();
        this.Close();
      }

    }

    private void RemoveItem()
    {
      if (dgvItemsAdded.SelectedRows.Count > 0 && dgvItemsAdded.SelectedRows[0].Index > -1)
      {
        dgvItemsAdded.Rows.RemoveAt(dgvItemsAdded.SelectedRows[0].Index);
      }
    }


    private void tsJob_Click(object sender, EventArgs e)
    {

    }

    private void dgvItemsAdded_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      if (dgvItemsAdded.SelectedRows.Count > 0 && dgvItemsAdded.SelectedRows[0].Index > -1)
      {
        ItemEdit frm = new ItemEdit((int)dgvItemsAdded.SelectedRows[0].Cells[0].Value);
        FormManagement.ShowDialogForm(frm);
      }
    }

    private void btnAddItem_Click(object sender, EventArgs e)
    {
      AddItem();
    }

    private void btnRemoveItem_Click(object sender, EventArgs e)
    {
      RemoveItem();
    }

    private void cmbField_SelectedIndexChanged(object sender, EventArgs e)
    {
      SearchItems();
    }

    private void dgvLocation_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      AddItem();
    }
  }
}
