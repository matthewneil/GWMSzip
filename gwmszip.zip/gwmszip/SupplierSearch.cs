﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace workshop_orders
{
  /*A form for adding a customer to the database, so their details can be retrieved if they were to come back.
   */
  public partial class SupplierSearch : Form
  {
    public int quoteNo = 0;
    private int SupplierID = 0;
    private bool update = true;
    private int form = 0; //0 = OrderDetail

    public SupplierSearch(int sID, int form)
    {
      InitializeComponent();
      
      this.SupplierID = sID;
      this.form = form;

      if(form > 0) tsSave.Text = "Select";

      if (sID < 1)
      {
        gbResult.Visible = true;
        gbMainDetails.Visible = false;
      }
      else
      {
        LoadCustomer();
      }

      DataAccess.FormState(this.AccessibilityObject.Name, tsSave);
    }

    private void CreateJobForm_Load(object sender, EventArgs e)
    {

    }

    private void LoadCustomer()
    {
      gbResult.Visible = false;
      gbMainDetails.Visible = true;

      DataTable dt = DataAccess.ExecuteDataTable(String.Format("SELECT * FROM supplier WHERE SupplierID = {0};", SupplierID));
      if(dt.Rows.Count > 0)
      {
        txtName.Text = dt.Rows[0]["SupplierName"].ToString();
        txtCode.Text = dt.Rows[0]["supCode"].ToString();
        txtMobileNo.Text = dt.Rows[0]["supMobile"].ToString();
        txtPhoneNo.Text = dt.Rows[0]["supPhone"].ToString();
        txtEmail.Text = dt.Rows[0]["supEmail"].ToString();

        txtAddress.Text = dt.Rows[0]["supAddress"].ToString();
        txtCity.Text = dt.Rows[0]["supCity"].ToString();
        txtPostcode.Text = dt.Rows[0]["supPostcode"].ToString();

        txtPoBox.Text = dt.Rows[0]["supPOBox"].ToString();
        txtAddress1.Text = dt.Rows[0]["supAddress1"].ToString();
        txtAddress2.Text = dt.Rows[0]["supAddress2"].ToString();
      }
     
    }


    private void textBox1_TextChanged(object sender, EventArgs e)
    {
      SupplierID = 0;
      update = true;
      dgvSupplier.Rows.Clear();
      try
      {
        String sql = null;

        this.SupplierID = 0;
        
        gbResult.Visible = true;
        gbMainDetails.Visible = false;

        switch (cmbField.Text)
        {
          case "Supplier Name":
            sql = String.Format("SELECT * FROM supplier WHERE SupplierName LIKE '{0}%' AND SupplierID > 0;", txtSearch.Text);
            break;
        }

        if (sql != null)
        {
          int amount = 0;
          DataTable dt = DataAccess.ExecuteDataTable(sql);
          foreach (DataRow row in dt.Rows)
          {
            amount++;
            dgvSupplier.Rows.Add(row["SupplierID"].ToString(), row["SupplierName"].ToString(), row["supMobile"].ToString(), row["supAddress"].ToString(), row["supEmail"].ToString());
          }

          if (amount == 0)
          {
            DataAccess.ShowMessage("No Supplier Records Found.\nPlease change your selection or add new supplier.");
          }
          else if (amount == 1)
          {
            //searchText.Text = rdr["cSurname"].ToString();
            //LoadCustomer(rdr["cID"].ToString());
          }
        }
      }
      catch (Exception ex)
      {
        DataAccess.ShowMessage("Error: Couldn't fetch supplier data.");
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                  System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }

    }

    private void toolStripButton1_Click_1(object sender, EventArgs e)
    {
      this.Close();
    }

    private void ClearAllFields()
    {
      txtName.Text = "";
      txtCode.Text = "";
      txtMobileNo.Text = "";
      txtPhoneNo.Text = "";
      txtPoBox.Text = "";
      txtAddress1.Text = "";
      txtAddress2.Text = "";
      txtEmail.Text = "";


      txtAddress.Text = "";
      txtPostcode.Text = "";
      txtCity.Text = "";
      txtPostcode.Text = "";
    }

    private void addtoolStripButton_Click(object sender, EventArgs e)
    {
      gbMainDetails.Visible = true;
      gbResult.Visible = false;
      gbsearch.Enabled = false;

      update = false;
      SupplierID = 0;
      ClearAllFields();
    }

    private void saveToolStripButton2_Click(object sender, EventArgs e)
    {
      SaveCustomer();      
    }

    private void SaveCustomer()
    {
      if (this.SupplierID == 0 && update == true)
      {
        DataAccess.ShowMessage("You haven't selected a Supplier!");
        return;
      }

      String errors = "Unable to save supplier details due to the following issues:\n\n";

      if (txtName.Text == "")
      {
        errors += " - You must enter in a Supplier Name.\n";
      }

      if (txtEmail.Text != "" && !(DataAccess.ValidateEmail(txtEmail.Text)))
      {
        errors += " - Invalid email has been entered.\n";
      }

      if (!(DataAccess.IsNumeric(txtPostcode.Text)))
      {
        errors += " - Postcode isn't a valid number.\n";
      }

      if (errors != "Unable to save supplier details due to the following issues:\n\n")
      {
        DataAccess.ShowMessage(errors);
        return;
      }

      try
      {
        DataAccess.SupplierManage(SupplierID, txtName.Text, txtAddress.Text, txtAddress1.Text, txtAddress2.Text, txtCity.Text, int.Parse(txtPostcode.Text), txtPoBox.Text,
          "", txtPhoneNo.Text, "", txtMobileNo.Text, txtEmail.Text, "", txtCode.Text, 0, -1, "");
      }
      catch (Exception ex)
      {
        DataAccess.ShowMessage("Supplier failed to save, please contact the administrator");
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                  System.Reflection.MethodBase.GetCurrentMethod().Name, "");
        return;
      }

      if(form == 0) DataAccess.ShowMessage("Supplier saved Successfully");
 
      if (!update)
      {
        DataTable dt = DataAccess.ExecuteDataTable("SELECT MAX(SupplierID) AS MaxID FROM supplier");
        SupplierID = (int)dt.Rows[0]["MaxID"];
      }

      if (this.SupplierID > 0)
      {
        if (form == 1)
        {
          //JobEdit.CustomerID = SupplierID;
        }
        this.Close();
      }
      else
      {
        DataAccess.ShowMessage("No Supplier has been selected.");
      }
    }

    private void customerDataGrid_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      if (e.RowIndex >= 0)
      {
        update = true;

        gbResult.Visible = false;
        gbMainDetails.Visible = true;
        //searchText.Enabled = false;
        DataGridViewRow row = this.dgvSupplier.Rows[e.RowIndex];
        this.SupplierID = int.Parse(row.Cells["ID"].Value.ToString());
        LoadCustomer();
      }

    }
  }
}
