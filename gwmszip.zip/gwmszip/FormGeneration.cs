﻿using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using IronPython.Runtime.Operations;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
//using Outlook = Microsoft.Office.Interop.Outlook;
using NReco;
using DocumentFormat.OpenXml.Wordprocessing;

namespace workshop_orders
{
    /*This is a form is view all the created jobjobs in the database*
     * This data can a queried and filter so you can only display the job you want to see*/
    public partial class FormGeneration : Form
    {
        private bool update = false;
        private String pID;
        private String objID;
        private String jobNo;
        private Graphics g;
        private Bitmap bmp;

        /*A method to connect to the GoreGlassJob database*/
        public MySqlConnection connectMySql()
        {
            string connStr = "server=10.1.1.70;user=admin;database=GWGJOBS;port=3306;password=aQuack1nce4^";
            using (MySqlConnection conn = new MySqlConnection(GWMS.connStr))
            {
                try
                {
                    Console.WriteLine("Connecting to MySQL...");
                    
                    return conn;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error connecting to server, please contact the administrator.", "Error!");
                    return null;
                }

            }
        }

        public static Byte[] PdfSharpConvert(String html)
        {
            Byte[] res = null;
            using (MemoryStream ms = new MemoryStream())
            {
                var pdf = TheArtOfDev.HtmlRenderer.PdfSharp.PdfGenerator.GeneratePdf(html, PdfSharp.PageSize.A4);
                pdf.Save(ms);
                res = ms.ToArray();
            }
            return res;
        }

        /*Initializes the component and add the database varible names to the 'WHERE' box, used for querying the job database job*/
        public FormGeneration()
        {
            InitializeComponent();



            String sql = String.Format("SELECT pCode, pAltCode, pNagCode FROM part;");
            using (MySqlConnection conn = connectMySql())
            {
                try
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    using (MySqlDataReader rdr = cmd.ExecuteReader())
                    {
                        while (rdr.Read())
                        {
                            altCodeText.AutoCompleteCustomSource.Add(rdr["pAltCode"].ToString());
                            partCodeText.AutoCompleteCustomSource.Add(rdr["pCode"].ToString());
                        }
                    }
                }
                catch(Exception ex)
                {

                }
                conn.Close();
            }
            reset_all_fields();
        }

        public FormGeneration(int objID)
        {
            
            InitializeComponent();

            String sql = String.Format("SELECT * FROM jobPart INNER JOIN (SELECT objID, MAX(date) AS maxdate FROM jobPart GROUP BY objID) jP " +
                "ON date = maxdate AND jP.objID = jobPart.objID INNER JOIN part ON part.pID = jobPart.pID WHERE jobPart.objID = {0};", objID);
            using (MySqlConnection conn = connectMySql())
            {
                try
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    using (MySqlDataReader rdr = cmd.ExecuteReader())
                    {

                        rdr.Read();

                        typeLabel.Text = "Part Type: " + rdr["pType"].ToString();
                        partCodeText.Text = rdr["pCode"].ToString();
                        altCodeText.Text = rdr["pAltCode"].ToString();

                        contactLabel.Text = "Contact Name: " + GWMS.StaffID;

                        dateTime.Value = DateTime.Today;
                        deliveryDateTime.Value = DateTime.Today;

                        this.jobNo = rdr["pAllocated"].ToString();
                        this.objID = rdr["objID"].ToString();
                        this.pID = rdr["pID"].ToString();

                        g = pictureBox1.CreateGraphics();

                        bmp = new Bitmap(@"\\SERVER\c\BMS\Forms\Screen.png");

                        pictureBox1.Image = bmp;

                        while (rdr.Read())
                        {
                            altCodeText.AutoCompleteCustomSource.Add(rdr["pAltCode"].ToString());
                            partCodeText.AutoCompleteCustomSource.Add(rdr["pCode"].ToString());
                        }
                    }
                }
                catch(Exception ex)
                {

                }
                conn.Close();
            }
            //partTypeCombo.Enabled = false;
            //partCodeText.Enabled = false;

            update = true;
        }



        /*Check if String entered into function is a number
         */
        public bool IsNumber(String number)
        {
            return number.All(char.IsNumber);
        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            Pen pn = new Pen(System.Drawing.Color.Black, 1);
            using (var graphics = Graphics.FromImage(bmp))
            {
                graphics.DrawLine(pn, e.X - 5, e.Y - 5, e.X + 5, e.Y + 5);
                graphics.DrawLine(pn, e.X + 5, e.Y - 5, e.X - 5, e.Y + 5);

            }
            pictureBox1.Invalidate();

            //g.DrawLine(pn, e.X-5, e.Y-5, e.X + 5, e.Y + 5);
            //g.DrawLine(pn, e.X+5, e.Y-5, e.X-5, e.Y+5);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        /*reset_all_fields method
         * Resets all the fields in the form to empty
         * Also refreshes the Today's orders' box to reflect any changes that may have happened to the database.
         */
        private void reset_all_fields()
        {
        }

        public void updateButton_Click()
        {
            
        }

        /**methods below are unused*/
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void executeSQL(string sql, bool errors)
        {
            using (MySqlConnection conn = connectMySql())
            {
                try
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    cmd.ExecuteReader();
                }
                catch (Exception ex)
                {
                    if (errors)
                    {
                        MessageBox.Show("Error communicating with database. If this problem persists, please contact the administrator.\n" + ex.ToString());
                        Console.WriteLine(ex.ToString());
                    }
                }
                conn.Close();
            }           
        }

        private String quote(string x)
        {
            return "'" + x + "'";
        }



        private void partButton_Click(object sender, EventArgs e)
        {

        }

        private void ViewJobForm_Resize(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void altCodeText_TextChanged(object sender, EventArgs e)
        {
            if (altCodeText.AutoCompleteCustomSource.Contains(altCodeText.Text))
            {
                altCodeText.Text.Trim();
                String code = altCodeText.Text;
                using (MySqlConnection conn = connectMySql())
                {
                    try
                    {
                        conn.Open();
                        string sql = String.Format("SELECT * FROM part WHERE pAltCode = '{0}';", code);
                        MySqlCommand cmd = new MySqlCommand(sql, conn);
                        using (MySqlDataReader rdr = cmd.ExecuteReader())
                        {
                            rdr.Read();

                            partCodeText.Text = rdr["pCode"].ToString();
                            //this.pID = int.Parse(rdr["pID"].ToString());
                            update = true;
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.ToString());
                        //MessageBox.Show("Issue. Please Contact Administrator.\nError Information:\n" + ex.ToString());
                        update = false;
                        //this.pID = 0;
                    }
                    conn.Close();
                }
            }
            else { 
                update = false;
                //this.pID = 0;
                //nagCodeText.Text = "";
                //partCodeText.Text = "";
                //partTypeCombo.Text = "";
            }
        }

        private void statusCombo_TextChanged(object sender, EventArgs e)
        {

        }

        private void statusCombo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void previewButton_Click(object sender, EventArgs e)
        {
            if (creditRadio.Checked)
            {
                if (incorrectRadio.Checked || cancelRadio.Checked || errorRadio.Checked || itemRadio.Checked || otherRadio.Checked)
                {
                    String html = "";
                    html += "<!DOCTYPE html>" +
                        "<html lang='en' xmlns='http://www.w3.org/1999/xhtml' style='background-color:white;'>" +
                        "<head><link rel='stylesheet' href='style.css'>" +
                        "<meta charset = 'utf-8'/>" +
                        "<title>Credit Form</title>" +
                        "</head><body>";

                    html += "<img src='Credit1.png' />";
                    html += String.Format("<section id='header'><p><pre><u>Date: {0}                                                </u>   " +
                        "<u>Contact name:<u> {1}                                                                                                                 </u></pre></p></section>",
                        dateTime.Value.ToString("dd-MM-yyyy"), GWMS.StaffID);
                    html += "<img src='Credit2.png'/>";

                    html += "<section>";
                    html += "<p><pre>OBG Code:<u> " + altCodeText.Text + "                                                                                 </u></pre></p>";
                    html += "<p><pre>Euro Code:<u> " + partCodeText.Text + "                                                                               </u></pre></p>";
                    html += "<p><pre>Quantity:<u> " + quantity.Text + "            </u> Delivery Date:<u> " + deliveryDateTime.Value.ToString("dd-MM-yyyy") + "                                                    </u></pre></p>";
                    html += "<p><pre>Sales Order:<u> " + salesText.Text + "                      </u> Invoice:<u> " + invoiceText.Text + "                                                                        </u></pre></p>";
                    html += "<p><pre>If this is a sourcing request, please provide rego number for </pre></p>";
                    html += "<p><pre>return to Supplier:<u> " + regoText.Text + "                                                                                               </u></pre></p>";
                    html += "</section>";

                    String c1 = "", c2 = "", c3 = "", c4 = "", c5 = "";

                    if (incorrectRadio.Checked)
                    {
                        c1 = "checked";
                    }

                    if (cancelRadio.Checked)
                    {
                        c2 = "checked";
                    }

                    if (errorRadio.Checked)
                    {
                        c3 = "checked";
                    }

                    if (itemRadio.Checked)
                    {
                        c4 = "checked";
                    }

                    if (otherRadio.Checked)
                    {
                        c5 = "checked";
                    }

                    html += String.Format("<section id='reason'>" +
                        "<ul>" +
                        "<li><input type='checkbox' {0}> Incorrect I.D - Ordered wrong product</li>" +
                        "<li><input type='checkbox' {1}> Customer Cancellation </li>" +
                        "<li><input type='checkbox' {2}> Picking Error </li>" +
                        "<li><input type='checkbox' {3}> Item not required</li>" +
                        "<li><input type='checkbox' {4}> Other (Please explain): ___________________</li>" +
                        "<li><pre><u>{5}                                                                                                   </u></pre></li>" +
                        "</ul>" +
                        "</section>", c1, c2, c3, c4, c5, otherText.Text);

                    html += "<img style='position:relative;left:9px;'src='Credit3.png'/>";
                    html += "</body>";
                    html += "</html>";

                    File.Delete(@"C:\Forms\Credit.html");
                    using (System.IO.StreamWriter file = new System.IO.StreamWriter(@"C:\Forms\Credit.html", true))
                    {
                        file.WriteLine(html);
                    }
                    //Process.Start("chrome.exe", @"C:\Forms\Credit.html");

                    var htmlContent = String.Format(html);
                    var htmlToPdf = new NReco.PdfGenerator.HtmlToPdfConverter();
                    /*htmlToPdf.Quiet = false;
                    htmlToPdf.LogReceived += (senders, es) => {
                        MessageBox.Show(String.Format("WkHtmlToPdf Log: {0}", es.Data));
                    };*/
                    htmlToPdf.CustomWkHtmlArgs = " --enable-local-file-access";
                    try
                    {
                        htmlToPdf.GeneratePdfFromFile(@"C:\Forms\Credit.html", null, @"C:\Forms\credit.pdf");
                        printDocument1.Print();
                    }
                    catch
                    {
                        MessageBox.Show("Unable to create PDF. The destination PDF file is opened in another program.");
                    }

                    try
                    {
                        //Outlook.Application oApp = new Outlook.Application();
                        //Outlook._MailItem oMailItem = (Outlook._MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                        //oMailItem.Attachments.Add((object)@"C:\Forms\credit.pdf", Outlook.OlAttachmentType.olEmbeddeditem, 1, (object)"Attachment");

                        //oMailItem.Subject = "Credit Return: " + partCodeText.Text + " : " + altCodeText.Text;
                        //oMailItem.To = @"adcreditschristchurchdc@smithandsmith.co.nz";
                        //oMailItem.CC = @"lynda@goreglass.co.nz";
                        // body, bcc etc...
                        //oMailItem.Display(true);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error, Couldn't open Outlook, Outlook may already be open. Please ensure that an Outlook 'compose' window is closed and try again. Also cgeck if Outlook is installed and set up on this device/user.");
                    }
                }
                else
                {
                    MessageBox.Show("Return Reason Must be Stated.");
                }
            }

            if (qualityRadio.Checked)
            {
                if (distortionRadio.Checked || delaminRadio.Checked || shapeRadio.Checked || tintRadio.Checked || otherQRadio.Checked || rainRadio.Checked || hardwareRadio.Checked)
                {
                    String html = "";

                    html += "<!DOCTYPE html>" +
                        "<html lang='en' xmlns='http://www.w3.org/1999/xhtml' style='background-color:white;'>" +
                        "<head><link rel='stylesheet' href='style.css'>" +
                        "<meta charset = 'utf-8'/>" +
                        "<title>Quality Form</title>" +
                        "</head><body>";

                    html += "<img src='Quality1.png' />";
                    html += String.Format("<section id='header'><p><pre><u>Dealer: Gore Windscreens and Glass                    </u>   " +
                        "<u>Contact name:<u> {0}                                                                                                                 </u></pre></p></section>",
                         GWMS.StaffID);
                    html += "<img src='Quality2.png'/>";

                    html += "<section>";
                    html += "<p><pre>Date:<u> " + dateTime.Value.ToString("dd-MM-yyyy") + "                                                                                 </u></pre></p>";
                    html += "<p><pre>OBG Code:<u> " + altCodeText.Text + "                                                                                 </u></pre></p>";
                    html += "<p><pre>Euro Code:<u> " + partCodeText.Text + "                                                                               </u></pre></p>";
                    html += "<p><pre>Quantity:<u> " + quantity.Text + "            </u> Delivery Date:<u> " + deliveryDateTime.Value.ToString("dd-MM-yyyy") + "                                                    </u></pre></p>";
                    html += "<p><pre>Sales Order:<u> " + salesText.Text + "                      </u> Invoice:<u> " + invoiceText.Text + "                                                                        </u></pre></p>";
                    html += "</section>";

                    String c1 = "", c2 = "", c3 = "", c4 = "", c5 = "", c6 = "", c7 = "";

                    if (distortionRadio.Checked)
                    {
                        c1 = "checked";
                    }

                    if (delaminRadio.Checked)
                    {
                        c2 = "checked";
                    }

                    if (shapeRadio.Checked)
                    {
                        c3 = "checked";
                    }

                    if (tintRadio.Checked)
                    {
                        c4 = "checked";
                    }

                    if (rainRadio.Checked)
                    {
                        c5 = "checked";
                    }

                    if (hardwareRadio.Checked)
                    {
                        c6 = "checked";
                    }

                    if (otherQRadio.Checked)
                    {
                        c7 = "checked";
                    }

                    html += String.Format("<section id='reason'>" +
                        "<ul>" +
                        "<li><pre><input type='checkbox' {0}>Distortion</pre></li>" +
                        "<li><pre><input type='checkbox' {1}>Delamination</pre></li>" +
                        "<li><pre><input type='checkbox' {2}>Shape and/or Size</pre></li>" +
                        "<li><pre><input type='checkbox' {3}>Tint Band/Colour</pre></li>" +
                        "<li><pre><input type='checkbox' {4}>Rain Sensor/Vin/Mirror Block</pre></li>" +
                        "<li><pre><input type='checkbox' {5}>Hardware/Retainer/Mould</pre></li>" +
                        "<li><pre><input type='checkbox' {6}>Other (Explain):<u>{7}                                                                                                        </u></pre></li>" +
                        "</ul>" +
                        "</section>", c1, c2, c3, c4, c5, c6, c7, otherQText.Text);

                    html += "<img style='position:relative;left:9px;'src='Quality3.png'/>";
                    html += "</body>";
                    html += "</html>";

                    File.Delete(@"C:\Forms\quality.html");
                    using (System.IO.StreamWriter file = new System.IO.StreamWriter(@"C:\Forms\quality.html", true))
                    {
                        file.WriteLine(html);
                    }


                    var htmlContent = String.Format(html);
                    var htmlToPdf = new NReco.PdfGenerator.HtmlToPdfConverter();
                    /*htmlToPdf.Quiet = false;
                    htmlToPdf.LogReceived += (senders, es) => {
                        MessageBox.Show(String.Format("WkHtmlToPdf Log: {0}", es.Data));
                    };*/
                    htmlToPdf.CustomWkHtmlArgs = " --enable-local-file-access";
                    try
                    {
                        htmlToPdf.GeneratePdfFromFile(@"C:\Forms\quality.html", null, @"C:\Forms\quality.pdf");
                    }
                    catch
                    {
                        MessageBox.Show("Unable to create PDF. The destination PDF file is opened in another program.");
                    }

                    var pdfBytes = htmlToPdf.GeneratePdf(html);
                    try
                    {
                        //File.WriteAllBytes(@"C:\Users\User\Desktop\test.pdf", pdfBytes);
                    }
                    catch
                    {
                        MessageBox.Show("Error, couldn't write to file, make sure that file isn't open in another program.");
                    }

                    Process.Start("chrome.exe", @"file:C:/Forms/quality.html");

                    try
                    {
                        //Outlook.Application oApp = new Outlook.Application();
                        //Outlook._MailItem oMailItem = (Outlook._MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                        //oMailItem.Attachments.Add((object)@"C:\Forms\quality.pdf", Outlook.OlAttachmentType.olEmbeddeditem, 1, (object)"Attachment");
                        //oMailItem.Subject = "Quality Claim: " + partCodeText.Text + " : " + altCodeText.Text;
                        //oMailItem.To = @"adcreditschristchurchdc@smithandsmith.co.nz";
                        //oMailItem.CC = @"lynda@goreglass.co.nz";
                        // body, bcc etc...
                        //oMailItem.Display(true);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error, Couldn't open Outlook, Outlook may already be open. Please ensure that Outlook is installed and set up on this device/user.");
                    }
                }
                else
                {
                    MessageBox.Show("Quality Issue Must be Stated.");
                }
            }

            if (transitRadio.Checked)
            {
                if (shelledRadio.Checked || crackedRadio.Checked || smashedRadio.Checked || scratchedRadio.Checked || otherTRadio.Checked || brokenRadio.Checked)
                {
                    String html = "";

                    html += "<!DOCTYPE html>" +
                        "<html lang='en' xmlns='http://www.w3.org/1999/xhtml' style='background-color:white;'>" +
                        "<head><link rel='stylesheet' href='style.css'>" +
                        "<meta charset = 'utf-8'/>" +
                        "<title>Transit Form</title>" +
                        "</head>" +
                        "" +
                        "<body>";

                    html += "<img src='c:\\Forms\\Transit1.png' />";
                    html += String.Format("<section id='header'><p><pre><u>Date: {0}                                                </u>   " +
                        "<u>Contact name:<u> {1}                                                                                                                 </u></pre></p></section>",
                         dateTime.Value.ToString("dd-MM-yyyy"), GWMS.StaffID);
                    html += "<img src='c:/Forms/Transit2.png'/>";

                    html += "<section>";
                    html += "<p><pre>Date:<u> " + dateTime.Value.ToString("dd-MM-yyyy") + "                                                                                 </u></pre></p>";
                    html += "<p><pre>OBG Code:<u> " + altCodeText.Text + "                                                                                 </u></pre></p>";
                    html += "<p><pre>Euro Code:<u> " + partCodeText.Text + "                                                                               </u></pre></p>";
                    html += "<p><pre>Quantity:<u> " + quantity.Text + "            </u> Delivery Date:<u> " + deliveryDateTime.Value.ToString("dd-MM-yyyy") + "                                                    </u></pre></p>";
                    html += "<p><pre>Sales Order:<u> " + salesText.Text + "                      </u> Invoice:<u> " + invoiceText.Text + "                                                                        </u></pre></p>";
                    html += "</section>";

                    String c1 = "", c2 = "", c3 = "", c4 = "", c5 = "", c6 = "";

                    if (shelledRadio.Checked)
                    {
                        c1 = "checked";
                    }

                    if (crackedRadio.Checked)
                    {
                        c2 = "checked";
                    }

                    if (smashedRadio.Checked)
                    {
                        c3 = "checked";
                    }

                    if (scratchedRadio.Checked)
                    {
                        c4 = "checked";
                    }

                    if (brokenRadio.Checked)
                    {
                        c5 = "checked";
                    }

                    if (otherTRadio.Checked)
                    {
                        c6 = "checked";
                    }

                    html += String.Format("<section id='reason'>" +
                        "<ul>" +
                        "<li><pre><input type='checkbox' {0}>Shelled</pre></li>" +
                        "<li><pre><input type='checkbox' {1}>Cracked</pre></li>" +
                        "<li><pre><input type='checkbox' {2}>Smashed</pre></li>" +
                        "<li><pre><input type='checkbox' {3}>Scratched</pre></li>" +
                        "<li><pre><input type='checkbox' {4}>Broken Features (R/S, Mirror Block, Heater)</pre></li>" +
                        "<li><pre><input type='checkbox' {5}>Other (Explain):<u>{6}                                                                                                        </u></pre></li>" +
                        "</ul>" +
                        "</section>", c1, c2, c3, c4, c5, c6, otherTText.Text);

                    html += "<img style='position:relative;left:9px;'src='//SERVER/c/BMS/Forms/Transit3.png'/>";
                    html += "<img style='position:relative;left:9px;'src='//SERVER/c/BMS/Forms/Transit4.png'/>";
                    html += "<img style='position:relative;left:170px;width:1100px;'src='//SERVER/c/BMS/Forms/Transit5.png'/>";
                    html += String.Format("" +
                        "<ul id='screencheck'>" +

                        "<li><pre><input type='checkbox' {1}>Cracked</pre></li>" +
                        "<li><pre><input type='checkbox' {3}>Scratched</pre></li>" +
                        "<li><pre><input type='checkbox' {0}>Shelled</pre></li>" +
                        "<li><pre><input type='checkbox' {2}>Smashed</pre></li>" +
                        "<li><pre><input type='checkbox' {4}>Damaged Features</pre></li>" +

                        "</ul>" +
                        "", c1, c2, c3, c4, c5);
                    html += "<img style='position:relative;left:9px;'src='//SERVER/c/BMS/Forms/Transit6.png'/>";
                    html += "</body>";
                    html += "</html>";

                    pictureBox1.Image.Save(@"//SERVER/c/BMS/Forms/Transit5.png");
                    File.Delete(@"C:\Forms\transit.html");
                    using (System.IO.StreamWriter file = new System.IO.StreamWriter(@"C:\Forms\transit.html", true))
                    {
                        file.WriteLine(html);
                    }

                    var htmlContent = String.Format(html);
                    var htmlToPdf = new NReco.PdfGenerator.HtmlToPdfConverter();
                    /*htmlToPdf.Quiet = false;
                    htmlToPdf.LogReceived += (senders, es) => {
                        MessageBox.Show(String.Format("WkHtmlToPdf Log: {0}", es.Data));
                    };*/
                    htmlToPdf.CustomWkHtmlArgs = " --enable-local-file-access";
                    try
                    {
                        htmlToPdf.GeneratePdfFromFile(@"C:\Forms\transit.html", null, @"C:\Forms\transit.pdf");
                    }
                    catch
                    {
                        MessageBox.Show("Unable to create PDF. The destination PDF file is opened in another program.");
                    }

                    var pdfBytes = htmlToPdf.GeneratePdf(html);
                    try
                    {
                        //File.WriteAllBytes(@"C:\Users\User\Desktop\test.pdf", pdfBytes);
                    }
                    catch
                    {
                        MessageBox.Show("Error, couldn't write to file, make sure that file isn't open in another program.");
                    }

                    Process.Start("chrome.exe", @"file:C:/Forms/Transit.html");

                    try
                    {
                        //Outlook.Application oApp = new Outlook.Application();
                        //Outlook._MailItem oMailItem = (Outlook._MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                        //oMailItem.Attachments.Add((object)@"C:\Forms\transit.pdf", Outlook.OlAttachmentType.olEmbeddeditem, 1, (object)"Attachment");
                        //oMailItem.Subject = "Transit Claim: " + partCodeText.Text + " : " + altCodeText.Text;
                        //oMailItem.To = @"adcreditschristchurchdc@smithandsmith.co.nz";
                        //oMailItem.CC = @"lynda@goreglass.co.nz";
                        // body, bcc etc...
                        //oMailItem.Display(true);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error, Couldn't open Outlook, Outlook may already be open. Please ensure that Outlook is installed and set up on this device/user.");
                    }

                    
                }
                else
                {
                    MessageBox.Show("Damage Reason Must be Stated.");
                }

            }

            
        }

        private static void InsertValuesInWorksheet(WorksheetPart worksheetPart, IEnumerable<string> values)
        {
            var worksheet = worksheetPart.Worksheet;
            var sheetData = worksheet.GetFirstChild<SheetData>();
            var row = new Row { RowIndex = 1 };  // add a row at the top of spreadsheet
            sheetData.Append(row);

            int i = 0;
            foreach (var value in values)
            {
                var cell = new Cell
                {
                    CellValue = new CellValue(value),
                    DataType = new EnumValue<CellValues>(CellValues.String)
                };

                row.InsertAt(cell, i);
                i++;
            }
        }

        private void qualityButton_Click(object sender, EventArgs e)
        {

            
        }



        private void otherRadio_CheckedChanged(object sender, EventArgs e)
        {
            if (otherRadio.Checked)
            {
                otherText.Enabled = true;
            }
            else
            {
                otherText.Enabled = false;
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void otherQRadio_CheckedChanged(object sender, EventArgs e)
        {
            if (otherQRadio.Checked)
            {
                otherQText.Enabled = true;
            }
            else
            {
                otherQText.Enabled = false;
            }
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void otherTRadio_CheckedChanged(object sender, EventArgs e)
        {
            if (otherTRadio.Checked)
            {
                otherTText.Enabled = true;
            }
            else
            {
                otherTText.Enabled = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bmp = new Bitmap(@"\\SERVER\c\BMS\Forms\Screen.png");
            pictureBox1.Image = bmp;
        }

        private void creditRadio_CheckedChanged(object sender, EventArgs e)
        {
            if (creditRadio.Checked)
            {
                returnGroup.Visible = true;
            }
            else
            {
                returnGroup.Visible = false;
            }
        }

        private void qualityRadio_CheckedChanged(object sender, EventArgs e)
        {
            if (qualityRadio.Checked)
            {
                qualityGroup.Visible = true;
            }
            else
            {
                qualityGroup.Visible = false;
            }
        }

        private void transitRadio_CheckedChanged(object sender, EventArgs e)
        {
            if (transitRadio.Checked)
            {
                damageGroup.Visible = true;
            }
            else
            {
                damageGroup.Visible = false;
            }
        }
    }
}
