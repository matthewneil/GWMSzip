﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workshop_orders
{
  public sealed class FormManagement
  {
    public static GWMS mdi;
    public static int globalID { get; set; }
    public static int globalID1 { get; set; }
    public static void ShowChildForm(string frmName, int iID = 0, int iID1 = 0)
    {
      if (frmName == "") { return; }
      foreach (System.Windows.Forms.Form f in Application.OpenForms)
      {
        if (f.Name == frmName)
        {
          f.Activate();
          f.ShowIcon = false;
          f.ControlBox = false;
          //f.WindowState = FormWindowState.Maximized;
          return;
        }
      }
      if (GetSecurityRole(frmName) == -1)
      {
        DataAccess.ShowMessage("You do not have the required role to access this form.\nTo change this, contact the manager.");
        return;
      }
      
      Form frm = (Form)Activator.CreateInstance(Type.GetType("workshop_orders." + frmName));
      if (GetSecurityRole(frmName) == 1)
      {
        frm.AccessibilityObject.Name += "Read Only";
        frm.Name += " [Read Only]";
      }
      globalID = iID;
      globalID1 = iID1;
      frm.MdiParent = mdi;
      frm.Dock = System.Windows.Forms.DockStyle.Fill;
      frm.FormBorderStyle = FormBorderStyle.None;
      frm.ShowIcon = false;
      frm.ControlBox = false;
      frm.Show();

    }
    public static void ShowChildForm(Form frm, int iID = 0, int iID1 = 0)
    {
      if (frm == null) { return; }
      foreach (System.Windows.Forms.Form f in Application.OpenForms)
      {
        if (f.Name == frm.Name)
        {
          f.Activate();
          f.ShowIcon = false;
          f.ControlBox = false;
          //f.WindowState = FormWindowState.Maximized;
          return;
        }
      }
      if (GetSecurityRole(frm.Name) == -1 )
      {
        DataAccess.ShowMessage("You do not have the required role to access this form.\nTo change this, contact the manager.");
        return;
      }
      if (GetSecurityRole(frm.Name) == 1)
      {
        frm.AccessibilityObject.Name += "Read Only";
        frm.Name += " [Read Only]";
      }
      globalID = iID;
      globalID1 = iID1;
      frm.MdiParent = mdi;
      frm.Dock = System.Windows.Forms.DockStyle.Fill;
      frm.FormBorderStyle = FormBorderStyle.None;
      frm.ShowIcon = false;
      frm.ControlBox = false;
      frm.Show();

      //frm.WindowState = FormWindowState.Maximized;
    }

    public static void ShowDialogForm(string frmName, int iID = 0, int iID1 = 0)
    {
      if (frmName == "") { return; }
      if (GetSecurityRole(frmName) == -1)
      {
        DataAccess.ShowMessage("You do not have the required role to access this form.\nTo change this, contact the manager.");
        return;
      }

      Form frm = (Form)Activator.CreateInstance(Type.GetType("workshop_orders." + frmName));
      if (GetSecurityRole(frmName) == 1)
      {
        frm.AccessibilityObject.Name += "Read Only";
        frm.Name += " [Read Only]";
      }

      globalID = iID;
      globalID1 = iID1;
      frm.ShowDialog();
    }

    public static void ShowDialogForm(Form frm, int iID = 0, int iID1 = 0)
    {
      if (frm == null) { return; }
      if (GetSecurityRole(frm.Name) == -1)
      {
        DataAccess.ShowMessage("You do not have the required role to access this form.\nTo change this, contact the manager.");
        return;
      }
      if (GetSecurityRole(frm.Name) == 1)
      {
        frm.AccessibilityObject.Name += "Read Only";
        frm.Name += " [Read Only]";
      }
      globalID = iID;
      globalID1 = iID1;
      frm.ShowDialog();
      //frm.WindowState = FormWindowState.Maximized;
    }

    public static bool IsFormOpen(string sFormName)
    {
      foreach (System.Windows.Forms.Form f in Application.OpenForms)
      {
        if (f.Name == sFormName)
        {
          return true;
        }
      }
      return false;
    }

    public static void CloseAll()
    {
      while (Application.OpenForms.Count > 1)
      {
        foreach (System.Windows.Forms.Form f in Application.OpenForms)
        {
          if (f.Name != "GWMS")
          {
            f.Close();
            break;
          }
        }
      }
    }

    public static void CloseChildForm(string frmName)
    {
      if (frmName == "") { return; }
      foreach (System.Windows.Forms.Form f in Application.OpenForms)
      {
        if (f.Name == frmName)
        {
          f.Close();
          return;
        }
      }
    }
    private static int GetSecurityRole(string sFormName) //Returns 0 for RW, 1 for Read Only, -1 for no access
    {
      if (sFormName == "Home") { return 0; }
      if (GWMS.Roles == null) { return -1; }
      //if admin then full access
      if (GWMS.Roles.IsInRole("R1-0"))
      {
        return 0;
      }
      //get matching role for the selected form
      try
      {
        int iRoleID = DataAccess.ExecuteScalarInt("SELECT RoleID FROM forms WHERE FormName = '" + sFormName + "'");
        if(iRoleID == 0) return 0;
        string sRoleRW = "R" + iRoleID + "-0";
        string sRoleRead = "R" + iRoleID + "-1";
        //check if user has that role, either read/write or read only
        if (GWMS.Roles.IsInRole(sRoleRW))
        {
          return 0;
        }
        else if (GWMS.Roles.IsInRole(sRoleRead))
        {
          return 1;
        }
      } catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
      return -1;

    }

  }
}