﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workshop_orders
{
  public partial class Onsite : Form
  {
    public static int time = -1;
    public static bool complete = false;
    public static string note = "";
    public static int travel = -1;
    public static int distance = -1;

    private DateTime StartTime;
    private DateTime EndTime;

    private int StaffID = -1;
    public Onsite(int StaffID, DateTime StartTime, DateTime EndTime)
    {
      InitializeComponent();

      //Set default values
      nudTravelTime.Value = 0;
      nudUnproductiveTime.Value = 0;
      nudDistance.Value = 0;
      txtJobTime.Text = "0";
      txtTimeToAllo.Text = "0";
      txtTimeAllocated.Text = "0";
      txtTimeLeft.Text = "0";

      if (EndTime > DateTime.Now)
      {
        EndTime = DateTime.Now;
      }
      this.StartTime = StartTime;
      this.EndTime = EndTime;


      //Load Staff Username
      this.StaffID = StaffID;
      tsUser.Text = DataAccess.ExecuteScalarString("SELECT StaffFullName FROM staff WHERE StaffID = " + StaffID);

      /*
      //Load Last staff labour record (today)
      String starttime = DataAccess.ExecuteScalarString(String.Format("SELECT StartTime FROM Labour WHERE StaffID = {0} AND EndTime IS NULL AND " +
        "StartTime BETWEEN '{1}' AND '{1} 23:59:59'", StaffID, DateTime.Today.ToString("yyyy-MM-dd")));


      
      //If staff somehow get here without starting day, flag this code.
      if(starttime == "ERROR")
      {
        if(StaffID == 1) starttime = DateTime.Today.ToString("yyyy-MM-dd ") + "8:00:00"; //Only here for dev testing, StaffID 1 = Dev Account Matt
        else
        {
          DataAccess.ShowMessage("Please start your day before submitting this Onsite Form.");
          this.Close();
        }
      }*/

      //Set amount of time since last record
      TimeSpan TotalTime = EndTime - StartTime;

      //Set time to allocate
      txtTimeToAllo.Text = ((int)TotalTime.TotalMinutes).ToString();
      txtTimeLeft.Text = ((int)TotalTime.TotalMinutes).ToString();
    }

    private void txtSearch_TextChanged(object sender, EventArgs e)
    {
      SearchJobs();
    }

    private void SearchJobs()
    {
      DataTable dt = DataAccess.ExecuteDataTable(String.Format("SELECT JobID, TypeName, CustomerName, Vehicle, JobBookingDateBlank, StatusName FROM vwJob WHERE " +
        "(JobID LIKE '{0}%' OR cSurname LIKE '{0}%' OR CustomerName LIKE '{0}%' OR Vehicle LIKE '{0}%') AND StatusID != 10 {1} LIMIT 100", txtSearch.Text, ShowCompleted()));
      dgvJob.DataSource = dt;
    }

    private String ShowCompleted()
    {
      if (!chkCompleted.Checked) return "AND StatusID != 11"; //Status 11 = Completed
      return "";
    }

    private void AddJob()
    {
      //If there is no time left to use, dont open the form
      if(int.Parse(txtTimeLeft.Text) < 1)
      {
        DataAccess.ShowMessage("There is no time left to allocate!");
        return;
      }
      try
      {
        if (dgvJob.SelectedRows.Count > 0 && dgvJob.SelectedRows[0].Index > -1)
        {
          //Check if job has already been added
          foreach (DataGridViewRow item in dgvJobAdded.Rows)
          {
            if (item.Cells["chJobIDAdded"].Value.ToString() == dgvJob.SelectedRows[0].Cells[0].Value.ToString())
            {
              DataAccess.ShowMessage("This Job has already been added.");
              return;
            }
          }
          FormManagement.ShowDialogForm(new JobAllocate((int)dgvJob.SelectedRows[0].Cells["chJobID"].Value, int.Parse(txtTimeLeft.Text), (int)nudTravelTime.Value, (int)nudDistance.Value));
          if (time != -1) //if value returned from form is '-1', this means that the cancel/back button was pressed, so job will not be added
          {
            dgvJobAdded.Rows.Add(dgvJob.SelectedRows[0].Cells["chJobID"].Value, time, travel, distance, note, complete, dgvJob.SelectedRows[0].Cells["chType"].Value, 
              dgvJob.SelectedRows[0].Cells["chCustomer"].Value);
            time = -1;
          }        
        }
      } catch (Exception ex)
      {
        DataAccess.ShowMessage("There was an error adding this Job, please reselect and try again");
      }
      CalculateJobTime();
    }

    private void btnAdd_Click(object sender, EventArgs e)
    {
      AddJob();    
    }

    private void btnRemove_Click(object sender, EventArgs e)
    {
      if (dgvJobAdded.SelectedRows.Count > 0 && dgvJobAdded.SelectedRows[0].Index > -1)
      {
        dgvJobAdded.Rows.RemoveAt(dgvJobAdded.SelectedRows[0].Index);
      }
      CalculateJobTime();
    }

    private void dgvJob_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      AddJob();
    }

    private void tsBack_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private void CalculateTimeAllocated()
    {
      txtTimeAllocated.Text = ((int)nudTravelTime.Value + (int)nudUnproductiveTime.Value + int.Parse(txtJobTime.Text)).ToString();
    }

    private void CalculateJobTime()
    {
      //Calculates all the Job times that were added to the list, and therefore calculates the time left to allocate
      int jobtime = 0;
      foreach (DataGridViewRow item in dgvJobAdded.Rows)
      {
        jobtime += (int)item.Cells["chTime"].Value;
      }
      txtJobTime.Text = jobtime.ToString();
    }

    private void nudTravelTime_ValueChanged(object sender, EventArgs e)
    {
      CalculateTimeAllocated();
    }

    private void nudUnproductive_ValueChanged(object sender, EventArgs e)
    {
      CalculateTimeAllocated();
    }

    private void tsSave_Click(object sender, EventArgs e)
    {
      if(int.Parse(txtTimeLeft.Text) > 0)
      {
        DataAccess.ShowMessage("There is time still to be allocated!");
        return;
      }

      if(txtJobTime.Text == "0")
      {
        DataAccess.ShowMessage("You haven't allocated any time to a Job!");
        return;
      }

      try
      {
        //Saving Code

        //Travel Time
        if ((int)nudTravelTime.Value > 0)
        {
          DataAccess.ExecuteNonQuery(String.Format("INSERT INTO labour (StaffID, JobTaskID, Percent, StartTime, EndTime) VALUES ({0}, {1}, 100, '{2}', '{3}')",
            StaffID, 112, StartTime.ToString("yyyy-MM-dd HH:mm:ss"), StartTime.AddMinutes((int)nudTravelTime.Value).ToString("yyyy-MM-dd HH:mm:ss")));

          //DataAccess.LabourOnsiteManage(StaffID, 112, ((int)nudTravelTime.Value).ToString(), txtTravelNote.Text); //112 is code for Admin Task Travel
        }

        StartTime = StartTime.AddMinutes((int)nudTravelTime.Value);
        //Unproductive time
        if ((int)nudUnproductiveTime.Value > 0)
        {
          DataAccess.ExecuteNonQuery(String.Format("INSERT INTO labour (StaffID, JobTaskID, Percent, StartTime, EndTime) VALUES ({0}, {1}, 100, '{2}', '{3}')",
            StaffID, 100, StartTime.ToString("yyyy-MM-dd HH:mm:ss"), StartTime.AddMinutes((int)nudUnproductiveTime.Value).ToString("yyyy-MM-dd HH:mm:ss")));
          //DataAccess.LabourOnsiteManage(StaffID, 100, ((int)nudUnproductiveTime.Value).ToString(), txtUnproductiveNote.Text); //Code will need to be created for unproductive
        }
        StartTime = StartTime.AddMinutes((int)nudUnproductiveTime.Value);
        //INSERT CODE FOR DISTANCE KM

        //JobTime
        //For loop through datagrid
        foreach (DataGridViewRow item in dgvJobAdded.Rows)
        {
          DataAccess.ExecuteNonQuery(String.Format("INSERT INTO labour (StaffID, JobTaskID, Percent, StartTime, EndTime, Note) VALUES ({0}, {1}, 100, '{2}', '{3}', '{4}')",
            StaffID, (int)item.Cells["chJobIDAdded"].Value, StartTime.ToString("yyyy-MM-dd HH:mm:ss"), 
            StartTime.AddMinutes(int.Parse(item.Cells["chTime"].Value.ToString())).ToString("yyyy-MM-dd HH:mm:ss"), item.Cells["chNote"].Value.ToString()));
          //DataAccess.LabourOnsiteManage(StaffID, (int)item.Cells["chJobIDAdded"].Value, item.Cells["chTime"].Value.ToString(), item.Cells["chNote"].Value.ToString()); //Code will need to be created for unproductive
        }
      } catch (Exception ex)
      {
        DataAccess.ShowMessage("An error has occured. Please double check onsite information and report error to admin.");
        return;
      }
      DataAccess.ShowMessage("Save successful");
      this.Close();
    }

    private void chkCompleted_CheckedChanged(object sender, EventArgs e)
    {
      SearchJobs();
    }

    private void dgvJobAdded_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      try
      {
        if (dgvJobAdded.SelectedRows.Count > 0 && dgvJobAdded.SelectedRows[0].Index > -1)
        {
          FormManagement.ShowDialogForm(new JobAllocate((int)dgvJobAdded.SelectedRows[0].Cells["chJobIDAdded"].Value, int.Parse(txtTimeLeft.Text), (int)dgvJobAdded.SelectedRows[0].Cells["chTravel"].Value,
            (int)dgvJobAdded.SelectedRows[0].Cells["chDistance"].Value, (int)dgvJobAdded.SelectedRows[0].Cells["chTime"].Value, 
            (bool)dgvJobAdded.SelectedRows[0].Cells["chComplete"].Value, dgvJobAdded.SelectedRows[0].Cells["chNote"].Value.ToString()));

          //Copy information from row before it is deleted
          int JobID = (int)dgvJobAdded.SelectedRows[0].Cells["chJobIDAdded"].Value;
          String Type = dgvJobAdded.SelectedRows[0].Cells["chTypeAdded"].Value.ToString();
          String Customer = dgvJobAdded.SelectedRows[0].Cells["chCustomerAdded"].Value.ToString();

          dgvJobAdded.Rows.RemoveAt(dgvJobAdded.SelectedRows[0].Index); //Delete row with old information

          if (time != -1) //if value returned from form is '-1', this means that the cancel/back button was pressed, so job will not be added
          {
            dgvJobAdded.Rows.Add(JobID, time, travel, distance, note, complete, Type, Customer);
            time = -1;
          }
        }
      }
      catch (Exception ex)
      {
        DataAccess.ShowMessage("There was an error adding this Job, please reselect and try again");
      }
      CalculateJobTime();
    }

    private void txtTimeAllocated_TextChanged(object sender, EventArgs e)
    {
      //Calculate the Time left to allocate and set the meximum values the other nuds can be
      int TimeLeft = int.Parse(txtTimeToAllo.Text) - int.Parse(txtTimeAllocated.Text);

      txtTimeLeft.Text = TimeLeft.ToString();

      nudTravelTime.Maximum = (int)nudTravelTime.Value + TimeLeft;
      nudUnproductiveTime.Maximum = (int)nudUnproductiveTime.Value + TimeLeft;
      //nudJobTime.Maximum = nudJobTime.Value + TimeLeft;
    }

    private void txtJobTime_TextChanged(object sender, EventArgs e)
    {
      CalculateTimeAllocated();
    }

    private void groupBox3_Enter(object sender, EventArgs e)
    {

    }
  }
}
