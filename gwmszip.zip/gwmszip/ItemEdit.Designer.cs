﻿namespace workshop_orders
{
  partial class ItemEdit
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      this.label1 = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this.label3 = new System.Windows.Forms.Label();
      this.label4 = new System.Windows.Forms.Label();
      this.label5 = new System.Windows.Forms.Label();
      this.lblQuantity = new System.Windows.Forms.Label();
      this.label7 = new System.Windows.Forms.Label();
      this.cmbGroup = new System.Windows.Forms.ComboBox();
      this.txtCode = new System.Windows.Forms.TextBox();
      this.txtDescription = new System.Windows.Forms.TextBox();
      this.txtCost = new System.Windows.Forms.TextBox();
      this.txtPrice = new System.Windows.Forms.TextBox();
      this.nudQuantity = new System.Windows.Forms.NumericUpDown();
      this.toolStrip1 = new System.Windows.Forms.ToolStrip();
      this.tsClose = new System.Windows.Forms.ToolStripButton();
      this.tsSave = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
      this.tsActive = new System.Windows.Forms.ToolStripButton();
      this.tsCode = new System.Windows.Forms.ToolStripLabel();
      this.nudAllowance = new System.Windows.Forms.NumericUpDown();
      this.lblAllowance = new System.Windows.Forms.Label();
      this.lblmm = new System.Windows.Forms.Label();
      this.gbItemDetails = new System.Windows.Forms.GroupBox();
      this.cmbUOM = new System.Windows.Forms.ComboBox();
      this.dgvHistory = new System.Windows.Forms.DataGridView();
      this.chJobID = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.tabControl1 = new System.Windows.Forms.TabControl();
      this.tabPage2 = new System.Windows.Forms.TabPage();
      this.dgvLocations = new System.Windows.Forms.DataGridView();
      this.cmLocation = new System.Windows.Forms.ContextMenuStrip(this.components);
      this.cmMove = new System.Windows.Forms.ToolStripMenuItem();
      this.cnAllocate = new System.Windows.Forms.ToolStripMenuItem();
      this.cmRemove = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStrip2 = new System.Windows.Forms.ToolStrip();
      this.tsAdd = new System.Windows.Forms.ToolStripButton();
      this.tsRemove = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
      this.tsMove = new System.Windows.Forms.ToolStripButton();
      this.tsAllocate = new System.Windows.Forms.ToolStripButton();
      this.tabPage3 = new System.Windows.Forms.TabPage();
      this.dgvItemHistory = new System.Windows.Forms.DataGridView();
      this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Group = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.SubGroup = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Code = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.tabPage1 = new System.Windows.Forms.TabPage();
      this.chID = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chGroup = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chSubGroup = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.cdDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chTotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chReserved = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chAvailable = new System.Windows.Forms.DataGridViewTextBoxColumn();
      ((System.ComponentModel.ISupportInitialize)(this.nudQuantity)).BeginInit();
      this.toolStrip1.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.nudAllowance)).BeginInit();
      this.gbItemDetails.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgvHistory)).BeginInit();
      this.tabControl1.SuspendLayout();
      this.tabPage2.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgvLocations)).BeginInit();
      this.cmLocation.SuspendLayout();
      this.toolStrip2.SuspendLayout();
      this.tabPage3.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgvItemHistory)).BeginInit();
      this.tabPage1.SuspendLayout();
      this.SuspendLayout();
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label1.Location = new System.Drawing.Point(54, 25);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(50, 18);
      this.label1.TabIndex = 0;
      this.label1.Text = "Group";
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label2.Location = new System.Drawing.Point(60, 55);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(44, 18);
      this.label2.TabIndex = 1;
      this.label2.Text = "Code";
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label3.Location = new System.Drawing.Point(21, 85);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(83, 18);
      this.label3.TabIndex = 2;
      this.label3.Text = "Description";
      // 
      // label4
      // 
      this.label4.AutoSize = true;
      this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label4.Location = new System.Drawing.Point(64, 184);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(40, 18);
      this.label4.TabIndex = 3;
      this.label4.Text = "Cost";
      // 
      // label5
      // 
      this.label5.AutoSize = true;
      this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label5.Location = new System.Drawing.Point(62, 211);
      this.label5.Name = "label5";
      this.label5.Size = new System.Drawing.Size(42, 18);
      this.label5.TabIndex = 4;
      this.label5.Text = "Price";
      // 
      // lblQuantity
      // 
      this.lblQuantity.AutoSize = true;
      this.lblQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblQuantity.Location = new System.Drawing.Point(286, 187);
      this.lblQuantity.Name = "lblQuantity";
      this.lblQuantity.Size = new System.Drawing.Size(96, 18);
      this.lblQuantity.TabIndex = 5;
      this.lblQuantity.Text = "Minimum Qty";
      // 
      // label7
      // 
      this.label7.AutoSize = true;
      this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label7.Location = new System.Drawing.Point(60, 243);
      this.label7.Name = "label7";
      this.label7.Size = new System.Drawing.Size(44, 18);
      this.label7.TabIndex = 6;
      this.label7.Text = "UOM";
      // 
      // cmbGroup
      // 
      this.cmbGroup.DisplayMember = "textfield";
      this.cmbGroup.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.cmbGroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbGroup.FormattingEnabled = true;
      this.cmbGroup.Location = new System.Drawing.Point(111, 22);
      this.cmbGroup.Name = "cmbGroup";
      this.cmbGroup.Size = new System.Drawing.Size(221, 26);
      this.cmbGroup.TabIndex = 1;
      this.cmbGroup.ValueMember = "datafield";
      this.cmbGroup.SelectedIndexChanged += new System.EventHandler(this.cmbGroup_SelectedIndexChanged);
      // 
      // txtCode
      // 
      this.txtCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtCode.Location = new System.Drawing.Point(111, 53);
      this.txtCode.MaxLength = 50;
      this.txtCode.Name = "txtCode";
      this.txtCode.Size = new System.Drawing.Size(353, 24);
      this.txtCode.TabIndex = 2;
      // 
      // txtDescription
      // 
      this.txtDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtDescription.Location = new System.Drawing.Point(111, 83);
      this.txtDescription.MaxLength = 50;
      this.txtDescription.Multiline = true;
      this.txtDescription.Name = "txtDescription";
      this.txtDescription.Size = new System.Drawing.Size(353, 93);
      this.txtDescription.TabIndex = 3;
      // 
      // txtCost
      // 
      this.txtCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtCost.Location = new System.Drawing.Point(111, 182);
      this.txtCost.Name = "txtCost";
      this.txtCost.Size = new System.Drawing.Size(103, 24);
      this.txtCost.TabIndex = 4;
      // 
      // txtPrice
      // 
      this.txtPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtPrice.Location = new System.Drawing.Point(111, 210);
      this.txtPrice.Name = "txtPrice";
      this.txtPrice.Size = new System.Drawing.Size(103, 24);
      this.txtPrice.TabIndex = 5;
      // 
      // nudQuantity
      // 
      this.nudQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.nudQuantity.Location = new System.Drawing.Point(389, 184);
      this.nudQuantity.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
      this.nudQuantity.Name = "nudQuantity";
      this.nudQuantity.Size = new System.Drawing.Size(75, 24);
      this.nudQuantity.TabIndex = 7;
      // 
      // toolStrip1
      // 
      this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsClose,
            this.tsSave,
            this.toolStripSeparator2,
            this.tsActive,
            this.tsCode});
      this.toolStrip1.Location = new System.Drawing.Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new System.Drawing.Size(1799, 39);
      this.toolStrip1.TabIndex = 14;
      this.toolStrip1.Text = "toolStrip1";
      // 
      // tsClose
      // 
      this.tsClose.Image = global::workshop_orders.Properties.Resources.back;
      this.tsClose.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsClose.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsClose.Name = "tsClose";
      this.tsClose.Size = new System.Drawing.Size(72, 36);
      this.tsClose.Text = "Close";
      this.tsClose.Click += new System.EventHandler(this.tsClose_Click);
      // 
      // tsSave
      // 
      this.tsSave.Image = global::workshop_orders.Properties.Resources.save;
      this.tsSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsSave.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsSave.Name = "tsSave";
      this.tsSave.Size = new System.Drawing.Size(67, 36);
      this.tsSave.Text = "Save";
      this.tsSave.Click += new System.EventHandler(this.tsSave_Click);
      // 
      // toolStripSeparator2
      // 
      this.toolStripSeparator2.Name = "toolStripSeparator2";
      this.toolStripSeparator2.Size = new System.Drawing.Size(6, 39);
      // 
      // tsActive
      // 
      this.tsActive.Image = global::workshop_orders.Properties.Resources.duplicate_remove32;
      this.tsActive.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsActive.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsActive.Name = "tsActive";
      this.tsActive.Size = new System.Drawing.Size(117, 36);
      this.tsActive.Text = "Set to Inactive";
      this.tsActive.Click += new System.EventHandler(this.tsActive_Click);
      // 
      // tsCode
      // 
      this.tsCode.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
      this.tsCode.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.tsCode.Name = "tsCode";
      this.tsCode.Size = new System.Drawing.Size(44, 36);
      this.tsCode.Text = "Code";
      // 
      // nudAllowance
      // 
      this.nudAllowance.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.nudAllowance.Location = new System.Drawing.Point(389, 214);
      this.nudAllowance.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
      this.nudAllowance.Name = "nudAllowance";
      this.nudAllowance.Size = new System.Drawing.Size(75, 24);
      this.nudAllowance.TabIndex = 16;
      // 
      // lblAllowance
      // 
      this.lblAllowance.AutoSize = true;
      this.lblAllowance.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblAllowance.Location = new System.Drawing.Point(307, 216);
      this.lblAllowance.Name = "lblAllowance";
      this.lblAllowance.Size = new System.Drawing.Size(75, 18);
      this.lblAllowance.TabIndex = 15;
      this.lblAllowance.Text = "Allowance";
      // 
      // lblmm
      // 
      this.lblmm.AutoSize = true;
      this.lblmm.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblmm.Location = new System.Drawing.Point(470, 217);
      this.lblmm.Name = "lblmm";
      this.lblmm.Size = new System.Drawing.Size(34, 18);
      this.lblmm.TabIndex = 17;
      this.lblmm.Text = "mm";
      // 
      // gbItemDetails
      // 
      this.gbItemDetails.Controls.Add(this.cmbUOM);
      this.gbItemDetails.Controls.Add(this.label1);
      this.gbItemDetails.Controls.Add(this.lblmm);
      this.gbItemDetails.Controls.Add(this.label2);
      this.gbItemDetails.Controls.Add(this.nudAllowance);
      this.gbItemDetails.Controls.Add(this.label3);
      this.gbItemDetails.Controls.Add(this.lblAllowance);
      this.gbItemDetails.Controls.Add(this.label4);
      this.gbItemDetails.Controls.Add(this.label5);
      this.gbItemDetails.Controls.Add(this.nudQuantity);
      this.gbItemDetails.Controls.Add(this.lblQuantity);
      this.gbItemDetails.Controls.Add(this.label7);
      this.gbItemDetails.Controls.Add(this.txtPrice);
      this.gbItemDetails.Controls.Add(this.cmbGroup);
      this.gbItemDetails.Controls.Add(this.txtCost);
      this.gbItemDetails.Controls.Add(this.txtCode);
      this.gbItemDetails.Controls.Add(this.txtDescription);
      this.gbItemDetails.Dock = System.Windows.Forms.DockStyle.Top;
      this.gbItemDetails.Location = new System.Drawing.Point(0, 39);
      this.gbItemDetails.Name = "gbItemDetails";
      this.gbItemDetails.Size = new System.Drawing.Size(1799, 275);
      this.gbItemDetails.TabIndex = 18;
      this.gbItemDetails.TabStop = false;
      this.gbItemDetails.Text = "Item Details";
      // 
      // cmbUOM
      // 
      this.cmbUOM.DisplayMember = "textfield";
      this.cmbUOM.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.cmbUOM.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbUOM.FormattingEnabled = true;
      this.cmbUOM.Location = new System.Drawing.Point(111, 240);
      this.cmbUOM.Name = "cmbUOM";
      this.cmbUOM.Size = new System.Drawing.Size(103, 26);
      this.cmbUOM.TabIndex = 18;
      this.cmbUOM.ValueMember = "datafield";
      // 
      // dgvHistory
      // 
      this.dgvHistory.AllowUserToAddRows = false;
      this.dgvHistory.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      this.dgvHistory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvHistory.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.chJobID,
            this.chStatus,
            this.chDate,
            this.chCost,
            this.chPrice});
      this.dgvHistory.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dgvHistory.Location = new System.Drawing.Point(3, 3);
      this.dgvHistory.Name = "dgvHistory";
      this.dgvHistory.ReadOnly = true;
      this.dgvHistory.RowHeadersWidth = 5;
      this.dgvHistory.Size = new System.Drawing.Size(1785, 484);
      this.dgvHistory.TabIndex = 0;
      // 
      // chJobID
      // 
      this.chJobID.DataPropertyName = "JobID";
      this.chJobID.HeaderText = "JobID";
      this.chJobID.Name = "chJobID";
      this.chJobID.ReadOnly = true;
      this.chJobID.Width = 80;
      // 
      // chStatus
      // 
      this.chStatus.DataPropertyName = "StatusName";
      this.chStatus.HeaderText = "Status";
      this.chStatus.Name = "chStatus";
      this.chStatus.ReadOnly = true;
      this.chStatus.Width = 150;
      // 
      // chDate
      // 
      this.chDate.DataPropertyName = "DateCreated";
      this.chDate.HeaderText = "Date Created";
      this.chDate.Name = "chDate";
      this.chDate.ReadOnly = true;
      this.chDate.Width = 200;
      // 
      // chCost
      // 
      this.chCost.DataPropertyName = "Cost";
      this.chCost.HeaderText = "Cost";
      this.chCost.Name = "chCost";
      this.chCost.ReadOnly = true;
      // 
      // chPrice
      // 
      this.chPrice.DataPropertyName = "Price";
      this.chPrice.HeaderText = "Price";
      this.chPrice.Name = "chPrice";
      this.chPrice.ReadOnly = true;
      // 
      // tabControl1
      // 
      this.tabControl1.Controls.Add(this.tabPage2);
      this.tabControl1.Controls.Add(this.tabPage3);
      this.tabControl1.Controls.Add(this.tabPage1);
      this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.tabControl1.Location = new System.Drawing.Point(0, 314);
      this.tabControl1.Name = "tabControl1";
      this.tabControl1.SelectedIndex = 0;
      this.tabControl1.Size = new System.Drawing.Size(1799, 521);
      this.tabControl1.TabIndex = 20;
      // 
      // tabPage2
      // 
      this.tabPage2.Controls.Add(this.dgvLocations);
      this.tabPage2.Controls.Add(this.toolStrip2);
      this.tabPage2.Location = new System.Drawing.Point(4, 27);
      this.tabPage2.Name = "tabPage2";
      this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
      this.tabPage2.Size = new System.Drawing.Size(1791, 490);
      this.tabPage2.TabIndex = 1;
      this.tabPage2.Text = "Locations";
      this.tabPage2.UseVisualStyleBackColor = true;
      // 
      // dgvLocations
      // 
      this.dgvLocations.AllowUserToAddRows = false;
      this.dgvLocations.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      this.dgvLocations.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvLocations.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.chID,
            this.chGroup,
            this.chSubGroup,
            this.chCode,
            this.cdDesc,
            this.chQty,
            this.chTotal,
            this.chReserved,
            this.chAvailable});
      this.dgvLocations.ContextMenuStrip = this.cmLocation;
      this.dgvLocations.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dgvLocations.Location = new System.Drawing.Point(3, 42);
      this.dgvLocations.Name = "dgvLocations";
      this.dgvLocations.RowHeadersWidth = 5;
      this.dgvLocations.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
      this.dgvLocations.Size = new System.Drawing.Size(1785, 445);
      this.dgvLocations.TabIndex = 0;
      // 
      // cmLocation
      // 
      this.cmLocation.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cmMove,
            this.cnAllocate,
            this.cmRemove});
      this.cmLocation.Name = "cmsLocation";
      this.cmLocation.Size = new System.Drawing.Size(118, 70);
      // 
      // cmMove
      // 
      this.cmMove.Name = "cmMove";
      this.cmMove.Size = new System.Drawing.Size(117, 22);
      this.cmMove.Text = "Move";
      this.cmMove.Click += new System.EventHandler(this.cmMove_Click);
      // 
      // cnAllocate
      // 
      this.cnAllocate.Name = "cnAllocate";
      this.cnAllocate.Size = new System.Drawing.Size(117, 22);
      this.cnAllocate.Text = "Allocate";
      this.cnAllocate.Click += new System.EventHandler(this.cnAllocate_Click);
      // 
      // cmRemove
      // 
      this.cmRemove.Name = "cmRemove";
      this.cmRemove.Size = new System.Drawing.Size(117, 22);
      this.cmRemove.Text = "Remove";
      this.cmRemove.Click += new System.EventHandler(this.cmRemove_Click);
      // 
      // toolStrip2
      // 
      this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsAdd,
            this.tsRemove,
            this.toolStripSeparator1,
            this.tsMove,
            this.tsAllocate});
      this.toolStrip2.Location = new System.Drawing.Point(3, 3);
      this.toolStrip2.Name = "toolStrip2";
      this.toolStrip2.Size = new System.Drawing.Size(1785, 39);
      this.toolStrip2.TabIndex = 1;
      this.toolStrip2.Text = "toolStrip2";
      // 
      // tsAdd
      // 
      this.tsAdd.Image = global::workshop_orders.Properties.Resources.addnew;
      this.tsAdd.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsAdd.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsAdd.Name = "tsAdd";
      this.tsAdd.Size = new System.Drawing.Size(65, 36);
      this.tsAdd.Text = "Add";
      this.tsAdd.Click += new System.EventHandler(this.tsAdd_Click);
      // 
      // tsRemove
      // 
      this.tsRemove.Image = global::workshop_orders.Properties.Resources.remove_role;
      this.tsRemove.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsRemove.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsRemove.Name = "tsRemove";
      this.tsRemove.Size = new System.Drawing.Size(86, 36);
      this.tsRemove.Text = "Remove";
      this.tsRemove.Click += new System.EventHandler(this.tsRemove_Click);
      // 
      // toolStripSeparator1
      // 
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
      // 
      // tsMove
      // 
      this.tsMove.Image = global::workshop_orders.Properties.Resources.group32;
      this.tsMove.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsMove.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsMove.Name = "tsMove";
      this.tsMove.Size = new System.Drawing.Size(73, 36);
      this.tsMove.Text = "Move";
      this.tsMove.Click += new System.EventHandler(this.tsMove_Click);
      // 
      // tsAllocate
      // 
      this.tsAllocate.Image = global::workshop_orders.Properties.Resources.import32;
      this.tsAllocate.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsAllocate.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsAllocate.Name = "tsAllocate";
      this.tsAllocate.Size = new System.Drawing.Size(86, 36);
      this.tsAllocate.Text = "Allocate";
      // 
      // tabPage3
      // 
      this.tabPage3.Controls.Add(this.dgvItemHistory);
      this.tabPage3.Location = new System.Drawing.Point(4, 27);
      this.tabPage3.Name = "tabPage3";
      this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
      this.tabPage3.Size = new System.Drawing.Size(1791, 490);
      this.tabPage3.TabIndex = 2;
      this.tabPage3.Text = "Item History";
      this.tabPage3.UseVisualStyleBackColor = true;
      // 
      // dgvItemHistory
      // 
      this.dgvItemHistory.AllowUserToAddRows = false;
      this.dgvItemHistory.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      this.dgvItemHistory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvItemHistory.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.Group,
            this.SubGroup,
            this.Code,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.Column1,
            this.Column2});
      this.dgvItemHistory.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dgvItemHistory.Location = new System.Drawing.Point(3, 3);
      this.dgvItemHistory.Name = "dgvItemHistory";
      this.dgvItemHistory.ReadOnly = true;
      this.dgvItemHistory.RowHeadersWidth = 5;
      this.dgvItemHistory.Size = new System.Drawing.Size(1785, 484);
      this.dgvItemHistory.TabIndex = 1;
      // 
      // dataGridViewTextBoxColumn1
      // 
      this.dataGridViewTextBoxColumn1.DataPropertyName = "ItemMovementID";
      this.dataGridViewTextBoxColumn1.HeaderText = "ItemMovementID";
      this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
      this.dataGridViewTextBoxColumn1.ReadOnly = true;
      this.dataGridViewTextBoxColumn1.Visible = false;
      this.dataGridViewTextBoxColumn1.Width = 80;
      // 
      // Group
      // 
      this.Group.DataPropertyName = "LocationGroup";
      this.Group.HeaderText = "Group";
      this.Group.Name = "Group";
      this.Group.ReadOnly = true;
      // 
      // SubGroup
      // 
      this.SubGroup.DataPropertyName = "LocationSubGroup";
      this.SubGroup.HeaderText = "Sub Group";
      this.SubGroup.Name = "SubGroup";
      this.SubGroup.ReadOnly = true;
      // 
      // Code
      // 
      this.Code.DataPropertyName = "LocationCode";
      this.Code.HeaderText = "Code";
      this.Code.Name = "Code";
      this.Code.ReadOnly = true;
      // 
      // dataGridViewTextBoxColumn2
      // 
      this.dataGridViewTextBoxColumn2.DataPropertyName = "mtDescription";
      this.dataGridViewTextBoxColumn2.HeaderText = "Description";
      this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
      this.dataGridViewTextBoxColumn2.ReadOnly = true;
      this.dataGridViewTextBoxColumn2.Width = 150;
      // 
      // dataGridViewTextBoxColumn3
      // 
      this.dataGridViewTextBoxColumn3.DataPropertyName = "imDate";
      this.dataGridViewTextBoxColumn3.HeaderText = "Date";
      this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
      this.dataGridViewTextBoxColumn3.ReadOnly = true;
      this.dataGridViewTextBoxColumn3.Width = 200;
      // 
      // dataGridViewTextBoxColumn4
      // 
      this.dataGridViewTextBoxColumn4.DataPropertyName = "StaffFullName";
      this.dataGridViewTextBoxColumn4.HeaderText = "Staff";
      this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
      this.dataGridViewTextBoxColumn4.ReadOnly = true;
      this.dataGridViewTextBoxColumn4.Width = 150;
      // 
      // dataGridViewTextBoxColumn5
      // 
      this.dataGridViewTextBoxColumn5.DataPropertyName = "imQuantity";
      this.dataGridViewTextBoxColumn5.HeaderText = "Quantity";
      this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
      this.dataGridViewTextBoxColumn5.ReadOnly = true;
      // 
      // Column1
      // 
      this.Column1.DataPropertyName = "imCost";
      this.Column1.HeaderText = "Cost";
      this.Column1.Name = "Column1";
      this.Column1.ReadOnly = true;
      // 
      // Column2
      // 
      this.Column2.DataPropertyName = "imReference";
      this.Column2.HeaderText = "Reference";
      this.Column2.Name = "Column2";
      this.Column2.ReadOnly = true;
      this.Column2.Width = 300;
      // 
      // tabPage1
      // 
      this.tabPage1.Controls.Add(this.dgvHistory);
      this.tabPage1.Location = new System.Drawing.Point(4, 27);
      this.tabPage1.Name = "tabPage1";
      this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
      this.tabPage1.Size = new System.Drawing.Size(1791, 490);
      this.tabPage1.TabIndex = 0;
      this.tabPage1.Text = "Job History";
      this.tabPage1.UseVisualStyleBackColor = true;
      // 
      // chID
      // 
      this.chID.DataPropertyName = "ItemStockID";
      this.chID.HeaderText = "ID";
      this.chID.Name = "chID";
      this.chID.ReadOnly = true;
      this.chID.Visible = false;
      // 
      // chGroup
      // 
      this.chGroup.DataPropertyName = "LocationGroup";
      this.chGroup.HeaderText = "Group";
      this.chGroup.Name = "chGroup";
      this.chGroup.ReadOnly = true;
      this.chGroup.Width = 120;
      // 
      // chSubGroup
      // 
      this.chSubGroup.DataPropertyName = "LocationSubGroup";
      this.chSubGroup.HeaderText = "Sub Group";
      this.chSubGroup.Name = "chSubGroup";
      this.chSubGroup.ReadOnly = true;
      this.chSubGroup.Width = 120;
      // 
      // chCode
      // 
      this.chCode.DataPropertyName = "LocationCode";
      this.chCode.HeaderText = "Code";
      this.chCode.Name = "chCode";
      this.chCode.ReadOnly = true;
      this.chCode.Width = 120;
      // 
      // cdDesc
      // 
      this.cdDesc.DataPropertyName = "LocationDescription";
      this.cdDesc.HeaderText = "Description";
      this.cdDesc.Name = "cdDesc";
      this.cdDesc.ReadOnly = true;
      this.cdDesc.Width = 500;
      // 
      // chQty
      // 
      this.chQty.DataPropertyName = "Quantity";
      this.chQty.HeaderText = "Qty";
      this.chQty.Name = "chQty";
      this.chQty.ReadOnly = true;
      this.chQty.Visible = false;
      this.chQty.Width = 80;
      // 
      // chTotal
      // 
      this.chTotal.DataPropertyName = "Stock";
      this.chTotal.HeaderText = "All Qty";
      this.chTotal.Name = "chTotal";
      this.chTotal.ReadOnly = true;
      // 
      // chReserved
      // 
      this.chReserved.DataPropertyName = "Reservation";
      this.chReserved.HeaderText = "Reserved";
      this.chReserved.Name = "chReserved";
      this.chReserved.ReadOnly = true;
      // 
      // chAvailable
      // 
      this.chAvailable.DataPropertyName = "Available";
      this.chAvailable.HeaderText = "Available";
      this.chAvailable.Name = "chAvailable";
      this.chAvailable.ReadOnly = true;
      // 
      // ItemEdit
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.ClientSize = new System.Drawing.Size(1799, 835);
      this.Controls.Add(this.tabControl1);
      this.Controls.Add(this.gbItemDetails);
      this.Controls.Add(this.toolStrip1);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
      this.Name = "ItemEdit";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
      this.Text = "Edit Item";
      ((System.ComponentModel.ISupportInitialize)(this.nudQuantity)).EndInit();
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.nudAllowance)).EndInit();
      this.gbItemDetails.ResumeLayout(false);
      this.gbItemDetails.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgvHistory)).EndInit();
      this.tabControl1.ResumeLayout(false);
      this.tabPage2.ResumeLayout(false);
      this.tabPage2.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgvLocations)).EndInit();
      this.cmLocation.ResumeLayout(false);
      this.toolStrip2.ResumeLayout(false);
      this.toolStrip2.PerformLayout();
      this.tabPage3.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.dgvItemHistory)).EndInit();
      this.tabPage1.ResumeLayout(false);
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.Label label5;
    private System.Windows.Forms.Label lblQuantity;
    private System.Windows.Forms.Label label7;
    private System.Windows.Forms.ComboBox cmbGroup;
    private System.Windows.Forms.TextBox txtCode;
    private System.Windows.Forms.TextBox txtDescription;
    private System.Windows.Forms.TextBox txtCost;
    private System.Windows.Forms.TextBox txtPrice;
    private System.Windows.Forms.NumericUpDown nudQuantity;
    private System.Windows.Forms.ToolStrip toolStrip1;
    private System.Windows.Forms.ToolStripButton tsClose;
    private System.Windows.Forms.ToolStripButton tsSave;
    private System.Windows.Forms.NumericUpDown nudAllowance;
    private System.Windows.Forms.Label lblAllowance;
    private System.Windows.Forms.Label lblmm;
    private System.Windows.Forms.GroupBox gbItemDetails;
    private System.Windows.Forms.ComboBox cmbUOM;
    private System.Windows.Forms.DataGridView dgvHistory;
    private System.Windows.Forms.TabControl tabControl1;
    private System.Windows.Forms.TabPage tabPage2;
    private System.Windows.Forms.DataGridView dgvLocations;
    private System.Windows.Forms.TabPage tabPage1;
    private System.Windows.Forms.ToolStrip toolStrip2;
    private System.Windows.Forms.ToolStripButton tsAdd;
    private System.Windows.Forms.ToolStripButton tsAllocate;
    private System.Windows.Forms.ToolStripButton tsMove;
    private System.Windows.Forms.TabPage tabPage3;
    private System.Windows.Forms.DataGridView dgvItemHistory;
    private System.Windows.Forms.DataGridViewTextBoxColumn chJobID;
    private System.Windows.Forms.DataGridViewTextBoxColumn chStatus;
    private System.Windows.Forms.DataGridViewTextBoxColumn chDate;
    private System.Windows.Forms.DataGridViewTextBoxColumn chCost;
    private System.Windows.Forms.DataGridViewTextBoxColumn chPrice;
    private System.Windows.Forms.ToolStripButton tsRemove;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
    private System.Windows.Forms.ContextMenuStrip cmLocation;
    private System.Windows.Forms.ToolStripMenuItem cmMove;
    private System.Windows.Forms.ToolStripMenuItem cnAllocate;
    private System.Windows.Forms.ToolStripMenuItem cmRemove;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
    private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
    private System.Windows.Forms.DataGridViewTextBoxColumn Group;
    private System.Windows.Forms.DataGridViewTextBoxColumn SubGroup;
    private System.Windows.Forms.DataGridViewTextBoxColumn Code;
    private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
    private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
    private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
    private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
    private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
    private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
    private System.Windows.Forms.ToolStripButton tsActive;
    private System.Windows.Forms.ToolStripLabel tsCode;
    private System.Windows.Forms.DataGridViewTextBoxColumn chID;
    private System.Windows.Forms.DataGridViewTextBoxColumn chGroup;
    private System.Windows.Forms.DataGridViewTextBoxColumn chSubGroup;
    private System.Windows.Forms.DataGridViewTextBoxColumn chCode;
    private System.Windows.Forms.DataGridViewTextBoxColumn cdDesc;
    private System.Windows.Forms.DataGridViewTextBoxColumn chQty;
    private System.Windows.Forms.DataGridViewTextBoxColumn chTotal;
    private System.Windows.Forms.DataGridViewTextBoxColumn chReserved;
    private System.Windows.Forms.DataGridViewTextBoxColumn chAvailable;
  }
}