-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: localhost    Database: gwms
-- ------------------------------------------------------
-- Server version	8.0.25

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `location` (
  `LocationID` int NOT NULL AUTO_INCREMENT,
  `LocationGroup` varchar(45) NOT NULL,
  `LocationSubGroup` varchar(45) NOT NULL,
  `LocationCode` varchar(45) NOT NULL,
  `LocationDescription` varchar(500) DEFAULT NULL,
  `Active` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`LocationID`),
  UNIQUE KEY `LocationID_UNIQUE` (`LocationID`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location`
--

LOCK TABLES `location` WRITE;
/*!40000 ALTER TABLE `location` DISABLE KEYS */;
INSERT INTO `location` VALUES (1,'Gore','Gore','Temp','Tempory Holding',1),(2,'Gore','Gore','Non-Stock','Non-Stock Purchasing',1),(3,'Gore','Gore','Order','On Order',1),(4,'Gore','Gore','Credit','Items to be Credited',1),(7,'Gore','Wooden','WA1','Asian',1),(8,'Gore','Wooden','WE1','European',1),(9,'Gore','Wooden','WF1','Ford 1',1),(10,'Gore','Wooden','WF2','Ford 2',1),(11,'Gore','Wooden','WF3','Ford 3',1),(12,'Gore','Wooden','WH1','Hyundai',1),(13,'Gore','Wooden','WH2','Honda',1),(14,'Gore','Wooden','WH3','Holden 1',1),(15,'Gore','Wooden','WK1','Kia',1),(16,'Gore','Wooden','WM1','Mitsubishi',1),(17,'Gore','Wooden','WM2','Mazda',1),(18,'Gore','Wooden','WN1','Nissan',1),(19,'Gore','Wooden','WR1','Rearscreen 1',1),(20,'Gore','Wooden','WR2','Rearscreen 2',1),(21,'Gore','Wooden','WT1','Toyota 1',1),(22,'Gore','Wooden','WT2','Toyota 2',1),(23,'Gore','Wooden','WT3','Toyota 3',1),(24,'Gore','WIP','WIP1','Work in Progress 1',1),(25,'Gore','WIP','WIP2','Work in Progress 2',1),(26,'Gore','Wooden','WH4','Holden 2',1),(27,'Gore','WIP','WIP3','Work in Progress 3',1),(32,'Gore','WIP','WIP4','Work in Progress 4',1),(33,'Gore','WIP','WIP5','Work in Progress 5',1),(34,'Gore','WIP','WIP6','Work in Progress 6',1),(35,'Gore','WIP','WIP7','Work in Progress 7',1),(36,'Gore','WIP','WIP8','Work in Progress 8',1),(37,'Gore','WIP','WIP9','Work in Progress 9',1),(38,'Gore','WIP','WIP10','Work in Progress 10',1),(39,'Gore','WIP','WIP11','Work in Progress 11',1),(40,'Gore','WIP','WIP12','Work in Progress 12',1),(41,'Gore','WIP','WIP13','Work in Progress 13',1),(42,'Gore','WIP','WIP14','Work in Progress 14',1),(43,'Gore','WIP','WIP15','Work in Progress 15',1),(44,'Gore','WIP','WIP16','Work in Progress 16',1),(45,'Gore','WIP','WIP17','Work in Progress 17',1),(46,'Gore','WIP','WIP18','Work in Progress 18',1),(47,'Gore','WIP','WIP19','Work in Progress 19',1),(48,'Gore','WIP','WIP20','Work in Progress 20',1),(49,'Gore','WIP','WIP21','Work in Progress 21',1),(50,'Gore','WIP','WIP22','Work in Progress 22',1),(51,'Gore','WIP','WIP23','Work in Progress 23',1),(52,'Gore','WIP','WIP24','Work in Progress 24',1),(53,'Gore','WIP','WIP25','Work in Progress 25',1),(54,'Gore','WIP','WIP26','Work in Progress 26',1),(55,'Gore','WIP','WIP27','Work in Progress 27',1),(56,'Gore','WIP','WIP28','Work in Progress 28',1),(57,'Gore','WIP','WIP29','Work in Progress 29',1),(58,'Gore','WIP','WIP30','Work in Progress 30',1),(59,'Gore','WIP','WIP31','Work in Progress 31',1),(60,'Gore','WIP','WIP32','Work in Progress 32',1),(61,'Gore','WIP','WIP33','Work in Progress 33',1),(62,'Gore','WIP','WIP34','Work in Progress 34',1),(63,'Gore','WIP','WIP35','Work in Progress 35',1),(64,'Gore','WIP','WIP36','Work in Progress 36',1),(65,'Gore','WIP','WIP37','Work in Progress 37',1),(66,'Gore','WIP','WIP38','Work in Progress 38',1),(67,'Gore','WIP','WIP39','Work in Progress 39',1),(68,'Gore','WIP','WIP40','Work in Progress 40',1),(69,'Gore','WIP','WIP41','Work in Progress 41',1),(70,'Gore','WIP','WIP42','Work in Progress 42',1),(71,'Gore','Day Rack','DR1','Day Rack 1',1),(72,'Gore','Day Rack','DR2','Day Rack 2',1),(73,'Gore','Day Rack','DR3','Day Rack 3',1),(74,'Gore','Day Rack','DR4','Day Rack 4',1),(75,'Gore','Day Rack','DR5','Day Rack 5',1),(76,'Gore','Day Rack','DR6','Day Rack 6',1),(77,'Gore','Truck Rack','TR1','Truck Rack 1',1),(78,'Gore','Truck Rack','TR2','Truck Rack 2',1);
/*!40000 ALTER TABLE `location` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-18 16:31:43
