﻿
namespace workshop_orders
{
  partial class WorkshopLabour
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.chkTextToday = new System.Windows.Forms.CheckBox();
      this.rbTextNo = new System.Windows.Forms.RadioButton();
      this.rbTextYes = new System.Windows.Forms.RadioButton();
      this.dtpTextTime = new System.Windows.Forms.DateTimePicker();
      this.dtpTextDay = new System.Windows.Forms.DateTimePicker();
      this.nudMilage = new System.Windows.Forms.NumericUpDown();
      this.txtNote = new System.Windows.Forms.TextBox();
      this.tbrPercentage = new System.Windows.Forms.TrackBar();
      this.toolStrip1 = new System.Windows.Forms.ToolStrip();
      this.tsBack = new System.Windows.Forms.ToolStripButton();
      this.tsTime = new System.Windows.Forms.ToolStripButton();
      this.tsUser = new System.Windows.Forms.ToolStripLabel();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.lblPercent2 = new System.Windows.Forms.Label();
      this.lblPercent = new System.Windows.Forms.Label();
      this.btnPercentDown = new System.Windows.Forms.Button();
      this.btnPercentUp = new System.Windows.Forms.Button();
      this.panel1 = new System.Windows.Forms.Panel();
      this.btnTime = new System.Windows.Forms.Button();
      this.groupBox2 = new System.Windows.Forms.GroupBox();
      this.groupBox3 = new System.Windows.Forms.GroupBox();
      this.btnTextDown = new System.Windows.Forms.Button();
      this.btnTextUp = new System.Windows.Forms.Button();
      this.groupBox4 = new System.Windows.Forms.GroupBox();
      this.groupBox5 = new System.Windows.Forms.GroupBox();
      this.label1 = new System.Windows.Forms.Label();
      this.rbYes = new System.Windows.Forms.RadioButton();
      this.rbNo = new System.Windows.Forms.RadioButton();
      ((System.ComponentModel.ISupportInitialize)(this.nudMilage)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.tbrPercentage)).BeginInit();
      this.toolStrip1.SuspendLayout();
      this.groupBox1.SuspendLayout();
      this.panel1.SuspendLayout();
      this.groupBox2.SuspendLayout();
      this.groupBox3.SuspendLayout();
      this.groupBox4.SuspendLayout();
      this.groupBox5.SuspendLayout();
      this.SuspendLayout();
      // 
      // chkTextToday
      // 
      this.chkTextToday.AutoSize = true;
      this.chkTextToday.Checked = true;
      this.chkTextToday.CheckState = System.Windows.Forms.CheckState.Checked;
      this.chkTextToday.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.chkTextToday.Location = new System.Drawing.Point(312, 25);
      this.chkTextToday.Name = "chkTextToday";
      this.chkTextToday.Size = new System.Drawing.Size(71, 24);
      this.chkTextToday.TabIndex = 47;
      this.chkTextToday.Text = "Today";
      this.chkTextToday.UseVisualStyleBackColor = true;
      this.chkTextToday.Visible = false;
      this.chkTextToday.CheckedChanged += new System.EventHandler(this.chkTextToday_CheckedChanged);
      // 
      // rbTextNo
      // 
      this.rbTextNo.AutoSize = true;
      this.rbTextNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.rbTextNo.Location = new System.Drawing.Point(27, 56);
      this.rbTextNo.Name = "rbTextNo";
      this.rbTextNo.Size = new System.Drawing.Size(99, 24);
      this.rbTextNo.TabIndex = 46;
      this.rbTextNo.TabStop = true;
      this.rbTextNo.Text = "Don\'t Text";
      this.rbTextNo.UseVisualStyleBackColor = true;
      // 
      // rbTextYes
      // 
      this.rbTextYes.AutoSize = true;
      this.rbTextYes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.rbTextYes.Location = new System.Drawing.Point(27, 27);
      this.rbTextYes.Name = "rbTextYes";
      this.rbTextYes.Size = new System.Drawing.Size(57, 24);
      this.rbTextYes.TabIndex = 45;
      this.rbTextYes.TabStop = true;
      this.rbTextYes.Text = "Text";
      this.rbTextYes.UseVisualStyleBackColor = true;
      this.rbTextYes.CheckedChanged += new System.EventHandler(this.rbTextYes_CheckedChanged);
      // 
      // dtpTextTime
      // 
      this.dtpTextTime.CustomFormat = "hh:mm tt";
      this.dtpTextTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.dtpTextTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
      this.dtpTextTime.Location = new System.Drawing.Point(181, 25);
      this.dtpTextTime.Name = "dtpTextTime";
      this.dtpTextTime.Size = new System.Drawing.Size(115, 26);
      this.dtpTextTime.TabIndex = 44;
      this.dtpTextTime.Value = new System.DateTime(2022, 2, 21, 8, 0, 0, 0);
      this.dtpTextTime.Visible = false;
      // 
      // dtpTextDay
      // 
      this.dtpTextDay.CustomFormat = "ddd, dd MMMM yyyy";
      this.dtpTextDay.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.dtpTextDay.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
      this.dtpTextDay.Location = new System.Drawing.Point(312, 49);
      this.dtpTextDay.Name = "dtpTextDay";
      this.dtpTextDay.Size = new System.Drawing.Size(243, 26);
      this.dtpTextDay.TabIndex = 43;
      this.dtpTextDay.Visible = false;
      // 
      // nudMilage
      // 
      this.nudMilage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.nudMilage.Location = new System.Drawing.Point(12, 28);
      this.nudMilage.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
      this.nudMilage.Name = "nudMilage";
      this.nudMilage.Size = new System.Drawing.Size(156, 26);
      this.nudMilage.TabIndex = 41;
      // 
      // txtNote
      // 
      this.txtNote.Dock = System.Windows.Forms.DockStyle.Fill;
      this.txtNote.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtNote.Location = new System.Drawing.Point(3, 22);
      this.txtNote.MaxLength = 1000;
      this.txtNote.Multiline = true;
      this.txtNote.Name = "txtNote";
      this.txtNote.Size = new System.Drawing.Size(555, 87);
      this.txtNote.TabIndex = 38;
      // 
      // tbrPercentage
      // 
      this.tbrPercentage.Location = new System.Drawing.Point(113, 30);
      this.tbrPercentage.Maximum = 100;
      this.tbrPercentage.Name = "tbrPercentage";
      this.tbrPercentage.Size = new System.Drawing.Size(401, 45);
      this.tbrPercentage.SmallChange = 5;
      this.tbrPercentage.TabIndex = 35;
      this.tbrPercentage.TickFrequency = 10;
      this.tbrPercentage.ValueChanged += new System.EventHandler(this.tbrPercentage_ValueChanged);
      // 
      // toolStrip1
      // 
      this.toolStrip1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsBack,
            this.tsTime,
            this.tsUser});
      this.toolStrip1.Location = new System.Drawing.Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new System.Drawing.Size(589, 39);
      this.toolStrip1.TabIndex = 49;
      this.toolStrip1.Text = "toolStrip1";
      // 
      // tsBack
      // 
      this.tsBack.Image = global::workshop_orders.Properties.Resources.back;
      this.tsBack.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsBack.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsBack.Name = "tsBack";
      this.tsBack.Size = new System.Drawing.Size(78, 36);
      this.tsBack.Text = "Back";
      this.tsBack.Click += new System.EventHandler(this.tsBack_Click);
      // 
      // tsTime
      // 
      this.tsTime.Image = global::workshop_orders.Properties.Resources.hourglass32;
      this.tsTime.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsTime.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsTime.Name = "tsTime";
      this.tsTime.Size = new System.Drawing.Size(112, 36);
      this.tsTime.Text = "Add Time";
      this.tsTime.Click += new System.EventHandler(this.tsTime_Click);
      // 
      // tsUser
      // 
      this.tsUser.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
      this.tsUser.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.tsUser.Name = "tsUser";
      this.tsUser.Size = new System.Drawing.Size(71, 36);
      this.tsUser.Text = "No User";
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.Add(this.lblPercent2);
      this.groupBox1.Controls.Add(this.lblPercent);
      this.groupBox1.Controls.Add(this.btnPercentDown);
      this.groupBox1.Controls.Add(this.btnPercentUp);
      this.groupBox1.Controls.Add(this.tbrPercentage);
      this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.groupBox1.Location = new System.Drawing.Point(458, 42);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(561, 100);
      this.groupBox1.TabIndex = 50;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Percentage";
      // 
      // lblPercent2
      // 
      this.lblPercent2.AutoSize = true;
      this.lblPercent2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblPercent2.Location = new System.Drawing.Point(509, 30);
      this.lblPercent2.Name = "lblPercent2";
      this.lblPercent2.Size = new System.Drawing.Size(31, 18);
      this.lblPercent2.TabIndex = 39;
      this.lblPercent2.Text = "0%";
      // 
      // lblPercent
      // 
      this.lblPercent.AutoSize = true;
      this.lblPercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblPercent.Location = new System.Drawing.Point(47, 75);
      this.lblPercent.Name = "lblPercent";
      this.lblPercent.Size = new System.Drawing.Size(31, 18);
      this.lblPercent.TabIndex = 38;
      this.lblPercent.Text = "0%";
      this.lblPercent.TextChanged += new System.EventHandler(this.lblPercent_TextChanged);
      // 
      // btnPercentDown
      // 
      this.btnPercentDown.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnPercentDown.Image = global::workshop_orders.Properties.Resources.arrow_back32;
      this.btnPercentDown.Location = new System.Drawing.Point(17, 30);
      this.btnPercentDown.Name = "btnPercentDown";
      this.btnPercentDown.Size = new System.Drawing.Size(42, 37);
      this.btnPercentDown.TabIndex = 36;
      this.btnPercentDown.UseVisualStyleBackColor = false;
      this.btnPercentDown.Click += new System.EventHandler(this.btnPercentDown_Click);
      // 
      // btnPercentUp
      // 
      this.btnPercentUp.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnPercentUp.Image = global::workshop_orders.Properties.Resources.arrow_next32;
      this.btnPercentUp.Location = new System.Drawing.Point(65, 30);
      this.btnPercentUp.Name = "btnPercentUp";
      this.btnPercentUp.Size = new System.Drawing.Size(42, 37);
      this.btnPercentUp.TabIndex = 37;
      this.btnPercentUp.UseVisualStyleBackColor = false;
      this.btnPercentUp.Click += new System.EventHandler(this.btnPercentUp_Click);
      // 
      // panel1
      // 
      this.panel1.BackColor = System.Drawing.SystemColors.Control;
      this.panel1.Controls.Add(this.btnTime);
      this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
      this.panel1.Location = new System.Drawing.Point(0, 443);
      this.panel1.Name = "panel1";
      this.panel1.Padding = new System.Windows.Forms.Padding(5);
      this.panel1.Size = new System.Drawing.Size(589, 58);
      this.panel1.TabIndex = 51;
      // 
      // btnTime
      // 
      this.btnTime.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnTime.Dock = System.Windows.Forms.DockStyle.Right;
      this.btnTime.Enabled = false;
      this.btnTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnTime.Image = global::workshop_orders.Properties.Resources.hourglass32;
      this.btnTime.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
      this.btnTime.Location = new System.Drawing.Point(458, 5);
      this.btnTime.Name = "btnTime";
      this.btnTime.Size = new System.Drawing.Size(126, 48);
      this.btnTime.TabIndex = 48;
      this.btnTime.Text = "Add Time";
      this.btnTime.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      this.btnTime.UseVisualStyleBackColor = false;
      this.btnTime.Click += new System.EventHandler(this.btnTime_Click);
      // 
      // groupBox2
      // 
      this.groupBox2.Controls.Add(this.txtNote);
      this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.groupBox2.Location = new System.Drawing.Point(12, 319);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new System.Drawing.Size(561, 112);
      this.groupBox2.TabIndex = 52;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Note";
      // 
      // groupBox3
      // 
      this.groupBox3.Controls.Add(this.btnTextDown);
      this.groupBox3.Controls.Add(this.rbTextYes);
      this.groupBox3.Controls.Add(this.btnTextUp);
      this.groupBox3.Controls.Add(this.dtpTextDay);
      this.groupBox3.Controls.Add(this.dtpTextTime);
      this.groupBox3.Controls.Add(this.rbTextNo);
      this.groupBox3.Controls.Add(this.chkTextToday);
      this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.groupBox3.Location = new System.Drawing.Point(12, 148);
      this.groupBox3.Name = "groupBox3";
      this.groupBox3.Size = new System.Drawing.Size(561, 85);
      this.groupBox3.TabIndex = 53;
      this.groupBox3.TabStop = false;
      this.groupBox3.Text = "Text";
      // 
      // btnTextDown
      // 
      this.btnTextDown.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnTextDown.Image = global::workshop_orders.Properties.Resources.arrow_back32;
      this.btnTextDown.Location = new System.Drawing.Point(84, 20);
      this.btnTextDown.Name = "btnTextDown";
      this.btnTextDown.Size = new System.Drawing.Size(42, 37);
      this.btnTextDown.TabIndex = 40;
      this.btnTextDown.UseVisualStyleBackColor = false;
      this.btnTextDown.Visible = false;
      this.btnTextDown.Click += new System.EventHandler(this.btnTextDown_Click);
      // 
      // btnTextUp
      // 
      this.btnTextUp.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnTextUp.Image = global::workshop_orders.Properties.Resources.arrow_next32;
      this.btnTextUp.Location = new System.Drawing.Point(132, 20);
      this.btnTextUp.Name = "btnTextUp";
      this.btnTextUp.Size = new System.Drawing.Size(42, 37);
      this.btnTextUp.TabIndex = 41;
      this.btnTextUp.UseVisualStyleBackColor = false;
      this.btnTextUp.Visible = false;
      this.btnTextUp.Click += new System.EventHandler(this.btnTextUp_Click);
      // 
      // groupBox4
      // 
      this.groupBox4.Controls.Add(this.nudMilage);
      this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.groupBox4.Location = new System.Drawing.Point(12, 240);
      this.groupBox4.Name = "groupBox4";
      this.groupBox4.Size = new System.Drawing.Size(561, 68);
      this.groupBox4.TabIndex = 54;
      this.groupBox4.TabStop = false;
      this.groupBox4.Text = "Mileage";
      // 
      // groupBox5
      // 
      this.groupBox5.Controls.Add(this.rbNo);
      this.groupBox5.Controls.Add(this.rbYes);
      this.groupBox5.Controls.Add(this.label1);
      this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.groupBox5.Location = new System.Drawing.Point(12, 42);
      this.groupBox5.Name = "groupBox5";
      this.groupBox5.Size = new System.Drawing.Size(437, 100);
      this.groupBox5.TabIndex = 55;
      this.groupBox5.TabStop = false;
      this.groupBox5.Text = "Completion";
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label1.Location = new System.Drawing.Point(21, 30);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(151, 18);
      this.label1.TabIndex = 0;
      this.label1.Text = "Is this Job Complete?";
      // 
      // rbYes
      // 
      this.rbYes.AutoSize = true;
      this.rbYes.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.rbYes.Location = new System.Drawing.Point(29, 57);
      this.rbYes.Name = "rbYes";
      this.rbYes.Size = new System.Drawing.Size(51, 22);
      this.rbYes.TabIndex = 1;
      this.rbYes.TabStop = true;
      this.rbYes.Text = "Yes";
      this.rbYes.UseVisualStyleBackColor = true;
      // 
      // rbNo
      // 
      this.rbNo.AutoSize = true;
      this.rbNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.rbNo.Location = new System.Drawing.Point(119, 57);
      this.rbNo.Name = "rbNo";
      this.rbNo.Size = new System.Drawing.Size(46, 22);
      this.rbNo.TabIndex = 2;
      this.rbNo.TabStop = true;
      this.rbNo.Text = "No";
      this.rbNo.UseVisualStyleBackColor = true;
      // 
      // WorkshopLabour
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.ClientSize = new System.Drawing.Size(589, 501);
      this.Controls.Add(this.groupBox5);
      this.Controls.Add(this.groupBox2);
      this.Controls.Add(this.groupBox4);
      this.Controls.Add(this.groupBox3);
      this.Controls.Add(this.panel1);
      this.Controls.Add(this.groupBox1);
      this.Controls.Add(this.toolStrip1);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
      this.Name = "WorkshopLabour";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
      this.Text = "Labour";
      ((System.ComponentModel.ISupportInitialize)(this.nudMilage)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.tbrPercentage)).EndInit();
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.panel1.ResumeLayout(false);
      this.groupBox2.ResumeLayout(false);
      this.groupBox2.PerformLayout();
      this.groupBox3.ResumeLayout(false);
      this.groupBox3.PerformLayout();
      this.groupBox4.ResumeLayout(false);
      this.groupBox5.ResumeLayout(false);
      this.groupBox5.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Button btnTime;
    private System.Windows.Forms.CheckBox chkTextToday;
    private System.Windows.Forms.RadioButton rbTextNo;
    private System.Windows.Forms.RadioButton rbTextYes;
    private System.Windows.Forms.DateTimePicker dtpTextTime;
    private System.Windows.Forms.DateTimePicker dtpTextDay;
    private System.Windows.Forms.NumericUpDown nudMilage;
    private System.Windows.Forms.TextBox txtNote;
    private System.Windows.Forms.Button btnPercentDown;
    private System.Windows.Forms.TrackBar tbrPercentage;
    private System.Windows.Forms.Button btnPercentUp;
    private System.Windows.Forms.ToolStrip toolStrip1;
    private System.Windows.Forms.ToolStripButton tsBack;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.ToolStripButton tsTime;
    private System.Windows.Forms.Panel panel1;
    private System.Windows.Forms.Label lblPercent;
    private System.Windows.Forms.GroupBox groupBox2;
    private System.Windows.Forms.GroupBox groupBox3;
    private System.Windows.Forms.GroupBox groupBox4;
    private System.Windows.Forms.Label lblPercent2;
    private System.Windows.Forms.ToolStripLabel tsUser;
    private System.Windows.Forms.Button btnTextDown;
    private System.Windows.Forms.Button btnTextUp;
    private System.Windows.Forms.GroupBox groupBox5;
    private System.Windows.Forms.RadioButton rbNo;
    private System.Windows.Forms.RadioButton rbYes;
    private System.Windows.Forms.Label label1;
  }
}