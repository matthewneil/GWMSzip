﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workshop_orders
{
  public partial class SupplierDetail : Form
  {
    private int SupplierID = -1;
    public SupplierDetail(int SupplierID)
    {
      InitializeComponent();
      this.SupplierID = SupplierID;

      LoadCustomerData();
      SetButtonState(DataAccess.FormState(this.AccessibilityObject.Name, tsSave));
    }

  private void SetButtonState(Boolean bState)
  {
      tsInactive.Enabled = bState;
  }


  private void LoadCustomerData()
    {
      DataTable dt = DataAccess.ExecuteDataTable("SELECT * FROM supplier WHERE SupplierID = " + SupplierID);
      if(dt.Rows.Count > 0)
      {
        txtName.Text = dt.Rows[0]["SupplierName"].ToString();
        txtCode.Text = dt.Rows[0]["supCode"].ToString();
        txtMobileNo.Text = dt.Rows[0]["supMobile"].ToString();
        txtEmail.Text = dt.Rows[0]["supEmail"].ToString();
        txtPhoneNo.Text = dt.Rows[0]["supPhone"].ToString();

        txtAddress.Text = dt.Rows[0]["supAddress"].ToString();
        txtCity.Text = dt.Rows[0]["supCity"].ToString();      
        txtPostcode.Text = dt.Rows[0]["supPostCode"].ToString();
        txtPoBox.Text = dt.Rows[0]["supPOBox"].ToString();

        if (dt.Rows[0]["supDisabled"].ToString() == "1")
        {
          lblActive.Text = "Inactive";
          tsInactive.Text = "Set to Active";
        }

        txtAddress1.Text = dt.Rows[0]["supAddress1"].ToString();
        txtAddress2.Text = dt.Rows[0]["supAddress2"].ToString();
      }
    }

    private void tsClose_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private void tabPage1_Click(object sender, EventArgs e)
    {

    }

    private void tsSave_Click(object sender, EventArgs e)
    {
      DataAccess.SupplierManage(SupplierID, txtName.Text, txtAddress.Text, txtAddress1.Text, txtAddress2.Text, txtCity.Text, int.Parse(txtPostcode.Text), txtPoBox.Text, "",
        txtPhoneNo.Text, "", txtMobileNo.Text, txtEmail.Text, "", txtCode.Text, 0, -1, "");

      DataAccess.ShowMessage("Supplier Details saved successfully");
    }
  }
}
