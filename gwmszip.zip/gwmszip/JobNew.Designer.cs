﻿namespace workshop_orders
{
  partial class JobNew
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
      this.gbCustomer = new System.Windows.Forms.GroupBox();
      this.groupBox5 = new System.Windows.Forms.GroupBox();
      this.txtCustomer = new System.Windows.Forms.TextBox();
      this.btnCustomer = new System.Windows.Forms.Button();
      this.gbVehicle = new System.Windows.Forms.GroupBox();
      this.groupBox2 = new System.Windows.Forms.GroupBox();
      this.dgvVehicle = new System.Windows.Forms.DataGridView();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.txtVehicle = new System.Windows.Forms.TextBox();
      this.btnVehicle = new System.Windows.Forms.Button();
      this.gbType = new System.Windows.Forms.GroupBox();
      this.chkMilage = new System.Windows.Forms.CheckBox();
      this.cmbType = new System.Windows.Forms.ComboBox();
      this.label31 = new System.Windows.Forms.Label();
      this.rbGlass = new System.Windows.Forms.RadioButton();
      this.rbAuto = new System.Windows.Forms.RadioButton();
      this.gbAccount = new System.Windows.Forms.GroupBox();
      this.lblInsurance = new System.Windows.Forms.Label();
      this.txtAccountNo = new System.Windows.Forms.TextBox();
      this.lblAccountNo = new System.Windows.Forms.Label();
      this.cmbInsurance = new System.Windows.Forms.ComboBox();
      this.txtAccountName = new System.Windows.Forms.TextBox();
      this.lblAccountName = new System.Windows.Forms.Label();
      this.label1 = new System.Windows.Forms.Label();
      this.cmbPayment = new System.Windows.Forms.ComboBox();
      this.gbOnsite = new System.Windows.Forms.GroupBox();
      this.rbOnsite = new System.Windows.Forms.RadioButton();
      this.rbWorkshop = new System.Windows.Forms.RadioButton();
      this.lblArea = new System.Windows.Forms.Label();
      this.cmbArea = new System.Windows.Forms.ComboBox();
      this.txtAddress = new System.Windows.Forms.TextBox();
      this.lblAddress = new System.Windows.Forms.Label();
      this.gbBooking = new System.Windows.Forms.GroupBox();
      this.chkBooking = new System.Windows.Forms.CheckBox();
      this.btnTimeForward = new System.Windows.Forms.Button();
      this.btnTimeBack = new System.Windows.Forms.Button();
      this.dtpBookTime = new System.Windows.Forms.DateTimePicker();
      this.dtpBookDate = new System.Windows.Forms.DateTimePicker();
      this.gbReference = new System.Windows.Forms.GroupBox();
      this.groupBox4 = new System.Windows.Forms.GroupBox();
      this.txtNote = new System.Windows.Forms.TextBox();
      this.groupBox3 = new System.Windows.Forms.GroupBox();
      this.txtReference = new System.Windows.Forms.TextBox();
      this.JobNameLabel = new System.Windows.Forms.Label();
      this.panel1 = new System.Windows.Forms.Panel();
      this.rbReference = new System.Windows.Forms.RadioButton();
      this.rbBooking = new System.Windows.Forms.RadioButton();
      this.rbVehicle = new System.Windows.Forms.RadioButton();
      this.rbAccount = new System.Windows.Forms.RadioButton();
      this.rbOnsitePanel = new System.Windows.Forms.RadioButton();
      this.rbCustomer = new System.Windows.Forms.RadioButton();
      this.rbType = new System.Windows.Forms.RadioButton();
      this.toolStrip2 = new System.Windows.Forms.ToolStrip();
      this.tsPrevious = new System.Windows.Forms.ToolStripButton();
      this.tsNext = new System.Windows.Forms.ToolStripButton();
      this.tsSave = new System.Windows.Forms.ToolStripButton();
      this.panel2 = new System.Windows.Forms.Panel();
      this.btnSave = new System.Windows.Forms.Button();
      this.btnCancel = new System.Windows.Forms.Button();
      this.chID = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chRego = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.chVehicle = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.gbCustomer.SuspendLayout();
      this.groupBox5.SuspendLayout();
      this.gbVehicle.SuspendLayout();
      this.groupBox2.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgvVehicle)).BeginInit();
      this.groupBox1.SuspendLayout();
      this.gbType.SuspendLayout();
      this.gbAccount.SuspendLayout();
      this.gbOnsite.SuspendLayout();
      this.gbBooking.SuspendLayout();
      this.gbReference.SuspendLayout();
      this.groupBox4.SuspendLayout();
      this.groupBox3.SuspendLayout();
      this.panel1.SuspendLayout();
      this.toolStrip2.SuspendLayout();
      this.panel2.SuspendLayout();
      this.SuspendLayout();
      // 
      // gbCustomer
      // 
      this.gbCustomer.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.gbCustomer.Controls.Add(this.groupBox5);
      this.gbCustomer.Dock = System.Windows.Forms.DockStyle.Fill;
      this.gbCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbCustomer.Location = new System.Drawing.Point(230, 39);
      this.gbCustomer.Name = "gbCustomer";
      this.gbCustomer.Size = new System.Drawing.Size(599, 391);
      this.gbCustomer.TabIndex = 1;
      this.gbCustomer.TabStop = false;
      this.gbCustomer.Text = "Customer";
      // 
      // groupBox5
      // 
      this.groupBox5.Controls.Add(this.txtCustomer);
      this.groupBox5.Controls.Add(this.btnCustomer);
      this.groupBox5.Dock = System.Windows.Forms.DockStyle.Top;
      this.groupBox5.Location = new System.Drawing.Point(3, 20);
      this.groupBox5.Name = "groupBox5";
      this.groupBox5.Size = new System.Drawing.Size(593, 69);
      this.groupBox5.TabIndex = 10;
      this.groupBox5.TabStop = false;
      // 
      // txtCustomer
      // 
      this.txtCustomer.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
      this.txtCustomer.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
      this.txtCustomer.Cursor = System.Windows.Forms.Cursors.Default;
      this.txtCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtCustomer.Location = new System.Drawing.Point(169, 25);
      this.txtCustomer.Name = "txtCustomer";
      this.txtCustomer.ReadOnly = true;
      this.txtCustomer.Size = new System.Drawing.Size(412, 26);
      this.txtCustomer.TabIndex = 8;
      // 
      // btnCustomer
      // 
      this.btnCustomer.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.btnCustomer.BackgroundImage = global::workshop_orders.Properties.Resources.customers32;
      this.btnCustomer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
      this.btnCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnCustomer.ForeColor = System.Drawing.Color.Black;
      this.btnCustomer.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
      this.btnCustomer.Location = new System.Drawing.Point(3, 20);
      this.btnCustomer.Margin = new System.Windows.Forms.Padding(0);
      this.btnCustomer.Name = "btnCustomer";
      this.btnCustomer.Size = new System.Drawing.Size(158, 36);
      this.btnCustomer.TabIndex = 9;
      this.btnCustomer.Text = "Find Customer";
      this.btnCustomer.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      this.btnCustomer.UseVisualStyleBackColor = false;
      this.btnCustomer.Click += new System.EventHandler(this.btnCustomer_Click);
      // 
      // gbVehicle
      // 
      this.gbVehicle.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.gbVehicle.Controls.Add(this.groupBox2);
      this.gbVehicle.Controls.Add(this.groupBox1);
      this.gbVehicle.Dock = System.Windows.Forms.DockStyle.Fill;
      this.gbVehicle.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbVehicle.Location = new System.Drawing.Point(230, 39);
      this.gbVehicle.Name = "gbVehicle";
      this.gbVehicle.Size = new System.Drawing.Size(599, 391);
      this.gbVehicle.TabIndex = 10;
      this.gbVehicle.TabStop = false;
      this.gbVehicle.Text = "Vehicle";
      // 
      // groupBox2
      // 
      this.groupBox2.Controls.Add(this.dgvVehicle);
      this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
      this.groupBox2.Location = new System.Drawing.Point(3, 86);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new System.Drawing.Size(593, 302);
      this.groupBox2.TabIndex = 46;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Vehicles previously used by this customer";
      // 
      // dgvVehicle
      // 
      this.dgvVehicle.AllowUserToAddRows = false;
      this.dgvVehicle.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
      dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
      dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
      dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
      dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
      dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
      dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
      this.dgvVehicle.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
      this.dgvVehicle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvVehicle.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.chID,
            this.chRego,
            this.chVehicle});
      dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
      dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
      dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
      dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
      dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
      dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
      this.dgvVehicle.DefaultCellStyle = dataGridViewCellStyle2;
      this.dgvVehicle.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dgvVehicle.Location = new System.Drawing.Point(3, 20);
      this.dgvVehicle.Name = "dgvVehicle";
      dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
      dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
      dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
      dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
      dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
      dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
      this.dgvVehicle.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
      this.dgvVehicle.RowHeadersWidth = 5;
      this.dgvVehicle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
      this.dgvVehicle.Size = new System.Drawing.Size(587, 279);
      this.dgvVehicle.TabIndex = 44;
      this.dgvVehicle.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvVehicle_CellDoubleClick);
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.Add(this.txtVehicle);
      this.groupBox1.Controls.Add(this.btnVehicle);
      this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
      this.groupBox1.Location = new System.Drawing.Point(3, 20);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(593, 66);
      this.groupBox1.TabIndex = 45;
      this.groupBox1.TabStop = false;
      // 
      // txtVehicle
      // 
      this.txtVehicle.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
      this.txtVehicle.Cursor = System.Windows.Forms.Cursors.Default;
      this.txtVehicle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtVehicle.Location = new System.Drawing.Point(147, 23);
      this.txtVehicle.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
      this.txtVehicle.MaxLength = 6;
      this.txtVehicle.Name = "txtVehicle";
      this.txtVehicle.ReadOnly = true;
      this.txtVehicle.Size = new System.Drawing.Size(434, 26);
      this.txtVehicle.TabIndex = 42;
      // 
      // btnVehicle
      // 
      this.btnVehicle.BackColor = System.Drawing.Color.White;
      this.btnVehicle.BackgroundImage = global::workshop_orders.Properties.Resources.find;
      this.btnVehicle.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
      this.btnVehicle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnVehicle.ForeColor = System.Drawing.Color.Black;
      this.btnVehicle.Location = new System.Drawing.Point(3, 14);
      this.btnVehicle.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
      this.btnVehicle.Name = "btnVehicle";
      this.btnVehicle.Size = new System.Drawing.Size(136, 43);
      this.btnVehicle.TabIndex = 43;
      this.btnVehicle.Text = "Find Vehicle";
      this.btnVehicle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      this.btnVehicle.UseVisualStyleBackColor = false;
      this.btnVehicle.Click += new System.EventHandler(this.btnVehicle_Click);
      // 
      // gbType
      // 
      this.gbType.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.gbType.Controls.Add(this.chkMilage);
      this.gbType.Controls.Add(this.cmbType);
      this.gbType.Controls.Add(this.label31);
      this.gbType.Controls.Add(this.rbGlass);
      this.gbType.Controls.Add(this.rbAuto);
      this.gbType.Dock = System.Windows.Forms.DockStyle.Fill;
      this.gbType.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbType.Location = new System.Drawing.Point(230, 39);
      this.gbType.Name = "gbType";
      this.gbType.Size = new System.Drawing.Size(599, 391);
      this.gbType.TabIndex = 45;
      this.gbType.TabStop = false;
      this.gbType.Text = "Job Type";
      // 
      // chkMilage
      // 
      this.chkMilage.AutoSize = true;
      this.chkMilage.Location = new System.Drawing.Point(34, 139);
      this.chkMilage.Name = "chkMilage";
      this.chkMilage.Size = new System.Drawing.Size(148, 22);
      this.chkMilage.TabIndex = 208;
      this.chkMilage.Text = "Milage Required";
      this.chkMilage.UseVisualStyleBackColor = true;
      // 
      // cmbType
      // 
      this.cmbType.DisplayMember = "textfield";
      this.cmbType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.cmbType.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbType.FormattingEnabled = true;
      this.cmbType.Location = new System.Drawing.Point(113, 69);
      this.cmbType.Name = "cmbType";
      this.cmbType.Size = new System.Drawing.Size(171, 28);
      this.cmbType.TabIndex = 207;
      this.cmbType.ValueMember = "datafield";
      this.cmbType.SelectedIndexChanged += new System.EventHandler(this.cmbType_SelectedIndexChanged);
      // 
      // label31
      // 
      this.label31.AutoSize = true;
      this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label31.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
      this.label31.Location = new System.Drawing.Point(30, 72);
      this.label31.Name = "label31";
      this.label31.Size = new System.Drawing.Size(77, 20);
      this.label31.TabIndex = 46;
      this.label31.Text = "Job Type:";
      // 
      // rbGlass
      // 
      this.rbGlass.AutoSize = true;
      this.rbGlass.Location = new System.Drawing.Point(118, 35);
      this.rbGlass.Name = "rbGlass";
      this.rbGlass.Size = new System.Drawing.Size(70, 22);
      this.rbGlass.TabIndex = 2;
      this.rbGlass.Text = "Glass";
      this.rbGlass.UseVisualStyleBackColor = true;
      this.rbGlass.CheckedChanged += new System.EventHandler(this.rbGlass_CheckedChanged);
      // 
      // rbAuto
      // 
      this.rbAuto.AutoSize = true;
      this.rbAuto.Checked = true;
      this.rbAuto.Location = new System.Drawing.Point(34, 35);
      this.rbAuto.Name = "rbAuto";
      this.rbAuto.Size = new System.Drawing.Size(60, 22);
      this.rbAuto.TabIndex = 1;
      this.rbAuto.TabStop = true;
      this.rbAuto.Text = "Auto";
      this.rbAuto.UseVisualStyleBackColor = true;
      this.rbAuto.CheckedChanged += new System.EventHandler(this.rbAuto_CheckedChanged);
      // 
      // gbAccount
      // 
      this.gbAccount.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.gbAccount.Controls.Add(this.lblInsurance);
      this.gbAccount.Controls.Add(this.txtAccountNo);
      this.gbAccount.Controls.Add(this.lblAccountNo);
      this.gbAccount.Controls.Add(this.cmbInsurance);
      this.gbAccount.Controls.Add(this.txtAccountName);
      this.gbAccount.Controls.Add(this.lblAccountName);
      this.gbAccount.Controls.Add(this.label1);
      this.gbAccount.Controls.Add(this.cmbPayment);
      this.gbAccount.Dock = System.Windows.Forms.DockStyle.Fill;
      this.gbAccount.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbAccount.Location = new System.Drawing.Point(230, 39);
      this.gbAccount.Name = "gbAccount";
      this.gbAccount.Size = new System.Drawing.Size(599, 391);
      this.gbAccount.TabIndex = 45;
      this.gbAccount.TabStop = false;
      this.gbAccount.Text = "Payment";
      // 
      // lblInsurance
      // 
      this.lblInsurance.AutoSize = true;
      this.lblInsurance.Enabled = false;
      this.lblInsurance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblInsurance.ForeColor = System.Drawing.Color.Black;
      this.lblInsurance.Location = new System.Drawing.Point(49, 108);
      this.lblInsurance.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.lblInsurance.Name = "lblInsurance";
      this.lblInsurance.Size = new System.Drawing.Size(70, 20);
      this.lblInsurance.TabIndex = 216;
      this.lblInsurance.Text = "Provider:";
      // 
      // txtAccountNo
      // 
      this.txtAccountNo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
      this.txtAccountNo.Enabled = false;
      this.txtAccountNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtAccountNo.Location = new System.Drawing.Point(127, 170);
      this.txtAccountNo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
      this.txtAccountNo.MaxLength = 30;
      this.txtAccountNo.Name = "txtAccountNo";
      this.txtAccountNo.Size = new System.Drawing.Size(237, 26);
      this.txtAccountNo.TabIndex = 215;
      this.txtAccountNo.TextChanged += new System.EventHandler(this.txtAccountNo_TextChanged);
      // 
      // lblAccountNo
      // 
      this.lblAccountNo.AutoSize = true;
      this.lblAccountNo.Enabled = false;
      this.lblAccountNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblAccountNo.ForeColor = System.Drawing.Color.Black;
      this.lblAccountNo.Location = new System.Drawing.Point(27, 174);
      this.lblAccountNo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.lblAccountNo.Name = "lblAccountNo";
      this.lblAccountNo.Size = new System.Drawing.Size(96, 20);
      this.lblAccountNo.TabIndex = 217;
      this.lblAccountNo.Text = "Account No:";
      // 
      // cmbInsurance
      // 
      this.cmbInsurance.DisplayMember = "textfield";
      this.cmbInsurance.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.cmbInsurance.Enabled = false;
      this.cmbInsurance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbInsurance.FormattingEnabled = true;
      this.cmbInsurance.Location = new System.Drawing.Point(127, 104);
      this.cmbInsurance.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
      this.cmbInsurance.Name = "cmbInsurance";
      this.cmbInsurance.Size = new System.Drawing.Size(237, 28);
      this.cmbInsurance.TabIndex = 213;
      this.cmbInsurance.ValueMember = "datafield";
      this.cmbInsurance.SelectedValueChanged += new System.EventHandler(this.cmbInsurance_SelectedValueChanged);
      // 
      // txtAccountName
      // 
      this.txtAccountName.Enabled = false;
      this.txtAccountName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtAccountName.Location = new System.Drawing.Point(127, 139);
      this.txtAccountName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
      this.txtAccountName.MaxLength = 30;
      this.txtAccountName.Name = "txtAccountName";
      this.txtAccountName.Size = new System.Drawing.Size(237, 26);
      this.txtAccountName.TabIndex = 214;
      this.txtAccountName.TextChanged += new System.EventHandler(this.txtAccountName_TextChanged);
      // 
      // lblAccountName
      // 
      this.lblAccountName.AutoSize = true;
      this.lblAccountName.Enabled = false;
      this.lblAccountName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblAccountName.ForeColor = System.Drawing.Color.Black;
      this.lblAccountName.Location = new System.Drawing.Point(5, 143);
      this.lblAccountName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.lblAccountName.Name = "lblAccountName";
      this.lblAccountName.Size = new System.Drawing.Size(118, 20);
      this.lblAccountName.TabIndex = 218;
      this.lblAccountName.Text = "Account Name:";
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
      this.label1.Location = new System.Drawing.Point(46, 38);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(75, 20);
      this.label1.TabIndex = 212;
      this.label1.Text = "Payment:";
      // 
      // cmbPayment
      // 
      this.cmbPayment.DisplayMember = "textfield";
      this.cmbPayment.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.cmbPayment.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbPayment.FormattingEnabled = true;
      this.cmbPayment.Location = new System.Drawing.Point(127, 35);
      this.cmbPayment.Name = "cmbPayment";
      this.cmbPayment.Size = new System.Drawing.Size(171, 28);
      this.cmbPayment.TabIndex = 211;
      this.cmbPayment.ValueMember = "datafield";
      this.cmbPayment.SelectedValueChanged += new System.EventHandler(this.cmbPayment_SelectedValueChanged);
      // 
      // gbOnsite
      // 
      this.gbOnsite.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.gbOnsite.Controls.Add(this.rbOnsite);
      this.gbOnsite.Controls.Add(this.rbWorkshop);
      this.gbOnsite.Controls.Add(this.lblArea);
      this.gbOnsite.Controls.Add(this.cmbArea);
      this.gbOnsite.Controls.Add(this.txtAddress);
      this.gbOnsite.Controls.Add(this.lblAddress);
      this.gbOnsite.Dock = System.Windows.Forms.DockStyle.Fill;
      this.gbOnsite.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbOnsite.Location = new System.Drawing.Point(230, 39);
      this.gbOnsite.Name = "gbOnsite";
      this.gbOnsite.Size = new System.Drawing.Size(599, 391);
      this.gbOnsite.TabIndex = 219;
      this.gbOnsite.TabStop = false;
      this.gbOnsite.Text = "Onsite Address";
      // 
      // rbOnsite
      // 
      this.rbOnsite.AutoSize = true;
      this.rbOnsite.Location = new System.Drawing.Point(162, 35);
      this.rbOnsite.Name = "rbOnsite";
      this.rbOnsite.Size = new System.Drawing.Size(75, 22);
      this.rbOnsite.TabIndex = 48;
      this.rbOnsite.Text = "Onsite";
      this.rbOnsite.UseVisualStyleBackColor = true;
      this.rbOnsite.CheckedChanged += new System.EventHandler(this.rbOnsite_CheckedChanged_1);
      // 
      // rbWorkshop
      // 
      this.rbWorkshop.AutoSize = true;
      this.rbWorkshop.Checked = true;
      this.rbWorkshop.Location = new System.Drawing.Point(43, 35);
      this.rbWorkshop.Name = "rbWorkshop";
      this.rbWorkshop.Size = new System.Drawing.Size(104, 22);
      this.rbWorkshop.TabIndex = 47;
      this.rbWorkshop.TabStop = true;
      this.rbWorkshop.Text = "Workshop";
      this.rbWorkshop.UseVisualStyleBackColor = true;
      this.rbWorkshop.CheckedChanged += new System.EventHandler(this.rbWorkshop_CheckedChanged);
      // 
      // lblArea
      // 
      this.lblArea.AutoSize = true;
      this.lblArea.Enabled = false;
      this.lblArea.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblArea.ForeColor = System.Drawing.Color.Black;
      this.lblArea.Location = new System.Drawing.Point(58, 78);
      this.lblArea.Name = "lblArea";
      this.lblArea.Size = new System.Drawing.Size(47, 20);
      this.lblArea.TabIndex = 221;
      this.lblArea.Text = "Area:";
      // 
      // cmbArea
      // 
      this.cmbArea.DisplayMember = "textfield";
      this.cmbArea.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.cmbArea.Enabled = false;
      this.cmbArea.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmbArea.ForeColor = System.Drawing.Color.Black;
      this.cmbArea.FormattingEnabled = true;
      this.cmbArea.Items.AddRange(new object[] {
            "Gore",
            "Northern Southland",
            "West Otago",
            "Mataura",
            "Edendale",
            "Invercargill"});
      this.cmbArea.Location = new System.Drawing.Point(110, 74);
      this.cmbArea.Name = "cmbArea";
      this.cmbArea.Size = new System.Drawing.Size(180, 28);
      this.cmbArea.TabIndex = 219;
      this.cmbArea.ValueMember = "datafield";
      this.cmbArea.SelectedValueChanged += new System.EventHandler(this.cmbArea_SelectedValueChanged);
      // 
      // txtAddress
      // 
      this.txtAddress.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
      this.txtAddress.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
      this.txtAddress.Enabled = false;
      this.txtAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtAddress.ForeColor = System.Drawing.Color.Black;
      this.txtAddress.Location = new System.Drawing.Point(109, 112);
      this.txtAddress.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
      this.txtAddress.MaxLength = 50;
      this.txtAddress.Name = "txtAddress";
      this.txtAddress.Size = new System.Drawing.Size(180, 26);
      this.txtAddress.TabIndex = 218;
      this.txtAddress.TextChanged += new System.EventHandler(this.txtAddress_TextChanged);
      // 
      // lblAddress
      // 
      this.lblAddress.AutoSize = true;
      this.lblAddress.Enabled = false;
      this.lblAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblAddress.ForeColor = System.Drawing.Color.Black;
      this.lblAddress.Location = new System.Drawing.Point(37, 114);
      this.lblAddress.Name = "lblAddress";
      this.lblAddress.Size = new System.Drawing.Size(72, 20);
      this.lblAddress.TabIndex = 220;
      this.lblAddress.Text = "Address:";
      // 
      // gbBooking
      // 
      this.gbBooking.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.gbBooking.Controls.Add(this.chkBooking);
      this.gbBooking.Controls.Add(this.btnTimeForward);
      this.gbBooking.Controls.Add(this.btnTimeBack);
      this.gbBooking.Controls.Add(this.dtpBookTime);
      this.gbBooking.Controls.Add(this.dtpBookDate);
      this.gbBooking.Dock = System.Windows.Forms.DockStyle.Fill;
      this.gbBooking.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbBooking.Location = new System.Drawing.Point(230, 39);
      this.gbBooking.Name = "gbBooking";
      this.gbBooking.Size = new System.Drawing.Size(599, 391);
      this.gbBooking.TabIndex = 222;
      this.gbBooking.TabStop = false;
      this.gbBooking.Text = "Booking";
      // 
      // chkBooking
      // 
      this.chkBooking.AutoSize = true;
      this.chkBooking.Checked = true;
      this.chkBooking.CheckState = System.Windows.Forms.CheckState.Checked;
      this.chkBooking.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.chkBooking.ForeColor = System.Drawing.Color.Black;
      this.chkBooking.Location = new System.Drawing.Point(16, 23);
      this.chkBooking.Name = "chkBooking";
      this.chkBooking.Size = new System.Drawing.Size(214, 24);
      this.chkBooking.TabIndex = 168;
      this.chkBooking.Text = "There is no booking yet";
      this.chkBooking.UseVisualStyleBackColor = true;
      this.chkBooking.CheckedChanged += new System.EventHandler(this.chkBooking_CheckedChanged);
      // 
      // btnTimeForward
      // 
      this.btnTimeForward.BackColor = System.Drawing.Color.White;
      this.btnTimeForward.BackgroundImage = global::workshop_orders.Properties.Resources.arrow_next32;
      this.btnTimeForward.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
      this.btnTimeForward.Enabled = false;
      this.btnTimeForward.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnTimeForward.ForeColor = System.Drawing.Color.Black;
      this.btnTimeForward.Location = new System.Drawing.Point(172, 91);
      this.btnTimeForward.Name = "btnTimeForward";
      this.btnTimeForward.Size = new System.Drawing.Size(31, 27);
      this.btnTimeForward.TabIndex = 167;
      this.btnTimeForward.UseVisualStyleBackColor = false;
      this.btnTimeForward.Click += new System.EventHandler(this.btnTimeForward_Click);
      // 
      // btnTimeBack
      // 
      this.btnTimeBack.BackColor = System.Drawing.Color.White;
      this.btnTimeBack.BackgroundImage = global::workshop_orders.Properties.Resources.arrow_back32;
      this.btnTimeBack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
      this.btnTimeBack.Enabled = false;
      this.btnTimeBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.btnTimeBack.ForeColor = System.Drawing.Color.Black;
      this.btnTimeBack.Location = new System.Drawing.Point(16, 91);
      this.btnTimeBack.Name = "btnTimeBack";
      this.btnTimeBack.Size = new System.Drawing.Size(29, 26);
      this.btnTimeBack.TabIndex = 166;
      this.btnTimeBack.UseVisualStyleBackColor = false;
      this.btnTimeBack.Click += new System.EventHandler(this.btnTimeBack_Click);
      // 
      // dtpBookTime
      // 
      this.dtpBookTime.CustomFormat = "hh:mm tt";
      this.dtpBookTime.Enabled = false;
      this.dtpBookTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.dtpBookTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
      this.dtpBookTime.Location = new System.Drawing.Point(51, 91);
      this.dtpBookTime.Name = "dtpBookTime";
      this.dtpBookTime.Size = new System.Drawing.Size(115, 26);
      this.dtpBookTime.TabIndex = 165;
      this.dtpBookTime.Value = new System.DateTime(2020, 11, 20, 8, 0, 0, 0);
      // 
      // dtpBookDate
      // 
      this.dtpBookDate.CustomFormat = " ddd dd MMM yyyy";
      this.dtpBookDate.Enabled = false;
      this.dtpBookDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.dtpBookDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
      this.dtpBookDate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
      this.dtpBookDate.Location = new System.Drawing.Point(16, 57);
      this.dtpBookDate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
      this.dtpBookDate.MinDate = new System.DateTime(2020, 1, 1, 0, 0, 0, 0);
      this.dtpBookDate.Name = "dtpBookDate";
      this.dtpBookDate.Size = new System.Drawing.Size(186, 26);
      this.dtpBookDate.TabIndex = 164;
      this.dtpBookDate.Value = new System.DateTime(2020, 6, 29, 13, 1, 44, 0);
      // 
      // gbReference
      // 
      this.gbReference.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.gbReference.Controls.Add(this.groupBox4);
      this.gbReference.Controls.Add(this.groupBox3);
      this.gbReference.Dock = System.Windows.Forms.DockStyle.Fill;
      this.gbReference.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.gbReference.Location = new System.Drawing.Point(230, 39);
      this.gbReference.Name = "gbReference";
      this.gbReference.Size = new System.Drawing.Size(599, 391);
      this.gbReference.TabIndex = 223;
      this.gbReference.TabStop = false;
      this.gbReference.Text = "Reference and Note";
      // 
      // groupBox4
      // 
      this.groupBox4.Controls.Add(this.txtNote);
      this.groupBox4.Dock = System.Windows.Forms.DockStyle.Fill;
      this.groupBox4.Location = new System.Drawing.Point(3, 75);
      this.groupBox4.Name = "groupBox4";
      this.groupBox4.Size = new System.Drawing.Size(593, 313);
      this.groupBox4.TabIndex = 5;
      this.groupBox4.TabStop = false;
      this.groupBox4.Text = "Note";
      // 
      // txtNote
      // 
      this.txtNote.AcceptsReturn = true;
      this.txtNote.Dock = System.Windows.Forms.DockStyle.Fill;
      this.txtNote.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtNote.Location = new System.Drawing.Point(3, 20);
      this.txtNote.MaxLength = 5000;
      this.txtNote.Multiline = true;
      this.txtNote.Name = "txtNote";
      this.txtNote.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
      this.txtNote.Size = new System.Drawing.Size(587, 290);
      this.txtNote.TabIndex = 211;
      this.txtNote.TextChanged += new System.EventHandler(this.txtNote_TextChanged);
      // 
      // groupBox3
      // 
      this.groupBox3.Controls.Add(this.txtReference);
      this.groupBox3.Controls.Add(this.JobNameLabel);
      this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
      this.groupBox3.Location = new System.Drawing.Point(3, 20);
      this.groupBox3.Name = "groupBox3";
      this.groupBox3.Size = new System.Drawing.Size(593, 55);
      this.groupBox3.TabIndex = 212;
      this.groupBox3.TabStop = false;
      // 
      // txtReference
      // 
      this.txtReference.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtReference.Location = new System.Drawing.Point(105, 17);
      this.txtReference.MaxLength = 100;
      this.txtReference.Name = "txtReference";
      this.txtReference.Size = new System.Drawing.Size(476, 26);
      this.txtReference.TabIndex = 3;
      this.txtReference.TextChanged += new System.EventHandler(this.txtReference_TextChanged);
      // 
      // JobNameLabel
      // 
      this.JobNameLabel.AutoSize = true;
      this.JobNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.JobNameLabel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
      this.JobNameLabel.Location = new System.Drawing.Point(9, 18);
      this.JobNameLabel.Name = "JobNameLabel";
      this.JobNameLabel.Size = new System.Drawing.Size(88, 20);
      this.JobNameLabel.TabIndex = 4;
      this.JobNameLabel.Text = "Reference:";
      // 
      // panel1
      // 
      this.panel1.BackColor = System.Drawing.Color.Gray;
      this.panel1.Controls.Add(this.rbReference);
      this.panel1.Controls.Add(this.rbBooking);
      this.panel1.Controls.Add(this.rbVehicle);
      this.panel1.Controls.Add(this.rbAccount);
      this.panel1.Controls.Add(this.rbOnsitePanel);
      this.panel1.Controls.Add(this.rbCustomer);
      this.panel1.Controls.Add(this.rbType);
      this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
      this.panel1.Location = new System.Drawing.Point(0, 0);
      this.panel1.Name = "panel1";
      this.panel1.Size = new System.Drawing.Size(230, 480);
      this.panel1.TabIndex = 225;
      // 
      // rbReference
      // 
      this.rbReference.AutoSize = true;
      this.rbReference.Enabled = false;
      this.rbReference.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.rbReference.ForeColor = System.Drawing.Color.White;
      this.rbReference.Location = new System.Drawing.Point(39, 205);
      this.rbReference.Name = "rbReference";
      this.rbReference.Size = new System.Drawing.Size(158, 22);
      this.rbReference.TabIndex = 232;
      this.rbReference.Text = "Reference and Note";
      this.rbReference.UseVisualStyleBackColor = true;
      this.rbReference.CheckedChanged += new System.EventHandler(this.rbReference_CheckedChanged);
      // 
      // rbBooking
      // 
      this.rbBooking.AutoSize = true;
      this.rbBooking.Enabled = false;
      this.rbBooking.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.rbBooking.ForeColor = System.Drawing.Color.White;
      this.rbBooking.Location = new System.Drawing.Point(39, 173);
      this.rbBooking.Name = "rbBooking";
      this.rbBooking.Size = new System.Drawing.Size(81, 22);
      this.rbBooking.TabIndex = 231;
      this.rbBooking.Text = "Booking";
      this.rbBooking.UseVisualStyleBackColor = true;
      this.rbBooking.CheckedChanged += new System.EventHandler(this.rbBooking_CheckedChanged);
      // 
      // rbVehicle
      // 
      this.rbVehicle.AutoSize = true;
      this.rbVehicle.Enabled = false;
      this.rbVehicle.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.rbVehicle.ForeColor = System.Drawing.Color.White;
      this.rbVehicle.Location = new System.Drawing.Point(40, 86);
      this.rbVehicle.Name = "rbVehicle";
      this.rbVehicle.Size = new System.Drawing.Size(73, 22);
      this.rbVehicle.TabIndex = 230;
      this.rbVehicle.Text = "Vehicle";
      this.rbVehicle.UseVisualStyleBackColor = true;
      this.rbVehicle.CheckedChanged += new System.EventHandler(this.rbVehicle_CheckedChanged);
      // 
      // rbAccount
      // 
      this.rbAccount.AutoSize = true;
      this.rbAccount.Enabled = false;
      this.rbAccount.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.rbAccount.ForeColor = System.Drawing.Color.White;
      this.rbAccount.Location = new System.Drawing.Point(40, 114);
      this.rbAccount.Name = "rbAccount";
      this.rbAccount.Size = new System.Drawing.Size(84, 22);
      this.rbAccount.TabIndex = 229;
      this.rbAccount.Text = "Payment";
      this.rbAccount.UseVisualStyleBackColor = true;
      this.rbAccount.CheckedChanged += new System.EventHandler(this.rbAccount_CheckedChanged);
      // 
      // rbOnsitePanel
      // 
      this.rbOnsitePanel.AutoSize = true;
      this.rbOnsitePanel.Enabled = false;
      this.rbOnsitePanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.rbOnsitePanel.ForeColor = System.Drawing.Color.White;
      this.rbOnsitePanel.Location = new System.Drawing.Point(40, 145);
      this.rbOnsitePanel.Name = "rbOnsitePanel";
      this.rbOnsitePanel.Size = new System.Drawing.Size(69, 22);
      this.rbOnsitePanel.TabIndex = 228;
      this.rbOnsitePanel.Text = "Onsite";
      this.rbOnsitePanel.UseVisualStyleBackColor = true;
      this.rbOnsitePanel.CheckedChanged += new System.EventHandler(this.rbOnsite_CheckedChanged);
      // 
      // rbCustomer
      // 
      this.rbCustomer.AutoSize = true;
      this.rbCustomer.Checked = true;
      this.rbCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.rbCustomer.ForeColor = System.Drawing.Color.White;
      this.rbCustomer.Location = new System.Drawing.Point(39, 30);
      this.rbCustomer.Name = "rbCustomer";
      this.rbCustomer.Size = new System.Drawing.Size(92, 22);
      this.rbCustomer.TabIndex = 227;
      this.rbCustomer.TabStop = true;
      this.rbCustomer.Text = "Customer";
      this.rbCustomer.UseVisualStyleBackColor = true;
      this.rbCustomer.CheckedChanged += new System.EventHandler(this.rbCustomer_CheckedChanged);
      // 
      // rbType
      // 
      this.rbType.AutoSize = true;
      this.rbType.Enabled = false;
      this.rbType.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.rbType.ForeColor = System.Drawing.Color.White;
      this.rbType.Location = new System.Drawing.Point(39, 58);
      this.rbType.Name = "rbType";
      this.rbType.Size = new System.Drawing.Size(58, 22);
      this.rbType.TabIndex = 226;
      this.rbType.Text = "Type";
      this.rbType.UseVisualStyleBackColor = true;
      this.rbType.CheckedChanged += new System.EventHandler(this.rbType_CheckedChanged);
      // 
      // toolStrip2
      // 
      this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsPrevious,
            this.tsNext,
            this.tsSave});
      this.toolStrip2.Location = new System.Drawing.Point(230, 0);
      this.toolStrip2.Name = "toolStrip2";
      this.toolStrip2.Size = new System.Drawing.Size(599, 39);
      this.toolStrip2.TabIndex = 226;
      this.toolStrip2.Text = "toolStrip2";
      // 
      // tsPrevious
      // 
      this.tsPrevious.Image = global::workshop_orders.Properties.Resources.arrow_back32;
      this.tsPrevious.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsPrevious.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsPrevious.Name = "tsPrevious";
      this.tsPrevious.Size = new System.Drawing.Size(69, 36);
      this.tsPrevious.Text = "Prev.";
      this.tsPrevious.Click += new System.EventHandler(this.tsPrevious_Click);
      // 
      // tsNext
      // 
      this.tsNext.Image = global::workshop_orders.Properties.Resources.arrow_next32;
      this.tsNext.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsNext.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsNext.Name = "tsNext";
      this.tsNext.Size = new System.Drawing.Size(68, 36);
      this.tsNext.Text = "Next";
      this.tsNext.Click += new System.EventHandler(this.tsNext_Click);
      // 
      // tsSave
      // 
      this.tsSave.Image = global::workshop_orders.Properties.Resources.save;
      this.tsSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
      this.tsSave.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsSave.Name = "tsSave";
      this.tsSave.Size = new System.Drawing.Size(67, 36);
      this.tsSave.Text = "Save";
      this.tsSave.Visible = false;
      this.tsSave.Click += new System.EventHandler(this.tsSave_Click_1);
      // 
      // panel2
      // 
      this.panel2.Controls.Add(this.btnSave);
      this.panel2.Controls.Add(this.btnCancel);
      this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
      this.panel2.Location = new System.Drawing.Point(230, 430);
      this.panel2.Name = "panel2";
      this.panel2.Size = new System.Drawing.Size(599, 50);
      this.panel2.TabIndex = 11;
      // 
      // btnSave
      // 
      this.btnSave.Enabled = false;
      this.btnSave.Image = global::workshop_orders.Properties.Resources.save;
      this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
      this.btnSave.Location = new System.Drawing.Point(509, 5);
      this.btnSave.Name = "btnSave";
      this.btnSave.Size = new System.Drawing.Size(75, 39);
      this.btnSave.TabIndex = 1;
      this.btnSave.Text = "Save";
      this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      this.btnSave.UseVisualStyleBackColor = true;
      this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
      // 
      // btnCancel
      // 
      this.btnCancel.Image = global::workshop_orders.Properties.Resources.cancel32;
      this.btnCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
      this.btnCancel.Location = new System.Drawing.Point(422, 6);
      this.btnCancel.Name = "btnCancel";
      this.btnCancel.Size = new System.Drawing.Size(82, 38);
      this.btnCancel.TabIndex = 0;
      this.btnCancel.Text = "Cancel";
      this.btnCancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      this.btnCancel.UseVisualStyleBackColor = true;
      this.btnCancel.Click += new System.EventHandler(this.button2_Click);
      // 
      // chID
      // 
      this.chID.DataPropertyName = "VehicleID";
      this.chID.HeaderText = "ID";
      this.chID.Name = "chID";
      this.chID.ReadOnly = true;
      this.chID.Visible = false;
      // 
      // chRego
      // 
      this.chRego.DataPropertyName = "vRegistration";
      this.chRego.HeaderText = "Registration";
      this.chRego.Name = "chRego";
      this.chRego.ReadOnly = true;
      this.chRego.Width = 150;
      // 
      // chVehicle
      // 
      this.chVehicle.DataPropertyName = "vehicle";
      this.chVehicle.HeaderText = "Vehicle";
      this.chVehicle.Name = "chVehicle";
      this.chVehicle.ReadOnly = true;
      this.chVehicle.Width = 400;
      // 
      // JobNew
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.ClientSize = new System.Drawing.Size(829, 480);
      this.Controls.Add(this.gbVehicle);
      this.Controls.Add(this.gbType);
      this.Controls.Add(this.gbCustomer);
      this.Controls.Add(this.gbOnsite);
      this.Controls.Add(this.gbAccount);
      this.Controls.Add(this.gbReference);
      this.Controls.Add(this.gbBooking);
      this.Controls.Add(this.toolStrip2);
      this.Controls.Add(this.panel2);
      this.Controls.Add(this.panel1);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
      this.Name = "JobNew";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
      this.Text = "JobNew";
      this.gbCustomer.ResumeLayout(false);
      this.groupBox5.ResumeLayout(false);
      this.groupBox5.PerformLayout();
      this.gbVehicle.ResumeLayout(false);
      this.groupBox2.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.dgvVehicle)).EndInit();
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.gbType.ResumeLayout(false);
      this.gbType.PerformLayout();
      this.gbAccount.ResumeLayout(false);
      this.gbAccount.PerformLayout();
      this.gbOnsite.ResumeLayout(false);
      this.gbOnsite.PerformLayout();
      this.gbBooking.ResumeLayout(false);
      this.gbBooking.PerformLayout();
      this.gbReference.ResumeLayout(false);
      this.groupBox4.ResumeLayout(false);
      this.groupBox4.PerformLayout();
      this.groupBox3.ResumeLayout(false);
      this.groupBox3.PerformLayout();
      this.panel1.ResumeLayout(false);
      this.panel1.PerformLayout();
      this.toolStrip2.ResumeLayout(false);
      this.toolStrip2.PerformLayout();
      this.panel2.ResumeLayout(false);
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion
    private System.Windows.Forms.GroupBox gbCustomer;
    private System.Windows.Forms.Button btnCustomer;
    private System.Windows.Forms.TextBox txtCustomer;
    private System.Windows.Forms.GroupBox gbVehicle;
    private System.Windows.Forms.TextBox txtVehicle;
    private System.Windows.Forms.Button btnVehicle;
    private System.Windows.Forms.GroupBox gbType;
    private System.Windows.Forms.RadioButton rbGlass;
    private System.Windows.Forms.RadioButton rbAuto;
    private System.Windows.Forms.Label label31;
    private System.Windows.Forms.GroupBox gbAccount;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.ComboBox cmbPayment;
    private System.Windows.Forms.Label lblInsurance;
    private System.Windows.Forms.TextBox txtAccountNo;
    private System.Windows.Forms.Label lblAccountNo;
    private System.Windows.Forms.ComboBox cmbInsurance;
    private System.Windows.Forms.TextBox txtAccountName;
    private System.Windows.Forms.Label lblAccountName;
    private System.Windows.Forms.GroupBox gbOnsite;
    private System.Windows.Forms.Label lblArea;
    private System.Windows.Forms.ComboBox cmbArea;
    private System.Windows.Forms.TextBox txtAddress;
    private System.Windows.Forms.Label lblAddress;
    private System.Windows.Forms.RadioButton rbOnsite;
    private System.Windows.Forms.RadioButton rbWorkshop;
    private System.Windows.Forms.GroupBox gbBooking;
    private System.Windows.Forms.CheckBox chkBooking;
    private System.Windows.Forms.Button btnTimeForward;
    private System.Windows.Forms.Button btnTimeBack;
    private System.Windows.Forms.DateTimePicker dtpBookTime;
    private System.Windows.Forms.DateTimePicker dtpBookDate;
    private System.Windows.Forms.GroupBox gbReference;
    private System.Windows.Forms.Label JobNameLabel;
    private System.Windows.Forms.TextBox txtReference;
    private System.Windows.Forms.TextBox txtNote;
    private System.Windows.Forms.Panel panel1;
    private System.Windows.Forms.RadioButton rbCustomer;
    private System.Windows.Forms.RadioButton rbType;
    private System.Windows.Forms.RadioButton rbVehicle;
    private System.Windows.Forms.RadioButton rbAccount;
    private System.Windows.Forms.RadioButton rbOnsitePanel;
    private System.Windows.Forms.RadioButton rbReference;
    private System.Windows.Forms.RadioButton rbBooking;
    private System.Windows.Forms.DataGridView dgvVehicle;
    private System.Windows.Forms.ToolStrip toolStrip2;
    private System.Windows.Forms.ToolStripButton tsPrevious;
    private System.Windows.Forms.ToolStripButton tsNext;
    private System.Windows.Forms.ComboBox cmbType;
    private System.Windows.Forms.GroupBox groupBox2;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.GroupBox groupBox3;
    private System.Windows.Forms.GroupBox groupBox5;
    private System.Windows.Forms.Panel panel2;
    private System.Windows.Forms.Button btnSave;
    private System.Windows.Forms.Button btnCancel;
    private System.Windows.Forms.ToolStripButton tsSave;
    private System.Windows.Forms.GroupBox groupBox4;
    private System.Windows.Forms.CheckBox chkMilage;
    private System.Windows.Forms.DataGridViewTextBoxColumn chID;
    private System.Windows.Forms.DataGridViewTextBoxColumn chRego;
    private System.Windows.Forms.DataGridViewTextBoxColumn chVehicle;
  }
}