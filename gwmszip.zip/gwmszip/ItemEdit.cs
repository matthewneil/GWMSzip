﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workshop_orders
{
  public partial class ItemEdit : Form
  {
    private int ItemID;
    private bool active = true;
    public ItemEdit(int ItemCostID)
    {
      InitializeComponent();
      ItemID = ItemCostID;
      LoadGroups();
      LoadUOM();
      Text = "Add New Item";
      if (ItemCostID > 0)
      {
        Text = "Edit Item";
        txtCode.ReadOnly = true;
        LoadData();
      }
      SetButtonState(DataAccess.FormState(this.AccessibilityObject.Name, tsSave));
    }

    private void SetButtonState(Boolean bState)
    {
      tsActive.Enabled = bState;
      tsAdd.Enabled = bState;
      tsRemove.Enabled = bState;
      tsMove.Enabled = bState;
      tsAllocate.Enabled = bState;
    }


    public void LoadData()
    {
      DataTable dt = DataAccess.ExecuteDataTable("SELECT * FROM ItemCost WHERE ItemCostID = " + ItemID);
      try
      {
        if (dt != null && dt.Rows.Count > 0)
        {

          cmbGroup.SelectedValue = dt.Rows[0]["ItemGroupID"].ToString();
          txtCode.Text = dt.Rows[0]["icCode"].ToString();
          tsCode.Text = txtCode.Text;
          txtDescription.Text = dt.Rows[0]["icDescription"].ToString();
          txtCost.Text = dt.Rows[0]["icCost"].ToString();
          txtPrice.Text = dt.Rows[0]["icPrice"].ToString();
          cmbUOM.SelectedValue = dt.Rows[0]["uom"].ToString();
          nudQuantity.Text = dt.Rows[0]["minQuantity"].ToString();
          nudAllowance.Text = dt.Rows[0]["allowance"].ToString();

          if (dt.Rows[0]["active"].ToString() == "0")
          {
            tsActive.Text = "Set to Active";
            tsCode.Text += " (Inactive)";
            active = false;
          }
        }
      }
      catch (Exception ex)
      {
        MessageBox.Show("There was an error loading Item Data");
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name, 
          System.Reflection.MethodBase.GetCurrentMethod().Name, "SELECT * FROM ItemCost WHERE ItemCostID = " + ItemID);
      }

      try
      {
        DataTable dtHistory = DataAccess.ExecuteDataTable("" +
          "SELECT JobID, StatusName, DateCreated, Cost, Price " +
          "FROM jobitem i " +
          "INNER JOIN status s ON s.StatusID = i.StatusID " +
          "WHERE ItemCostID = " + ItemID + " AND JobID != '-1' ORDER BY JobID DESC");
        dgvHistory.DataSource = dtHistory;
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
          System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }

      try
      {
        /*
        DataTable dtLocations = DataAccess.ExecuteDataTable("" +
          "SELECT s.ItemStockID, SUM(imQuantity) AS Quantity, LocationGroup, LocationSubGroup, LocationCode, LocationDescription " +
          "FROM itemstock s " +
          "INNER JOIN location l ON s.LocationID = l.LocationID " +
          "INNER JOIN itemmovement m ON s.ItemStockID = m.ItemStockID " +
          "WHERE ItemCostID = " + ItemID + " " +
          "GROUP BY s.ItemStockID " +
          "HAVING SUM(imQuantity) > 0 " +
          "ORDER BY LocationGroup, LocationSubGroup, LocationCode "

          );*/
        dgvLocations.AutoGenerateColumns = false;
        DataTable dtLocations = DataAccess.ExecuteDataTable("SELECT * FROM vwitemlocation WHERE ItemCostID = " + ItemID);
        dgvLocations.DataSource = dtLocations;
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
          System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }

      try
      {
        DataTable dtItemHistory = DataAccess.ExecuteDataTable("" +
          "SELECT LocationGroup, LocationSubGroup, LocationCode, im.ItemMovementID, mt.mtDescription, im.imDate, s.StaffFullName, im.imQuantity, im.imCost, im.imReference " +
          "FROM itemmovement im " +
          "INNER JOIN movementtype mt ON im.MovementTypeID = mt.MovementTypeID " +
          "INNER JOIN staff s ON im.StaffID = s.StaffID " +
          "INNER JOIN itemstock i ON im.ItemStockID = i.ItemStockID " +
          "INNER JOIN location l ON l.LocationID = i.LocationID " +
          "WHERE i.ItemCostID = " + ItemID + " " +
          "ORDER BY imDate DESC");
        dgvItemHistory.DataSource = dtItemHistory;
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
          System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }
    }

    public void LoadGroups()
    {
      try
      {
        DataTable dt = DataAccess.ExecuteDataTable("SELECT ItemGroupID as datafield, igDescription as textfield FROM itemgroup");
        DataAccess.AddSelect(dt);
        cmbGroup.DataSource = dt;
      }
      catch (Exception ex) 
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name, System.Reflection.MethodBase.GetCurrentMethod().Name, "SELECT ItemGroupID as datafield, igDescription as textfield FROM itemgroup");
      }
    }

    public void LoadUOM()
    {
      try
      {
        DataTable dt = DataAccess.ExecuteDataTable("SELECT uomID as datafield, uomName as textfield FROM uom");
        DataAccess.AddSelect(dt);
        cmbUOM.DataSource = dt;
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name, System.Reflection.MethodBase.GetCurrentMethod().Name, "SELECT ItemGroupID as datafield, igDescription as textfield FROM itemgroup");
      }
    }

    private void tsClose_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private void tsSave_Click(object sender, EventArgs e)
    {
      //ERROR CHECK
      String errors = "";

      if(cmbGroup.SelectedIndex == 0)
      {
        errors += "- Group (None Selected)\n";
      }
      if(txtCode.Text == "")
      {
        errors += "- Code (Blank)\n";
      }
      if (txtDescription.Text == "")
      {
        errors += "- Description (Blank)\n";
      }
      if (txtCost.Text == "")
      {
        errors += "- Cost (Invalid)\n";
      }
      if (txtPrice.Text == "")
      {
        errors += "- Price (Invalid)\n";
      }

      if (errors == "")
      {
        int Quantity = (int)nudQuantity.Value;
        int Allowance = (int)nudAllowance.Value;
        if (!((int)cmbGroup.SelectedValue == 99 || (int)cmbGroup.SelectedValue == 999))
        {
          Quantity = 0;
          Allowance = 0;
        }
        //Update to db
        DataAccess.ItemCostManage(ItemID, (int)cmbGroup.SelectedValue, txtCode.Text, txtDescription.Text,
        decimal.Parse(txtCost.Text), decimal.Parse(txtPrice.Text), (int)cmbUOM.SelectedValue, Quantity, Allowance);

        this.Close();
      }
      else
      {
        MessageBox.Show("The following fields are invalid:\n\n" + errors);
      }
    }

    public bool IsCurrency(string value)
    {
      value.Remove('.').All(char.IsNumber);
      return true;
    }

    private void cmbGroup_SelectedIndexChanged(object sender, EventArgs e)
    {
      if((int)cmbGroup.SelectedValue == 99 || (int)cmbGroup.SelectedValue == 999)
      {
        nudQuantity.Visible = true;
        nudAllowance.Visible = true;

        lblQuantity.Visible = true;
        lblAllowance.Visible = true;
        lblmm.Visible = true;
      }
      else
      {
        nudQuantity.Visible = false;
        nudAllowance.Visible = false;

        lblQuantity.Visible = false;
        lblAllowance.Visible = false;
        lblmm.Visible = false;
      }
    }

    private void tsMove_Click(object sender, EventArgs e)
    {
      MoveItem();
    }

    private void tsAdd_Click(object sender, EventArgs e)
    {
        ItemLocation frm = new ItemLocation(0, ItemID, -1, 2);
      FormManagement.ShowDialogForm(frm);
      LoadData();
    }

    private void tsRemove_Click(object sender, EventArgs e)
    {
      RemoveItem();
    }

    private void cmMove_Click(object sender, EventArgs e)
    {
      MoveItem();
    }

    private void cnAllocate_Click(object sender, EventArgs e)
    {

    }

    private void cmRemove_Click(object sender, EventArgs e)
    {
      RemoveItem();
    }

    private void MoveItem()
    {
      if (dgvLocations.SelectedRows.Count > 0 && dgvLocations.SelectedRows[0].Index > -1)
      {
        ItemLocation frm = new ItemLocation((int)dgvLocations.SelectedRows[0].Cells["chID"].Value, ItemID, -1, 1);
        FormManagement.ShowDialogForm(frm);
        LoadData();
      }
    }
    private void AllocateItem()
    {

    }

    private void RemoveItem()
    {
      if (dgvLocations.SelectedRows.Count > 0 && dgvLocations.SelectedRows[0].Index > -1)
      {
        ItemLocation frm = new ItemLocation((int)dgvLocations.SelectedRows[0].Cells["chID"].Value, ItemID, -1, 3);
        FormManagement.ShowDialogForm(frm);
        LoadData();
      }
    }

    private void tsActive_Click(object sender, EventArgs e)
    {
      if (active)
      {
        bool res = DataAccess.ShowMessage("Set item to Inactive?", "Inactive", false);
        if (res)
        {
          DataAccess.ExecuteNonQuery("UPDATE itemcost SET active = 0 WHERE itemcostID = " + ItemID);
          tsActive.Text = "Set to Active";
          tsCode.Text += " (Inactive)";
          active = false;
        }
      }
      else
      {
        bool res = DataAccess.ShowMessage("Set item to Active?", "Active", false);
        if (res)
        {
          DataAccess.ExecuteNonQuery("UPDATE itemcost SET active = 1 WHERE itemcostID = " + ItemID);
          tsActive.Text = "Set to Inactive";
          tsCode.Text = txtCode.Text;
          active = true;
        }
      }
    }
  }
}
