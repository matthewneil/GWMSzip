﻿using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace workshop_orders
{
	public partial class Retrofit : Form
	{
		enum WindowOptions
		{
			Glass = 1,
			Sash = 99,
			Bead = 999,
			Handle = 9999,
			Hinge = 99999,
			Stay = 999999
		}

		private DataTable _dt;
		private DataTable _dtEdit;
		private QuoteDetail frmQuoteDetail;
		private int _rowid = -1;
		private int fiLayout = 0;
		private int fiLinkID;
		private int fiNextLinkID;
		private int fiQuoteNo = 0;
		private int fiGroupID = 0;
		private int fiDefaultLayout = 1;
		private int fiGlassItemID = 0;
		private int fiOptionItemID = 0;
		private bool fbEditState = false;
		private bool fbPageLoad = false;
		const int fiStateColumn = 15;

		public Retrofit(int quoteno, int groupid, QuoteDetail frm = null)
		{
			InitializeComponent();
			fiQuoteNo = quoteno;
			fiGroupID = groupid;
			frmQuoteDetail = frm;
			SetButtonState(DataAccess.FormState(this.AccessibilityObject.Name, tbSave));
		}

		private void SetButtonState(Boolean bState)
		{
			tbDelete.Enabled = bState;
		}

		private void Retrofit_Load(object sender, EventArgs e)
		{
			fbPageLoad = false;
			GetGlassType();
			GetitemType("Component");
			_dt = CreateDatatable();
			_dtEdit =CreateDatatable();
			FillDataTable();
			ScreenLayout(fiDefaultLayout);
			ListViewGroup lvgData = new ListViewGroup("Products", HorizontalAlignment.Left);
			lvData.Groups.AddRange(new ListViewGroup[] { lvgData });
			lvData.LargeImageList = iglProduct;
			fbPageLoad = true;
			CalculateDimensions();
			lblM2.Text = "m2";
			fiNextLinkID  = DataAccess.ExecuteScalarInt("SELECT MAX(QuoteItemID) FROM quoteitems") + 1;
		}
		private DataTable CreateDatatable()
		{
			DataTable dt = new DataTable();
			dt.Columns.Add("linkid", typeof(int));
			dt.Columns.Add("quoteitemid", typeof(int));
			dt.Columns.Add("subgroup", typeof(String));
			dt.Columns.Add("thickness", typeof(Double));
			dt.Columns.Add("width", typeof(Double));
			dt.Columns.Add("height", typeof(Double));
			dt.Columns.Add("costid", typeof(int));
			dt.Columns.Add("size", typeof(Double));
			dt.Columns.Add("itemgroupid", typeof(int));
			dt.Columns.Add("quantity", typeof(Decimal));
			dt.Columns.Add("icdescription", typeof(String));
			dt.Columns.Add("quoteitemtype", typeof(String));
			dt.Columns.Add("quoteitemCost", typeof(Decimal));
			dt.Columns.Add("quoteitemPrice", typeof(Decimal));
			dt.Columns.Add("unique", typeof(int));
			dt.Columns.Add("state", typeof(int));
			return dt;
		}
		private void FillDataTable()
		{
			try
			{
				DataTable dt = DataAccess.ExecuteDataTable("SELECT * FROM vwquoteitem WHERE QuoteNo = " + fiQuoteNo + " AND quoteItemGroupId = " + fiGroupID + " ORDER BY linkid, quoteitemGroupID");
				if (dt != null && dt.Rows.Count > 0)
				{
					_dt.Rows.Clear();
					_dtEdit.Rows.Clear();
					int iIndex = 0;
					foreach (DataRow dr in dt.Rows)
					{
						_dt.Rows.Add(dr["linkid"].ToString(), dr["quoteitemid"].ToString(), dr["igSubGroup"].ToString(), dr["GlassThickness"].ToString(),
									dr["width"].ToString(), dr["height"].ToString(), dr["itemcostid"].ToString(), dr["size"].ToString(),
									dr["itemgroupid"].ToString(), dr["quantity"].ToString(), dr["icdescription"].ToString(), dr["quoteitemtype"].ToString(),
									dr["quoteitemCost"].ToString(), dr["quoteitemPrice"].ToString(), ++iIndex, 0);
					}
					if (_dt.Rows[0][11].ToString() == "Travel")
					{
						btnFixed.Visible = false;
						btnSash.Visible = false;
						btnComponents.Visible = false;
						GetitemType("Travel");
						fiDefaultLayout = 4;
					}
					FillListView();
				}
				dgvData.DataSource = _dt;
			} 
			catch(Exception ex)
      {
				DataAccess.ShowMessage("Failed to load item into retrofit form.");
				DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
					System.Reflection.MethodBase.GetCurrentMethod().Name, "");
				this.Close();
			}
		}
		private void FillListView()
		{
			//Loop trough the datatable and add the unique items 
			lvData.Clear();
			int linkid = -1;
			foreach (DataRow row in _dt.Rows)
			{
				if (int.Parse(row[fiStateColumn].ToString()) > -1 && linkid != int.Parse(row[0].ToString()))
				{
					linkid = int.Parse(row[0].ToString());
					if (row[11].ToString() == "Component" || row[11].ToString() == "Travel")
					{
						lvData.Items.Add(row[0].ToString(), row[11].ToString() + Environment.NewLine, GetImageIndex(row[11].ToString()));
					}
					else
					{
						lvData.Items.Add(row[0].ToString(), row[11].ToString() + Environment.NewLine + row[5].ToString() + " x " + row[4].ToString(), GetImageIndex(row[11].ToString()));
					}
				}
			}
			GetCosts();
		}
		private void GetGlassType()
		{
			try
			{
				DataTable dt = DataAccess.ExecuteDataTable("SELECT ItemGroupID as datafield, igDescription as textfield FROM itemgroup WHERE igSubGroup = 'Glass'");
				DataAccess.AddSelect(dt);
				cmbGlassType.DataSource = dt;
			}
			catch (Exception ex) 
			{ 
				DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
					System.Reflection.MethodBase.GetCurrentMethod().Name, "SELECT ItemGroupID as datafield, igDescription as textfield FROM itemgroup WHERE igSubGroup = 'Glass'");
			}
		}
		private void GetGlassCodes()
		{//GET GLASS CODES FROM DATABASE
			try
			{
				DataTable dt = DataAccess.ExecuteDataTable("SELECT ItemCostID as datafield, icDescription as textfield FROM vwitemcost" +
																										" WHERE GlassThickness = " + nudThickness.Value +
																										" AND ItemGroupId = " + cmbGlassType.SelectedValue);
				DataAccess.AddSelect(dt);
				cmbGlassCode.DataSource = dt;
			}
			catch (Exception ex)
			{
				DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
					System.Reflection.MethodBase.GetCurrentMethod().Name, "SELECT ItemCostID as datafield, icDescription as textfield FROM vwitemcost" +
																										" WHERE GlassThickness = " + nudThickness.Value +
																										" AND ItemGroupId = " + cmbGlassType.SelectedValue);

			}
		}
		private void GetitemType(string sType)
		{//GET ITEM CATEGORIES
			string sWhere = "WHERE itemGroupID >= 9999";
			if (sType == "Travel") { sWhere = "WHERE itemGroupID = 50"; }
			DataTable dt = DataAccess.ExecuteDataTable("SELECT itemGroupID as datafield, igSubGroup as textfield FROM itemgroup " + sWhere + " ORDER BY igSubGroup");
			DataAccess.AddSelect(dt);
			cmbType.DataSource = dt;
			cmbType.SelectedIndex = 0;
		}
		private void GetItems()
		{//GET COMPONENT CATEGORIES
			int iGroupID = -1;
			if (dgvComponent.Rows[_rowid].Cells[4].Value != null)
			{
				iGroupID = int.Parse(dgvComponent.Rows[_rowid].Cells[4].Value.ToString());
			}
			DataTable dt = DataAccess.ExecuteDataTable("SELECT itemCostID as datafield, icDescription as textfield FROM itemcost WHERE itemGroupID = " + iGroupID + " ORDER BY icDescription");
			if (dt != null)
			{
				fbPageLoad = false;
				DataAccess.AddSelect(dt);
				cmbCostItem.DataSource = dt;
				fbPageLoad = true;
			}
		}
		private void GetOptions(WindowOptions iOptionID)
		{//GET THE COMPONENT ITEMS FOR SELECT CATEGORY
			int id = (int)iOptionID;
			DataTable dt = DataAccess.ExecuteDataTable("SELECT itemCostID as datafield, CONCAT(icCode, ' - ',icDescription) as textfield FROM itemcost WHERE itemGroupID = " + id + " ORDER BY icDescription");
			DataAccess.AddSelect(dt);
			cmbOption.DataSource = dt;
			cmbOption.SelectedIndex = 0;
		}
		private void ScreenLayout(int iLayout)
		{
			//Validate screen objects to check if existing data in glass or components
			//yes to update and   if dataedit() = false then do this code
			gbComponents.Visible = false;
			gbComponents.Top = gbGlassDetails.Top + gbGlassDetails.Height + 10;
			gbComponents.Left = gbGlassDetails.Left;
			gbGlassDetails.Visible = true;
			btnClear.Visible = true;
			btnFixed.BackColor = SystemColors.Control;
			btnSash.BackColor = SystemColors.Control;
			btnComponents.BackColor = SystemColors.Control;
			fiLayout = iLayout;
			switch (iLayout)
			{
				case 1: //Fixed Glass
					lblOption.Text = "Bead";
					GetOptions(WindowOptions.Bead);
					btnFixed.BackColor = Color.Green;
					CalculateDimensions();
					break;
				case 2:  //Sash Glass
					gbComponents.Visible = true;
					lblOption.Text = "Sash";
					btnSash.BackColor = Color.Green;
					GetOptions(WindowOptions.Sash);
					CalculateDimensions();
					break;
				case 3:  // Components
					gbGlassDetails.Visible = false;
					gbComponents.Top = gbGlassDetails.Top;
					gbComponents.Left = gbGlassDetails.Left;
					gbComponents.Visible = true;
					btnComponents.BackColor = Color.Green;
					break;
				case 4:  // Travel
					gbGlassDetails.Visible = false;
					gbComponents.Top = gbGlassDetails.Top;
					gbComponents.Left = gbGlassDetails.Left;
					gbComponents.Visible = true;
					btnClear.Visible = false;
					break;
			}
		}

		private void dgvComponent_CellClick(object sender, DataGridViewCellEventArgs e)
		{
			if (e.RowIndex == -1 || e.ColumnIndex == -1) { return; }
			_rowid = e.RowIndex;
			int iID = -1;
			//Check if Columns 1 or 2 have been clicked. Use values from cells 4 and 5 to set selected values in combo boxes
			if (e.ColumnIndex < 3 && dgvComponent.Rows[e.RowIndex].Cells[e.ColumnIndex + 3].Value != null)
			{
				iID = int.Parse(dgvComponent.Rows[e.RowIndex].Cells[e.ColumnIndex + 3].Value.ToString());
				//iID = 3;
			}
			HideComboBox();
			switch (e.ColumnIndex)
			{
				case 1:
					ManageComboBoxes(e.ColumnIndex, e.RowIndex, cmbType);
					cmbType.SelectedValue = iID;
					break;
				case 2:
					GetItems();
					if (cmbCostItem.Items.Count > 1)
					{
						ManageComboBoxes(e.ColumnIndex, e.RowIndex, cmbCostItem);
						cmbCostItem.SelectedValue = iID;
					}
					break;
			}
		}
		private void ManageComboBoxes(int iColumnIndex, int iRowIndex, ComboBox cmb)
		{
			if (cmb.Items.Count == 1) { return; } //Combo bo only has <select>?
			try
			{//Size combo box to fit datagridview cell size
				Rectangle rect = dgvComponent.GetCellDisplayRectangle(iColumnIndex, iRowIndex, true);
				cmb.Size = rect.Size;
				cmb.Left = rect.Left + 5;
				cmb.Top = rect.Top + 25;
				cmb.Visible = true;
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void AddLabour()
    {
			//dgvComponent.Rows.Add("", "Labour", "Labour", 1.5);
			_rowid = 0;
			dgvComponent.Rows.Add("");
			
			cmbType.SelectedIndex = cmbType.FindString("Labour");
			GetItems();
			cmbCostItem.SelectedIndex = cmbCostItem.FindString("Labour");
			dgvComponent.Rows[_rowid].Cells["chQuantity"].Value = "1.5";


		}
		private void HideComboBox() {
			cmbType.Visible = false;
			cmbCostItem.Visible = false;
		}
		private void cmbType_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (fbPageLoad == true)
			{
				if (cmbType.SelectedIndex > 0)
				{
					dgvComponent.Rows[_rowid].Cells[4].Value = cmbType.SelectedValue;
					dgvComponent.Rows[_rowid].Cells[1].Value = cmbType.Text;
					dgvComponent.Rows[_rowid].Cells[2].Value = "";
				}
			}
		}

		private void cmbCostItem_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (fbPageLoad == true && cmbCostItem.SelectedIndex > 0)
			{
				dgvComponent.Rows[_rowid].Cells[5].Value = cmbCostItem.SelectedValue;
				dgvComponent.Rows[_rowid].Cells[2].Value = cmbCostItem.Text;
			}
		}

		private bool ValidatData(bool bShowMessage = true)
		{
			if (fiLayout < 3)
			{
				//No glass code selected
				if (cmbGlassType.SelectedIndex == 0)
				{
					if (bShowMessage == true) { MessageBox.Show("Please select a Glass Type", "Missing Data", MessageBoxButtons.OK); }
					cmbGlassType.Focus();
					return false;
				}
				if (cmbGlassCode.SelectedIndex == 0)
				{
					if (bShowMessage == true) { MessageBox.Show("Please select a Glass Code", "Missing Data", MessageBoxButtons.OK); }
					cmbGlassCode.Focus();
					return false;
				}
			}
			//If sash glass and no sash selected
			if (fiLayout == 2 && cmbOption.SelectedIndex == 0)
			{
				if (bShowMessage == true) { MessageBox.Show("Please select a sash"); }
				cmbOption.Focus();
				return false;
			}
			//Missing component data
			if (!CheckRowsComponents()) return false;
			return true;
		}
		private void btnAdd_Click(object sender, EventArgs e)
		{
			AddButton();
		}
		private void AddButton()
		{
			//VALIDATE DATA
			if (ValidatData() == false) { return; }
			AddRecord();
			FillListView();
			if (fbEditState == true)
			{
				SetState();
			}
			ClearAll();
		}
		private void AddRecord()
		{
			int iLinkID;
			string sItemGroup;
			int iIndex = _dt.Rows.Count + 1;
			sItemGroup = GetLayoutName();
			if (fbEditState == true)
			{
				iLinkID = fiLinkID;
			}
			else
			{
				iLinkID = fiNextLinkID;
				fiNextLinkID++;
			}
			//If Fixed Or Sash Window then add Glass details
			if (fiLayout < 3)
			{
				_dt.Rows.Add(iLinkID, fiGlassItemID, "GLASS", nudThickness.Value, nudWidth.Value, nudHeight.Value, cmbGlassCode.SelectedValue, 0, cmbGlassType.SelectedValue, CalculateDimensions(), 
											cmbGlassCode.Text, sItemGroup, GetCost((int)cmbGlassCode.SelectedValue, "Glass Code"), GetPrice((int)cmbGlassCode.SelectedValue, "Glass Code"), iIndex, GetState(fiGlassItemID));
				// Add Bead or Sash details
				switch (fiLayout)
				{
					case 1:
						if (cmbOption.SelectedIndex != 0)
						{

							_dt.Rows.Add(iLinkID, fiOptionItemID, "BEAD", nudThickness.Value, nudWidth.Value, nudHeight.Value, (int)cmbOption.SelectedValue, nudLength.Value, 0, nudLength.Value / 1000, 
														cmbOption.Text, sItemGroup, GetCost((int)cmbOption.SelectedValue, "Bead"), GetPrice((int)cmbOption.SelectedValue, "Bead"), ++iIndex, GetState(fiOptionItemID));
						}
						else
						{
							DataAccess.ExecuteNonQuery("DELETE FROM quoteitems WHERE quoteItemID = " + fiOptionItemID);
						}
						break;
					case 2:
						_dt.Rows.Add(iLinkID, fiOptionItemID, "SASH", nudThickness.Value, nudWidth.Value, nudHeight.Value, cmbOption.SelectedValue, nudLength.Value, 0, nudLength.Value / 1000, 
													cmbOption.Text, sItemGroup, GetCost((int)cmbOption.SelectedValue, "Sash"), GetPrice((int)cmbOption.SelectedValue, "Sash"), ++iIndex, GetState(fiOptionItemID));
						break;
				}
			}
			//Add Component details and clear the datatable
			foreach (DataGridViewRow row in dgvComponent.Rows)
			{
				try
				{
					if (row.IsNewRow == false)
					{
						if (row.Cells[6].Value == null) { row.Cells[6].Value = 0; }
						//Check that the item, description and quantity
						_dt.Rows.Add(iLinkID, int.Parse(row.Cells[6].Value.ToString()), row.Cells[1].Value.ToString(), nudThickness.Value, nudWidth.Value, nudHeight.Value, row.Cells[5].Value.ToString(), 0, row.Cells[4].Value.ToString(), 
													row.Cells[3].Value.ToString(), row.Cells[2].Value.ToString(), sItemGroup, GetCost(int.Parse(row.Cells[5].Value.ToString()), "Component"), GetPrice(int.Parse(row.Cells[5].Value.ToString()), "Component"), 
													++iIndex, GetState(int.Parse(row.Cells[6].Value.ToString())));
					}
				}
				catch (Exception ex ) { MessageBox.Show(ex.Message, "Unexpected Error", MessageBoxButtons.OK); }
			}
			//Check for deleted components
			foreach (DataRow row in _dtEdit.Rows)
			{
				if ((int) row[fiStateColumn] == -1 && (int)row[1] > 0 && (int)row[1] > 99)
				{
					_dt.Rows.Add(-1, (int)row[1], "", nudThickness.Value, nudWidth.Value, nudHeight.Value, 0, 0, 0,	0, "", sItemGroup, 0, 0, -99, -1);
				}
			}

		}
		private int GetState (int iID)
		{
			if(iID == 0)
			{
				return 99;	//New
			}
			else
			{
				return 1;  //Updated
			}
		}
		private void btnEdit_Click(object sender, EventArgs e)
		{
			if(fbEditState == true)
			{
				RevertChanges();

			}
			PrepareRecord();
		}
		private void PrepareRecord()
		{
			//Check if record was selected
			if (fbEditState == false && lvData.SelectedItems.Count == 0)
			{
				MessageBox.Show("Please select an item to edit");
				return;
			}
			SetState();
		}
		private void SetState()
		{
			if (fbEditState == true)
			{
				//No edits where made
				fbEditState = false;
				btnAdd.Text = "Add >>";
				btnAdd.BackColor = SystemColors.Control;
				btnEdit.Text = "<< Edit";
				btnEdit.BackColor = SystemColors.Control;
				lvData.Enabled = true;
				btnFixed.Enabled = true;
				btnSash.Enabled = true;
				btnComponents.Enabled = true;
				btnDelete.Visible = false;
				tbSave.Enabled = true;
				tbDelete.Enabled = true;
				try
				{
					if (lvData.SelectedItems.Count > 0)
					{
						lvData.SelectedItems[0].ImageIndex = GetImageIndex(GetLayoutName());
						lvData.SelectedItems.Clear();
					}
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message, "Unexpected Error", MessageBoxButtons.OK);
				}
				fiLinkID = 0;
				ClearAll();
			}
			else
			{
				//Get record to edit
				fbEditState = true;
				btnAdd.Text = "Update";
				btnAdd.BackColor = Color.Green;
				btnEdit.Text = "Cancel";
				btnEdit.BackColor = Color.Orange;
				lvData.Enabled = false;
				btnFixed.Enabled = false;
				btnSash.Enabled = false;
				btnComponents.Enabled = false;
				btnDelete.Visible = true;
				tbSave.Enabled = false;
				tbDelete.Enabled = false;
				fiLinkID = int.Parse(lvData.SelectedItems[0].Name);
				LoadEditData(fiLinkID);
				lvData.SelectedItems[0].ImageIndex = 0;

			}
		}

		public void LoadEditData(int ID)
		{
			fbPageLoad = false;
			try
			{
				int iCount = 0;
				//Get Glass, Bead, Sash Or Components for selected linkid
				_dt.AcceptChanges();
				fiGlassItemID = 0;
				fiOptionItemID = 0;

				foreach (DataRow row in _dt.Rows)
				{
					if (int.Parse(row[0].ToString()) == ID)
					{
						DataRow dRow = _dt.NewRow();
							dRow = row;
						_dtEdit.Rows.Add(row.ItemArray);
						if (iCount == 0)
						{
							//fiItemState = int.Parse(row[fiStateColumn].ToString()); //Get Record State
							fiLayout = GetLayoutNumber(row[11].ToString());  //Get Layout based on quoteitemtype
							ScreenLayout(fiLayout);
						}
						iCount += 1;
						switch (row[2].ToString().ToLower())
						{
							case "glass":
								nudHeight.Value = int.Parse(row[5].ToString());
								nudWidth.Value = int.Parse(row[4].ToString());
								cmbGlassType.SelectedValue = row[8].ToString(); //CHECK THIS VALUE
								nudThickness.Value = int.Parse(row[3].ToString());
								lblM2.Text = row[9].ToString();
								GetGlassCodes();
								cmbGlassCode.SelectedValue = row[6].ToString();
								fiGlassItemID = int.Parse(row[1].ToString());
								break;
							case "sash":
								ScreenLayout(2);
								cmbOption.SelectedValue = row[6].ToString();
								nudLength.Value = int.Parse(row[7].ToString());
								fiOptionItemID = int.Parse(row[1].ToString());
								break;
							case "bead":
								ScreenLayout(1);
								cmbOption.SelectedValue = row[6].ToString();
								nudLength.Value = int.Parse(row[7].ToString());
								fiOptionItemID = int.Parse(row[1].ToString());
								break;
							default:
								if(int.Parse(row[fiStateColumn].ToString()) != -1)
								{
									//Add items to the dgvComponets
									DataGridViewRow drow = new DataGridViewRow();
									drow = (DataGridViewRow)dgvComponent.Rows[0].Clone();
									drow.Cells[0].Value = (int)row[0];
									drow.Cells[1].Value = row[2].ToString();
									drow.Cells[2].Value = row[10].ToString();
									drow.Cells[3].Value = (decimal)row[9];
									drow.Cells[4].Value = (int)row[8];
									drow.Cells[5].Value = (int)row[6];
									drow.Cells[6].Value = row[1].ToString();
									dgvComponent.Rows.Add(drow);
								}
								
								break;
						}
						//DELETE all records from _dt that match the linkid
						row.Delete();
						//row[fiStateColumn] = fiLinkID * 1000 + fiItemState;  //creates a unique state number to use when upating the record 
					}
				}
			}
			catch(Exception ex) { MessageBox.Show(ex.Message, "Unexpected error", MessageBoxButtons.OK); }
			finally 
			{ 
				fbPageLoad = true;
				_dt.AcceptChanges();
			}
		}
		private void RevertChanges()
		{
			foreach(DataRow row in _dtEdit.Rows)
			{
				_dt.Rows.Add(row.ItemArray);

			}
			_dtEdit.Rows.Clear();
			_dtEdit.AcceptChanges();
			_dt.AcceptChanges();
		}
		private void ClearAll()
		{
			nudHeight.Value = 100;
			nudWidth.Value = 100;
			cmbGlassType.SelectedIndex = 0;
			nudThickness.Value = 4;
			fiGlassItemID = 0;
			fiOptionItemID = 0;
			if (fiDefaultLayout != 4)
			{
				cmbGlassCode.SelectedIndex = 0;
				cmbOption.SelectedIndex = 0;
			}
			dgvComponent.Rows.Clear();
			ScreenLayout(fiDefaultLayout);
			CalculateDimensions();
			_dtEdit.Rows.Clear();
			_dtEdit.AcceptChanges();
			GetCosts();
		}
		private void cmbGlassType_SelectedIndexChanged(object sender, EventArgs e)
		{
				GetGlassCodes();
		}
		private void nudThickness_ValueChanged(object sender, EventArgs e)
		{
				GetGlassCodes();
		}
		private void tbBack_Click(object sender, EventArgs e)
		{
			//if (!CheckIfClearData()) return;
			this.Close();
		}
		private void nudHeight_ValueChanged(object sender, EventArgs e)
		{
			CalculateDimensions();
		}
		private void nudWidth_ValueChanged(object sender, EventArgs e)
		{
			CalculateDimensions();
		}
		private void btnClear_Click(object sender, EventArgs e)
		{
			ClearAll();
		}
		private void tbSave_Click(object sender, EventArgs e)
		{//Save the item records
			// Last Item Record
			int iLinkID = 0;
			if (fbEditState == false && ValidatData(false) == true) { AddButton(); } //add any new complete record
			
				//Loop through the records in the _dt datatable and add / edit.
			foreach (DataRow row in _dt.Rows)
			{
				try
				{
					int.Parse(row[0].ToString());
					switch (int.Parse(row[fiStateColumn].ToString()))
				{
					case 0:
						break;
					case -1:  //delete items
						DataAccess.ExecuteNonQuery("DELETE FROM quoteitems WHERE quoteitemid = " + int.Parse(row[1].ToString()));
						break;
					case 99: //Newly Added
							//GET The Next ItemID, if it changes then get the next quoteitemid.
							if(iLinkID != int.Parse(row[0].ToString()))
							{
								iLinkID = int.Parse(row[0].ToString());
							}
							DataAccess.QuoteItemManage(fiQuoteNo, 0, int.Parse(row[6].ToString()), decimal.Parse(row[9].ToString()),
																					decimal.Parse(row[7].ToString()), decimal.Parse(row[4].ToString()), decimal.Parse(row[5].ToString()),
																					decimal.Parse(row[12].ToString()), decimal.Parse(row[13].ToString()), fiGroupID, iLinkID, row[11].ToString(), "");
							break;
					default: //Insert or Update items	
							DataAccess.QuoteItemManage(fiQuoteNo, int.Parse(row[1].ToString()), int.Parse(row[6].ToString()), decimal.Parse(row[9].ToString()),
																					decimal.Parse(row[7].ToString()), decimal.Parse(row[4].ToString()), decimal.Parse(row[5].ToString()),
																					decimal.Parse(row[12].ToString()), decimal.Parse(row[13].ToString()), fiGroupID, int.Parse(row[0].ToString()), row[11].ToString(), "");
							break;
				}
				}
				catch(Exception ex)
				{
					MessageBox.Show("An unexpected error occurred: " + Environment.NewLine + ex.Message, "Error", MessageBoxButtons.OK);
				}
			}
			//FillDataTable();
			RefreshQuoteDetails();
			this.Close();
		}
		private void tbDelete_Click(object sender, EventArgs e)
		{
			string sMessage = "Do you really want to delete quote item " + tslName.Text + "?";
			if (MessageBox.Show(sMessage, "Delete Item", MessageBoxButtons.YesNoCancel) == DialogResult.Yes)
			{
				//Delete database record
				DataAccess.QuoteItemDelete(fiGroupID);
				RefreshQuoteDetails();
				this.Close();
			}
		}
		private void RefreshQuoteDetails()
		{
			if (frmQuoteDetail != null) { frmQuoteDetail.LoadData(); }
		}
		private bool CheckRowsComponents(bool bShowMessage = true)
		{
			if (fiLayout > 1) //only check if not fixed glass
			{
				foreach (DataGridViewRow row in dgvComponent.Rows)
				{
					if (row.IsNewRow == false)
					{
						if (row.Cells[4].Value == null || row.Cells[4].Value.ToString() == "-1")
						{
							if (bShowMessage == true) { MessageBox.Show("There is at least one component with a missing item type!"); }
							return false;
						}
						else if (row.Cells[5].Value == null || row.Cells[5].Value.ToString() == "-1")
						{
							if (bShowMessage == true) { MessageBox.Show("There is at least one component with a missing item description!"); }
							return false;
						}
						else if (row.Cells[3].Value == null || !DataAccess.IsNumeric(row.Cells[3].Value.ToString()) || decimal.Parse(row.Cells[3].Value.ToString()) <= 0)
						{
							if (bShowMessage == true) { MessageBox.Show("There is at least one component with a missing or invalid quantity!"); }
							return false;
						}
					}
				}
			}
			return true;
		}
		private void btnFixed_Click(object sender, EventArgs e)
		{
			ScreenLayout(1);
		}
		private void btnSash_Click(object sender, EventArgs e)
		{
			ScreenLayout(2);
			AddLabour();
		}
		private void btnComponents_Click(object sender, EventArgs e)
		{
			ScreenLayout(3);
		}
		private void btnTravel_Click(object sender, EventArgs e)
		{
			ScreenLayout(4);
		}
		private string GetLayoutName()
		{
			switch (fiLayout)
			{
				case 2:
					return "Sash Glass";
				case 3:
					return "Component";
				case 4:
					return "Travel";
				default:
					return "Fixed Glass";
			}
		}
		private int GetLayoutNumber(string sName)
		{
			switch (sName)
			{
				case "Sash Glass":
					return 2;
				case "Component":
					return 3;
				case "Travel":
					return 4;
				default:
					return 1;
			}
		}
		private int GetImageIndex(string sName)
		{
			switch (sName)
			{
				case "Fixed Glass":
					return 1;
				case "Sash Glass":
					return 2;
				case "Component":
					return 3;
				case "Travel":
					return 4;
				default:
					return 0;
			}
		}
		private decimal CalculateDimensions()
		{
			decimal Dimension = 0;
			nudLength.Value = (nudHeight.Value + nudWidth.Value) * 2;
			lblM2.Text ="m2";
			switch (fiLayout)
			{			
				case 1:
					//Fixed Window Calc
					Dimension = decimal.Round(((nudHeight.Value - 6) / 1000) * ((nudWidth.Value - 6) / 1000), 4);
					lblM2.Text = Dimension.ToString() + "m2";
					nudLength.Value = (nudHeight.Value + nudWidth.Value) * 2;
					break;
				case 2:
					//Sash Window Calc
					Dimension = decimal.Round(((nudHeight.Value - 31) / 1000) * ((nudWidth.Value - 31) / 1000), 4);
					lblM2.Text = Dimension.ToString() + "m2";
					nudLength.Value = (nudHeight.Value + nudWidth.Value + 48) * 2;   //Platform  + 12mm all the way around
					break;
			}
			return Dimension;
		}

		private void btnDelete_Click(object sender, EventArgs e)
		{//Delete selected item
			try
			{
				for (int i = _dtEdit.Rows.Count - 1; i >= 0; i--)
				{
						if (int.Parse(_dtEdit.Rows[i][1].ToString()) == 0)
						{
						_dtEdit.Rows.RemoveAt(i);
						}
						else
						{
						_dtEdit.Rows[i][fiStateColumn] = -1;
						}
				}
				_dtEdit.AcceptChanges();
				RevertChanges();
				lvData.Items.Remove(lvData.SelectedItems[0]);
				SetState();
				
			}
			catch (Exception ex) { MessageBox.Show(ex.Message, "Unexpected Error", MessageBoxButtons.OK); }
		}

		private void lvData_DoubleClick(object sender, EventArgs e)
		{
			PrepareRecord();
		}
		private void lvData_Click(object sender, EventArgs e)
		{
			PrepareRecord();
		}
		private decimal GetCost(int iCostID, string sType)
		{
			decimal dCost = DataAccess.ExecuteScalarDec("SELECT icCost FROM itemCost WHERE ItemCostID = "  + iCostID);
			if (dCost == 0)
			{
				MessageBox.Show("Unable to find a cost for the selected " + sType, "No Cost Data", MessageBoxButtons.OK);
			}
			return dCost;
		}
		private decimal GetPrice(int iCostID, string sType)
		{
			decimal dCost = DataAccess.ExecuteScalarDec("SELECT icPrice FROM itemCost WHERE ItemCostID = " + iCostID);
			if (dCost == 0)
			{
				MessageBox.Show("Unable to find a cost for the selected " + sType, "No Cost Data", MessageBoxButtons.OK);
			}
			return dCost;
		}

		private void dgvComponent_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
		{
			if (fbEditState == true)
			{
				foreach (DataRow row in _dtEdit.Rows)
				{
					if (e.Row.IsNewRow == false && e.Row.Cells[6].Value != null && int.Parse(row[0].ToString()) == fiLinkID && row[1].ToString() == e.Row.Cells[6].Value.ToString())
					{
						row[fiStateColumn] = -1;
						_dtEdit.AcceptChanges();
					}
				}
			}
		}
		private void GetCosts()
		{
			decimal dGlassC = 0;
			decimal dBeadC = 0;
			decimal dSashC = 0;
			decimal dCompC = 0;
			decimal dTravelC = 0;
			decimal dGlassP = 0;
			decimal dBeadP = 0;
			decimal dSashP = 0;
			decimal dCompP = 0;
			decimal dTravelP = 0;
			foreach (DataRow row in _dt.Rows)
			{
				switch (row["subgroup"].ToString().ToUpper())
				{
					case "GLASS":
						dGlassC += (decimal)row["quantity"] * (decimal)row["quoteitemcost"];
						dGlassP += (decimal)row["quantity"] * (decimal)row["quoteitemprice"];
						break;
					case "BEAD":
						dBeadC += (decimal)row["quantity"] * (decimal)row["quoteitemcost"];
						dBeadP += (decimal)row["quantity"] * (decimal)row["quoteitemprice"];
						break;
					case "SASH":
						dSashC += (decimal)row["quantity"] * (decimal)row["quoteitemcost"];
						dSashP += (decimal)row["quantity"] * (decimal)row["quoteitemprice"];
						break;
					case "TRAVEL":
						dTravelC += (decimal)row["quantity"] * (decimal)row["quoteitemcost"];
						dTravelP += (decimal)row["quantity"] * (decimal)row["quoteitemprice"];
						break;
					default:
						dCompC += (decimal)row["quantity"] * (decimal)row["quoteitemcost"];
						dCompP += (decimal)row["quantity"] * (decimal)row["quoteitemprice"];
						break;
				}
			}
			lblGlassCost.Text = "$" + decimal.Round(dGlassC, 2).ToString();
			lblBeadCost.Text = "$" + decimal.Round(dBeadC, 2).ToString();
			lblSashCost.Text = "$" + decimal.Round(dSashC, 2).ToString();
			lblComponentCost.Text = "$" + decimal.Round(dCompC, 2).ToString();
			lblTravel.Text = "$" + decimal.Round(dTravelC, 2).ToString();
			lblTotalCost.Text = "$" + (decimal.Round(dGlassC, 2) + decimal.Round(dBeadC, 2) + decimal.Round(dSashC, 2) + decimal.Round(dCompC, 2) + decimal.Round(dTravelC, 2)).ToString();
			lblGlassPrice.Text = "$" + decimal.Round(dGlassP, 2).ToString();
			lblBeadPrice.Text = "$" + decimal.Round(dBeadP, 2).ToString();
			lblSashPrice.Text = "$" + decimal.Round(dSashP, 2).ToString();
			lblCompPrice.Text = "$" + decimal.Round(dCompP, 2).ToString();
			lblTravelPrice.Text = "$" + decimal.Round(dTravelP, 2).ToString();
			lblTotalPrice.Text = "$" + (decimal.Round(dGlassP, 2) + decimal.Round(dBeadP, 2) + decimal.Round(dSashP, 2) + decimal.Round(dCompP, 2) + decimal.Round(dTravelP, 2)).ToString();
		}
		private void tslName_DoubleClick(object sender, EventArgs e)
		{
			this.Height += dgvData.Height + 50;
			dgvData.Visible = true;
		}

	}
}

