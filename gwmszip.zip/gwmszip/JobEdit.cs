﻿using System;
using System.Linq;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;
using System.Data;
using System.Drawing.Printing;
using System.Diagnostics;
using Microsoft.Scripting.Interpreter;
using System.Security.Cryptography;
using System.Windows.Forms.DataVisualization.Charting;
using System.Drawing;
using System.Collections.Generic;

namespace workshop_orders
{
  public partial class JobEdit : Form
  {
    private String[] times = { "8:00", "9:00", "10:30", "11:30", "13:00", "14:00", "15:15" };
    
    public static int partID;
    private int i = 0;

    private int JobID;
    public static int CustomerID = -1;
    public static int VehicleID = -1;
    private int StatusID = 0;
    private int QuoteID = -1;
    public static Workshop frm;
    public bool ws = false;


    private void CreateJobForm_Load(object sender, EventArgs e)
    {
      //dtpBookDate.Value = DateTime.Now;
      //dtpBookTime.Value = DateTime.Parse("8:00:00");
      SetButtonState(DataAccess.FormState(this.AccessibilityObject.Name, tsSave));

      if (GWMS.getAdminStatus())
      {
        tsCancel.Visible = true;
      }

    }

    private void SetButtonState(Boolean bState)
    {
      tsCancel.Enabled = bState;
      tsCopy.Enabled = bState;
      tsAddProduct.Enabled = bState;
      tsLabour.Enabled = bState;
      tsNewInvoice.Enabled = bState;
    }

    public MySqlConnection connectMySql()
    {
      using (MySqlConnection conn = new MySqlConnection(GWMS.connStr))
      {
        try
        {
          Console.WriteLine("Connecting to MySQL...");

          return conn;
        }
        catch (Exception ex)
        {
          MessageBox.Show("Error connecting to server, please contact the administrator.", "Error!");
          DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
          return null;
        }
      }
    }


    public JobEdit(int JobID)
    {
      if (this.ScaleChildren == true)
      {
        SizeF sc = new SizeF();
        sc.Width = (float)1.0;
        sc.Height = (float)1.0;
        this.Scale(sc);

      }

      InitializeComponent();
      GetJobDetails(JobID);

      
    }


    public JobEdit(int JobID, int form)
    {
      if (this.ScaleChildren == true) {
        SizeF sc = new SizeF();
        sc.Width = (float)1.0;
        sc.Height = (float)1.0;
        this.Scale(sc);       
      }

      InitializeComponent();
      GetJobDetails(JobID);

      gbInsurance.Enabled = false;
      tcJob.TabPages.Remove(tpInvoice);
      tpInvoice.Visible = false;
      nudIviis.Enabled = false;
      gbPrices.Visible = false;
      tsCopy.Visible = false;
      tsCancel.Visible = false;
      tsSep.Visible = false;
      gbNote.Visible = true;
      chkMilage.Enabled = false;
      cmbGroup.Enabled = false;
      cmbType.Enabled = false;
      cmbPayment.Enabled = false;
      ws = true;
    }
    private void GetJobDetails(int JobID)
    {
      this.JobID = JobID;

      cmbGroup.SelectedIndex = 0;
      /**Load Data*/
      LoadJobTypes(); //Job Types from Type Table
      LoadPaymentTypes(); //Payment from Payment table (or hard code)
      LoadInsuranceProviders(); //Insurance Providers from insurance table
      LoadOnsiteAddress(); //Onsite Locations from location table

      /**Load Job Details*/
      LoadJobData(); //Load all data from job table

      LoadCustomerFromID(); //Load Customer from customer table, from CustomerID
      LoadVehicleFromID(); //Load Vehicle Details, from VehicleID
      LoadStatusFromID(); //Load Status of Job

      LoadJobItems(); //All products from product table    
      LoadJobLabour();
      LoadFiles();  //Files from file table?
      LoadInvoices(); //Invoices from invoice table

      LoadJobCosts();

      SetJobLabel();
    }

    public void LoadJobTypes()
    {
      switch (cmbGroup.SelectedIndex)
      {
        case 0: //Auto
          DataTable dt = DataAccess.ExecuteDataTable(
          "SELECT TypeID AS datafield, TypeName AS textfield FROM JobType WHERE TypeGroup = 'Auto' ORDER BY TypeName");
          cmbType.DataSource = dt;
          cmbType.SelectedValue = 2; //Car Screen

          lblVehicle.Visible = true;
          txtVehicle.Visible = true;
          btnVehicle.Visible = true;
          break;

        case 1: //Glass
          DataTable dt2 = DataAccess.ExecuteDataTable(
          "SELECT TypeID AS datafield, TypeName AS textfield FROM JobType WHERE TypeGroup = 'Glass' ORDER BY TypeName");
          cmbType.DataSource = dt2;
          cmbType.SelectedValue = 37; //Flat Glass

          lblVehicle.Visible = false;
          txtVehicle.Visible = false;
          btnVehicle.Visible = false;
          break;
      }
    }

    public void LoadPaymentTypes()
    {
      DataTable dt = DataAccess.ExecuteDataTable(
        "SELECT PaymentID AS datafield, pType AS textfield FROM Payment");
      cmbPayment.DataSource = dt;
    }

    public void LoadInsuranceProviders()
    {
      Dictionary<string, string> insurance = new Dictionary<string, string>();
      try
      {

        DataTable dtTop3 = DataAccess.ExecuteDataTable("SELECT i.InsuranceID, InsuranceName, COUNT(*) FROM insurance i INNER JOIN job j ON i.InsuranceID = j.InsuranceID GROUP BY i.InsuranceID, InsuranceName ORDER BY COUNT(*) DESC LIMIT 3;");
        //DataAccess.AddSelect(dtTop3);

        foreach (DataRow row in dtTop3.Rows)
        {
          insurance.Add(row["InsuranceID"].ToString(), row["InsuranceName"].ToString());
          //cmbInsurance.Items.Insert(int.Parse(row["InsuranceID"].ToString()), row["InsuranceName"].ToString());
        }
        insurance.Add("-1", "-");
      } catch { }

      try { 
      
        DataTable dtAll = DataAccess.ExecuteDataTable(
          "SELECT InsuranceID, InsuranceName FROM Insurance");
        foreach (DataRow row in dtAll.Rows)
        {
          if (!insurance.ContainsKey(row["InsuranceID"].ToString()))
          {
            insurance.Add(row["InsuranceID"].ToString(), row["InsuranceName"].ToString());
          }
          
          //cmbInsurance.Items.Insert((int)row["InsuranceID"], row["InsuranceName"]);
        }
      } catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                  System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }

      try
      {
        cmbInsurance.DataSource = new BindingSource(insurance, null);
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                  System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }
    }

    public void LoadOnsiteAddress()
    {
      DataTable dt = DataAccess.ExecuteDataTable(
        "SELECT AreaID AS datafield, AreaName AS textfield FROM Area");
      DataAccess.AddSelect(dt);
      cmbArea.DataSource = dt;
    }

    private void LoadVehicleFromID()
    {
      if (VehicleID > 0)
      {
        try
        {
          DataTable dt = DataAccess.ExecuteDataTable(
            "SELECT * FROM vehicle WHERE VehicleID = " + VehicleID);
          txtVehicle.Text = dt.Rows[0]["vRegistration"].ToString() + " - " + dt.Rows[0]["vMake"].ToString() + " " + dt.Rows[0]["vModel"].ToString() + " " + dt.Rows[0]["vYear"].ToString();
        }
        catch (Exception ex)
        {
          DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                  System.Reflection.MethodBase.GetCurrentMethod().Name, "");
        }
      }
      else
      {
        txtVehicle.Text = "";
      }
    }

    private void LoadStatusFromID()
    {
      lblStatus.Text = DataAccess.ExecuteScalarString("SELECT statusname FROM status WHERE statusID = " + StatusID);
    }

    private void LoadCustomerFromID()
    {
      if (CustomerID > 0)
      {
        DataTable dt = DataAccess.ExecuteDataTable(
          "SELECT * FROM customer WHERE CustomerID = " + CustomerID);
        txtCustomer.Text = dt.Rows[0]["CustomerName"].ToString() + " " + dt.Rows[0]["cMobilePhone"].ToString(); 
        //txtAccountName.Text = dt.Rows[0]["cAccountName"].ToString();
        //txtAccountNo.Text = dt.Rows[0]["cAccountNo"].ToString();
      }
      else
      {
        txtCustomer.Text = "";
      }
    }

    

    public void LoadJobData()
    {
      cmbGroup.SelectedIndex = 0;
      String group = DataAccess.ExecuteScalarString("SELECT TypeGroup FROM vwJob WHERE JobID = " + JobID);
      switch (group)
      {
        case "Glass":
          cmbGroup.SelectedIndex = 1;
          break;
      }
      //Job Table
      DataTable dtJob = DataAccess.ExecuteDataTable(
        "SELECT * FROM job WHERE JobID = " + JobID);

      cmbType.SelectedValue = dtJob.Rows[0]["TypeID"].ToString();
      CustomerID = (int)dtJob.Rows[0]["CustomerID"];
      cmbPayment.SelectedValue = dtJob.Rows[0]["PaymentID"].ToString();
      VehicleID = (int)dtJob.Rows[0]["VehicleID"];
      StatusID = (int)dtJob.Rows[0]["StatusID"];

      txtAccountName.Text = dtJob.Rows[0]["AccountName"].ToString();
      txtAccountNo.Text = dtJob.Rows[0]["AccountNo"].ToString();
      if ((int)dtJob.Rows[0]["AreaID"] > 0)
      {
        cmbArea.SelectedValue = dtJob.Rows[0]["AreaID"].ToString();
        txtAddress.Text = dtJob.Rows[0]["JobSiteAddress"].ToString();
      }
      else if (dtJob.Rows[0]["JobSiteAddress"].ToString() != "")
      {
        cmbArea.SelectedValue = 1;
        txtAddress.Text = dtJob.Rows[0]["JobSiteAddress"].ToString();
      }

      cmbInsurance.SelectedValue = dtJob.Rows[0]["InsuranceID"].ToString();

      if (dtJob.Rows[0]["JobBookingDate"].ToString() != "" && DateTime.Parse(dtJob.Rows[0]["JobBookingDate"].ToString()) > DateTime.Parse("2000-01-01"))
      {
        chkBooking.Checked = true;
        dtpBookDate.Value = DateTime.Parse(dtJob.Rows[0]["JobBookingDate"].ToString());
        dtpBookTime.Value = DateTime.Parse(dtJob.Rows[0]["JobBookingDate"].ToString());
      }
      else
      {
        dtpBookDate.Value = DateTime.Now;
        dtpBookTime.Value = DateTime.Parse("8:00:00");
        chkBooking.Checked = false;
        dtpBookDate.Enabled = false;
        dtpBookTime.Enabled = false;
        btnTimeBack.Enabled = false;
        btnTimeForward.Enabled = false;
      }
      txtNote.Text = dtJob.Rows[0]["JobNote"].ToString();
      nudIviis.Text = dtJob.Rows[0]["JobiViisNo"].ToString();
      nudMilage.Text = dtJob.Rows[0]["JobMilage"].ToString();
      txtReference.Text = dtJob.Rows[0]["JobReference"].ToString();

      if ((int)dtJob.Rows[0]["MilageRequired"] == 1) chkMilage.Checked = true;

    }

    public void LoadJobItems()
    {
      dgvItem.AutoGenerateColumns = false;
      try
      {
        DataTable dt = DataAccess.ExecuteDataTable(String.Format(
          "SELECT ji.JobItemID, ig.igDescription, ic.icCode, c.Code, s.StatusName, ji.Price, ic.icDescription, COUNT(0) AS quantity " +
          "FROM jobItem ji " +
          "INNER JOIN itemcost ic ON ji.ItemCostID = ic.ItemCostID " +
          "INNER JOIN status s ON ji.StatusID = s.StatusID " +
          "INNER JOIN itemgroup ig ON ic.ItemGroupID = ig.ItemGroupID " +
          "LEFT JOIN itemcode c ON c.LinkID = ic.ItemCostID " +
          "WHERE ji.JobID = {0} " +
          "GROUP BY ji.ItemCostID;", JobID));
        dgvItem.DataSource = dt; 
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.ToString());
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                  System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }
    }

    public void LoadJobLabour()
    {
      dgvLabour.AutoGenerateColumns = false;
      try
      {
        DataTable dt = DataAccess.ExecuteDataTable(String.Format(
          "SELECT StaffFullName, Percent, TimeLength, Cost, Note " +
          "FROM vwLabour l " +
          "WHERE l.JobTaskID = {0};", JobID));
        dgvLabour.DataSource = dt;
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                  System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }
    }

    public void LoadInvoices()
    {
      try
      {
        DataTable dt = DataAccess.ExecuteDataTable(String.Format("SELECT InvoiceID, invNo, invPrice, invDate FROM invoice WHERE JobID = {0};", JobID));
        dgvInvoice.DataSource = dt;
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                  System.Reflection.MethodBase.GetCurrentMethod().Name, String.Format("SELECT invoiceno, price, date FROM invoice WHERE JobNo = {0};", JobID));
      }
    }

    public void LoadFiles()
    {
      List<string> files;
      try
      {
        files = Directory.GetFiles(fbdJobPath.SelectedPath, "*.*", SearchOption.AllDirectories).ToList();
        for (int i = 0; i < files.Count; i++)
        {
          dgvFiles.Rows.Add(files[i].Split('\\').Last());
        }
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                   System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }

    }


    private String quote(String str)
    {
      return "'" + str + "'";
    }

    private void SaveJob()
    {
      /**Error checks*/
      String errors = "Cannot save due to the following issues:\n\n";
      //Check customerID
      if (CustomerID < 1)
      {
        errors += "- No Customer is currently selected\n";
      }
      //check vehicleID
      if (VehicleID < 1)
      {
        VehicleID = -1;
      }

      int InsuranceID = -1;
      try
      {
        InsuranceID = (int)cmbInsurance.SelectedValue;
      }
      catch { }

      /* CODE FOR CHECKING IF INSURANCE PROVIDER IS SELECTED BEFORE SAVING, BUT WAS REMOVED
      //check insuranceID isnt 0 IF holder name or claim no has a value
      if ((int)cmbPayment.SelectedValue == 2)
      {
        if ((int)cmbInsurance.SelectedValue == -1)
        {
          errors += "- No Insurance Provider is currently selected\n";
        }
        else
        {
          InsuranceID = (int)cmbInsurance.SelectedValue;
        }

      }
      */

      //check locationID isnt 0 IF onsite is checked
      int AreaID = -1;
      String AreaAddress = "";
      if ((int)cmbArea.SelectedValue != -1)
      {
        AreaID = (int)cmbArea.SelectedValue;
        AreaAddress = txtAddress.Text;
      }

      String BookingDate = dtpBookDate.Value.ToString("yyyy-MM-dd ") + dtpBookTime.Value.ToString("HH:mm:ss");
      if (!chkBooking.Checked)
      {
        BookingDate = "1998-01-01"; //Sets date to before year 2000 -> Before 2000 means there is no Booking on this job.
      }

      if (errors != "Cannot save due to the following issues:\n\n")
      {
        MessageBox.Show(errors);
        return;
      }

      if(cmbGroup.SelectedIndex == 1) // Glass Job
      {
        VehicleID = -1; //No vehicle allowed on Glass job at this stage.
      }

      int milage = 0;
      if (chkMilage.Checked) milage = 1;

      /**Saving*/
      try
      {
        DataAccess.JobManage(JobID, (int)cmbType.SelectedValue, CustomerID, (int)cmbPayment.SelectedValue, VehicleID, StatusID, AreaID,
          InsuranceID, QuoteID, AreaAddress, DateTime.Parse(BookingDate), txtNote.Text, (int)nudIviis.Value, (int)nudMilage.Value, txtReference.Text, txtAccountName.Text, txtAccountNo.Text, milage);
      }
      catch (Exception ex)
      {
        DataAccess.ShowMessage("Job failed to save, please contact the administrator if issues persists.");
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
        return;
      }

      DataAccess.ShowMessage("Job saved successfully.");
    }

    private void addRegoButton_Click(object sender, EventArgs e)
    {
      SearchVehicle form = new SearchVehicle(VehicleID, 1);
      form.jobNo = JobID;
      FormManagement.ShowDialogForm(form);
      LoadVehicleFromID();
    }
  
    private void invoiceDataGrid_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      try
      {
        if (dgvInvoice.SelectedRows.Count > 0 && dgvInvoice.SelectedRows[0].Index > -1)
        {
          JobInvoice frm = new JobInvoice((int)dgvInvoice.SelectedRows[0].Cells[0].Value, JobID);
          FormManagement.ShowDialogForm(frm);
        }
        

      }
      catch (Exception ex) {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");

      }
      LoadInvoices();
    }

    private void dataGridView3_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      try
      {
        if (dgvFiles.SelectedRows.Count > 0 && dgvFiles.SelectedRows[0].Index > -1)
        {
          String path = fbdJobPath.SelectedPath + @"\" + dgvFiles.SelectedRows[0].Cells[0].Value;
          Process.Start(path);
        }
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }
    }

    private void downButton_Click(object sender, EventArgs e)
    {
      if (i > 0) i--;
      dtpBookTime.Value = DateTime.Parse(times[i]);
    }

    private void upButton_Click(object sender, EventArgs e)
    {
      if (i < times.Length - 1) i++;
      dtpBookTime.Value = DateTime.Parse(times[i]);
    }

    

    private void tsSave_Click(object sender, EventArgs e)
    {
      SaveJob();
    }

    private void tsPrint_Click(object sender, EventArgs e)
    {
      ReportView frm = new ReportView("SELECT * FROM vwjobitem WHERE jobID = " + JobID, "job.rdlc");
      FormManagement.ShowDialogForm(frm);
    }

    private void tbOpenFolder_Click(object sender, EventArgs e)
    {
      try
      {
        Process.Start(fbdJobPath.SelectedPath);
      } 
      catch (Exception ex)
      {
        DataAccess.ShowMessage("Job file path not found.");
      }
    }

    private void tsDetails_Click(object sender, EventArgs e)
    {
      String Details = "";
      try
      {
        using (MySqlConnection conn = connectMySql())
        {
          conn.Open();
          string sql = String.Format("SELECT smsDate, smsSent FROM sms WHERE smsJobID = {0};", JobID);
          MySqlCommand cmd = new MySqlCommand(sql, conn);
          using (MySqlDataReader rdr = cmd.ExecuteReader())
          {
            while (rdr.Read())
            {
              String sent = "(Not Sent)";
              if (rdr["smsSent"].ToString() == "1")
              {
                sent = "(Sent)";
              }
              Details += String.Format("Pick Up Time: {0} {1}\n\n", DateTime.Parse(rdr["smsDate"].ToString()).ToString("hh:mm tt"), sent);
            }
          }
        }
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, String.Format("SELECT time, sent FROM texts WHERE JobNo = {0};", JobID));
      }

      try
      {
        DataTable dt = DataAccess.ExecuteDataTable(String.Format("SELECT s.StaffFullName, j.DateCreated FROM Job j INNER JOIN staff s ON j.StaffID = s.StaffID WHERE j.JobID = {0};", JobID));
        Details += String.Format("Created By: {0}\n", dt.Rows[0]["StaffFullName"].ToString());
        Details += String.Format("Created On: {0}\n\n", dt.Rows[0]["DateCreated"].ToString());
      } 
      catch(Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }
      

      DataAccess.ShowMessage(Details, "Details");
    }

    private void tsNewInvoice_Click(object sender, EventArgs e)
    {
      JobInvoice form = new JobInvoice(0, JobID);
      FormManagement.ShowDialogForm(form);
      LoadInvoices();
    }

    private void SetJobLabel()
    {
      tsJobID.Text = "Job: " + JobID;

      if ((int)cmbArea.SelectedValue == -1)
      {
        tsJobID.Text += " - Workshop";
        tsJobID.ForeColor = Color.Black;
      }
      else
      {
        tsJobID.Text += " - Onsite";
        tsJobID.ForeColor = Color.Purple;
      }
    }

    private void LoadJobCosts()
    {
      try
      {
        DataTable dt = DataAccess.ExecuteDataTable("SELECT SUM(icCost) AS ItemCost, SUM(icPrice) AS ItemPrice FROM itemcost ic INNER JOIN jobitem ji ON ic.ItemCostID = ji.ItemCostID WHERE jobID = " + JobID + " GROUP BY JobID");
        txtItemCost.Text = String.Format("${0:0.00}", (decimal)dt.Rows[0]["ItemCost"]);
        txtItemPrice.Text = String.Format("${0:0.00}", (decimal)dt.Rows[0]["ItemPrice"]);

        DataTable dtLabour = DataAccess.ExecuteDataTable("SELECT SUM(Cost) AS LabourCost, SUM(Price) AS LabourPrice FROM vwLabour lb WHERE JobTaskID = " + JobID + " GROUP BY JobTaskID");
        txtLabourCost.Text = String.Format("${0:0.00}", (decimal)dtLabour.Rows[0]["LabourCost"]);
        txtLabourPrice.Text = String.Format("${0:0.00}", (decimal)dtLabour.Rows[0]["LabourPrice"]);

        txtTotalCost.Text = String.Format("${0:0.00}", (decimal)dt.Rows[0]["ItemCost"] + (decimal)dtLabour.Rows[0]["LabourCost"]);
        txtTotalPrice.Text = String.Format("${0:0.00}", (decimal)dt.Rows[0]["ItemPrice"] + (decimal)dtLabour.Rows[0]["LabourPrice"]);

      } catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");

      }
    }

    private void policyNameText_TextChanged(object sender, EventArgs e)
    {

    }

    private void tsBack_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private void cbNoBooking_CheckedChanged(object sender, EventArgs e)
    {
      dtpBookDate.Enabled = chkBooking.Checked;
      dtpBookTime.Enabled = chkBooking.Checked;
      btnTimeBack.Enabled = chkBooking.Checked;
      btnTimeForward.Enabled = chkBooking.Checked;
    }

    private void btnCustomer_Click(object sender, EventArgs e)
    {
      SearchCustomer form = new SearchCustomer(CustomerID, 1);
      form.quoteNo = JobID;
      FormManagement.ShowDialogForm(form);
      LoadCustomerFromID();
    }

    private void cmbPayment_SelectedIndexChanged(object sender, EventArgs e)
    {
      if (cmbPayment.SelectedValue.ToString() == "2")//insurance
      {
        gbInsurance.Enabled = true;

        gbInsurance.Text = "Insurance";
        lblInsurance.Visible = true;
        cmbInsurance.Visible = true;
        lblAccountName.Text = "Policy Name:";
        lblAccountNo.Text = "Claim No:";
      }
      else if (cmbPayment.SelectedValue.ToString() == "3")//Accounts
      {
        gbInsurance.Enabled = true;

        gbInsurance.Text = "Account";
        //lblInsurance.Visible = false;
        //cmbInsurance.Visible = false;
        lblAccountName.Text = "Account Name:";
        lblAccountNo.Text = "Account No:";
      }
      else
      {
        gbInsurance.Enabled = false;
      }
    }

    

    private void tsAddProduct_Click(object sender, EventArgs e)
    {
      JobItem form = new JobItem(1);
      form.quoteNo = JobID;
      form.vehicleID = VehicleID;
      FormManagement.ShowDialogForm(form);
      LoadJobItems();
    }

    private void textBox1_TextChanged(object sender, EventArgs e)
    {

    }

    private void timPricings_Tick(object sender, EventArgs e)
    {
      timPricings.Enabled = false;
      timPricings.Stop();
      pnlCosts.Visible = true;
    }

    private void tsDeleteProduct_Click(object sender, EventArgs e)
    {
      
    }

    private void cmbArea_SelectedValueChanged(object sender, EventArgs e)
    {
      if((int)cmbArea.SelectedValue == -1)
      {       
        txtAddress.Text = "";
        txtAddress.Enabled = false;
      }
      else 
      {
        txtAddress.Enabled = true;
      }
      SetJobLabel();
    }


    private void pnlCosts_Click(object sender, EventArgs e)
    {
      ShowPrices();
    }

    private void lblPricings_Click(object sender, EventArgs e)
    {
      ShowPrices();
    }

    private void ShowPrices()
    {
      pnlCosts.Visible = false;
      timPricings.Enabled = true;
      timPricings.Start();
    }

    private void tsCopy_Click(object sender, EventArgs e)
    {
      bool res = DataAccess.ShowMessage("Are you sure you want to copy this job?", "Copy Job", true);
      if (res)
      {
        DataAccess.DuplicateJob(JobID);
        int iNewJobNo = DataAccess.ExecuteScalarInt("SELECT MAX(JobID) FROM Job");
        DataAccess.ShowMessage("Job copied to JobID: " + iNewJobNo);
        GetJobDetails(iNewJobNo);

      }
    }

    private void cmbGroup_SelectedIndexChanged(object sender, EventArgs e)
    {
      LoadJobTypes();
    }

    private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
    {

    }

    private void tsCancel_Click(object sender, EventArgs e)
    {
      bool res = DataAccess.ShowMessage("Are you sure you want to cancel this Job?", "Cancel Job", true);
      if (res)
      {
        DataAccess.JobCancel(JobID);
        DataAccess.ShowMessage("Job Cancelled");
        this.Close();
      }
      
    }

    private void txtNote2_KeyDown(object sender, KeyEventArgs e)
    {
      txtNote.Text = txtNote2.Text;
    }

    private void txtNote_KeyDown(object sender, KeyEventArgs e)
    {
      txtNote2.Text = txtNote.Text;
    }

      private void dgvItem_CellContentClick(object sender, DataGridViewCellEventArgs e)
    {
      var senderGrid = (DataGridView)sender;

      if (senderGrid.Columns[e.ColumnIndex] is DataGridViewLinkColumn &&
          e.RowIndex >= 0)
      {
        if(dgvItem.CurrentRow.Index > -1)
        {
          if(dgvItem.CurrentCell.ColumnIndex == 9)
          {
            bool result = DataAccess.ShowMessage("Are you sure you want to delete this Item? This action can not be undone.", "Confirm Deletion", true);
            if (result)
            {
              try
              {
                DataAccess.JobItemDelete((int)dgvItem.Rows[dgvItem.CurrentCell.RowIndex].Cells["JobItemID"].Value);
              } 
              catch (Exception ex)
              {
                DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
              }
            }
          }
          else
          {
            FormManagement.ShowDialogForm("MaterialMovement", 1);
          }
        }
        LoadJobItems();
      }
    }

    private void tsLabour_Click_1(object sender, EventArgs e)
    {
      WorkshopLabour workshopfrm;
      if (ws)
      {
        workshopfrm = new WorkshopLabour(JobID, Workshop.StaffID);
      }
      else if (GWMS.StaffID > 0 && GWMS.StaffID != 15)
      {
        workshopfrm = new WorkshopLabour(JobID, GWMS.StaffID);
      }
      else return;

      WorkshopLabour.frm = frm;
      FormManagement.ShowDialogForm(workshopfrm);
      LoadJobLabour();

    }

    private void moveProductToolStripMenuItem_Click(object sender, EventArgs e)
    {

    }

    private void tpItem_Click(object sender, EventArgs e)
    {

    }
  }
}
