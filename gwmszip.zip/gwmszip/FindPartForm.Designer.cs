﻿using System;
using System.IO;
using System.Windows.Forms;

namespace workshop_orders
{
    partial class FindPartForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.partButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.partLabel = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.partCodeText = new System.Windows.Forms.TextBox();
            this.partTypeCombo = new System.Windows.Forms.ComboBox();
            this.altCodeText = new System.Windows.Forms.TextBox();
            this.carModelLabel = new System.Windows.Forms.Label();
            this.regoLabel = new System.Windows.Forms.Label();
            this.regoGridView = new System.Windows.Forms.DataGridView();
            this.modelLabel = new System.Windows.Forms.Label();
            this.modelGridView = new System.Windows.Forms.DataGridView();
            this.searchText = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.nagCodeText = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.stockLabel = new System.Windows.Forms.Label();
            this.typeGridView = new System.Windows.Forms.DataGridView();
            this.typeLabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.descText = new System.Windows.Forms.TextBox();
            this.accessGridView = new System.Windows.Forms.DataGridView();
            this.accessLabel = new System.Windows.Forms.Label();
            this.buyText = new System.Windows.Forms.TextBox();
            this.sellText = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.regoGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.modelGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.accessGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // partButton
            // 
            this.partButton.BackColor = System.Drawing.Color.White;
            this.partButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.partButton.Location = new System.Drawing.Point(11, 13);
            this.partButton.Name = "partButton";
            this.partButton.Size = new System.Drawing.Size(259, 43);
            this.partButton.TabIndex = 6;
            this.partButton.Text = "Add Product to Job";
            this.partButton.UseVisualStyleBackColor = false;
            this.partButton.Click += new System.EventHandler(this.partButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 124);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 20);
            this.label1.TabIndex = 36;
            this.label1.Text = "Type";
            // 
            // partLabel
            // 
            this.partLabel.AutoSize = true;
            this.partLabel.Location = new System.Drawing.Point(389, 158);
            this.partLabel.Name = "partLabel";
            this.partLabel.Size = new System.Drawing.Size(43, 20);
            this.partLabel.TabIndex = 37;
            this.partLabel.Text = "Main";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(770, 158);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 20);
            this.label3.TabIndex = 38;
            this.label3.Text = "NAGS";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(41, 158);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(28, 20);
            this.label4.TabIndex = 39;
            this.label4.Text = "Alt";
            // 
            // partCodeText
            // 
            this.partCodeText.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.partCodeText.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.partCodeText.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.partCodeText.Location = new System.Drawing.Point(462, 155);
            this.partCodeText.MaxLength = 20;
            this.partCodeText.Name = "partCodeText";
            this.partCodeText.Size = new System.Drawing.Size(252, 26);
            this.partCodeText.TabIndex = 3;
            // 
            // partTypeCombo
            // 
            this.partTypeCombo.FormattingEnabled = true;
            this.partTypeCombo.Location = new System.Drawing.Point(101, 121);
            this.partTypeCombo.Name = "partTypeCombo";
            this.partTypeCombo.Size = new System.Drawing.Size(252, 28);
            this.partTypeCombo.TabIndex = 2;
            this.partTypeCombo.TextChanged += new System.EventHandler(this.partTypeCombo_TextChanged);
            this.partTypeCombo.Click += new System.EventHandler(this.partTypeCombo_Click);
            // 
            // altCodeText
            // 
            this.altCodeText.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.altCodeText.Location = new System.Drawing.Point(101, 155);
            this.altCodeText.MaxLength = 6;
            this.altCodeText.Name = "altCodeText";
            this.altCodeText.Size = new System.Drawing.Size(252, 26);
            this.altCodeText.TabIndex = 5;
            // 
            // carModelLabel
            // 
            this.carModelLabel.AutoSize = true;
            this.carModelLabel.Location = new System.Drawing.Point(662, 187);
            this.carModelLabel.Name = "carModelLabel";
            this.carModelLabel.Size = new System.Drawing.Size(33, 20);
            this.carModelLabel.TabIndex = 44;
            this.carModelLabel.Text = "null";
            // 
            // regoLabel
            // 
            this.regoLabel.AutoSize = true;
            this.regoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.regoLabel.Location = new System.Drawing.Point(6, 242);
            this.regoLabel.Name = "regoLabel";
            this.regoLabel.Size = new System.Drawing.Size(530, 25);
            this.regoLabel.TabIndex = 46;
            this.regoLabel.Text = "Products Previously Used With this Registration: ";
            // 
            // regoGridView
            // 
            this.regoGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.regoGridView.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.regoGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.regoGridView.Location = new System.Drawing.Point(11, 272);
            this.regoGridView.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.regoGridView.Name = "regoGridView";
            this.regoGridView.Size = new System.Drawing.Size(1076, 131);
            this.regoGridView.TabIndex = 47;
            // 
            // modelLabel
            // 
            this.modelLabel.AutoSize = true;
            this.modelLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.modelLabel.Location = new System.Drawing.Point(6, 408);
            this.modelLabel.Name = "modelLabel";
            this.modelLabel.Size = new System.Drawing.Size(387, 25);
            this.modelLabel.TabIndex = 48;
            this.modelLabel.Text = "Products used by same Car Model: ";
            this.modelLabel.Click += new System.EventHandler(this.partModelLabel_Click);
            // 
            // modelGridView
            // 
            this.modelGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.modelGridView.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.modelGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.modelGridView.Location = new System.Drawing.Point(11, 438);
            this.modelGridView.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.modelGridView.Name = "modelGridView";
            this.modelGridView.Size = new System.Drawing.Size(1078, 116);
            this.modelGridView.TabIndex = 49;
            // 
            // searchText
            // 
            this.searchText.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.searchText.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.searchText.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.searchText.Location = new System.Drawing.Point(101, 73);
            this.searchText.Name = "searchText";
            this.searchText.Size = new System.Drawing.Size(972, 26);
            this.searchText.TabIndex = 1;
            this.searchText.TextChanged += new System.EventHandler(this.searchText_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(26, 76);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 20);
            this.label6.TabIndex = 51;
            this.label6.Text = "Search";
            // 
            // nagCodeText
            // 
            this.nagCodeText.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.nagCodeText.Location = new System.Drawing.Point(863, 155);
            this.nagCodeText.MaxLength = 20;
            this.nagCodeText.Name = "nagCodeText";
            this.nagCodeText.Size = new System.Drawing.Size(210, 26);
            this.nagCodeText.TabIndex = 4;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(365, 184);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(172, 20);
            this.label7.TabIndex = 53;
            this.label7.Text = "In-Stock (Unallocated):";
            // 
            // stockLabel
            // 
            this.stockLabel.AutoSize = true;
            this.stockLabel.Location = new System.Drawing.Point(554, 193);
            this.stockLabel.Name = "stockLabel";
            this.stockLabel.Size = new System.Drawing.Size(18, 20);
            this.stockLabel.TabIndex = 54;
            this.stockLabel.Text = "0";
            // 
            // typeGridView
            // 
            this.typeGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.typeGridView.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.typeGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.typeGridView.Location = new System.Drawing.Point(13, 589);
            this.typeGridView.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.typeGridView.Name = "typeGridView";
            this.typeGridView.Size = new System.Drawing.Size(1079, 126);
            this.typeGridView.TabIndex = 55;
            // 
            // typeLabel
            // 
            this.typeLabel.AutoSize = true;
            this.typeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.typeLabel.Location = new System.Drawing.Point(8, 559);
            this.typeLabel.Name = "typeLabel";
            this.typeLabel.Size = new System.Drawing.Size(410, 25);
            this.typeLabel.TabIndex = 56;
            this.typeLabel.Text = "Products Used By Same Model Type: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(447, 190);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(209, 20);
            this.label2.TabIndex = 57;
            this.label2.Text = "(Smith and Smith Eurocode)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(238, 193);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(218, 20);
            this.label5.TabIndex = 58;
            this.label5.Text = "(Smith and Smith OBG Code)";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(28, 190);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(46, 20);
            this.label8.TabIndex = 59;
            this.label8.Text = "Desc";
            // 
            // descText
            // 
            this.descText.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.descText.Location = new System.Drawing.Point(101, 187);
            this.descText.MaxLength = 20;
            this.descText.Name = "descText";
            this.descText.Size = new System.Drawing.Size(972, 26);
            this.descText.TabIndex = 60;
            // 
            // accessGridView
            // 
            this.accessGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.accessGridView.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.accessGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.accessGridView.Location = new System.Drawing.Point(1102, 39);
            this.accessGridView.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.accessGridView.Name = "accessGridView";
            this.accessGridView.Size = new System.Drawing.Size(614, 676);
            this.accessGridView.TabIndex = 61;
            // 
            // accessLabel
            // 
            this.accessLabel.AutoSize = true;
            this.accessLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.accessLabel.Location = new System.Drawing.Point(1097, 9);
            this.accessLabel.Name = "accessLabel";
            this.accessLabel.Size = new System.Drawing.Size(147, 25);
            this.accessLabel.TabIndex = 62;
            this.accessLabel.Text = "Accessories:";
            // 
            // buyText
            // 
            this.buyText.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.buyText.Location = new System.Drawing.Point(462, 123);
            this.buyText.MaxLength = 10;
            this.buyText.Name = "buyText";
            this.buyText.Size = new System.Drawing.Size(252, 26);
            this.buyText.TabIndex = 63;
            // 
            // sellText
            // 
            this.sellText.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.sellText.Location = new System.Drawing.Point(863, 124);
            this.sellText.MaxLength = 10;
            this.sellText.Name = "sellText";
            this.sellText.Size = new System.Drawing.Size(210, 26);
            this.sellText.TabIndex = 64;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(389, 126);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(49, 20);
            this.label10.TabIndex = 65;
            this.label10.Text = "Buy $";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(777, 126);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(48, 20);
            this.label11.TabIndex = 66;
            this.label11.Text = "Sell $";
            // 
            // FindPartForm
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1725, 733);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.sellText);
            this.Controls.Add(this.buyText);
            this.Controls.Add(this.accessLabel);
            this.Controls.Add(this.accessGridView);
            this.Controls.Add(this.descText);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.partButton);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.typeLabel);
            this.Controls.Add(this.typeGridView);
            this.Controls.Add(this.stockLabel);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.nagCodeText);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.searchText);
            this.Controls.Add(this.modelGridView);
            this.Controls.Add(this.modelLabel);
            this.Controls.Add(this.regoGridView);
            this.Controls.Add(this.regoLabel);
            this.Controls.Add(this.carModelLabel);
            this.Controls.Add(this.altCodeText);
            this.Controls.Add(this.partTypeCombo);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.partLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.partCodeText);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.MaximizeBox = false;
            this.Name = "FindPartForm";
            this.Text = " ";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Resize += new System.EventHandler(this.ViewJobForm_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.regoGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.modelGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.accessGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Button partButton;
        private Label label1;
        private Label partLabel;
        private Label label3;
        private Label label4;
        private TextBox partCodeText;
        private ComboBox partTypeCombo;
        private TextBox altCodeText;
        private Label carModelLabel;
        private Label regoLabel;
        private DataGridView regoGridView;
        private Label modelLabel;
        private DataGridView modelGridView;
        private TextBox searchText;
        private Label label6;
        private TextBox nagCodeText;
        private Label label7;
        private Label stockLabel;
        private DataGridView typeGridView;
        private Label typeLabel;
        private Label label2;
        private Label label5;
        private Label label8;
        private TextBox descText;
        private DataGridView accessGridView;
        private Label accessLabel;
        private TextBox buyText;
        private TextBox sellText;
        private Label label10;
        private Label label11;
    }
}

