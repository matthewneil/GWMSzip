﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workshop_orders
{
  public partial class ErrorView : Form
  {
    public ErrorView()
    {
      InitializeComponent();
      LoadFilterData();
      LoadErrorData();

      DataAccess.FormState(this.AccessibilityObject.Name, tsDelete);
    }



    public void LoadErrorData()
    {
      try
      {
        DataTable dt = DataAccess.ExecuteDataTable("SELECT * FROM errors " + AddFilters() + " ORDER BY errorID DESC");
        dgvErrors.DataSource = dt;
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(0, ex.Message, this.Name, System.Reflection.MethodBase.GetCurrentMethod().Name, "SELECT * FROM errors;");
      }
    }

    private void tsBack_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private void tsDelete_Click(object sender, EventArgs e)
    {
      for (int i = 0; i < (dgvErrors.SelectedRows.Count); i++)
      {       
        if (dgvErrors.SelectedRows[i].Index > -1)
        {
          DataAccess.ExecuteNonQuery("DELETE FROM errors WHERE ErrorID = " + dgvErrors.SelectedRows[i].Cells["ErrorID"].Value);
        }
      }
      LoadErrorData();
    }

    private void tsRefresh_Click(object sender, EventArgs e)
    {
      LoadErrorData();
    }

    private void LoadFilterData()
    {
      //Code
      try
      {
        DataTable dtCode = DataAccess.ExecuteDataTable("SELECT errCode AS datafield, CAST(errCode AS char(20)) AS textfield FROM errors GROUP BY errCode;");
        DataAccess.AddSelectInt(dtCode);
        cmbCode.DataSource = dtCode;
      } catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name, 
          System.Reflection.MethodBase.GetCurrentMethod().Name, "SELECT errCode AS datafield, CAST(errCode AS char(20)) AS textfield FROM errors GROUP BY errCode;");
      }

      //Module
      try
      {
        DataTable dtModule = DataAccess.ExecuteDataTable("SELECT errModule AS textfield, errModule AS datafield FROM errors GROUP BY errModule;");
        DataAccess.AddSelect(dtModule);
        cmbModule.DataSource = dtModule;
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
        System.Reflection.MethodBase.GetCurrentMethod().Name, "SELECT errModule AS textfield, errModule AS datafield FROM errors GROUP BY errModule;");
      }


      //Staff
      try
      {
        DataTable dtStaff = DataAccess.ExecuteDataTable("SELECT StaffID AS datafield, StaffFullName AS textfield FROM staff WHERE StaffActive = true;");
        DataAccess.AddSelect(dtStaff);
        cmbStaff.DataSource = dtStaff;
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
        System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }

    }

   

    public string AddFilters()
    {
      try
      {
        String sql = "WHERE";
        if (cmbCode.SelectedIndex > 0)
        {
          sql += " errCode = " + cmbCode.SelectedValue.ToString();
        }
        if (cmbModule.SelectedIndex > 0)
        {
          if (sql != "WHERE")
          {
            sql += " AND";
          }
          sql += " errModule = '" + cmbModule.SelectedValue.ToString() + "'";
        }
        if (cmbStaff.SelectedIndex > 0)
        {
          if (sql != "WHERE")
          {
            sql += " AND";
          }
          sql += " StaffUsername = '" + cmbStaff.SelectedValue.ToString() + "'";
        }
        //Dont return sql if there are no filter applied
        if (sql != "WHERE")
        {
          return sql;
        }
        
      } catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name, System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }
      return "";
    }

    private void cmbCode_SelectedIndexChanged(object sender, EventArgs e)
    {
      LoadErrorData();
    }

    private void cmbModule_SelectedIndexChanged(object sender, EventArgs e)
    {
      LoadErrorData();
    }

    private void cmbStaff_SelectedIndexChanged(object sender, EventArgs e)
    {
      LoadErrorData();
    }
  }
}
