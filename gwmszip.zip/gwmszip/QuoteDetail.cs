﻿using System;
using System.Linq;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;
using System.Data;
using System.Drawing.Printing;
using System.Diagnostics;
using Microsoft.Scripting.Interpreter;
using System.Security.Cryptography;
using System.Windows.Forms.DataVisualization.Charting;
using System.Drawing;
using System.Collections.Generic;
using Microsoft.VisualBasic;

namespace workshop_orders
{
  public partial class QuoteDetail : Form
  {
    private int fiQuoteNo;
    private int fiStatusID = 1;
    public static int fiCustomerID;
    private decimal fdQuotePrice;
    public static Quotes frm;
    private string type = "retrofit";

    public QuoteDetail()
    {
      InitializeComponent();
      GetStaff(" OR StaffID = '" + GWMS.StaffID + "'");
      cmbStaff.SelectedValue = GWMS.StaffID;
      pnlHeader.Text = pnlHeader.Text + "NEW";
      lblHeader.Left = GWMS.HeaderPanelPosition(pnlHeader, this);
      //frm = quotes;
      SearchCustomer search = new SearchCustomer(0, 3);
      search.quoteNo = 0;
      FormManagement.ShowDialogForm(search);
      LoadCustomer();
      //Load Default text into quote letter
      LoadDefaultText();
    }
    public QuoteDetail(Quotes quotes)
    {
      InitializeComponent();
      GetStaff(" OR StaffID = '" + GWMS.StaffID + "'");
      cmbStaff.SelectedValue = GWMS.StaffID;
      pnlHeader.Text = pnlHeader.Text + "NEW";
      lblHeader.Left = GWMS.HeaderPanelPosition(pnlHeader, this);
      frm = quotes;
      SearchCustomer search = new SearchCustomer(0, 3);
      search.quoteNo = 0;
      FormManagement.ShowDialogForm(search);
      LoadCustomer();
      //Load Default text into quote letter
      LoadDefaultText();

    }
    public QuoteDetail(int quoteNo, Quotes quotes)
    {
      InitializeComponent();
      this.fiQuoteNo = quoteNo;
      frm = quotes;
      lblHeader.Text = "Quote: " + fiQuoteNo;
      LoadData();
      GetFollowupTypes();
      LoadFollowupCustomer();
      LoadCorrespondence();

      if(type == "retrofit")
      {        
        chDesc.Visible = false;
      }
      else if (type == "Basic Quote")
      {
        chName.Visible = false;
        chFixed.Visible = false;
        chSash.Visible = false;
        chComponent.Visible = false;
      }
    }


    private void QuoteDetail_Load(object sender, EventArgs e)
    {
      pnlHeader.Left = GWMS.HeaderPanelPosition(pnlHeader, this);
      dtpNextFollowup.Value = DateTime.Now.AddDays(14);
      SetButtonState(DataAccess.FormState(this.AccessibilityObject.Name, tsSave));
    }

    private void SetButtonState(Boolean bState)
    {
      tsJob.Enabled = bState;
      tsAddItem.Enabled = bState;
      tsAddInstallation.Enabled = bState;
      tsEdit.Enabled = bState;
      tsFollowupNew.Enabled = bState;
      tsFollowupSave.Enabled = bState;
    }


    public void LoadDefaultText()
    {
      /*
      DataTable dtTerms = DataAccess.ExecuteDataTable("sp_terms");
      try
      {
        foreach (DataRow row in dtTerms.Rows)
        {
          txtQuoteLetter.Text += row["Term"].ToString() + "\n";
        }
        txtQuoteLetter.Text += "\n";
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }*/

      DataTable dtDefaultText = DataAccess.ExecuteDataTable(String.Format("SELECT DefaultText FROM DefaultText WHERE GroupName = '{0}' AND enabled = 1;", cmbType.Text));
      try
      {
        foreach (DataRow row in dtDefaultText.Rows)
        {
          txtQuoteLetter.Text += row["DefaultText"].ToString() + "\n";
        }
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }
    }
    public void LoadData()
    {
      DataTable dt = DataAccess.ExecuteDataTable("SELECT * FROM vwquote WHERE QuoteNo = " + fiQuoteNo);
      try
      {
        if (dt != null && dt.Rows.Count > 0)
        {
          EnableControls();
          //Get Quote Details
          fiCustomerID = int.Parse(dt.Rows[0]["customerID"].ToString());
          fiStatusID = int.Parse(dt.Rows[0]["statusID"].ToString());
          txtCustomer.Text = dt.Rows[0]["CustomerName"].ToString();
          txtReference.Text = dt.Rows[0]["reference"].ToString();
          txtComments.Text = dt.Rows[0]["comments"].ToString();
          type = dt.Rows[0]["quoteType"].ToString();
          cmbType.Text = dt.Rows[0]["quoteType"].ToString();
          dtpQuoted.Value = DateTime.Parse(dt.Rows[0]["dateCreated"].ToString());
          txtDiscount.Text = decimal.Round(decimal.Parse(dt.Rows[0]["discount"].ToString()), 2).ToString();
          txtTotalCost.Text = decimal.Round(decimal.Parse(dt.Rows[0]["CostPrice"].ToString()), 2).ToString("C2");
          fdQuotePrice = decimal.Round(decimal.Parse(dt.Rows[0]["QuotePrice"].ToString()), 2);
          txtQuotePrice.Text = fdQuotePrice.ToString("C2");
          txtMarginCost.Text = decimal.Round(decimal.Parse(dt.Rows[0]["Margin"].ToString()), 2).ToString("C2");
          txtMarginPercent.Text = decimal.Round(decimal.Parse(dt.Rows[0]["MarginP"].ToString()), 2).ToString("P2");
          lblStatus.Text = dt.Rows[0]["StatusName"].ToString();
          nudWorkers.Value = decimal.Parse(dt.Rows[0]["workersNo"].ToString());
          nudDistance.Value = decimal.Parse(dt.Rows[0]["distance"].ToString());
          nudWorkDays.Value = decimal.Parse(dt.Rows[0]["workDays"].ToString());
          nudHoursPerDay.Value = decimal.Parse(dt.Rows[0]["hoursPerDay"].ToString());
          txtQuoteLetter.Text = dt.Rows[0]["QuoteLetterText"].ToString();

          if (fiStatusID == 2)  //Accepted Quotes
          {
            gbOther.Visible = true;
            txtAcceptedDate.Text = DateTime.Parse(dt.Rows[0]["dateAccepted"].ToString()).ToString("dd/MM/yyyy");
            txtAcceptedPrice.Text = decimal.Round(decimal.Parse(dt.Rows[0]["QuotePrice"].ToString()), 2).ToString("C2");
          }
          try
          {
            //Get Staff Details
            GetStaff(" OR StaffID = '" + dt.Rows[0]["StaffID"].ToString() + "'");
            cmbStaff.SelectedValue = dt.Rows[0]["StaffID"].ToString();
          }
          catch { }
          //Get Quote Item Details
          LoadItemData();
          SetStatus((int)dt.Rows[0]["statusID"], false);
        }
      }
      catch (Exception ex)
      {
        MessageBox.Show("There was an error loading Quote Data");
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                  System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }
    }
    public void GetStaff(string sFilter = "")
    {
      DataTable dt = DataAccess.ExecuteDataTable("SELECT StaffID as datafield, StaffFullName as textfield FROM staff WHERE StaffActive = 1 " + sFilter + " ORDER BY StaffFullName");
      cmbStaff.DataSource = dt;
    }
    public void LoadItemData()
    {
      try
      {
        dgvProduct.AutoGenerateColumns = false;
        DataTable dt = DataAccess.ExecuteDataTable(String.Format("SELECT QuoteItemGroupID, GroupName, FixedGlass, SashGlass, Components, CostPrice, QuotePrice, description FROM vwquoteitemgroup WHERE QuoteNo = {0};", fiQuoteNo));
        dgvProduct.DataSource = dt;
      }
      catch (Exception ex)
      {
        MessageBox.Show("Failed to load Item Data for this Quote.");
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }
    }
    private void EnableControls()
    {
      tsAddItem.Enabled = true;
      tsAddInstallation.Enabled = true;
      tsEdit.Enabled = true;
      tsPrint.Enabled = true;
      tsStatus.Enabled = true;
      tsReports.Enabled = true;
      btnTravel.Enabled = true;
      tsJob.Enabled = true;
    }
    private void LoadCustomer()
    {
      if (fiCustomerID == 0)
      {
        txtCustomer.Text = "";
      }
      else
      {
        txtCustomer.Text = DataAccess.ExecuteScalarString(String.Format("SELECT CustomerName FROM Customer WHERE CustomerID = {0};", fiCustomerID));
      }
    }
    //private void SearchCustomer(int highestCustomer)
    //{
    //    //HighestCustomer = 0;
    //    try
    //    {
    //        using (MySqlConnection conn = GWMS.ConnectSQLBMS())
    //        {
    //            conn.Open();
    //            String sql = String.Format(
    //                "SELECT cID, cFirstName, cSurname, cCompany FROM Customer WHERE cID > {0};", highestCustomer);

    //            MySqlCommand cmd = new MySqlCommand(sql, conn);

    //            MySqlDataReader rdr = cmd.ExecuteReader();

    //            //MySqlDataReader cmd2 = cmd.ExecuteReader();

    //            while (rdr.Read())
    //            {
    //                //MessageBox.Show(rdr["cID"].ToString());
    //                txtCustomer.AutoCompleteCustomSource.Add((rdr["cFirstName"].ToString() + " " + rdr["cSurname"].ToString()) + " (" + rdr["cID"].ToString() + ")");
    //                txtCustomer.AutoCompleteCustomSource.Add((rdr["cSurname"].ToString() + " " + rdr["cFirstName"].ToString()) + " (" + rdr["cID"].ToString() + ")");
    //                txtCustomer.AutoCompleteCustomSource.Add((rdr["cCompany"].ToString())+ " (" + (rdr["cFirstName"].ToString() + ")") + " (" + rdr["cID"].ToString() + ")");
    //            }
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,System.Reflection.MethodBase.GetCurrentMethod().Name, "");
    //    }
    //}
    public void RefreshCustomers()
    {
      LoadCustomer();
    }
    private void AddCustomerButton_Click(object sender, EventArgs e)
    {
      SearchCustomer form = new SearchCustomer(fiCustomerID, 3);
      form.quoteNo = fiQuoteNo;
      FormManagement.ShowDialogForm(form);
      LoadCustomer();
    }
    private void printToolStripMenuItem_Click(object sender, EventArgs e)
    {
      /*
      try
      {
        using (MySqlConnection conn = GWMS.connectMySql())
        {
          conn.Open();

          String QuoteHeader = File.ReadAllText("//database/GWGFiles/BMS/Reports/Quotes/QuoteHeader.html");
          String QuoteProductHeader = File.ReadAllText("//database/GWGFiles/BMS/Reports/Quotes/QuoteProductHeader.html");
          String QuoteProduct = File.ReadAllText("//database/GWGFiles/BMS/Reports/Quotes/QuoteProduct.html");
          String QuoteFooter = File.ReadAllText("//database/GWGFiles/BMS/Reports/Quotes/QuoteFooter.html");

          String Quote = "";
          String sql = String.Format(
              "SELECT * FROM vwquote WHERE QuoteNo = {0};", fiQuoteNo);

          MySqlCommand cmd = new MySqlCommand(sql, conn);
          MySqlDataReader rdr = cmd.ExecuteReader();

          while (rdr.Read())
          {
            Quote = String.Format(QuoteHeader, fiQuoteNo, rdr["jobName"].ToString(), "", "", "",
                LoadCustomer(fiCustomerID, "cFirstName") + " " + LoadCustomer(fiCustomerID, "cSurname"), LoadCustomer(fiCustomerID, "cPhone"),
                LoadCustomer(fiCustomerID, "cAddress") + " " + LoadCustomer(fiCustomerID, "cCity"), LoadCustomer(fiCustomerID, "cCompany"));
          }
          conn.Close();
          conn.Open();
          sql = String.Format(
              "SELECT * FROM QuoteItems WHERE QuoteNo = {0} " +
              "AND width IS NOT NULL AND height IS NOT NULL " +
              "GROUP BY itemGroup;", fiQuoteNo);

          cmd = new MySqlCommand(sql, conn);
          rdr = cmd.ExecuteReader();

          while (rdr.Read())
          {
            Quote += String.Format(QuoteProductHeader, rdr["itemGroup"].ToString(), rdr["height"].ToString(), rdr["width"].ToString());

            String sql2 = String.Format(
                "SELECT * FROM QuoteItems " +
                "INNER JOIN GlassItems ON itemName = GlassItems.type WHERE QuoteItems.QuoteNo = {0} AND itemGroup = '{1}';",
                fiQuoteNo, rdr["itemGroup"].ToString());

            using (MySqlConnection conn2 = GWMS.connectMySql())
            {
              conn2.Open();
              MySqlCommand cmd2 = new MySqlCommand(sql2, conn2);
              MySqlDataReader rdr2 = cmd2.ExecuteReader();
              while (rdr2.Read())
              {
                Quote += String.Format(QuoteProduct, rdr2["groupName"].ToString(), rdr2["itemName"].ToString(),
                   rdr2["cost"].ToString(), rdr2["size"].ToString(),
                   decimal.Parse(rdr2["cost"].ToString()) * decimal.Parse(rdr2["size"].ToString()));
              }
            }
          }
          File.WriteAllText("//database/GWGFiles/BMS/Reports/Quotes/Quote.html", Quote);
          Process.Start("chrome.exe", @"\\database\GWGFiles\BMS\Reports\Quotes\Quote.html");
        }
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
            System.Reflection.MethodBase.GetCurrentMethod().Name, "");
      }
      string QuoteTemplateUrl = @"C:\Users\Public\BMSLocalFiles\Reports\Quote\Quote.html";
      QuoteTemplateUrl = String.Format(QuoteTemplateUrl, fiQuoteNo, LoadCustomer(fiCustomerID, "cFirstName"), LoadCustomer(fiCustomerID, "cSurname"), LoadCustomer(fiCustomerID, "cPhone"));
      **/
    }

  
    private void tsSave_Click(object sender, EventArgs e)
    {
      SaveQuote();

    }
    private bool SaveQuote(bool bShowMessage = true)
    {

      if (!DataAccess.IsNumeric(txtDiscount.Text.Replace("$", ""))) { txtDiscount.Text = "0.00"; }
      if (DataAccess.QuoteManage(fiQuoteNo, "retrofit", txtReference.Text, (decimal)fiCustomerID, (int)cmbStaff.SelectedValue, (int)nudWorkers.Value, (int)nudDistance.Value,
                              nudWorkDays.Value, nudHoursPerDay.Value, fiStatusID, txtComments.Text, decimal.Parse(txtDiscount.Text.Replace("$", "")), txtQuoteLetter.Text) == true)
      {
        if (fiQuoteNo == 0)
        {
          fiQuoteNo = DataAccess.ExecuteScalarInt("SELECT MAX(quoteno) FROM quote WHERE staffID = '" + cmbStaff.SelectedValue.ToString() + "'");
          LoadData();
        }
        EnableControls();
        if (bShowMessage == true) { MessageBox.Show("Quote saved successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information); }
        return true;
      }
      else
      {
        if (bShowMessage == true) { MessageBox.Show("Failed to save the quote details", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        return false;
      }
    }

    private void tsBack_Click(object sender, EventArgs e)
    {
      if (frm != null) { frm.LoadQuotes(); }
      this.Close();
    }

    private void tsAdd_Click(object sender, EventArgs e)
    {
      
    }
    private void CostsDataGrid_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      EditItem();
    }
    private void tbEdit_Click(object sender, EventArgs e)
    {
      
    }
    private void EditItem()
    {
      if (fiQuoteNo > 0 && dgvProduct.SelectedRows.Count > 0 && dgvProduct.SelectedRows[0].Index > -1)
      {
        if(dgvProduct.SelectedRows[0].Cells["chName"].Value.ToString() == "Basic Quote")
        {
          BasicQuote frm = new BasicQuote(fiQuoteNo, (int)dgvProduct.SelectedRows[0].Cells["chID"].Value, 1);
          FormManagement.ShowDialogForm(frm);
        }
        else if(dgvProduct.SelectedRows[0].Cells["chName"].Value.ToString() == "Installation")
        {
          BasicQuote frm = new BasicQuote(fiQuoteNo, (int)dgvProduct.SelectedRows[0].Cells["chID"].Value, 2);
          FormManagement.ShowDialogForm(frm);
        } 
        else
        {
          Retrofit frm = new Retrofit(fiQuoteNo, (int)dgvProduct.SelectedRows[0].Cells["chID"].Value, this);
          frm.tslName.Text = dgvProduct.SelectedRows[0].Cells["chName"].Value.ToString();
          FormManagement.ShowDialogForm(frm);
        }
      }
      LoadItemData();
    }

    private void tsItemPrint_Click(object sender, EventArgs e)
    {
      ReportView frm = new ReportView("SELECT * FROM vwquotesummary WHERE quoteno = " + fiQuoteNo, "quote.rdlc");
      FormManagement.ShowDialogForm(frm);
    }

    private void tsSummaryPrint_Click(object sender, EventArgs e)
    {
      ReportView frm = new ReportView("SELECT * FROM vwquotesummary WHERE quoteno = " + fiQuoteNo, "quotesummary.rdlc");
      FormManagement.ShowDialogForm(frm);
    }

    private void tsComponents_Click(object sender, EventArgs e)
    {
      ReportView frm = new ReportView("SELECT * FROM vwcomponent WHERE quoteno = " + fiQuoteNo, "Components.rdlc");
      FormManagement.ShowDialogForm(frm);
    }

    private void txtDiscount_Leave(object sender, EventArgs e)
    {
      CalculateDiscount();
    }
    private void txtDiscount_KeyDown(object sender, KeyEventArgs e)
    {
      if (e.KeyCode == Keys.Enter)
      {
        txtReference.Focus();
      }
    }
    private void CalculateDiscount()
    {
      if (DataAccess.IsNumeric(txtDiscount.Text.Replace("$", "")) == true)
      {
        decimal dQuotePrice = fdQuotePrice;
        decimal dDiscount = decimal.Parse(txtDiscount.Text.Replace("$", ""));
        decimal dCostPrice = decimal.Parse(txtTotalCost.Text.Replace("$", ""));
        if (dDiscount > dQuotePrice)
        {
          MessageBox.Show("The Discount can not be greater that the Quote Price ", "Invalid Discount Value", MessageBoxButtons.OK);
          txtDiscount.Text = "$0.00";
          return;
        }
        txtQuotePrice.Text = (dQuotePrice - dDiscount).ToString("C2");
        txtDiscount.Text = decimal.Parse(txtDiscount.Text.Replace("$", "")).ToString("C2");
        dQuotePrice -= dDiscount;
        txtMarginCost.Text = (dQuotePrice - dCostPrice).ToString("C2");
        txtMarginPercent.Text = (1 - (dCostPrice / dQuotePrice)).ToString("P2");
        txtReference.Focus();
      }
      else
      {
        MessageBox.Show("Please enter a numeric discount value", "Invaild Value", MessageBoxButtons.OK);
        txtDiscount.Text = "$0.00";
      }
    }

    private void tsCancelled_Click(object sender, EventArgs e)
    {
      SetStatus(4);
    }
    private void tsAccepted_Click(object sender, EventArgs e)
    {
      SetStatus(2);
    }
    private void tsLost_Click(object sender, EventArgs e)
    {
      SetStatus(3);
    }
    private void tsClosed_Click(object sender, EventArgs e)
    {
      SetStatus(5);
    }
    private void SetStatus(int iStatus, bool bUpdate = true)
    {
      if (bUpdate == true)
      {
        DialogResult dr = MessageBox.Show("Are you sure you want to change the status of this quote?", "Confirm Change", MessageBoxButtons.YesNo);
        if (dr == DialogResult.Yes)
        {
          if (fiQuoteNo == 0) //Check if this is a new quote
          {
            if (SaveQuote(false) == false)
            {
              MessageBox.Show("Please save the quote before changing status", "Save", MessageBoxButtons.OK, MessageBoxIcon.Information);
              return;
            }
          }
          DataAccess.ExecuteNonQuery("UPDATE quote SET statusID = " + iStatus + ", dateModified = '" + DateTime.Now.ToString("yyyy-MM-dd") + "' WHERE quoteno = " + fiQuoteNo);
          if (iStatus == 2)
          {
            DataAccess.ExecuteNonQuery("UPDATE quote SET acceptedPrice = " + decimal.Parse(txtQuotePrice.Text.Replace("$", "")) + ", dateAccepted = '" + DateTime.Now.ToString("yyyy-MM-dd") + "' WHERE quoteno = " + fiQuoteNo);
            txtAcceptedDate.Text = DateTime.Now.ToString("dd/MM/yyyy");
            txtAcceptedPrice.Text = txtQuotePrice.Text;
          }
        }
      }
      lblStatus.ForeColor = Color.Black;
      fiStatusID = iStatus;
      gbOther.Visible = false;
      switch (iStatus)
      {
        case 1:
          lblStatus.ForeColor = Color.Blue;
          break;
        case 2:
          gbOther.Visible = true;
          lblStatus.ForeColor = Color.Green;
          lblStatus.Text = "Accepted";
          break;
        case 3:
          lblStatus.ForeColor = Color.Red;
          lblStatus.Text = "Lost";
          break;
        case 4:
          lblStatus.ForeColor = Color.Purple;
          lblStatus.Text = "Cancelled";
          break;
        case 5:
          lblStatus.Text = "Closed";
          break;
      }
    }

    private void btnTravel_Click(object sender, EventArgs e)
    {
      if(nudDistance.Value <= 0)
      {
        DataAccess.ShowMessage("Distance needs to be above 0 before it can be added to quote.");
        return;
      }
      //Delete any existing travel costs
      DataAccess.ExecuteNonQuery("DELETE FROM quoteitemgroup WHERE quoteno = " + fiQuoteNo + " AND GroupName = 'Travel Costs'");
      DataAccess.ExecuteNonQuery("DELETE FROM quoteitems WHERE quoteno = " + fiQuoteNo + " AND itemCostID IN  (SELECT itemCostID FROM itemcost WHERE ItemGroupID = 50)");
      //Create a new travel cost group
      DataAccess.ExecuteNonQuery("INSERT INTO quoteitemgroup (quoteno, GroupName) VALUES (" + fiQuoteNo + ", 'Travel Costs')");
      int iGroupID = DataAccess.ExecuteScalarInt("SELECT MAX(quoteitemgroupID)FROM quoteitemgroup WHERE quoteno = " + fiQuoteNo + " AND GroupName = 'Travel Costs'");
      if (iGroupID > 0)
      {
        //Get the next itemid
        int iLinkID = DataAccess.ExecuteScalarInt("SELECT MAX(quoteitemID) FROM quoteitems") + 1;
        DataTable dt = DataAccess.ExecuteDataTable("SELECT * FROM itemcost WHERE ItemGroupID = 50");
        if (dt != null && dt.Rows.Count > 0)
        {
          foreach (DataRow row in dt.Rows)
          {
            DataAccess.QuoteItemManage(fiQuoteNo, 0, (int)row["ItemCostID"], GetTravelQuantity(row["icCode"].ToString()), 0, 0, 0,
                                      (decimal)row["icCost"], (decimal)row["icPrice"], iGroupID, iLinkID, "Travel", "");
          }
        }
        LoadItemData();
      }
      else
      {
        MessageBox.Show("An error occured while creating the travel costs. Please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
      }
    }
    private decimal GetTravelQuantity(string sCode)
    {
      switch (sCode)
      {
        case "KMRATE":    //Milage
          return nudDistance.Value * nudWorkDays.Value * 2;
        case "HRRATE":    //Worker cost
          return (nudDistance.Value * nudWorkDays.Value * nudWorkers.Value * 2) / 60;   //Calculate total distance travelled then divide by average 60 km/h to get approx worker time
        default:
          return 0;
      }
    }

    private void tsComponents_Click_1(object sender, EventArgs e)
    {
      ReportView frm = new ReportView("SELECT * FROM vwcomponent WHERE quoteno = " + fiQuoteNo, "Components.rdlc");
      FormManagement.ShowDialogForm(frm);
    }

    private void tsItemList_Click(object sender, EventArgs e)
    {
      ReportView frm = new ReportView("SELECT * FROM vwquoteitem WHERE quoteno = " + fiQuoteNo, "itemlist.rdlc");
      FormManagement.ShowDialogForm(frm);
    }

    private void txtCustomer_TextChanged(object sender, EventArgs e)
    {

    }

    private void dgvProduct_CellContentClick(object sender, DataGridViewCellEventArgs e)
    {
      var senderGrid = (DataGridView)sender;

      if (senderGrid.Columns[e.ColumnIndex] is DataGridViewButtonColumn &&
          e.RowIndex >= 0)
      {
        if (dgvProduct.SelectedRows.Count > 0 && dgvProduct.SelectedRows[0].Index > -1)
        {
          bool result = DataAccess.ShowMessage("Are you sure you want to delete this Item? This action can not be undone.", "Confirm Deletion", true);
          if (result)
          {
            DataAccess.ExecuteNonQuery("DELETE FROM quoteitems WHERE quoteitemGroupID = " + dgvProduct.SelectedRows[0].Cells["chID"].Value);
            DataAccess.ExecuteNonQuery("DELETE FROM quoteitemgroup WHERE quoteitemGroupID = " + dgvProduct.SelectedRows[0].Cells["chID"].Value);
          }
        }
        LoadItemData();
      }
    }

    private void tpContact_Click(object sender, EventArgs e)
    {

    }

    private void GetFollowupTypes()
    {
      DataTable dt = DataAccess.ExecuteDataTable("SELECT CorrespondenceTypeID as datafield, ctName as textfield FROM correspondencetype");
      cmbFollowupType.DataSource = dt;
    }

    private void LoadFollowupCustomer()
    {
      if (fiCustomerID == 0)
      {
        cmbFollowupPerson.Text = "";
      }
      else
      {
        cmbFollowupPerson.Text = DataAccess.ExecuteScalarString(String.Format("SELECT CustomerName FROM Customer WHERE cID = {0};", fiCustomerID));
      }
    }

    private void LoadCorrespondence()
    {
      DataTable dt = DataAccess.ExecuteDataTable(String.Format("SELECT c.qcDate, c.qcDescription, t.ctName FROM quotecorrespondence c " +
        "INNER JOIN correspondencetype t ON c.CorrespondenceTypeID = t.CorrespondenceTypeID WHERE QuoteNo = {0};", fiQuoteNo));
      dgvFollowup.DataSource = dt;
    }

    private void tsFollowupSave_Click(object sender, EventArgs e)
    {
      DataAccess.QuoteCorrespondenceManage(0, fiQuoteNo, (int)cmbFollowupType.SelectedValue, DateTime.Now, dtpNextFollowup.Value, txtDescription.Text, "", 0, 0, GWMS.StaffID, DateTime.Now, "", 0);
      LoadCorrespondence();
      ResetFollowupFields();
      pnlFollowupDetails.Enabled = false;
    }

    private void ResetFollowupFields()
    {
      cmbFollowupType.SelectedIndex = 0;
      txtDescription.Text = "";
    }

    private void tsFollowupNew_Click(object sender, EventArgs e)
    {
      ResetFollowupFields();
      pnlFollowupDetails.Enabled = true;
    }

    private void dtpNextFollowup_ValueChanged(object sender, EventArgs e)
    {

    }

    private void tsCutlist_Click(object sender, EventArgs e)
    {
      ReportView frm = new ReportView(String.Format("SELECT * FROM vwquoteitem WHERE quoteno = {0}", fiQuoteNo), "cutlist.rdlc");
      FormManagement.ShowDialogForm(frm);
    }

    private void tsJob_Click(object sender, EventArgs e)
    {
      JobNew frm = new JobNew(fiQuoteNo);
      FormManagement.ShowDialogForm(frm);
    }

    private void tsAddItem_Click(object sender, EventArgs e)
    {
      if (fiQuoteNo == 0) //Check if this is a new quote
      {
        if (SaveQuote(false) == false)
        {
          MessageBox.Show("Please save the quote before adding items", "Save", MessageBoxButtons.OK, MessageBoxIcon.Information);
          return;
        }
      }
      if(type == "Retrofit")
      {
        String resultName = Interaction.InputBox("Please enter name for this item.", "Item Name");
        if (resultName != "")
        {
          DataAccess.ExecuteNonQuery("INSERT INTO quoteItemGroup (quoteNo, groupName) VALUES(" + fiQuoteNo + ", '" + resultName + "')");
          int groupID = DataAccess.ExecuteScalarInt("SELECT MAX(quoteitemgroupID) FROM quoteitemgroup WHERE quoteNo = " + fiQuoteNo);
          LoadItemData();
          Retrofit frm = new Retrofit(fiQuoteNo, groupID, this);
          frm.tslName.Text = resultName;
          FormManagement.ShowDialogForm(frm);
        }
      }
      else if (type == "Basic Quote")
      {
        FormManagement.ShowDialogForm(new BasicQuote(fiQuoteNo, 0, 1));
      }
      LoadItemData();
    }

    private void tsEdit_Click(object sender, EventArgs e)
    {
      EditItem();
    }

    private void tsAddInstallation_Click(object sender, EventArgs e)
    {
      BasicQuote frm = new BasicQuote(fiQuoteNo, 0, 2);
      FormManagement.ShowDialogForm(frm);
      LoadItemData();
    }
  }
}
