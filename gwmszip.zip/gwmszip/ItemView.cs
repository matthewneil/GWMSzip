﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workshop_orders
{
  public partial class ItemView : Form
  {
    public ItemView()
    {
      InitializeComponent();

      LoadData();
		}

    private void LoadData()
    {
      try
      {
        DataTable dt = DataAccess.ExecuteDataTable("SELECT * FROM itemcost;");

        dgvItems.DataSource = dt;
      }
      catch (Exception ex)
      {
        DataAccess.ErrorManage(System.Runtime.InteropServices.Marshal.GetExceptionCode(), ex.Message, this.Name,
          System.Reflection.MethodBase.GetCurrentMethod().Name, "SELECT * FROM itemcost;");
      }
    }

    private void cmbStatus_SelectedIndexChanged(object sender, EventArgs e)
    {
      LoadData();
    }


    private void tbClose_Click(object sender, EventArgs e)
    {
			this.Close();
    }

    private void dgvItems_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      EditItem();
    }

    private void EditItem()
    {
      if (dgvItems.SelectedRows.Count > 0 && dgvItems.SelectedRows[0].Index > -1)
      {
        //FormManagement.ShowChildForm(new ItemEdit((int)dgvItems.SelectedRows[0].Cells[0].Value));
        ItemEdit frm = new ItemEdit((int)dgvItems.SelectedRows[0].Cells[0].Value);
        FormManagement.ShowDialogForm(frm);
      }
    }

    private void tsNew_Click(object sender, EventArgs e)
    {
      ItemEdit frm = new ItemEdit(0);
      FormManagement.ShowDialogForm(frm);
    }

    private void tsRefresh_Click(object sender, EventArgs e)
    {
      LoadData();
    }

    private void tsEdit_Click(object sender, EventArgs e)
    {
      if (dgvItems.SelectedRows.Count > 0 && dgvItems.SelectedRows[0].Index > -1)
      {
        ItemEdit frm = new ItemEdit((int)dgvItems.SelectedRows[0].Cells[0].Value);
        FormManagement.ShowDialogForm(frm);
      }
    }

    private void btnCode_Click(object sender, EventArgs e)
    {
      FindItem();
    }
    private void FindItem()
    {
      if (txtCode.Text != "")
      {
        DataTable dt = DataAccess.ExecuteDataTable("SELECT * FROM itemcost WHERE icCode = '" + txtCode.Text + "'");
        if (dt != null && dt.Rows.Count > 0)
        {
          ItemEdit frm = new ItemEdit(int.Parse(dt.Rows[0]["ItemCostID"].ToString()));
          FormManagement.ShowDialogForm(frm);
          return;
        }
      }
      MessageBox.Show("Please enter a valid Item Code", "Invalid Item Code", MessageBoxButtons.OK);
    }

    
  }
}
